<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;

// use View;
// use App\Models\Restaurant;
// use Illuminate\Support\Facades\Auth;
  
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();

        // View::composer('*', function($view)
        // {  $restaurants = Restaurant::where('user_id',Auth::user()->id)->get();
        //     $view->with('restaurants', $restaurants);
        // });


    }
}
