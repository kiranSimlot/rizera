<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RestaurantFloor extends Model
{
    use HasFactory;

    protected $fillable = ['name'];

    public function getOrder(){
        return $this->belongsTo(Order::class, 'restaurant_id', 'restaurant_id');
    }
}
