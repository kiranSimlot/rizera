<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserFoodIntolerance extends Model
{
    use HasFactory;

     protected $table = 'users_food_intolerance';

     protected $guarded = ['id'];
}
