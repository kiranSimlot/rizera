<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RestaurantFacility extends Model
{
    use HasFactory;
    public function Restfacility(){
        return $this->belongsTo(Restaurant::class,'id');
    }
    public function Facilities(){
        return $this->belongsTo(Facility::class,'facility_id');
    }
    
}
