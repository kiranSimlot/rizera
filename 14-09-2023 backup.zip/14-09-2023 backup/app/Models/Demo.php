<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Demo extends Model
{
    use HasFactory;
    protected $table = 'demos';
        protected $fillable = ['id','first_name','last_name','country_code','mobile_no','email','restaurant_name'];
}
