<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Item extends Model
{
    use HasFactory;
    
	
    protected $table = 'items';


    public function category()
    {
        return $this->belongsTo(MenuCategory::class);
    }
    public function itemImages()
    {
        return $this->hasMany(ItemImage::class, 'item_id');
    }
    public function itemImage()
    {
        return $this->hasOne(ItemImage::class, 'item_id');
    }
    public function itemPrice()
    {
        return $this->hasMany(ItemPrice::class, 'item_id');
    }
    public function cartItem()
    {
        return $this->hasOne(AddToCart::class, 'item_id');
    }
}
