<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCuisineType extends Model
{
    use HasFactory;

     protected $table = 'users_cuisine_types';

     protected $guarded = ['id'];
}
