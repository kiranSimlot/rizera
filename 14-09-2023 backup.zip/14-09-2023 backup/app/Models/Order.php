<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'restaurant_id',
        'table_no',
        'floor_no',
        'name',
        'mobile_no',
        'email_id',
        'order_no',
        'total_amount',
        'discount_amt',
        'billing_status',
    ];


}
