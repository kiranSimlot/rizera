<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RestaurantCuisineType extends Model
{
    use HasFactory;
    public function restaurantcuisine(){
        return $this->belongsTo(Restaurant::class,'id');
    }
    public function Cuisine(){
        return $this->belongsTo(CuisineType::class,'cuisine_type_id');
    }
}
