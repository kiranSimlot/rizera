<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    // protected $fillable = ['name'];
    protected $guarded = ['id'];

    public function getUser()
    {
        return $this->belongsTo(User::class,'user_id');
    }

    public function getRestaurant()
    {
        return $this->belongsTo(Restaurant::class,'restaurant_id');
    }

    public function getCategory()
    {
        return $this->belongsTo(Category::class,'category_id');
    }

    public function getRestaurantFloor(){
        return $this->hasOne(RestaurantFloor::class);
    }

}
