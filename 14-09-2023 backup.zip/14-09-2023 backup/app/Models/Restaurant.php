<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    use HasFactory;

	public function getCountry(){
		return $this->belongsTo(Country::Class,'country_id');
	}

	public function getCity(){
		return $this->belongsTo(City::class,'city_id');

	}

	public function getOwner(){
		return $this->belongsTo(User::class,'user_id');

	}

	public function getFacilities(){
		return $this->hasMany(RestaurantFacility::class,'restaurant_id');
	}
	public function getCuisine(){
		return $this->hasMany(RestaurantCuisineType::class,'restaurant_id');
	}
	public function getHour(){
		return $this->hasOne(WeeklyHour::class);
	}

	public static function active(){
        return Restaurant::where('status',1);
    }

    public function getImages(){
		return $this->hasMany(RestaurantImage::class,'restaurant_id')->where('doc_for',1);
	}

    public function getWebImages(){
		return $this->hasMany(RestaurantImage::class,'restaurant_id');
	}

	public function getItemList(){
		return $this->hasMany(Item::class,'resturant_id');
	}

    public function verificationUpdate(){
    $this->verified = ($this->verified==0?0:1);
    }

}

