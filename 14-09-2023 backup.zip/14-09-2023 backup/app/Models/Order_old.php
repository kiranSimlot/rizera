<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'price',
        'quantity',
        'item_id',
        'table_id',
        'resturant_id',
        'order_id',
        'staff_id',
    ];

    public function getOrderItems(){
        return $this->belongsTo(Item::class, 'item_id', 'id');
    }
    public function getrestaurant(){
        return $this->belongsTo(Restaurant::class, 'resturant_id', 'id');
    }
    public function getTotal()
    {
        return $this->orders->sum(function ($orders) {
            return $orders->price * $orders->quantity;
        });
    }
   
}
