<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffPermission extends Model
{
     use HasFactory;
  protected $fillable = ['id','staff_id','permission_module','status'];
     /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'staff_permission_module';
}
