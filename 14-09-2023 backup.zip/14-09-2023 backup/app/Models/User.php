<?php
namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Database\Eloquent\Model;



class User extends Authenticatable implements JWTSubject
{
    use HasFactory, Notifiable;
 
    // protected $fillable = [
    //     'name',
    //     'email',
    //     'password',
    // ];

    protected $guarded = [
        'id'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];
 
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function scopeVerified(){
        return $this->where('type',2)->where('status','!=',0);
    }
    public function emailVerified(){
        $this->remember_token = null;
        $this->status = 1;
        $this->email_verified_at = date('Y-m-d h:i:s');
        return $this->save();
    }
    public function scopeCheckToken($token){
        return $this->where('remember_token',$token);
    }
    public function scopeDestroyIt(){
        $this->status = 0;
        return $this->save();
    }
    public function statusUpdate(){
        $this->status = ($this->status==2?1:2);       
    }

   public function getJWTIdentifier()
    {
        return $this->getKey();
    } 
    public function getJWTCustomClaims()
    {
        return [];
    } 
}