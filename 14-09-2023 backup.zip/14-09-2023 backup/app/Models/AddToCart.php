<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddToCart extends Model
{
    use HasFactory;

    protected $fillable = [
        'amount',
        'item_id',
        'table_no',
        'quantity',
        'restaurant_id',
        'order_id',
        'quantity_in_variation',
        'notes',
        'staff_id',
        'status',
    ];
    public function getOrderItems(){
        return $this->belongsTo(Item::class, 'item_id', 'id');
    }
    public function getOrder(){
        return $this->belongsTo(Order::class, 'order_id', 'id');
    }
    public function getrestaurant(){
        return $this->belongsTo(Restaurant::class, 'resturant_id', 'id');
    }

}