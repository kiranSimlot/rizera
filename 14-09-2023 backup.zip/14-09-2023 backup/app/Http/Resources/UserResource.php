<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\Booking;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'name'=>$this->name,
            'email'=>is_null($this->email) ? '' : $this->email,
            'provider'=>$this->provider,
            'email_verified_at'=>is_null($this->email_verified_at) ? '' : $this->email_verified_at,
            'mobile'=>is_null($this->mobile) ? '' : $this->mobile,
            'mobile_verified_at'=>is_null($this->mobile_verified_at) ? '' : $this->mobile_verified_at,
            'first_name'=>$this->first_name,
            'last_name'=>$this->last_name,
            'country_id'=>$this->country_id,
            'restaurant_id'=>$this->restaurant_id??"",
            'lang_id'=>$this->lang_id,
            'image'=>asset('storage').'/'.$this->image,
            'reservations_count'=>Booking::where('user_id',$this->id)->count(),
            // 'reservations_count'=>Booking::where('user_id',$this->id)->whereIn('status',[0,1])->count(),
            'jwt_token'=>is_null($this->jwt_token) ? '' : $this->jwt_token
        ];
    }
}
