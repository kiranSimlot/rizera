<?php

namespace App\Http\Resources;

use App\Models\Wishlist;
use App\Models\WeeklyHour;
use App\Models\Restaurant;
use App\Models\CuisineType;
use App\Models\RestaurantHoliday;
use App\Models\RestaurantCuisineType;
use Illuminate\Http\Resources\Json\JsonResource;

class RestaurantListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) 
    {
        $wishlist = Wishlist::where('restaurant_id',$this->id)->where('user_id',auth()->user()->id)->first(); 
         $restaurantFacilitiesData = RestaurantCuisineType::where('restaurant_id',$this->id)->first();
 
        if (!empty($restaurantFacilitiesData)) {
        $cuisine_type_data = CuisineType::where('id',$restaurantFacilitiesData->cuisine_type_id)->first();

        $this->cuisine_type = $cuisine_type_data->name;
        if (!empty($cuisine_type_data)) { 
        if (auth()->user()->lang_id == 2) {
              $this->cuisine_type = $cuisine_type_data->name_ar;    
        } elseif (auth()->user()->lang_id == 3) { 
              $this->cuisine_type = $cuisine_type_data->name_fr;
        }
        }
        
        } else {
        $this->cuisine_type = '';
        }

         $weeklyHour = WeeklyHour::where('restaurant_id',$this->id)->selectRaw('
                TIME_FORMAT(mon_from, "%h:%i %p") AS mon_from,
                TIME_FORMAT(mon_to, "%h:%i %p") AS mon_to,
                TIME_FORMAT(tue_from, "%h:%i %p") AS tue_from,
                TIME_FORMAT(tue_to, "%h:%i %p") AS tue_to,
                TIME_FORMAT(wed_from, "%h:%i %p") AS wed_from,
                TIME_FORMAT(wed_to, "%h:%i %p") AS wed_to,
                TIME_FORMAT(thu_from, "%h:%i %p") AS thu_from,
                TIME_FORMAT(thu_to, "%h:%i %p") AS thu_to,
                TIME_FORMAT(fri_from, "%h:%i %p") AS fri_from,
                TIME_FORMAT(fri_to, "%h:%i %p") AS fri_to,
                TIME_FORMAT(sat_from, "%h:%i %p") AS sat_from,
                TIME_FORMAT(sat_to, "%h:%i %p") AS sat_to,
                TIME_FORMAT(sun_from, "%h:%i %p") AS sun_from,
                TIME_FORMAT(sun_to, "%h:%i %p") sun_to
                ')->first();

        $open_status = 0;
        if (!empty($weeklyHour)) {


        switch (date('l')) {
            case 'Monday':
            $start_from = $weeklyHour->mon_from;
            $end_to = $weeklyHour->mon_to;
                break;
            case 'Tuesday':
            $start_from = $weeklyHour->tue_from;
            $end_to = $weeklyHour->tue_to;
                break;
            case 'Wednesday':
            $start_from = $weeklyHour->wed_from;
            $end_to = $weeklyHour->wed_to;
                break;
            case 'Thursday':
            $start_from = $weeklyHour->thu_from;
            $end_to = $weeklyHour->thu_to;
                break;
            case 'Friday':
            $start_from = $weeklyHour->fri_from;
            $end_to = $weeklyHour->fri_to;
                break;
            case 'Saturday':
            $start_from = $weeklyHour->sat_from;
            $end_to = $weeklyHour->sat_to;
                break;
            case 'Sunday':
            $start_from = $weeklyHour->sun_from;
            $end_to = $weeklyHour->sun_to;
                break;

            default:
                break;
        }

        $current_time = date("H:i:s");

        if (date('H:i:s',strtotime($start_from)) <= $current_time && $current_time <= date('H:i:s',strtotime($end_to))) {
            $open_status = 1;
        }

        }


        $holidays = RestaurantHoliday::where('restaurant_id',$this->id)->pluck('date')->toArray();
        if (in_array(date('Y-m-d'), $holidays)) {
            $open_status = 0;
        }

        if (auth()->user()->lang_id == 2) {
              $this->name = $this->ar_name;    
        } elseif (auth()->user()->lang_id == 3) { 
              $this->name = $this->fr_name;
        }

        return [
            'id' => $this->id,
            'image' => !empty($this->getImages()->where('default',1)->first()) ? asset('storage').'/'.$this->getImages()->first()->image : '',
            'name' => $this->name,
            'cuisine_type' => $this->cuisine_type,
            'takeout' => $this->takeout,
            'notes' => $this->notes,
            'address' => $this->address,
            'home_delivery' => $this->home_delivery,
            'verified' => $this->verified,
            'expensiveness' => $this->expensiveness,
            'open_status' => $open_status,
            'rating' => $this->rating,
            'latitude' => $this->latitude,
            'wishlist' => !empty($wishlist) ? 1 : 0,
            'longitude' => $this->longitude,
            'weekly_hours' => $weeklyHour,
        ];
    }
}
