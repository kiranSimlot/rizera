<?php

namespace App\Http\Resources;

use App\Models\Wishlist;
use App\Models\Restaurant;
use App\Models\WeeklyHour;
use App\Models\CuisineType;
use App\Models\RestaurantChef;
use App\Models\RestaurantImage;
use App\Models\RestaurantHoliday;
use App\Models\RestaurantCuisineType;
use Illuminate\Http\Resources\Json\JsonResource;

class RestaurantResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {

        $cuisineTypesIds = RestaurantCuisineType::where('restaurant_id',$this->id)
        ->selectRaw('GROUP_CONCAT(cuisine_type_id) AS cuisine_type_ids')->first();

        $similarRestaurants = [];

        if (!empty($cuisineTypesIds) && $cuisineTypesIds->cuisine_type_ids != "") {
            $similarRestaurantsIds = RestaurantCuisineType::whereIn('cuisine_type_id',explode(',', $cuisineTypesIds->cuisine_type_ids))->selectRaw('GROUP_CONCAT(restaurant_id) AS restaurant_ids')->where('restaurant_id','!=',$this->id)->first();

            if (!empty($similarRestaurantsIds) && $similarRestaurantsIds->restaurant_ids != "") {
                $similarRestaurants = RestaurantListResource::collection(Restaurant::whereIn('id',explode(',', $similarRestaurantsIds->restaurant_ids))->where('status',1)->get());
            }
        }

        $images = [];
        $menu = [];

        $images = RestaurantImage::where('restaurant_id',$this->id)->where('doc_for',1)->where('doc_type',1)->selectRaw('CONCAT("'.asset('storage').'/'.'",image) AS image,IF(image_type = 1,"1","2") AS images_type')->get();

        $menu = RestaurantImage::where('restaurant_id',$this->id)->where('doc_for',2)->selectRaw('CONCAT("'.asset('storage').'/'.'",image) AS image,IF(doc_type = 1,"1","2") AS menu_type')->get();

        $restaurantFacilitiesData = Restaurant::with('getFacilities.Facilities:id,name,image')->where('restaurants.id',$this->id)->first()->toArray();
        $restaurantFacilities = array();

        if (!empty($restaurantFacilitiesData)) {
        foreach ($restaurantFacilitiesData['get_facilities'] as $key => $value) {
            $value['facilities']['image'] = asset('/').$value['facilities']['image'];
            $restaurantFacilities[] = $value['facilities'];
        }
        }


        $restaurantFacilitiesData = RestaurantCuisineType::where('restaurant_id',$this->id)->first();


         if (!empty($restaurantFacilitiesData)) {
        $cuisine_type_data = CuisineType::where('id',$restaurantFacilitiesData->cuisine_type_id)->first();

        $this->cuisine_type = $cuisine_type_data->name;
        if (!empty($cuisine_type_data)) { 
        if (auth()->user()->lang_id == 2) {
              $this->cuisine_type = $cuisine_type_data->name_ar;    
        } elseif (auth()->user()->lang_id == 3) { 
              $this->cuisine_type = $cuisine_type_data->name_fr;
        }
        }
        
        } else {
        $this->cuisine_type = '';
        }


        $weeklyHour = WeeklyHour::where('restaurant_id',$this->id)->selectRaw('
                IF(TIME_FORMAT(mon_from, "%h:%i %p") != "",TIME_FORMAT(mon_from, "%h:%i %p"),"") AS mon_from,
                IF(TIME_FORMAT(mon_to, "%h:%i %p") != "",TIME_FORMAT(mon_to, "%h:%i %p"),"") AS mon_to,
                IF(TIME_FORMAT(tue_from, "%h:%i %p") != "",TIME_FORMAT(tue_from, "%h:%i %p"),"") AS tue_from,
                IF(TIME_FORMAT(tue_to, "%h:%i %p") != "",TIME_FORMAT(tue_to, "%h:%i %p"),"") AS tue_to,
                IF(TIME_FORMAT(wed_from, "%h:%i %p") != "",TIME_FORMAT(wed_from, "%h:%i %p"),"") AS wed_from,
                IF(TIME_FORMAT(wed_to, "%h:%i %p") != "",TIME_FORMAT(wed_to, "%h:%i %p"),"") AS wed_to,
                IF(TIME_FORMAT(thu_from, "%h:%i %p") != "",TIME_FORMAT(thu_from, "%h:%i %p"),"") AS thu_from,
                IF(TIME_FORMAT(thu_to, "%h:%i %p") != "",TIME_FORMAT(thu_to, "%h:%i %p"),"") AS thu_to,
                IF(TIME_FORMAT(fri_from, "%h:%i %p") != "",TIME_FORMAT(fri_from, "%h:%i %p"),"") AS fri_from,
                IF(TIME_FORMAT(fri_to, "%h:%i %p") != "",TIME_FORMAT(fri_to, "%h:%i %p"),"") AS fri_to,
                IF(TIME_FORMAT(sat_from, "%h:%i %p") != "",TIME_FORMAT(sat_from, "%h:%i %p"),"") AS sat_from,
                IF(TIME_FORMAT(sat_to, "%h:%i %p") != "",TIME_FORMAT(sat_to, "%h:%i %p"),"") AS sat_to,
                IF(TIME_FORMAT(sun_from, "%h:%i %p") != "",TIME_FORMAT(sun_from, "%h:%i %p"),"") AS sun_from,
                IF(TIME_FORMAT(sun_to, "%h:%i %p") != "",TIME_FORMAT(sun_to, "%h:%i %p"),"") AS sun_to
                ')
        ->first()
        ;
        // echo $weeklyHour->toSql();die;
        $open_status = 0;

        switch (date('l')) {
            case 'Monday':
            $start_from = $weeklyHour->mon_from;
            $end_to = $weeklyHour->mon_to;
                break;
            case 'Tuesday':
            $start_from = $weeklyHour->tue_from;
            $end_to = $weeklyHour->tue_to;
                break;
            case 'Wednesday':
            $start_from = $weeklyHour->wed_from;
            $end_to = $weeklyHour->wed_to;
                break;
            case 'Thursday':
            $start_from = $weeklyHour->thu_from;
            $end_to = $weeklyHour->thu_to;
                break;
            case 'Friday':
            $start_from = $weeklyHour->fri_from;
            $end_to = $weeklyHour->fri_to;
                break;
            case 'Saturday':
            $start_from = $weeklyHour->sat_from;
            $end_to = $weeklyHour->sat_to;
                break;
            case 'Sunday':
            $start_from = $weeklyHour->sun_from;
            $end_to = $weeklyHour->sun_to;
                break;

            default:
                break;
        }

        $current_time = date("H:i:s");

        if (date('H:i:s',strtotime($start_from)) <= $current_time && $current_time <= date('H:i:s',strtotime($end_to))) {
            $open_status = 1;
        }


        $holidays = RestaurantHoliday::where('restaurant_id',$this->id)->pluck('date')->toArray();
        if (in_array(date('Y-m-d'), $holidays)) {
            $open_status = 0;
        }

        $chef = RestaurantChef::where('restaurant_id',$this->id)->selectRaw('*,CONCAT("'.asset('storage').'/'.'",chef_image) AS chef_image')->first();

        if (empty($chef)) {
            $chef = (object)[];
        }
        $wishlist = Wishlist::where('restaurant_id',$this->id)->where('user_id',auth()->user()->id)->first();

        
        if (auth()->user()->lang_id == 2) {
              $this->name = $this->ar_name;    
        } elseif (auth()->user()->lang_id == 3) { 
              $this->name = $this->fr_name;
        }

        return [
            'id' => $this->id,
            'image' => !empty($this->getImages()->first()) ? asset('storage').'/'.$this->getImages()->first()->image : '',
            'name' => $this->name,
            'cuisine_type' => $this->cuisine_type,
            'takeout' => $this->takeout,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'notes' => $this->notes,
            'address' => $this->address,
            'home_delivery' => $this->home_delivery,
            'wishlist' => !empty($wishlist) ? 1 : 0,
            'verified' => $this->verified,
            'expensiveness' => $this->expensiveness,
            'open_status' => $open_status,
            'rating' => $this->rating,
            'weekly_hours' => $weeklyHour,
            'similar_restaurants' => $similarRestaurants,
            'images' => $images,
            'menu' => $menu,
            'floors_data' => isset($this->floors_data) ? $this->floors_data : [],
            'chef' => $chef,
            'restaurant_facilities' => $restaurantFacilities,
            'share_url' => route('restdetails',$this->id)
        ];
    }
}
