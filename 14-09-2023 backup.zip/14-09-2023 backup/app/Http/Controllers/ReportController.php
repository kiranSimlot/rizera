<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Restaurant;
use App\Models\Tag;
use App\Models\Category;
use App\Models\User;
use App\Models\Booking;
use DataTables;
use DB;


class ReportController extends Controller
{
    public function subscriptionReports()
    {
         
        return view('subscriptionReports');
    }


     public function subscriptionList(Request $request)
    {
     

        //print_r($subscription_list); die();
        $subscription_list=DB::table('user_subscriptions')->join('plans','plans.id','=','user_subscriptions.plan_id')->join('users','user_subscriptions.user_id','=','users.id')->select('user_subscriptions.plan_id as plan_id','user_subscriptions.user_id as user_id','users.name as ownername','plans.name as plan_name','user_subscriptions.id as id','user_subscriptions.active_from as active_from','user_subscriptions.expires_at as expires_at','user_subscriptions.active as active','user_subscriptions.type as type')->get();

        //print_r($country); die();
        return DataTables::collection($subscription_list)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('ownername',function ($result){
           
                return $result->ownername;
        })
            ->addColumn('plan_name',function ($result){
            return $result->plan_name;
        })
               ->addColumn('type',function ($result){
            return $result->type;
        })
             ->addColumn('active_from',function ($result){
            return date('Y-m-d', strtotime($result->active_from));
        })
              ->addColumn('expires_at',function ($result){
            return date('Y-m-d', strtotime($result->expires_at));
        })
           
           
            ->addColumn('status',function ($result){
            if($result->active == 1)
                $status=  'Active';
            elseif($result->active == 0)
                $status=  'Deactive';
                return $status;
            })

            ->addColumn('action',function ($result){
           $edit = "<a href='".route('admin.report.edit-subscription-list',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>";

            return $edit;
           
    
            
          
        })
        ->addIndexColumn()
        ->make(true);
    }

    public function monthlyBookingsReport()

    {
 
        return view('monthlyBookingsReport');
    }

    public function monthlyReportData(Request $request)
    {
	    
       $booking= Booking::join('restaurants','restaurants.id','=','bookings.restaurant_id')
                 ->join('users','users.id','=','bookings.user_id')
                 ->leftjoin('categories','categories.id','=','bookings.category_id')
                 ->leftjoin('tags','tags.id','=','bookings.tag_id')
                 ->where('bookings.created_at','LIKE','%'.$request->month.'%')
                 ->select('bookings.id','bookings.status as status','bookings.created_at as month','restaurants.name as Rname','users.name as Uname','categories.name as Cname','tags.name as Tname');
        $booking = $booking->get();
       // echo($booking); 
        return DataTables::collection($booking)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('Rname',function ($result){
            return $result->Rname;
        })
            ->addColumn('month',function ($result){
            return $result->month;
        })
                ->addColumn('Uname',function ($result){
            return $result->Uname;
        })
            ->addColumn('status',function ($result){
                   if($result->status == 0){
                     $result->status = 'Pending';
                   }
                   else if($result->status == 1){
                       $result->status = 'Confirmed';
                   }
                    else if($result->status == 2){
                       $result->status = 'Cancelled';
                   }
                    else if($result->status == 3){
                       $result->status = 'Waiting';
                   }
                   else{
                     $result->status = 'Visited';
                   }

                   return $result->status;
            

            
        })
		->addIndexColumn()
        ->make(true);
    }

    public function edit_subcription($id)
    {
        $subscription_list=DB::table('user_subscriptions')->join('plans','plans.id','=','user_subscriptions.plan_id')->join('users','user_subscriptions.user_id','=','users.id')->select('user_subscriptions.plan_id as plan_id','user_subscriptions.user_id as user_id','users.name as ownername','plans.name as plan_name','user_subscriptions.id as id','user_subscriptions.active_from as active_from','user_subscriptions.expires_at as expires_at','user_subscriptions.active as active','user_subscriptions.type as type')->where('user_subscriptions.id',$id )->first();

       // print_r($subscription_list); die();
        return view('editsubscriptionreport',compact('subscription_list'));
    }

     public function update_subscription(Request $request, $id)
     {
        $rules=[
            'expires_at'=>'required',
          
        ];
        $message = [
            'expires_at.required'=>'Please fill exxpirey date.',
        
        ];


        $request->validate($rules,$message);
        $subscription_list=DB::table('user_subscriptions')->where('user_subscriptions.id',$id)->first();
        $data=array('expires_at'=>$request->expires_at);
            
        DB::table('user_subscriptions')->where('user_subscriptions.id',$id)->update($data);
      
        return redirect()->Route('admin.report.subscriptionReports')->with('success','Report edited successfully');
    }
}