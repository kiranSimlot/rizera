<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {  
        if (app('router')->getRoutes()->match(app('request')->create(url()->previous()))->getPrefix() == '/restaurant-owner') {  
        // echo app('router')->getRoutes()->match(app('request')->create(url()->previous()))->getPrefix();die;
        return redirect('restaurant-owner/login');
        } elseif(app('router')->getRoutes()->match(app('request')->create(url()->previous()))->getPrefix() == '/admin') {  
        return redirect('admin/login');
        }  

        }

   
    /**
     * Handle an incoming authentication request.
     *
     * @param  \App\Http\Requests\Auth\LoginRequest  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(LoginRequest $request)
    { 



        $request->authenticate();
//print_r(Auth::user()); die();


        $request->session()->regenerate();

        if( isset(Auth::user()->type) != '4'){
            switch (Auth::user()->status) {
                case 0:
                    Auth::logout();                
                    return redirect()->back()
                    ->withErrors([ 'email' => 'Your account is disabled.'])
                    ->withInput();
                    break;
                    case 2:
                    Auth::logout();                
                    return redirect()->back()
                    ->withErrors([ 'email' => 'Your account is disabled, please contact to admin to enable your account!.'])
                    ->withInput();
                    break;
                    }


                    switch (Auth::user()->type) {
                    case 3:
                    session()->forget('id_restaurant');
                    session()->put('id_restaurant',Auth::user()->restaurant_id);
                    $dd=session()->get('url.intended');
                    //print_r('gg'); die();
                  
                     return redirect()->route('owner.restaurant.list',['id'=>session('id_restaurant')]);
                  
                    //return redirect()->route('staff.restaurant.floorManagement',['id'=>session('id_restaurant')]);
                    

                    break;
                    case 2:
                    if (url()->previous() != route('owner.login')) {
                        return redirect()->back()
                            ->withErrors([ 'email' => 'You are using different url for owner/staff login.'])
                            ->withInput();
                    }
                    if( !isset(Auth::user()->email_verified_at) ){
                        Auth::logout();                
                        return redirect('/restaurant-owner/login')
                            ->withErrors([ 'email' => 'Please verify your email'])
                            ->withInput();
                    } 
                    session()->forget('id_restaurant');
                    
                    //print_r('hh'); die();
                    // if(!empty(session()->get('url.intended'))){
                  
                    // return redirect(session()->get('url.intended',['id'=>session('id_restaurant')])); 
                    //   session()->forget('url.intended');
                   
                    //  }
                    // else{
                         return redirect()->route('owner.restaurant.list');
                      
                   // }
                    break;
                    case 1:
                    if (url()->previous() != route('admin.login')) {
                        return redirect()->back()
                            ->withErrors([ 'email' => 'You are using different url for admin panel login.'])
                            ->withInput();
                    }
                    return redirect()->route('admin.owners');
                    break;
                    default:
                    return $next($request);
                    break;
            }
        }
        else{

             return redirect()->back()
                    ->withErrors([ 'email' => 'This is app user account.'])
                    ->withInput();

        }

        
        
        return redirect()->intended(RouteServiceProvider::HOME);
    }

    /**
     * Destroy an authenticated session.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Request $request)
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
