<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Http\Controllers\UserController;

use Illuminate\Support\Facades\Session;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
         //print_r($request);die();
        $rules=[
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|confirmed|min:8',
            'mobile' => 'digits:10',
            'password_confirmation' => 'required|same:password',
        ];
        $message = [
            'name.required'=>'Name is required.',
            'email.required'=>'Email is required.',
            'password.required'=>'Password is required.',
            'password_confirmation.required'=>'Confirm Password is required.',
            'mobile.required'=>'Mobile Number is required.',
   
        ];
         $request->validate($rules,$message);

         $rand2 = rand(100000,999999);
         Session::put('mobile', $request->mobile);
         $today_date = date('Y-m-d');
         $from= date('Y-m-d', strtotime($today_date. ' + 14 days'));
       // print_r($from);die();
      
         $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'password' => Hash::make($request->password),
            'code'=>123456,
            'country_id'=>null,
            'lang_id'=>null,
            'mobile_verify'=>0,
            'subscription_status'=>0,
            'status' => 1,
            'demo_expired_at' => $from,
        ]);

         return redirect()->route('owner.otp');


        //print_r($request->name); die();
        // event(new Registered($user));

        // app('App\Http\Controllers\UserController')->verifymailsend($user);

        // // Commented by Vishal Singh Chouhan
        // // Auth::login($user);

        // // Commented by Vishal Singh Chouhan
        // // return redirect(RouteServiceProvider::HOME);
        // // return redirect('login')->withErrors([ 'email' => 'Please verify your email'])->withInput();
        // // Commented by Nirmal Sharma 
        // return redirect()->route('owner.login')->with('success','Account registered successfully! Please verify your email.');

    }

    public function verify_otp(Request $request)
    {
        $request->validate([
            'otp' => 'required|string|max:255',
        ]);

            $mobile=$request->mobile;
            $otp=$request->otp;

            //print_r($mobile);
           // print_r($otp);die();
         
            $user_otp=User::where('mobile',$mobile)->first();
    
            if($user_otp->code==$otp){
            $data['mobile_verify'] =1;
              User::where('mobile',$mobile)->update($data); 
              return redirect()->route('owner.login')->with('success','Account registered successfully! Please verify your email.');
            }
            else{
             return redirect()->route('owner.otp')->with('error','Otp Mismatch! Please try again.');   
            }
        

    }
}
