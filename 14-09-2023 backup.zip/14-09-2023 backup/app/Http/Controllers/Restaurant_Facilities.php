<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Restaurant_Facilities extends Controller
{
    //
}
