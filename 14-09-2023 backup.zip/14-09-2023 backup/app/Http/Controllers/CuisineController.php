<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CuisineType;
use App\Models\Country;
use File;
//use DB;
use DataTables;

use Illuminate\Validation\Rule;

class CuisineController extends Controller
{
    public function index()
    {

   $cuisine= CuisineType::join('countries','countries.id','=','cuisine_types.country_id')
                 ->select('cuisine_types.id as cid','countries.id as country_id','countries.country_name','cuisine_types.name as cuisine_name','cuisine_types.status as cuisine_status','cuisine_types.image as cuisine_image')
                     ->where('cuisine_types.status','!=',0);
        $cuisine = $cuisine->get();

      //  print_r($cuisine); die();
        return view('cuisine');
    }

    public function cuisineData(Request $request)
    {
     
        $cuisine= CuisineType::join('countries','countries.id','=','cuisine_types.country_id')
                 ->select('cuisine_types.id as cid','countries.id as country_id','countries.country_name','cuisine_types.name as cuisine_name','cuisine_types.status as cuisine_status','cuisine_types.image as cuisine_image')
                     ->where('cuisine_types.status','!=',0);
        $cuisine = $cuisine->get();
        return DataTables::collection($cuisine)
            ->addColumn('cid',function ($result){
            return $result->cid;
        })
            ->addColumn('country_name',function ($result){
            return $result->country_name;
        })
            ->addColumn('cuisine_name',function ($result){
            return $result->cuisine_name;
        })
            ->addColumn('image',function ($result){
            if(!empty($result->cuisine_image))
                return "<td><img src='".asset('storage').'/'.$result->cuisine_image."' width='100px'></td>";
            else
                return "<td><img src='".asset('storage/city/no_image.jpg')."' width='100px'></td>";
        })

            ->addColumn('action',function ($result){
					$edit = "<td><a href='".route('admin.cuisine.editcuisine',['id'=>$result->cid])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.cuisine.delete',['id'=>$result->cid])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete
                        </a>
                    </td>";
            if($result->cuisine_status == 1)
                return  '<button type="button" data-id="'.$result->cid.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->cuisine_status == 2)
                return  '<button type="button" data-id="'.$result->cid.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
				
        })
        ->rawColumns(['action','image'])
		->addIndexColumn()
        ->make(true);
    }
    
	public function statusupdatecuisine(Request $request){
       
		$id = $request->input('id');
         $status = CuisineType::find($id);
         if($status->status == 1)
          $status->status = 2;
         elseif($status->status == 2)
          $status->status = 1;
         $status->save();
         return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
    public function add()
    {
        $country = Country::all();
        return view('addcuisine',compact('country'));
    }
    public function store(Request $request)
    {



        $nameUniqueRule = Rule::unique('cuisine_types')->where('country_id', request()->get('country_name', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });

        $rules=[
            //'country_name'=>'required',
            //'name'=>'required|max:25|uniqueOfMultiple:cuisine_types,name,country_id'
            'name' => ['required', 'max:25',  $nameUniqueRule],
            'country_name' => 'required',
			'name_ar'=>'required|max:25',
			'name_fr'=>'required|max:25',
            'image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=500,min_height=500',
          

        ];
        $message = [
            'country_name.required'=>'Country name is required.',
            'name.required'=>'Cuisine name is required.',
            'name.max'=>'Cuisine name limit exceed',
			'name_ar.required'=>'Cuisine name is required.',
            'name_ar.max'=>'Cuisine name limit exceed',
			'name_fr.required'=>'Cuisine name is required.',
            'name_fr.max'=>'Cuisine name limit exceed',
            'image.required'=>'Image is required.',
            'image.mime'=>'file is not image',
            'image.dimensions'=>'file size is not correct',
           
    
			
        ];
        $request->validate($rules,$message);
        $cuisine = new CuisineType;
         
        $directory = 'cuisine';
        $image = $request->image;
        $image_name = $request->user()->id.time().rand(1,999999999).'.'.$image->extension(); 
        $image->storeAs('public/'.$directory, $image_name); 
        if($image = $request->file('image'))
        {
            $image = $directory.'/'.$image_name;
            
        }
        else
        {
            unset($request->image);
        }

         
   
        $cuisine->name = $request->name;
        $cuisine->name_ar = $request->name_ar;
        $cuisine->name_fr = $request->name_fr;
        $cuisine->image = $image;
        $cuisine->country_id = $request->country_name;
        $cuisine->status = 1;
        $cuisine->save();
       // print_r("hoiooi"); die();
        return redirect()->Route('admin.cuisine.cuisine')->with('success','Cuisine addded successfully');
    }
    public function delete($id)
    {
        $cuisine=CuisineType::find($id);
        $cuisine->status = 0;
        $cuisine->save();
        return redirect()->Route('admin.cuisine.cuisine')->with('success','Cuisine deleted successfully');
    }

    public function edit($id)
    {
        $country_list = Country::all();
        $cuisine=CuisineType::find($id);
        return view('editcuisine',compact('cuisine','country_list'));
    }
    public function update(Request $request, $id)
    {

        $nameUniqueRule = Rule::unique('cuisine_types')->where('country_id', request()->get('country_name', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);

        $rules=[
            'country_id'=>'required',
            //'name'=>'required|max:25|unique:cuisine_types,name,'.$id,
            'name' => ['required', 'max:25', $nameUniqueRule],
			'name_ar'=>'required|max:25',
			'name_fr'=>'required|max:25',
            'image'=>'image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=500,min_height=500',
        ];
        $message = [
            'country_id.required'=>'Country name is required.',
            'name.required'=>'Cuisine name is required.',
            'name.max'=>'Cuisine name limit exceed',
			'name_ar.required'=>'Cuisine name is required.',
			'name_fr.required'=>'Cuisine name is required.',
         'image.mime'=>'file is not image',
            'image.dimensions'=>'file size is not correct'
        ];
        $request->validate($rules,$message);
        $cuisine=CuisineType::find($id);
        $cuisine->name = $request->name;
        $cuisine->name_ar = $request->name_ar;
        $cuisine->name_fr = $request->name_fr;

         if(isset($request->image) && $request->image != '') 
        { 
            $directory = 'cuisine';
            $image = $request->image;
            $image_name = $id.time().rand(1,999999999).'.'.$image->extension(); 
            $image->storeAs('public/'.$directory, $image_name); 
             if (File::exists($image)) 
             { 
                unlink($image);
             }
            if($image = $request->file('image'))
            {
                $image = $image_name;
                $cuisine->image = 'cuisine'.'/'.$image;
            }
            else
            {
                unset($request->image);
            }
        }
        $cuisine->country_id = $request->country_id;
        $cuisine->save();
        return redirect()->Route('admin.cuisine.cuisine')->with('success','Cuisine edited successfully');
    }
}
