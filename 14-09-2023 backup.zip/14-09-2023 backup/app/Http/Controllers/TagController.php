<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tag;
//use DB;
use DataTables;
use Illuminate\Validation\Rule;
class TagController extends Controller
{
    public function index()
    {
        return view('tag');
    }

    public function tagData(Request $request)
    {
        $tags=Tag::where('status','!=',0)->get();
        return DataTables::collection($tags)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('action',function ($result){
           
					$edit = "<td><a href='".route('admin.tag.edittag',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.tag.delete',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
                    </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
				
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
	
	public function statusupdatetag(Request $request){
        /*$id=$request->input('id');
		$data = DB::table('tags')->select('status')->where('id', '=', $id)->get();
        if($data[0]->status==1)
        $status = 0;
        elseif($data[0]->status==0)
        $status = 1;
		DB::table('tags')->where('id', $id)->update(['status' => $status]);
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$data]);*/
		$id = $request->input('id');
 $status = Tag::find($id);
 if($status->status == 1)
  $status->status = 2;
 elseif($status->status == 2)
  $status->status = 1;
 $status->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
	
    public function add()
    {
        return view('addtag');
    }
    public function store(Request $request)
    {
        $nameUniqueRule = Rule::unique('tags')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });
        $rules=[
            //'name'=>'required|max:25|unique:tags,name'
            'name' => ['required', 'max:25', $nameUniqueRule]
        ];
        $message = [
            'name.required'=>'Tag name is required.',
            'name.max'=>'Tag name limit exceed'
        ];
        $request->validate($rules,$message);
        $tag = new Tag;
        $tag->name = $request->name;
        $tag->status = 1;
        $tag->save();
        return redirect()->Route('admin.tag.tag')->with('success','Tag addded successfully');
    }
    public function delete($id)
    {
        $tag=Tag::find($id);
        $tag->status = 0;
        $tag->save();
        return redirect()->Route('admin.tag.tag')->with('success','Tag deleted successfully');
    }
    public function edit($id)
    {
        $tag=Tag::find($id);
        return view('edittag',compact('tag'));
    }
    public function update(Request $request, $id)
    {

        $nameUniqueRule = Rule::unique('tags')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);



        $rules=[
            //'name'=>'required|max:25|unique:tags,name,'.$id.''
            'name' => ['required', 'max:25', $nameUniqueRule]
        ];
        $message = [
            'name.required'=>'Tag name is required.',
            'name.max'=>'Tag name limit exceed'
        ];
        $request->validate($rules,$message);
        $tag=Tag::find($id);
        $tag->name = $request->name;
        $tag->save();
        return redirect()->Route('admin.tag.tag')->with('success','Tag edited successfully');
    }
}
