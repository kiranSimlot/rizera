<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoodintoleranceType;
use App\Models\Country;
//use DB;
use DataTables;

use Illuminate\Validation\Rule;

class FoodintoleranceController extends Controller
{
    public function index()
    {

        $foodintolerance= FoodintoleranceType::join('countries','countries.id','=','foodintolerance_types.country_id')
                 ->select('foodintolerance_types.id as cid','countries.id as country_id','countries.country_name','foodintolerance_types.name as foodintolerance_name','foodintolerance_types.status as foodintolerance_status')->where('foodintolerance_types.status','!=',0);
        $foodintolerance = $foodintolerance->get();

        //print_r($foodintolerance); die();
        return view('foodintolerance');
    }

    public function foodintoleranceData(Request $request)
    {
     
        $foodintolerance= FoodintoleranceType::join('countries','countries.id','=','foodintolerance_types.country_id')
                 ->select('foodintolerance_types.id as cid','countries.id as country_id','countries.country_name','foodintolerance_types.name as foodintolerance_name','foodintolerance_types.status as foodintolerance_status')
                     ->where('foodintolerance_types.status','!=',0)->orderBy('foodintolerance_types.name');
        $foodintolerance = $foodintolerance->get();
        return DataTables::collection($foodintolerance)
            ->addColumn('cid',function ($result){
            return $result->cid;
        })
            ->addColumn('country_name',function ($result){
            return $result->country_name;
        })
            ->addColumn('foodintolerance_name',function ($result){
            return $result->foodintolerance_name;
        })

            ->addColumn('action',function ($result){
                    $edit = "<td><a href='".route('admin.foodintolerance.editfoodintolerance',['id'=>$result->cid])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.foodintolerance.delete',['id'=>$result->cid])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete
                        </a>
                    </td>";
            if($result->foodintolerance_status == 1)
                return  '<button type="button" data-id="'.$result->cid.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->foodintolerance_status == 2)
                return  '<button type="button" data-id="'.$result->cid.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
                
        })
        ->rawColumns(['action'])
        ->addIndexColumn()
        ->make(true);
    }
    
    public function statusupdatefoodintolerance(Request $request){
       
        $id = $request->input('id');
         $status = FoodintoleranceType::find($id);
         if($status->status == 1)
          $status->status = 2;
         elseif($status->status == 2)
          $status->status = 1;
         $status->save();
         return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
    
    public function add()
    {
        $country = Country::all();
        return view('addfoodintolerance',compact('country'));
    }
    public function store(Request $request)
    {

        $nameUniqueRule = Rule::unique('foodintolerance_types')->where('country_id', request()->get('country_name', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });

        $rules=[
            //'country_name'=>'required',
            //'name'=>'required|max:25|uniqueOfMultiple:foodintolerance_types,name,country_id'
            'name' => ['required', 'max:35',  $nameUniqueRule],
            'country_name' => 'required',
            'name_ar'=>'required|max:35',
            'name_fr'=>'required|max:35'

        ];
        $message = [
            'country_name.required'=>'Country name is required.',
            'name.required'=>'Food Intolerance name is required.',
            'name.max'=>'Food Intolerance name limit exceed',
            'name_ar.required'=>'Food Intolerance name is required.',
            'name_ar.max'=>'Food Intolerance name limit exceed',
            'name_fr.required'=>'Food Intolerance name is required.',
            'name_fr.max'=>'Food Intolerance name limit exceed'
            
        ];
        $request->validate($rules,$message);
        $foodintolerance = new FoodintoleranceType;
        $foodintolerance->name = $request->name;
        $foodintolerance->name_ar = $request->name_ar;
        $foodintolerance->name_fr = $request->name_fr;
        $foodintolerance->country_id = $request->country_name;
        $foodintolerance->status = 1;
        $foodintolerance->save();
        return redirect()->Route('admin.foodintolerance.foodintolerance')->with('success','Food Intolerance addded successfully');
    }
    public function delete($id)
    {
        $foodintolerance=FoodintoleranceType::find($id);
        $foodintolerance->status = 0;
        $foodintolerance->save();
        return redirect()->Route('admin.foodintolerance.foodintolerance')->with('success','Food Intolerance deleted successfully');
    }

    public function edit($id)
    {
        $country_list = Country::all();
        $foodintolerance=FoodintoleranceType::find($id);
        return view('editfoodintolerance',compact('foodintolerance','country_list'));
    }
    public function update(Request $request, $id)
    {

        $nameUniqueRule = Rule::unique('foodintolerance_types')->where('country_id', request()->get('country_name', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);

        $rules=[
            'country_id'=>'required',
            //'name'=>'required|max:25|unique:foodintolerance_types,name,'.$id,
            'name' => ['required', 'max:35', $nameUniqueRule],
            'name_ar'=>'required|max:35',
            'name_fr'=>'required|max:35'
        ];
        $message = [
            'country_id.required'=>'Country name is required.',
            'name.required'=>'Food Intolerance name is required.',
            'name.max'=>'Food Intolerance name limit exceed',
            'name_ar.required'=>'Food Intolerance name is required.',
            'name_fr.required'=>'Food Intolerance name is required.'
        ];
        $request->validate($rules,$message);
        $foodintolerance=FoodintoleranceType::find($id);
        $foodintolerance->name = $request->name;
        $foodintolerance->name_ar = $request->name_ar;
        $foodintolerance->name_fr = $request->name_fr;
        $foodintolerance->country_id = $request->country_id;
        $foodintolerance->save();
        return redirect()->Route('admin.foodintolerance.foodintolerance')->with('success','Food Intolerance edited successfully');
    }
}
