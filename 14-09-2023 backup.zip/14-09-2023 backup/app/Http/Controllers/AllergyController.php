<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AllergyType;
use App\Models\Country;
//use DB;
use DataTables;

use Illuminate\Validation\Rule;

class AllergyController extends Controller
{
    public function index()
    {

        $allergy= AllergyType::join('countries','countries.id','=','allergy_types.country_id')
                 ->select('allergy_types.id as cid','countries.id as country_id','countries.country_name','allergy_types.name as allergy_name','allergy_types.status as allergy_status')->where('allergy_types.status','!=',0);
        $allergy = $allergy->get();

        //print_r($allergy); die();
        return view('allergy');
    }

    public function allergyData(Request $request)
    {
     
        $allergy= AllergyType::join('countries','countries.id','=','allergy_types.country_id')
                 ->select('allergy_types.id as cid','countries.id as country_id','countries.country_name','allergy_types.name as allergy_name','allergy_types.status as allergy_status')
                     ->where('allergy_types.status','!=',0)->orderBy('allergy_types.name');
        $allergy = $allergy->get();
        return DataTables::collection($allergy)
            ->addColumn('cid',function ($result){
            return $result->cid;
        })
            ->addColumn('country_name',function ($result){
            return $result->country_name;
        })
            ->addColumn('allergy_name',function ($result){
            return $result->allergy_name;
        })

            ->addColumn('action',function ($result){
                    $edit = "<td><a href='".route('admin.allergy.editallergy',['id'=>$result->cid])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.allergy.delete',['id'=>$result->cid])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete
                        </a>
                    </td>";
            if($result->allergy_status == 1)
                return  '<button type="button" data-id="'.$result->cid.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->allergy_status == 2)
                return  '<button type="button" data-id="'.$result->cid.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
                
        })
        ->rawColumns(['action'])
        ->addIndexColumn()
        ->make(true);
    }
    
    public function statusupdateallergy(Request $request){
       
        $id = $request->input('id');
         $status = AllergyType::find($id);
         if($status->status == 1)
          $status->status = 2;
         elseif($status->status == 2)
          $status->status = 1;
         $status->save();
         return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
    
    public function add()
    {
        $country = Country::all();
        return view('addallergy',compact('country'));
    }
    public function store(Request $request)
    {

        $nameUniqueRule = Rule::unique('allergy_types')->where('country_id', request()->get('country_name', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });

        $rules=[
            //'country_name'=>'required',
            //'name'=>'required|max:25|uniqueOfMultiple:allergy_types,name,country_id'
            'name' => ['required', 'max:35',  $nameUniqueRule],
            'country_name' => 'required',
            'name_ar'=>'required|max:35',
            'name_fr'=>'required|max:35'

        ];
        $message = [
            'country_name.required'=>'Country name is required.',
            'name.required'=>'Allergy name is required.',
            'name.max'=>'Allergy name limit exceed',
            'name_ar.required'=>'Allergy name is required.',
            'name_ar.max'=>'Allergy name limit exceed',
            'name_fr.required'=>'Allergy name is required.',
            'name_fr.max'=>'Allergy name limit exceed'
            
        ];
        $request->validate($rules,$message);
        $allergy = new AllergyType;
        $allergy->name = $request->name;
        $allergy->name_ar = $request->name_ar;
        $allergy->name_fr = $request->name_fr;
        $allergy->country_id = $request->country_name;
        $allergy->status = 1;
        $allergy->save();
        return redirect()->Route('admin.allergy.allergy')->with('success','Allergy addded successfully');
    }
    public function delete($id)
    {
        $allergy=AllergyType::find($id);
        $allergy->status = 0;
        $allergy->save();
        return redirect()->Route('admin.allergy.allergy')->with('success','Allergy deleted successfully');
    }

    public function edit($id)
    {
        $country_list = Country::all();
        $allergy=AllergyType::find($id);
        return view('editallergy',compact('allergy','country_list'));
    }
    public function update(Request $request, $id)
    {

        $nameUniqueRule = Rule::unique('allergy_types')->where('country_id', request()->get('country_name', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);

        $rules=[
            'country_id'=>'required',
            //'name'=>'required|max:25|unique:allergy_types,name,'.$id,
            'name' => ['required', 'max:35', $nameUniqueRule],
            'name_ar'=>'required|max:35',
            'name_fr'=>'required|max:35'
        ];
        $message = [
            'country_id.required'=>'Country name is required.',
            'name.required'=>'Allergy name is required.',
            'name.max'=>'Allergy name limit exceed',
            'name_ar.required'=>'Allergy name is required.',
            'name_fr.required'=>'Allergy name is required.'
        ];
        $request->validate($rules,$message);
        $allergy=AllergyType::find($id);
        $allergy->name = $request->name;
        $allergy->name_ar = $request->name_ar;
        $allergy->name_fr = $request->name_fr;
        $allergy->country_id = $request->country_id;
        $allergy->save();
        return redirect()->Route('admin.allergy.allergy')->with('success','Allergy edited successfully');
    }
}
