<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VipTag;
//use DB;
use DataTables;
use Illuminate\Validation\Rule;

class VipTagController extends Controller
{
    public function index()
    {
        return view('viptag');
    }

    public function vipTagData(Request $request)
    {
        $vip=VipTag::where('status','!=',0)->get();
        return DataTables::collection($vip)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('action',function ($result){
					$edit = "<td><a href='".route('admin.viptag.editViptag',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.viptag.deleteViptag',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
                    </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
				
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
	
	public function statusupdateviptag(Request $request){
        /*$id=$request->input('id');
		$data = DB::table('vip_tags')->select('status')->where('id', '=', $id)->get();
        if($data[0]->status==1)
        $status = 0;
        elseif($data[0]->status==0)
        $status = 1;
		DB::table('vip_tags')->where('id', $id)->update(['status' => $status]);
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$data]);*/
		$id = $request->input('id');
 $status = VipTag::find($id);
 if($status->status == 1)
  $status->status = 2;
 elseif($status->status == 2)
  $status->status = 1;
 $status->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	

    public function add()
    {
        return view('addviptag');
    }

    public function store(Request $request)
    {
        $nameUniqueRule = Rule::unique('vip_tags')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });
        $rules=[
            //'name'=>'required|max:50|unique:vip_tags,name'
            'name' => ['required', 'max:50', $nameUniqueRule]
        ];
        $message = [
            'name.required'=>' Vip-Tag name is required.',
            'name.max'=>'Vip-Tag name limit exceed'
        ];
        $request->validate($rules,$message);
        $vip = new VipTag;
        $vip->name = $request->name;
        $vip->status = 1;
        $vip->save();
        return redirect()->Route('admin.viptag.viptag')->with('success','VipTag addded successfully');
    }

    public function delete($id)
    {
        $vip=VipTag::find($id);
        $vip->status=0;
        $vip->save();
        return redirect()->Route('admin.viptag.viptag')->with('success','VipTag deleted successfully');
    }

    public function edit($id)
    {
        $vip=VipTag::find($id);
        return view('editviptag',compact('vip'));
    }

    public function update(Request $request, $id)
    {

        $nameUniqueRule = Rule::unique('vip_tags')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);

        $rules=[
            //'name'=>'required|max:50|unique:vip_tags,name,'.$id.''
            'name' => ['required', 'max:50', $nameUniqueRule]
        ];
        $message = [
            'name.required'=>'Vip-Tag name is required.',
            'name.max'=>'Vip-Tag name limit exceed'
        ];
        $request->validate($rules,$message);
        $vip=VipTag::find($id);
        $vip->name = $request->name;
        $vip->save();
        return redirect()->Route('admin.viptag.viptag')->with('success','VipTag edited successfully');
    }
}
