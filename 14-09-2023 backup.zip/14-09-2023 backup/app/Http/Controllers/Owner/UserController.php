<?php

namespace App\Http\Controllers\Owner;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Restaurant;
use App\Models\Booking;
use App\Models\Item;
use App\Models\StaffPermission;
use Session;
use App\Http\Controllers\Controller;
use App\Mail\RizeraMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use DataTables;
use Carbon\Carbon;
class UserController extends Controller
{
    public function ownerList(){
        $ownerList = User::verified(2)->paginate(10);;
    	return view('owners',['owners'=>$ownerList]);
    }
    public function destroy($id){
    	$user = User::find($id);
    	if(!$user){
            return redirect()->route('owner.staff.list')->with('danger','Staff not found');;
	    }else{

            if( $user->destroyIt() ){
                return redirect()->route('owner.staff.list')->with('success','Staff deleted successfully');;
            }else{
                return redirect()->route('owner.staff.list')->with('danger','Error in: Staff deleted request');;
            }
	    }
    }
    public function verifymail($token){
        $user = User::where('remember_token',$token)->first();
        if(!$user){
            return view('auth.verified',['danger'=>'This record not found']);
        }else{
            if($user->emailVerified()){
                return view('auth.verified',['success'=>'Email verified successfully']);
            }else{
                return view('auth.verified',['danger'=>'Invalid request']);
            }
        }
    }
    public function verifymailsend($user){
        $token = Str::random(60);
        $details = [
            'view' => 'verifyMail',
            'subject' => 'Verify Email Address',
            'url' => url('verifymail',$token),
        ];
        $user = User::find($user->id);
        $user->remember_token = $token;
        $user->save();
        Mail::to($user)->send(new RizeraMail($details));
        return;
    }
    // public function staff(){
    //     // dd('P');
    //     $staffList = User::where('type',3)->where('status','!=',0)->paginate(10);
    //     // $staffList = [];
    //     return view('staffList',['staffList'=>$staffList]);
    // }

    public function ownerStaffList()
    {
        $id =Auth::user()->id;
        $id_restaurant = Session::get('id_restaurant');
        // dd($id_restaurant);
        $user = User::join('restaurants','restaurants.id','=','users.restaurant_id')
                        ->whereIn('type',[3,5,6])
                        ->where('users.restaurant_id',$id_restaurant)
                        ->where('users.owner_id',$id)
                        ->select('users.id','users.name','users.email','users.status as status','users.type','restaurants.name as Rname')
                        ->orderBy('users.id','desc')
                        ->paginate(10);
                        // dd($user);
        return view('staffList1',['stafflist'=>$user]);
    }
    // public function ownerStaffData(Request $request)
    // {

    //     $id =Auth::user()->id;
    //     $user = User::join('restaurants','restaurants.id','=','users.restaurant_id')
    //                     ->Where('type',3)
    //                     ->where('users.owner_id',$id)
    //                     ->select('users.id','users.name','users.email','users.status as status','users.type','restaurants.name as Rname')
    //                     ->get();

    //                     echo $user;

    //                     if(isset($request->month)){

    //                     }

    //     return DataTables::collection($user)
    //         ->addColumn('id',function ($result){
    //         return $result->id;
    //     })
    //         ->addColumn('name',function ($result){
    //         return $result->name;
    //     })
    //         ->addColumn('email',function ($result){
    //         return $result->email;
    //     })
    //         ->addColumn('Rname',function ($result){
    //         return $result->Rname;
    //     })
    //         ->addColumn('actions',function ($result){
    //             //
    //         $detail = '<a href='.route('owner.staff.ownerStaffdetail',['id'=>$result->id]).' class="btn btn-sm btn-outline-primary">View</a>';
    //         $delete = '<button type="button" data-id="'.$result["id"].'" class="btn btn-danger btn-sm del">'. __("owner.Delete").'</button>';
    //         $edit = '<a href='.route('owner.staff.edit',['id'=>$result->id]).' class="btn btn-black btn-sm" >'. __("owner.Edit").'</a>';
    //         if($result->status == 1)
    //             return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-primary btn-sm status">'. __("owner.Enable").'</button>'.$edit.$delete.$detail;
    //         else
    //             return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-warning btn-sm status">'. __("owner.Disabled").'</button>'.$edit.$delete.$detail;
    //     })
    //     ->rawColumns(['actions'])
    //     ->make(true);
    // }

    public function ownerStaffdetail(Request $request, $id)
    {
        $staff = User::join('restaurants','restaurants.id','=','users.restaurant_id')
                        ->where('users.id',$id)
                        ->select('users.*','restaurants.name as Rname')
                        ->get();
                        // dd($staff);
        return view('owner-staff-detail',['staff'=>$staff]);
    }

        public function staffdelete($id){
        User::where('id',$id)->delete();
            return redirect()->route('owner.staff.list')->with('success','Staff deleted successfully.');

    }


    public function addStaffView(Request $request)
    {
        $id =Auth::user()->id;
        // print_r($id);
        $restaurants = Restaurant::where('user_id',$id)->orderBy('id','DESC')->pluck("name","id");
        //  print_r($restaurants); die();
        return view('staff.add',['restaurants'=>$restaurants]);
    }
    public function addStaff(Request $request){
        $data = $request->all();

        //    print_r($data); die();
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'password_confirmation' => 'required|same:password',
            'restaurant' => 'required|numeric',
            'permission_type'=>'required',
        ];
        $request->validate($rules);
        $restaurants = Restaurant::where('id',$data['restaurant'])->first();

        //    print_r($restaurants); die();
        $user = new User;
        $user->name = ucwords($data['name']);
        $user->email = $data['email'];
        $user->restaurant_id = $data['restaurant'];
        $user->password = Hash::make($data['password']);
        // $user->type = 3;
        $user->status = 1;
        $user->owner_id = $data['owner_id'];
        $user->country_id = $restaurants['country_id'];
        $user->lang_id = 1;
        if(!empty($data['chef'])){
            $user->type = $data['chef'];
        }else{
            $user->type = 3;
        }
        if($user->save()){

            foreach ($data['permission_type'] as $key => $value) {
             $input['staff_id'] = $user->id;
             $input['permission_module'] =$value;
             $input['status'] =1;
            StaffPermission::create($input);
            }



            return redirect()->route('owner.staff.list')->with('success','Staff addded successfully');
        }
        return view('staff.add',['restaurants'=> $restaurants]);
    }
    public function editStaff($id){
        $staff = User::find($id);
        $permission =StaffPermission::where('staff_id',$id)->pluck('permission_module')->toArray();
        $userid =Auth::user()->id;
    //    echo "<pre>"; print_r($permission); die();
        $restaurants = Restaurant::where('user_id',$userid)->orderBy('id','DESC')->pluck("name","id");
        // $restaurants = Restaurant::where('user_id',$id)->orderBy('id','DESC')->pluck("name","id")->toArray();
        // echo "<pre>"; print_r($restaurants); die();
        return view('staff.add',['staff'=>$staff,'restaurants'=>$restaurants,'permission_type'=> $permission ]);
    }
    public function updateStaff(Request $request){
        $data = $request->all();
    //    print_r($data);die();
        $rules = [
            'id' =>  'required|numeric',
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,'.$data['id'],
            'password' => 'nullable|alpha_num|min:8|confirmed',
            'restaurant' => 'required|numeric',
            'permission_type' => 'required',
        ];
        $request->validate($rules);
        $user = User::find($data['id']);
        $user->name = ucwords($data['name']);
        $user->email = $data['email'];
        $user->restaurant_id = $data['restaurant'];
        if( isset($data['password']) && !empty($data['password']) ){
            $user->password = Hash::make($data['password']);
        }
        if(!empty($data['chef'])){
            $user->type = $data['chef'];
        }else{
            $user->type = 3;
        }
        if($user->save()){
           StaffPermission::where('staff_id', $user->id)->delete();
            foreach ($data['permission_type'] as $key => $value) {
             $input['staff_id'] = $user->id;
             $input['permission_module'] =$value;
             $input['status'] =1;

            StaffPermission::create($input);
            }


            return redirect()->route('owner.staff.list')->with('success','Staff updated successfully');
        }
    }

    public function statusChange($id){
        $user = User::find($id);
        if(!$user){
                return redirect('owners')->with('error','Owner not found.');
        }else{
            $user->statusUpdate();
            if($user->save()){
                return redirect('owners')->with('success', Str::ucfirst($user->name). ' account '. ($user->status==2?'disabled':'enabled'));
            }else{
                return redirect('owners')->with('error','Request failed.');
            }
        }
    }

        public function logout(Request $request) {
            Auth::logout();
            // return redirect('/login');
            return redirect()->Route('owner.login');
        }

    public function ownerPanelReport(Request $request)
    {
        $id_restaurant = session('id_restaurant');
		/*$booking = Booking::select('restaurant_id','no_of_person')->get();
        $dataPoints = [];
        foreach($booking as $value){
            $dataPoints[] = [
                "name" => $value['restaurant_id'],
                "y" => floatval($value['no_of_person'])
            ];
        }*/


		$online_bookings = Booking::where('restaurant_id', $id_restaurant)->where('booking_by',1)->count();
		$offline_bookings = Booking::where('restaurant_id', $id_restaurant)->where('booking_by',2)->count();


		$cancelled_bookings = Booking::where('restaurant_id', $id_restaurant)->where('status',2)->count();
		$confirmed_bookings = Booking::where('restaurant_id', $id_restaurant)->where('status',1)->count();


		$released_bookings = Booking::where('restaurant_id', $id_restaurant)->where('status',4)->count();
		$waiting_bookings = Booking::where('restaurant_id', $id_restaurant)->where('status',3)->count();


			if($request->get('year') != 'null' && $request->get('year') != '')
            {
             $current_year = $request->get('year');
            }
            else
            {
             $current_year = date('Y');
            }
			//$current_year = 2022;

            if($request->get('month') != 'null' && $request->get('month') != '')
            {
             $current_month = $request->get('month');
            }
            else
            {
             $current_month = date('m');
            }
            //$current_month = 8;

            $month_name = date('M', mktime(0, 0, 0, $current_month, 10));

            $days_month = cal_days_in_month(CAL_GREGORIAN,$current_month,$current_year);

            $total_days = '[]';

            if($days_month == 28)
            {
             $total_days = '["1 '.$month_name.'", "2 '.$month_name.'", "3 '.$month_name.'", "4 '.$month_name.'", "5 '.$month_name.'", "6 '.$month_name.'", "7 '.$month_name.'","8 '.$month_name.'", "9 '.$month_name.'", "10 '.$month_name.'", "11 '.$month_name.'", "12 '.$month_name.'", "13 '.$month_name.'", "14 '.$month_name.'","15 '.$month_name.'","16 '.$month_name.'", "17 '.$month_name.'", "18 '.$month_name.'", "19 '.$month_name.'", "20 '.$month_name.'", "21 '.$month_name.'", "22 '.$month_name.'","23 '.$month_name.'", "24 '.$month_name.'", "25 '.$month_name.'", "26 '.$month_name.'", "27 '.$month_name.'", "28 '.$month_name.'"]';
            }
            elseif($days_month == 29)
            {
             $total_days = '["1 '.$month_name.'", "2 '.$month_name.'", "3 '.$month_name.'", "4 '.$month_name.'", "5 '.$month_name.'", "6 '.$month_name.'", "7 '.$month_name.'","8 '.$month_name.'", "9 '.$month_name.'", "10 '.$month_name.'", "11 '.$month_name.'", "12 '.$month_name.'", "13 '.$month_name.'", "14 '.$month_name.'","15 '.$month_name.'","16 '.$month_name.'", "17 '.$month_name.'", "18 '.$month_name.'", "19 '.$month_name.'", "20 '.$month_name.'", "21 '.$month_name.'", "22 '.$month_name.'","23 '.$month_name.'", "24 '.$month_name.'", "25 '.$month_name.'", "26 '.$month_name.'", "27 '.$month_name.'", "28 '.$month_name.'", "29 '.$month_name.'"]';
            }
            elseif($days_month == 30)
            {
            $total_days = '["1 '.$month_name.'", "2 '.$month_name.'", "3 '.$month_name.'", "4 '.$month_name.'", "5 '.$month_name.'", "6 '.$month_name.'", "7 '.$month_name.'","8 '.$month_name.'", "9 '.$month_name.'", "10 '.$month_name.'", "11 '.$month_name.'", "12 '.$month_name.'", "13 '.$month_name.'", "14 '.$month_name.'","15 '.$month_name.'","16 '.$month_name.'", "17 '.$month_name.'", "18 '.$month_name.'", "19 '.$month_name.'", "20 '.$month_name.'", "21 '.$month_name.'", "22 '.$month_name.'","23 '.$month_name.'", "24 '.$month_name.'", "25 '.$month_name.'", "26 '.$month_name.'", "27 '.$month_name.'", "28 '.$month_name.'", "29 '.$month_name.'", "30 '.$month_name.'"]';
            }
            else // 31
            {
            $total_days = '["1 '.$month_name.'", "2 '.$month_name.'", "3 '.$month_name.'", "4 '.$month_name.'", "5 '.$month_name.'", "6 '.$month_name.'", "7 '.$month_name.'","8 '.$month_name.'", "9 '.$month_name.'", "10 '.$month_name.'", "11 '.$month_name.'", "12 '.$month_name.'", "13 '.$month_name.'", "14 '.$month_name.'","15 '.$month_name.'","16 '.$month_name.'", "17 '.$month_name.'", "18 '.$month_name.'", "19 '.$month_name.'", "20 '.$month_name.'", "21 '.$month_name.'", "22 '.$month_name.'","23 '.$month_name.'", "24 '.$month_name.'", "25 '.$month_name.'", "26 '.$month_name.'", "27 '.$month_name.'", "28 '.$month_name.'", "29 '.$month_name.'", "30 '.$month_name.'", "31 '.$month_name.'"]';
            }



$online_bookings_array = Booking::select(\DB::raw('DATE(for_date) as dates'),\DB::raw("COUNT(*) as count"))
						->where('booking_by',1)
						->whereMonth('for_date', $current_month)
						->whereYear('for_date', $current_year)
						->where('restaurant_id', $id_restaurant)
						->groupBy(\DB::raw('dates'))
						->get()
						->toArray();
//echo "<pre>"; print_r($online_bookings_array); die();
$days_num_count = array();
if(isset($online_bookings_array) && $online_bookings_array != '' && count($online_bookings_array) > 0)
{
$i = 0;
foreach($online_bookings_array as $bookingarr)
{
$timestamp = strtotime($bookingarr['dates']);
$day_date = date("j", $timestamp);
$days_num_count[$day_date] =  $bookingarr['count'];
$i++;
}
}
$online_bookings_day_wise = '[';
for($i=1; $i<=$days_month; $i++)
{
if(isset($days_num_count[$i]) && $days_num_count[$i] != '')
{
$online_bookings_day_wise .= $days_num_count[$i].', ';
}
else
{
$online_bookings_day_wise .= '0, ';
}
}
$online_bookings_day_wise = rtrim($online_bookings_day_wise, ' ');
$online_bookings_day_wise = rtrim($online_bookings_day_wise, ',');
$online_bookings_day_wise .= ']';
//echo $online_bookings_day_wise; //die;

$offline_bookings_array = Booking::select(\DB::raw('DATE(for_date) as dates'),\DB::raw("COUNT(*) as count"))
						->where('booking_by',2)
						->whereMonth('for_date', $current_month)
						->whereYear('for_date', $current_year)
						->where('restaurant_id', $id_restaurant)
						->groupBy(\DB::raw('dates'))
						->get()
						->toArray();
//echo "<pre>"; print_r($offline_bookings_array); //die();
$days_num_count_offline = array();
if(isset($offline_bookings_array) && $offline_bookings_array != '' && count($offline_bookings_array) > 0)
{
$i = 0;
foreach($offline_bookings_array as $bookingarr_offline)
{
$timestamp_offline = strtotime($bookingarr_offline['dates']);
$day_date_offline = date("j", $timestamp_offline);
$days_num_count_offline[$day_date_offline] =  $bookingarr_offline['count'];
$i++;
}
}
$offline_bookings_day_wise = '[';
for($l=1; $l<=$days_month; $l++)
{
if(isset($days_num_count_offline[$l]) && $days_num_count_offline[$l] != '')
{
$offline_bookings_day_wise .= $days_num_count_offline[$l].', ';
}
else
{
$offline_bookings_day_wise .= '0, ';
}
}
$offline_bookings_day_wise = rtrim($offline_bookings_day_wise, ' ');
$offline_bookings_day_wise = rtrim($offline_bookings_day_wise, ',');
$offline_bookings_day_wise .= ']';
//echo $offline_bookings_day_wise; die;


		return view('owner-report-chart', compact('current_month','current_year','total_days','cancelled_bookings','confirmed_bookings','online_bookings','offline_bookings', 'waiting_bookings','online_bookings_day_wise','offline_bookings_day_wise','released_bookings'));


    }

	public function ownerPanelReport1(Request $request)
    {
$id_restaurant = session('id_restaurant');
$current_year = date('Y');
if($request->get('month') != 'null' && $request->get('month') != '')
{
 $current_month = $request->get('month');
}
else
{
 $current_month = date('m');
}
//$current_month = 8;

$days_month = cal_days_in_month(CAL_GREGORIAN,$current_month,$current_year);

$total_days = '[]';

if($days_month == 28)
{
 $total_days = '["1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12", "13", "14","15","16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28"]';
}
elseif($days_month == 29)
{
 $total_days = '["1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12", "13", "14","15","16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29"]';
}
elseif($days_month == 30)
{
 $total_days = '["1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12", "13", "14","15","16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29","30"]';
}
else // 31
{
 $total_days = '["1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12", "13", "14","15","16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29","30","31"]';
}

$online_bookings_array = Booking::select(\DB::raw('DATE(for_date) as dates'),\DB::raw("COUNT(*) as count"))
			->where('booking_by',1)
			->whereMonth('for_date', $current_month)
			->whereYear('for_date', $current_year)
            ->where('restaurant_id', $id_restaurant)
			->groupBy(\DB::raw('dates'))
			->get()
			->toArray();
			$days_num_count = array();
			if(isset($online_bookings_array) && $online_bookings_array != '' && count($online_bookings_array) > 0)
			{
			  $i = 0;
			foreach($online_bookings_array as $bookingarr)
			{
			  $timestamp = strtotime($bookingarr['dates']);
              $day_date = date("j", $timestamp);
			  $days_num_count[$day_date] =  $bookingarr['count'];
			  $i++;
			}
			}
         $online_bookings_day_wise = '[';
         for($i=1; $i<=$days_month; $i++)
         {
          if(isset($days_num_count[$i]) && $days_num_count[$i] != '')
           {
            $online_bookings_day_wise .= $days_num_count[$i].', ';
           }
          else
           {
            $online_bookings_day_wise .= '0, ';
           }
         }
         $online_bookings_day_wise = rtrim($online_bookings_day_wise, ' ');
         $online_bookings_day_wise = rtrim($online_bookings_day_wise, ',');
         $online_bookings_day_wise .= ']';


        $offline_bookings_array = Booking::select(\DB::raw('DATE(for_date) as dates'),\DB::raw("COUNT(*) as count"))
        			->where('booking_by',2)
        			->whereMonth('for_date', $current_month)
        			->whereYear('for_date', $current_year)
                    ->where('restaurant_id', $id_restaurant)
        			->groupBy(\DB::raw('dates'))
        			->get()
        			->toArray();
			$days_num_count_offline = array();
    		if(isset($offline_bookings_array) && $offline_bookings_array != '' && count($offline_bookings_array) > 0)
    			{
    			  $i = 0;
    			foreach($offline_bookings_array as $bookingarr_offline)
    			{
    			  $timestamp_offline = strtotime($bookingarr_offline['dates']);
                  $day_date_offline = date("j", $timestamp_offline);
    			  $days_num_count_offline[$day_date_offline] =  $bookingarr_offline['count'];
    			  $i++;
    			}
    			}

                 $offline_bookings_day_wise = '[';
                 for($l=1; $l<=$days_month; $l++)
                 {
                  if(isset($days_num_count_offline[$l]) && $days_num_count_offline[$l] != '')
                   {
                    $offline_bookings_day_wise .= $days_num_count_offline[$l].', ';
                   }
                  else
                   {
                    $offline_bookings_day_wise .= '0, ';
                   }
                 }
                 $offline_bookings_day_wise = rtrim($offline_bookings_day_wise, ' ');
                 $offline_bookings_day_wise = rtrim($offline_bookings_day_wise, ',');
                 $offline_bookings_day_wise .= ']';

               return response()->json(['total_days'=>$total_days,'online_bookings_day_wise'=>$online_bookings_day_wise,'offline_bookings_day_wise'=>$offline_bookings_day_wise]);

    }

    public function statusUpdate($id){
        $staff = user::find($id);
        if($staff->status ==1 ){
            $staff->status = 2;
        }
        elseif($staff->status ==2 ){
            $staff->status = 1;
        }
        if( $staff->save() ){
            return redirect()->route('owner.staff.list')->with('success','Staff staus updated successfully.');
        }else{
            return redirect()->route('owner.staff.list')->with('error','Error in: updation.');
        }
    }
    public function orederData(Request $request, $order = null){
        $id_restaurant = Session::get('id_restaurant');
        $currentDate = Carbon::now()->format('Y-m-d');

        // dd($id_restaurant);
        $order = $request->order;
        // dd($order);
        if(empty($order)||$order == null ){
            $panding_orders =  OrderDetail::with(['getOrderItems','getOrder'])->whereIn('status', [0,2])->where('restaurant_id',Auth::user()->restaurant_id)->orderBy('id', 'DESC')->whereDate('created_at', $currentDate)->get();
            // echo "<pre>"; echo "dsddsddd"; print_r($panding_orders); die;
                return view('kitchen_order_list', compact('panding_orders', 'order'));
        }

        // dd($order);

        if($order == 'panding_orders' or null ){
            $panding_orders =  OrderDetail::with('getOrderItems','getOrder')->whereIn('status', [0,2])->where('restaurant_id',Auth::user()->restaurant_id)->orderBy('id', 'DESC')->whereDate('created_at', $currentDate)->get();
            // echo "<pre>"; echo "ddd"; print_r($panding_orders); die;
                return view('kitchen_order_list', compact('panding_orders', 'order'));
            }


        if($order == 'complete_orders'){
             $complete_order =  OrderDetail::with('getOrderItems','getOrder')->where('status', 1)->where('restaurant_id',Auth::user()->restaurant_id)->orderBy('id', 'DESC')->whereDate('created_at', $currentDate)->get();
            //  echo "<pre>"; echo "ddsdfdd"; print_r($complete_order); die;
             return view('kitchen_order_list', compact('complete_order', 'order'));
        }
        if($order == 'cancel_orders'){
             $cancel_order =  OrderDetail::with('getOrderItems','getOrder')->where('status', 3)->where('restaurant_id',Auth::user()->restaurant_id)->orderBy('id', 'DESC')->whereDate('created_at', $currentDate)->get();
            //  echo "<pre>"; echo "ddd"; print_r($cancel_order); die;
             return view('kitchen_order_list', compact('cancel_order', 'order'));
        }
    }


    /*public function orederData(Request $request){
        $id_restaurant = Session::get('id_restaurant');
        // dd($id_restaurant);

            $panding_orders =  OrderDetail::with('getOrderItems')->where('status', 0)->where('restaurant_id',$id_restaurant)->orderBy('id', 'DESC')->get();

            $complete_order =  OrderDetail::with('getOrderItems')->where('status', 1)->where('restaurant_id',$id_restaurant)->orderBy('id', 'DESC')->get();

            $cancel_order =  OrderDetail::with('getOrderItems')->where('status', 2)->where('restaurant_id',$id_restaurant)->orderBy('id', 'DESC')->get();

            return view('kitchen_order_list', compact('panding_orders','cancel_order','complete_order'));
        }*/
        // dd($order);
    public function completeOrderStatus(Request $request){
        $status = OrderDetail::where('id', $request->id)->first();
        $status->status = $request->status;
        $result = $status->update();
        if($result){
            return response()->json([
                'status' => 'true',
                'message' => 'Order deleted successfully',
            ]);
        }else{
            return response()->json([
                'status' => false,
                'message' => 'Order not found',
            ]);
        }
    }

    public function acceptOrderStatus(Request $request){
        $status = OrderDetail::where('id', $request->id)->first();
        $status->status = $request->status;
        $result = $status->update();
        if($result){
            return response()->json([
                'status' => 'true',
                'message' => 'Order Accept successfully',
            ]);
        }else{
            return response()->json([
                'status' => false,
                'message' => 'Order not found',
            ]);
        }
    }
    public function pendingsData(){
        $id_restaurant = Session::get('id_restaurant');
        $panding_orders =  OrderDetail::with('getOrderItems')->where('status', 0)->where('restaurant_id',$id_restaurant)->orderBy('id', 'DESC')->get();
        if(count($panding_orders) > 0){
            return response()->json($panding_orders);
        }else{
            return response()->json([
                'status' => false,
                'message' => 'Order not found',
            ]);
        }
    }
    public function list(){
        return view('order.order_list');
    }
	public function orderData(Request $request){
        $id_restaurant = Session::get('id_restaurant');
        // dd($id_restaurant);
        $items = Order::orderBy('id','DESC')
                    ->where('restaurant_id',$id_restaurant)
                    ->get();

        // print_r($items->toArray());
        // die;
        //$data = [] ;
        /*foreach($items as $key=>$item){
            $data[$key]['name'] = (isset($item->name)?$item->name:'');
            $data[$key]['mobile'] = (isset($item->mobile_no)?$item->mobile_no:'');
            $data[$key]['email'] = (isset($item->email_id)?$item->email_id:'');
            $data[$key]['discount'] = (isset($item->discount_amt)?$item->discount_amt:'');
            $data[$key]['order_no'] = (isset($item->order_no)?$item->order_no:'');
            $data[$key]['total_amount'] = (isset($item->total_amount)?$item->total_amount:'');
            $data[$key]['billing_status'] = (isset($item->billing_status)?$item->billing_status:'');
        }*/
        // print_r($data);
        // die;
        // exit('one');
        return DataTables::collection($items)
        ->addColumn('name',function ($result){
            return $result->name;
        })
        ->addColumn('mobile',function ($result){
            return $result->mobile_no;
        })
        ->addColumn('email',function ($result){
            return $result->email_id;
        })
        ->addColumn('discount',function ($result){
            return $result->discount_amt;
        })
        ->addColumn('order_no',function ($result){
            return $result->order_no;
        })
        ->addColumn('total_amount',function ($result){
            return $result->total_amount;
        })
        ->addColumn('billing_status',function ($result){
            if($result->billing_status == 1){
                return '<span style="background-color:#b3e8b3;border-block-color: inherit;
                border-radius: 40%;">Complete</span>';
            }else{
                return '<span style="background-color:#e7b65e;border-block-color: inherit;
                border-radius: 40%;">Pending</span>';
            }

        })
        ->addColumn('action',function ($result){

            $btn = "<a title = View Order List href='".route('owner.order.order_view',['order_id'=>$result['id']])."' style='border:none;text-align:center;'><i class='fas fa-eye'></i></a>";

            return $btn;


        })
        ->rawColumns(['action','billing_status'])
        ->addIndexColumn()
        ->make(true);
    }
    public function orderView(Request $request,$order_id){
        return view('order.order_view',compact('order_id'));
    }

    public function orderViewData(Request $request){
        $restaurant_id = Session::get('id_restaurant');
        $items = OrderDetail::with('getOrderItems','getrestaurant')
                        ->where('order_id',$request->order_id)
                        ->where('restaurant_id',$restaurant_id)
                        ->orderBy('id','DESC')
                        ->get();
        // echo"<pre>";
        // print_r($items);
        // die;
        $data = [] ;
        foreach($items as $key=>$item){
            $data[$key]['item_name'] = (isset($item->getOrderItems->name)?$item->getOrderItems->name:'');
            $data[$key]['quantity'] = (isset($item->quantity)?$item->quantity:'');
            $data[$key]['quantity_in_variation'] = (isset($item->quantity_in_variation)?$item->quantity_in_variation:'');
            $data[$key]['amount'] = (isset($item->amount)?$item->amount:'');
            $data[$key]['notes'] = (isset($item->notes)?$item->notes:'');
            $data[$key]['status'] = (isset($item->status)?$item->status:'');
        }
        return DataTables::collection($data)
            ->addColumn('status',function ($result){
                if($result['status'] == 1){
                    return '<span style="background-color:#b3e8b3;border-block-color: inherit;
                    border-radius: 40%;">Complete</span>';
                }else if($result['status'] == 0){
                    return '<span style="background-color:#e7b65e;border-block-color: inherit;
                    border-radius: 40%;">Pending</span>';
                }else if($result['status'] == 2){
                    return '<span style="background-color:#b9c1ee;border-block-color: inherit;
                    border-radius: 40%;">Accept By Chef</span>';
                }else{
                    return '<span style="background-color:#e6acae;border-block-color: inherit;
                    border-radius: 40%;">Cancel</span>';
                }

            })
        ->rawColumns(['status'])
        ->addIndexColumn()
        ->make(true);
    }
}
