<?php
namespace App\Http\Controllers\Owner;

use App\Models\User;
use App\Models\Facility;
use App\Models\Restaurant;
use App\Models\WeeklyHour;
use App\Models\CuisineType;
use App\Models\RestaurantImage;
use App\Models\RestaurantChef;
use App\Models\RestaurantHoliday;
use App\Models\RestaurantFacility;
use App\Models\RestaurantCuisineType;
use App\Models\RestaurantFloor;
use App\Models\Category;
use App\Models\Tag;
use App\Models\VipTag;
use App\Models\VipUser;

use App\Models\Booking;

use Illuminate\Http\Request;

use Carbon\Carbon;
use Carbon\CarbonPeriod;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use DB,Storage,Hash;
use DataTables;


class RestaurantController extends Controller
{
	public function index(){	


		if(Auth::user()->type == 1) {
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->orderBy('id','desc')->paginate(10);
		}

		elseif (Auth::user()->type == 2) {
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->where('user_id',Auth::user()->id)->orderBy('id')->paginate(10);
			if (count($restaurants)) { 
			session()->put('id_restaurant',$restaurants[0]->id);
			} else {
				return redirect()->route('owner.restaurant.add');
			}
		} 
		elseif (Auth::user()->type == 3) {     
			session()->put('id_restaurant',Auth::user()->restaurant_id); 
		}
		return redirect()->route('owner.restaurant.floorManagement');
	} 



public function ownerBookingList()
 {   
  $categories = Category::pluck('name','id');
  $tags = Tag::pluck('name','id');			

  return view('bookingList',['categories'=>$categories, 'tags'=>$tags]);
 }	
public function ownerBookingListfn(Request $request)
 {
  		
		
		$restaurant_arr = Restaurant::where('user_id', '=', Auth::user()->id)->select('id','name');
        $restaurant_arr_data = $restaurant_arr->get();
		$restaurant_ids = array();
		if(isset($restaurant_arr_data) && count($restaurant_arr_data) > 0)
		{
		foreach($restaurant_arr_data as $restids)
		{
		 $restaurant_ids[] = $restids['id'];
		}
		}
		
		$booking = Booking::join('restaurants','restaurants.id','=','bookings.restaurant_id')
                 ->join('users','users.id','=','bookings.user_id')
                 ->join('categories','categories.id','=','bookings.category_id')
                 ->join('tags','tags.id','=','bookings.tag_id')
				 ->whereIn('bookings.restaurant_id',$restaurant_ids);
				  
				 if(isset($request->status) && $request->status != '')
				  {
				   $booking->where('bookings.status',$request->status);
                  }
				  
				 if(isset($request->tag_id) && $request->tag_id != '')
				  {
				   $booking->where('bookings.tag_id', $request->tag_id);
                  }
				  
				 if(isset($request->category_id) && $request->category_id != '')
				  {
				   $booking->where('bookings.category_id',$request->category_id);
                  }
				 
				 //$booking->whereBetween('bookings.created_at', [$start_date, $end_date]) 
				 if(isset($request->from_date) && $request->from_date != '')
				  {
				   //$start_date = date("Y-m-d", strtotime($request->from_date)).' '.date("H:i:s");
				   $start_date = $request->from_date;
				   $booking->where('bookings.for_date', '>=', $start_date);
                  }
				  
				 if(isset($request->to_date) && $request->to_date != '')
				  {
				   //$end_date = date("Y-m-d", strtotime($request->to_date)).' '.date("H:i:s");
				   $end_date = $request->to_date;
				   $booking->where('bookings.for_date', '<=', $end_date);
                  }
				 
				 if(isset($request->month) && $request->month != '')
				  {
				   //echo $request->month; die;   //July 2021
				   $month = date('m');
				   $year = date('Y');
				   $month_year_data = explode(" ", $request->month);
				   if($month_year_data[0] == 'January') { $month = 1; }
				   if($month_year_data[0] == 'February') { $month = 2; }
				   if($month_year_data[0] == 'March') { $month = 3; }
				   if($month_year_data[0] == 'April') { $month = 4; }
				   if($month_year_data[0] == 'May') { $month = 5; }
				   if($month_year_data[0] == 'June') { $month = 6; }
				   if($month_year_data[0] == 'July') { $month = 7; }
				   if($month_year_data[0] == 'August') { $month = 8; }
				   if($month_year_data[0] == 'September') { $month = 9; }
				   if($month_year_data[0] == 'October') { $month = 10; }
				   if($month_year_data[0] == 'November') { $month = 11; }
				   if($month_year_data[0] == 'December') { $month = 12; }
				   $year = $month_year_data[1];
			$booking->whereMonth('bookings.for_date', $month)->whereYear('bookings.for_date', $year);
                  }
				  
				 if(isset($request->week) && $request->week != '')
				  {
				   //echo $request->week; die;  //2021-W01
				   $week = date('W');
				   $year = date('Y');
				   
				   $year_week_data = explode("-", $request->week);
				   $year = $year_week_data[0];
				   $week = substr($year_week_data[1], 1);
                   
				   $week_start_date = date('Y-m-d');
				   $week_end_date = date('Y-m-d');
				   
				  $date_string = $year . 'W' . sprintf('%02d', $week);
				  $week_start_date = date('Y-n-j', strtotime($date_string));
				  $week_end_date = date('Y-n-j', strtotime($date_string . '7'));
  
				  $booking->whereBetween('bookings.for_date', [$week_start_date, $week_end_date]);
                  } 
				  
				 if(isset($request->daily) && $request->daily != '' && $request->daily == 'today')
				  {
				   $today_date = date('Y-m-d'); 
				   $booking->where('bookings.for_date', '=', $today_date);
                  }  

//current date			      
//$booking->whereDate('bookings.for_date', Carbon::today());  

//current week
//$booking->whereBetween('bookings.for_date', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()]);

//current month
//$booking->whereMonth('bookings.for_date', date('m'))->whereYear('bookings.for_date', date('Y'));   
				  
				 $booking->select('bookings.id','bookings.for_date','bookings.for_time','bookings.status as status','bookings.created_at as month','restaurants.name as Rname','users.name as Uname','categories.name as Cname','tags.name as Tname');
				 
				  
        $booking = $booking->get();
		
		
               
		
		//$booking = $booking->toSql();
		//dd($booking); die;
		
        return DataTables::collection($booking)
		    
			->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('restaurant',function ($result){
            return $result->Rname;
        })
            ->addColumn('user',function ($result){
            return $result->Uname;
        })
            ->addColumn('category',function ($result){
            return $result->Cname;
        })
            ->addColumn('tag',function ($result){
            return $result->Tname;
        })
            ->addColumn('status',function ($result){
			if($result->status == 0)
			{
			 return 'Pending';
			}
			elseif($result->status == 1)
			{
			 return 'Confirm';
			}
			elseif($result->status == 2)
			{
			 return 'Cancelled';
			}
			else  //3
			{
			 return 'Denied';
			}
        })
            ->addColumn('booking_date',function ($result){
            return $result->for_date.' '.$result->for_time;
        })
		    /*->addColumn('created_date',function ($result){
            return $result->month;
        })*/
		
        ->make(true);
		
	
 }
	
	

	public function restaurantlist(Request $request){	
		//$data = $request->all();	
		if(Auth::user()->type != 1)
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->where('user_id',Auth::user()->id)->orderBy('id','desc')->paginate(120);
		else
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->orderBy('id','desc')->paginate(120);
		return view('restaurant.list',['restaurants'=>$restaurants]);
	}


public function booking_status_change(Request $request){
        
 $id = $request->input('id'); 
 //$type = $request->input('type'); 
 $res_data = Booking::find($id);
 $res_data->status = 1;
 $res_data->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$res_data]);
    }
	
	
	public function insert(Request $request){
		$data = $request->all();
		//print_r($data);die;
		$rules=[
			'name'=>'required|max:50',
			'min_payment'=>'required|min:0',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric',
			'images.*'=>'mimes:png,jpeg,jpg,webp',
			'images_360.*'=>'mimes:png,jpeg,jpg,webp',
			'menu_files.*'=>'mimes:png,jpeg,jpg,webp,pdf'
		];
		$request->validate($rules);
		$restaurant = new Restaurant;
		$restaurant->user_id = Auth::user()->id;
		$restaurant->name = ucwords($data['name']);
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];
		$restaurant->home_delivery = $data['home_delivery'];
		$restaurant->min_payment = $data['min_payment'];
		$restaurant->takeout = $data['takeout'];
		$restaurant->mobile = $data['mobile'];
		$restaurant->email = $data['email'];
		$restaurant->address = $data['address'];
		$restaurant->notes = $data['notes'];
		$restaurant->website = $data['website'];
		$restaurant->description = $data['description'];
		$restaurant->online_book_tnc = $data['online_book_tnc'];
		$restaurant->notification_emails = $data['notification_emails'];
		$restaurant->notification_mobiles = $data['notification_mobiles'];
		$restaurant->open_status = $data['open_status'];
		$restaurant->expensiveness = $data['expensive'];
		$restaurant->status = 0;

		
	
 		 
		if( $restaurant->save() ){ 

			if (isset($data['occasion_name']) and isset($data['occasion_date'])) {
				$holidays = [];
				foreach ($data['occasion_name'] as $key => $value) {
					$holidays[] = ['occasion'=>$value,'date'=> date('Y-m-d',strtotime($data['occasion_date'][$key])) ,'restaurant_id'=>$restaurant->id]; 
				}
					RestaurantHoliday::insert($holidays);
			}	

			$upload_cuisine_type_array = [];
			if (isset($data['cuisine_type_id'])) {
				foreach ($data['cuisine_type_id'] as $key => $value) {
					$upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
				}

				$restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();   
				if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) { 
					RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
					RestaurantCuisineType::insert($upload_cuisine_type_array); 
				}
			} else {
				if ($request->restaurant_cuisine_types_saved != "") { 
				RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
				}
			}


		$upload_facility_array = [];
		if (isset($data['facility_id'])) {
		foreach ($data['facility_id'] as $key => $value) {
			$upload_facility_array[] = array('restaurant_id'=>$restaurant->id,'facility_id'=>$value);
		}

		$restaurant_facility_array = RestaurantFacility::where('restaurant_id',$restaurant->id)->pluck('facility_id')->toArray();   
		if (!empty(array_diff($data['facility_id'], $restaurant_facility_array)) || !empty(array_diff($restaurant_facility_array,$data['facility_id']))) { 
		RestaurantFacility::where('restaurant_id',$restaurant->id)->delete(); 
		RestaurantFacility::insert($upload_facility_array); 
		}
		} else {
		if ($request->restaurant_facilities_saved != "") { 
		RestaurantFacility::where('restaurant_id',$restaurant->id)->delete(); 
		}
		}


			if (isset($data['images'])) {
			$images = [];
			foreach($data['images'] as $image) {  
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);
			$images[] = [
				'restaurant_id' => $restaurant->id,
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 1
			];
			} 
			RestaurantImage::insert($images);
		}

		if (isset($data['images_360'])) {
			$images_360 = [];
			foreach($data['images_360'] as $image) {  
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);
			$images_360[] = [
				'restaurant_id' => $restaurant->id,
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 2

			];
			}
			RestaurantImage::insert($images_360);
		}

		if (isset($data['menu_files'])) {
			$menu_files = [];
			foreach($data['menu_files'] as $image) {  
			$directory = 'restaurant_menu_files';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			); 
			$menu_files[] = [
				'restaurant_id' => $restaurant->id,
				'image' => $directory.'/'.$image_name,
				'doc_for' => 2,
				'doc_type' => $image->extension() != 'pdf' ? 1 : 2,
				'image_type' => 1

			];
			}
			RestaurantImage::insert($menu_files);
		}
		$chef_name = $data['chef_name'];
		$chef_mobile = $data['chef_mobile'];
		$chef_fb_link = $data['chef_fb_link'];
		$chef_insta_link = $data['chef_insta_link'];

		if (isset($data['chef_image'])) 
		{
			 
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$data['chef_image']->extension();
			$data['chef_image']->storeAs(
	    	'public/'.$directory, $image_name
			);
			$values[] = [
				'restaurant_id' => $restaurant->id,
				'chef_name' => $chef_name,
				'chef_mobile' => $chef_mobile,
				'chef_fb_link' => $chef_fb_link,
				'chef_insta_link' => $chef_insta_link,
				'chef_image' => $directory.'/'.$image_name,
				
			];
			
			DB::table('restaurant_chef')->insert($values);
		}

		

		$WeeklyHour = WeeklyHour::where('restaurant_id',$restaurant->id)->first();

		if (empty($WeeklyHour)) {
		WeeklyHour::create([
			'restaurant_id' => $restaurant->id,
			'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
			'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
			'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
			'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
			'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
			'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
		]);
		} else {
		WeeklyHour::where('restaurant_id',$restaurant->id)->update([
			'mon_from' => $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time,
			'fri_from' => $request->friday_open_time,
			'sat_from' => $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time,
			'mon_to' => $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time,
			'fri_to' => $request->friday_close_time,
			'sat_to' => $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time,
		]);
		}


			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant added successfully.');
		}
		return view('restaurant.add');
	}

	public function edit($id){


		$restaurant = Restaurant::where('id',$id)->where('user_id',Auth::user()->id)->first();
		$countries = DB::table("countries")->pluck("country_name","id");
		$cities = DB::table("cities")->pluck("city_name","id");
		$openingHours = WeeklyHour::where('restaurant_id',$id)->first();

		if (!empty($openingHours)) {
			$openingHours = $openingHours->toArray();
		}
		if(!$restaurant){
			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant not found.');
		}

		$cuisineTypes = CuisineType::pluck("name","id"); 
		$facilities = Facility::pluck("name","id"); 



		$restaurantCuisineTypes = RestaurantCuisineType::where('restaurant_id',$id)->pluck('cuisine_type_id')->toArray();  	
		$restaurantHolidays = RestaurantHoliday::where('restaurant_id',$id)->select('id','date','occasion')->get()->toArray();  	 
		$restaurantFacilities = RestaurantFacility::where('restaurant_id',$id)->pluck('facility_id')->toArray();  
		$restaurantChef= 	DB::table('restaurant_chef')->where('restaurant_id',$id)->first();
		$homeDeliveryArray = ['No','Yes'];
		$openStatusArray = ['Closed','Open'];
		$images = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',1)->get(); 
		$images_360 = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',2)->get();
		$menu_files = RestaurantImage::where('restaurant_id',$id)->where('doc_for',2)->get();

	//	print_r($restaurant);die;
		return view('restaurant.add',['countries'=>$countries,'restaurant'=>$restaurant,'cities'=>$cities,'openingHours'=>$openingHours,'cuisineTypes'=>$cuisineTypes,'restaurantCuisineTypes'=>$restaurantCuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray,'restaurantFacilities'=>$restaurantFacilities,'facilities'=>$facilities,'restaurantHolidays'=>$restaurantHolidays,'images'=>$images,'images_360'=>$images_360,'menu_files'=>$menu_files,'restaurantChef'=>$restaurantChef]);
	}

	public function update(Request $request){
		$data = $request->all(); 
		$rules= [
			'id'=>'required|numeric',
			'name'=>'required|max:50',
			'min_payment'=>'required|min:0',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric',
			'images.*'=>'mimes:png,jpeg,jpg,webp',
			'images_360.*'=>'mimes:png,jpeg,jpg,webp',
			'menu_files.*'=>'mimes:png,jpeg,jpg,webp,pdf'
		];
		$request->validate($rules);

		$restaurant = Restaurant::where('id',$data['id'])->where('user_id',Auth::user()->id)->first();
		if(!$restaurant){
			return redirect()->route('owner.restaurant.list')->with('success','Restaurant not found.');
		}
		$restaurant->name = ucwords($data['name']);
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];
		$restaurant->home_delivery = $data['home_delivery'];
		$restaurant->min_payment = $data['min_payment'];
		$restaurant->takeout = $data['takeout'];
		$restaurant->mobile = $data['mobile'];
		$restaurant->email = $data['email'];
		$restaurant->website = $data['website'];
		$restaurant->address = $data['address'];
		$restaurant->notes = $data['notes'];
		$restaurant->description = $data['description'];
		$restaurant->online_book_tnc = $data['online_book_tnc'];
		$restaurant->notification_emails = $data['notification_emails'];
		$restaurant->notification_mobiles = $data['notification_mobiles'];
		$restaurant->open_status = $data['open_status'];
		$restaurant->expensiveness = $data['expensive'];
		

		if (isset($data['delete_holiday_list'])) {
			RestaurantHoliday::whereIn('id',explode(',', $data['delete_holiday_list']))->delete();	
		}

		if (isset($data['occasion_name']) and isset($data['occasion_date'])) {
			$holidays = [];
			foreach ($data['occasion_name'] as $key => $value) {
				$holidays[] = ['occasion'=>$value,'date'=> date('Y-m-d',strtotime($data['occasion_date'][$key])),'restaurant_id'=>$restaurant->id]; 
			}
				RestaurantHoliday::insert($holidays);
		}
		
		// print_r($data['id']);die;   
		if (isset($data['saved_occasion_name']) and isset($data['saved_occasion_date'])) { 
			foreach ($data['saved_occasion_id'] as $key => $value) {
				$restaurantHolidayFind = RestaurantHoliday::find($data['saved_occasion_id'][$key]);
				$restaurantHolidayFind->date = $data['saved_occasion_date'][$key];
				$restaurantHolidayFind->occasion = $data['saved_occasion_name'][$key];
				if ($restaurantHolidayFind->isDirty('occasion') || $restaurantHolidayFind->isDirty('date')) {
					$restaurantHolidayFind->save();
				} 
			} 
		}

		$upload_cuisine_type_array = [];
		if (isset($data['cuisine_type_id'])) {
		foreach ($data['cuisine_type_id'] as $key => $value) {
			$upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
		}

		$restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();   
		if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) { 
		RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
		RestaurantCuisineType::insert($upload_cuisine_type_array); 
		}
		} else {
		if ($request->restaurant_cuisine_types_saved != "") { 
		RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
		}
		}



		$upload_facility_array = [];
		if (isset($data['facility_id'])) {
			foreach ($data['facility_id'] as $key => $value) {
				$upload_facility_array[] = array('restaurant_id'=>$restaurant->id,'facility_id'=>$value);
			}

			$restaurant_cuisine_type_array = RestaurantFacility::where('restaurant_id',$restaurant->id)->pluck('facility_id')->toArray();   
			if (!empty(array_diff($data['facility_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['facility_id']))) { 
				RestaurantFacility::where('restaurant_id',$restaurant->id)->delete(); 
				RestaurantFacility::insert($upload_facility_array); 
			}
		} else {
			if ($request->restaurant_cuisine_types_saved != "") { 
			RestaurantFacility::where('restaurant_id',$restaurant->id)->delete(); 
			}
		}
            // START:RESTAURANT IMAGE SAVE CODE
    		//         if( $request->has('images') ){
    		//         	$restaurantImageList = [];
    		//         	foreach ($request->file('images') as $key => $imgFile) {
	   		//              $newFileName = $request->user()->id.$data['id'].time().rand(1,999999999);
	   		//              $newFileName = $newFileName.'.'.$imgFile->getClientOriginalExtension();
	   		//          	// RESTAURANT IMAGES SAVE INTO restaurant_images FOLDER
	   		//              $imgFile->move(storage_path('app/public/restaurant_images'), $newFileName);

						// 	$restaurantImageList[$key]['restaurant_id'] = $data['id'];
						// 	$restaurantImageList[$key]['image'] = $newFileName;
						// 	$restaurantImageList[$key]['doc_for'] = 1;
						// 	$restaurantImageList[$key]['doc_type'] = 1;
						// 	$restaurantImageList[$key]['image_type'] = 1;
    		//         	}
    		//         	// RESTAURANT IMAGES SAVE INTO restaurant_image TABLE
				// RestaurantImage::insert($restaurantImageList); 
    		//         }
            // END:RESTAURANT IMAGE SAVE CODE
 
		if (isset($data['images'])) {
			$images = [];
			foreach($data['images'] as $image) {  
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);

			$images[] = [
				'restaurant_id' => $data['id'],
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 1];
			}
			RestaurantImage::insert($images);
		}



		if (isset($data['images_360'])) {
			$images_360 = [];
			foreach($data['images_360'] as $image) {  

			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			// $image_name = 'hello'.'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			); 
			// $images_360[] = [
			// 	'restaurant_id' => $data['id'],
			// 	'image' => $directory.'/'.$image_name,
			// 	'doc_for' => 1,
			// 	'doc_type' => 1,
			// 	'image_type' => 2 
			// ];

			$images_360[] = [
				'restaurant_id' => $data['id'],
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 2]; 
			} 
			RestaurantImage::insert($images_360);
		}
		if (isset($data['menu_files'])) {
			$menu_files = [];
			foreach($data['menu_files'] as $image) {  
			$directory = 'restaurant_menu_files';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			); 
			$menu_files[] = [
				'restaurant_id' => $data['id'],
				'image' => $directory.'/'.$image_name,
				'doc_for' => 2,
				'doc_type' => $image->extension() != 'pdf' ? 1 : 2,
				'image_type' => 1

			];
			}
			RestaurantImage::insert($menu_files);
		}

		$chef_name = $data['chef_name'];
		$chef_mobile = $data['chef_mobile'];
		$chef_fb_link = $data['chef_fb_link'];
		$chef_insta_link = $data['chef_insta_link'];

		if (isset($data['chef_image'])) 
		{
			 
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$data['chef_image']->extension();
			$data['chef_image']->storeAs(
	    	'public/'.$directory, $image_name
			);
			$values[] = [
				'restaurant_id' => $restaurant->id,
				'chef_name' => $chef_name,
				'chef_mobile' => $chef_mobile,
				'chef_fb_link' => $chef_fb_link,
				'chef_insta_link' => $chef_insta_link,
				'chef_image' => $directory.'/'.$image_name,
				
			];
			DB::table('restaurant_chef')->where('restaurant_id',$restaurant->id)->delete(); 
			DB::table('restaurant_chef')->insert($values);
		}


		$WeeklyHour = WeeklyHour::where('restaurant_id',$request->id)->first();

		if (empty($WeeklyHour)) {
		WeeklyHour::create([
			'restaurant_id' => $request->id,
			'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
			'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
			'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
			'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
			'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
			'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
		]);
		} else {
		WeeklyHour::where('restaurant_id',$request->id)->update([
			'mon_from' => $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time,
			'fri_from' => $request->friday_open_time,
			'sat_from' => $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time,
			'mon_to' => $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time,
			'fri_to' => $request->friday_close_time,
			'sat_to' => $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time,
		]);
		}

		if (isset($request->delete_list)) {
		$restaurantImages = RestaurantImage::whereIn('id', explode(',', $request->delete_list) )->select(DB::raw('GROUP_CONCAT(id) AS ids,GROUP_CONCAT(CONCAT("public/",image)) AS images'))->first();
			if (!empty($restaurantImages) && !empty($restaurantImages->ids)) {
				RestaurantImage::whereIn('id', explode(',', $restaurantImages->ids) )->delete(); 
				Storage::delete(explode(',', $restaurantImages->images)); 
			} 
      	}

      	if($restaurant->isDirty()){
      		$restaurant->status = 0;
      	if( $restaurant->save() ){
			return redirect()->route('owner.restaurant.list')->with('success','Restaurant details updated successfully.');
		}else{
			return redirect()->route('owner.restaurant.list')->with('error','Error in: Update restaurant.');
		}
      	}
      	else{
      		return redirect()->route('owner.restaurant.list');
      	}

	
	}

	public function getCity($id){
		$getCity = DB::table("cities")->where("country_id",$id)->pluck("city_name","id");
        return json_encode($getCity);
	}

	public function delete($id){
		$restaurant = Restaurant::find($id);
		$restaurant->status = 2;
		if( $restaurant->save() ){
			return redirect()->route('owner.restaurant.list')->with('success','Restaurant deleted successfully.');
		}else{
			return redirect()->route('owner.restaurant.list')->with('error','Error in: Delete restaurant.');
		}
	}
	public function add(){
		$countries = DB::table("countries")->pluck("country_name","id");


		$cuisineTypes = CuisineType::pluck("name","id"); 
		$facilities = Facility::pluck("name","id"); 
		$restaurantCuisineTypes = [];
		$restaurantFacilities = [];

		$homeDeliveryArray = ['No','Yes'];
		$openStatusArray = ['Closed','Open'];
		return view('restaurant.add',['countries'=>$countries,'cuisineTypes'=>$cuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray,'restaurantCuisineTypes'=>$restaurantCuisineTypes,'facilities'=>$facilities,'restaurantFacilities'=>$restaurantFacilities]);
	}
	public function account(){
		$account = Auth::user();		 
		return view('restaurant.account',['account'=>$account]);
	}

	public function updateAccount(Request $request){
		$request->validate([
		'name' => 'required',
		'password' => 'nullable|string|confirmed|min:8'
		]);

		$formData  = [
			'name'	=> $request->name,
		];
		$formData['password'] = Hash::make($request->password); 
		User::where('id',Auth::id())->update($formData);
		 
		$account = User::find(Auth::id());
		return redirect()->route('owner.account.detail');
	}

	public function logout(Request $request) {
        Auth::logout();
        // return redirect('/login');
        return redirect()->Route('owner.login');
    }

    public function floorManagement(Request $request){
    	// echo "hello";
    	// exit;
		$data = $request->all();
		$id_restaurant = session('id_restaurant');	

		$restaurantDetail = DB::table('restaurant_floors')
		->where('restaurant_id',$id_restaurant)
		->where('type',1)
		->first();
		
		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id',	$id_restaurant)
		->orderBy('type','asc')
		->get();
		
		$bookingList = DB::table('bookings')
		->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','bookings.floor_id','bookings.table_id','bookings.table_no','restaurant_floors.name as fln','users.name')
		->join('users','bookings.user_id','=','users.id')
		->join('restaurant_floors','bookings.floor_id','=','restaurant_floors.id') // 
		->where('bookings.restaurant_id',	$id_restaurant)
		->whereOr([ ['category_id',0],['category_id',null]   ])
		->get();	

		$categoriesList = Category::with(['booking','booking.getUser'])
		->get();
	
		return view('restaurant.floor_management',['restaurant_detail'=>$restaurantDetail,'restaurant_list'=>$restaurantFloorList,'booking_list'=>$bookingList,'categories_list'=>$categoriesList,'restaurant_id'=>	$id_restaurant]);

    }

    public function editFloor(Request $request){
		$data = $request->all();
		$id = session('id_restaurant');
		$restaurantDetail = DB::table('restaurant_floors')
		->where('restaurant_id',$id)
		->where('type',1)
		->first();
		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id',$id)
		->orderBy('type','asc')
		->get();

		$bookingList = DB::table('bookings')
		->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','users.name')
		->join('users','bookings.user_id','=','users.id')
		->where('bookings.restaurant_id',$id)
		->whereOr([ ['category_id',0],['category_id',null]   ])
		->get();
		$categoriesList = Category::with(['booking','booking.getUser' ])
		->get();
		return view('restaurant.edit_floor',['restaurant_detail'=>$restaurantDetail,'restaurant_list'=>$restaurantFloorList,'booking_list'=>$bookingList,'categories_list'=>$categoriesList,'restaurant_id'=>$id]);

    }

	public function saveRestaurantFloor(Request $request){
		$data = $request->all();
		$response = ['status'=>0,'msg'=>'invalid Request'];
		if( isset($data['restaurant_floor_id']) ){
				$data['table_view'] = isset($data['table_view'])?$data['table_view']:null;
				$data['floor_info'] = isset($data['floor_info'])?$data['floor_info']:null;
				$data['floor_name'] = isset($data['floor_name'])?ucwords($data['floor_name']):null;

    			// $restaurantDetail = DB::table('restaurant_floors')
    			// ->where('restaurant_id',$data['restaurant_id'],)
    			// ->where('id',$data['restaurant_floor_id'],)
    			// ->first();
				$updateData = ['floor_table_view'=>$data['table_view'],'floor_info'=>$data['floor_info'], 'name' => $data['floor_name']];
				$result = DB::table('restaurant_floors')
				->where('id',$data['restaurant_floor_id'])
				->update($updateData); 
			if($result)
				$response = ['status'=>1,'msg'=>'Floor view saved successfully'];
			else
				$response = ['status'=>0,'msg'=>'Error in: insert request'];

		}
		return $response;
	}

	public function getRestaurantFloorDetail(Request $request){
		$data = $request->all();
		$restaurantDetail = DB::table('restaurant_floors')
		->where('id',$data['restaurant_floor_id'])
		->first();

		$floorname = DB::table('restaurant_floors')
		->select('name')
		->where('id',$data['restaurant_floor_id'])
		->first();

		$bookingsDetail = DB::table('bookings')
		->where('floor_id',$data['restaurant_floor_id'])
		->get();
	
		if(!$restaurantDetail){
			$response = ['status'=>0,'msg'=>'Error in: not found'];
		}else{
			if(!$bookingsDetail){
				$bdata = '';
			}else{
				$bdata = $bookingsDetail;
			}			
			$response = ['status'=>1,'msg'=>'Restaurant Detail','data'=>$restaurantDetail, 'bdata'=> $bdata, 'floorname'=> $floorname];
		}			
		return $response;
	}

	public function createFloor(Request $request){		
		$data = $request->all();
		// print $data['restaurant_id'];die;
		if (RestaurantFloor::where('restaurant_id',$data['restaurant_id'])
		->where('name',ucwords($data['floor_name']))
		->exists()) {
			$response = ['status'=>0,'msg'=>'Restaurant Floor already created.'];
		}else{
			$restaurantFloor = new RestaurantFloor;
			$restaurantFloor->restaurant_id=$data['restaurant_id'];
			$restaurantFloor->type=2;
			$restaurantFloor->name=ucwords($data['floor_name']);
			if($restaurantFloor->save())
				$response = ['status'=>1,'msg'=>'Restaurant create Floor.','data'=>$restaurantFloor];
			else
				$response = ['status'=>0,'msg'=>'Error in : Create Restaurant Floor.'];
		}	
		return $response;
	}

	public function deleteRestaurantFloor(Request $request){
		$data = $request->all();
		if( isset($data['delete_restaurant_floor_id']) ){
			$restaurantFloor = new RestaurantFloor;			
			if (Booking::where('floor_id', '=',$data['delete_restaurant_floor_id'])->exists()) {
				$response = ['status'=>0,'msg'=>'Default Restaurant Floor have Booking.'];
			}else{
				$restaurantFloorDetail = $restaurantFloor->where('id',$data['delete_restaurant_floor_id'])->first();
				if($restaurantFloorDetail->type !=1){
					$deleteStatus = $restaurantFloorDetail->delete();
					if($deleteStatus){
						$response = ['status'=>1,'msg'=>'Delete successfully.'];
					}else{
						$response = ['status'=>0,'msg'=>'Error in : Delete Restaurant Floor.'];
					}				
				}else{
					$response = ['status'=>0,'msg'=>'Default Restaurant Floor can\'t be delete.'];				
				}			
			}			
		}else{
			$response = ['status'=>0,'msg'=>'Invalid request.'];			
		}
		return $response;
	}

	public function deleteRestaurantFloorTable(Request $request)
	{
		$data = $request->all();
		if( isset($data['delete_table_id']) ){
			if (Booking::where('table_id', '=',$data['delete_table_id'])->exists()) {
				$response = ['status'=>0,'msg'=>'Table has a booking.'];
			}else{
				$response = ['status'=>1,'msg'=>''];
			}		
		}else{
			$response = ['status'=>0,'msg'=>'Invalid request.'];			
		}
		return $response;

	}

	public function bookingSave(Request $request){
		$data = $request->all();
		$rules = [
			'user_id'=>'required',
			'no_of_person'=>'required',
			'for_date'=>'required',
			'for_time'=>'required',
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			$response = ['status'=>false,'msg'=>$validation_error[0]];
		}else{

			$dateArr = explode('/', $data['for_date']);
			$newDateFormat = $dateArr['2'].'/'.$dateArr['1'].'/'.$dateArr['0'];
			$insertData = ['restaurant_id'=>1,'user_id'=>$data['user_id'],'no_of_person'=>$data['no_of_person'],'for_date'=>$newDateFormat,'for_time'=>$data['for_time']];
			$insertResult = DB::table('bookings')->insert($insertData);
			if($insertResult){
				$response = ['status'=>true,'msg'=>'Booking saved successfully'];
			}else{
				$response = ['status'=>false,'msg'=>'Booking request Failed'];				
			}
		}
		return $response;

	}

	public function updateCategoryOfBooking(Request $request){
		$data = $request->all();
		foreach ($data['category_booking'] as $bookingId => $booking){
			$affectedRows = Booking::where('id',$data['category_booking']['booking_id'])
			->update( [
				'for_time'=>($data['category_booking']['for_time']==0?0:$data['category_booking']['for_time']),
				'for_date'=>($data['category_booking']['for_date']==0?0:$data['category_booking']['for_date']),
				'no_of_person'=>($data['category_booking']['no_of_person']==0?0:$data['category_booking']['no_of_person']),

					'category_id'=>($data['category_booking']['category_id']==0?0:$data['category_booking']['category_id']),
					'floor_id'=>($data['category_booking']['floor_id']==0?0:$data['category_booking']['floor_id']),
					'table_id'=>($data['category_booking']['table_id']==0?0:$data['category_booking']['table_id']),
					'table_no'=>($data['category_booking']['table_no']==0?0:$data['category_booking']['table_no']),
					'tag_id'=>($data['category_booking']['tag_id']==0?0:$data['category_booking']['tag_id']),			
					'status'=>($data['category_booking']['booking_status']==0?0:$data['category_booking']['booking_status'])
				] );
				
			$floor_name = DB::table('restaurant_floors')
             ->select('name')
             ->where('id','=', $data['category_booking']['floor_id'])
             ->first();

			 $new_time =  Carbon::parse($data['category_booking']['for_time'])->format('g:i A');	
			$resp = [
				'for_time'=>$new_time,
				'for_date'=>$data['category_booking']['for_date'],
				'no_of_person'=>$data['category_booking']['no_of_person'],
				'category_id'=>$data['category_booking']['category_id'],
				'floor_name'=>$floor_name->name,
				'table_id'=>$data['category_booking']['table_id'],
				'table_no'=>$data['category_booking']['table_no'],
				'status'=>true,'msg'=>'Category successfully update in booking'];
		}

		return $resp;
	}

	public function bookingUpdate(Request $request){
		$data = $request->all();
		$updateField = ['table_no'=>$data['table_no'],'status'=>$data['status']];
		$result = Booking::where('id', $data['booking_id'])->update($updateField);
		if($result){
			$response = ['status'=>true,'msg'=>'Booking Confirmed','booking_id'=>$data['booking_id']];
		}else{
			$response = ['status'=>false,'msg'=>'Booking Confirmed','booking_id'=>$data['booking_id']];
		}
		return $response;
	}	

	public function bookingDetail(Request $request){

		if($request->ajax()){
			$data = $request->all();
			$categoryList = Category::pluck('name','id');
			$tagList = Tag::pluck('name','id');		
			$restaurantfloorslist = RestaurantFloor::where('restaurant_id',$data['restaurant_id'])->pluck('name','id');
			$restauranttableslist = RestaurantFloor::select('floor_table_view')->where('id',$data['floor_id'])->first();	
	

			$bookingDetail = Booking::
			select('bookings.id as booking_id','bookings.floor_id','bookings.table_id','bookings.table_no','bookings.tag_id', 'bookings.status','bookings.category_id','bookings.no_of_person','bookings.for_date','bookings.for_time','users.name as user_name','users.mobile as mobile','categories.id as categories_id','categories.name as categories_name')
			->leftJoin('categories','categories.id','=','bookings.category_id')
			->join('users','bookings.user_id','=','users.id')
			->where('bookings.id',$data['booking_id'])
			->first();
			
			if($bookingDetail->booking_id > 0){
				$response = ['status'=>true,'msg'=>'Booking Detail','booking_detail'=>$bookingDetail,'category_list'=>$categoryList, 'tag_list'=>$tagList, 'floor_list'=>$restaurantfloorslist, 'table_list'=>$restauranttableslist];
			}else{
				$response = ['status'=>false,'msg'=>'Booking Confirmed'];
			}
		}else{
			$response = ['status'=>false,'msg'=>'Request is invalid'];
		}
		return $response;
	}
	


	
	
	/////////////////////////////////////////[fresh]///////////////////////////////////
	public function bookingNew(Request $request)
	{		
		$id_restaurant = session('id_restaurant');
		$bookings = Booking::
		select('bookings.user_id As user_id','bookings.restaurant_id  As restaurant_id','users.name','users.email','users.mobile','users.image')
		->distinct('user_id')
		->leftJoin('users','bookings.user_id','=','users.id')
		->where('users.type',4)
		->where('bookings.restaurant_id',$id_restaurant)
		->get();

		$restaurantUserList = [];  
		$resUserList = $bookings->map(
			function($items){
				$restaurantUserList ['user_id'] = $items->user_id; 
				$restaurantUserList ['name'] = $items->name; 
				$restaurantUserList ['email'] = $items->email; 
				$restaurantUserList ['mobile'] = $items->mobile; 
				$restaurantUserList ['image'] = $items->image; 
				$restaurantUserList ['total_record'] = Booking::where('user_id',$items->user_id)->where('restaurant_id',$items->restaurant_id)->count();
				$restaurantUserList ['visit'] = Booking::where('user_id',$items->user_id)->where('restaurant_id',$items->restaurant_id)->where('table_visit',2)->where('status',1)->count();
				$restaurantUserList ['cancel'] = Booking::where('user_id',$items->user_id)->where('restaurant_id',$items->restaurant_id)->where('table_visit',0)->where('status',2)->count();
				return $restaurantUserList;
				}
			);

		$categories = Category::pluck('name','id');
		$tags = Tag::pluck('name','id');			
		$floors = RestaurantFloor::where('restaurant_id',$id_restaurant)->pluck('name','id');
		
		return view('restaurant.booking',['restaurant_id'=>$id_restaurant, 'userlist'=> $resUserList,'categories'=>$categories, 'tags'=>$tags, 'floors'=>$floors]);
	}

	public function bookingby(Request $request)
	{	
		if($request->ajax()){
			$data = $request->all();
			$userdata = "";
			if($data['serchdata']!=null){				
				if(is_numeric($data['serchdata'])){
					$userdata = User::select('id','name','email','mobile')->where('type',4)->where('mobile',$data['serchdata'])->first();
				}elseif(filter_var($data['serchdata'], FILTER_VALIDATE_EMAIL)){
					$userdata = User::select('id','name','email','mobile')->where('type',4)->where('email',$data['serchdata'])->first();	
				}else{
					$userdata = User::select('id','name','email','mobile')->where('type',4)->where('name',$data['serchdata'])->first();	
				}
			}else{
				
				$response = ['status'=>false,'msg'=>'fill valid value'];
			}

			if($userdata != null){
				$response = ['status'=>true,'msg'=>'user exists' , 'data'=> $userdata];
				
			}else{
				$response =['status'=>false,'msg'=>'user not exists' , 'data'=> ''];
			}	

			return $response;
		}
	
	}

	public function tablelistbyfloorid(Request $request)
	{
		$data = $request->all();
		$tableslist = RestaurantFloor::select('floor_table_view')->where('id',$data['floor_id'])->first();
		$response = ['table_list'=>$tableslist];
		return $response;
	}

	public function newbooking(Request $request)
	{
		$data = $request->all();
		$rules = [
			'user_id'=>'required',
			'res_id' => 'required',
			'no_of_person'=>'required',
			'for_date'=>'required',
			'for_time'=>'required'
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{
			$booking = new Booking;
			$booking->restaurant_id = $data['res_id'];
			$booking->user_id = $data['user_id'];
			$booking->for_time = $data['for_time'];
			$booking->for_date = $data['for_date'];
			$booking->no_of_person = $data['no_of_person'];
			$booking->status = $data['booking_status'];
			$booking->category_id = $data['category_id'];
			$booking->tag_id = $data['tag_id'];
			$booking->floor_id = $data['floor_id'];
			$booking->table_id = $data['table_id'];
			$booking->table_no = $data['table_no'];
			if($booking->save()){			
				return redirect()->route('owner.restaurant.bookingNew')->with('success','Booking added successfully. booking is '.$booking->id);			
			}
		
		}
	}

	public function newreservation(Request $request)
	{
		$data = $request->all();
		$rules = [
			'user_id'=>'required',
			'res_id' => 'required',
			'no_of_person'=>'required',
			'for_date'=>'required',
			'for_time'=>'required',
			'table_id'=>'required'
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{
			$booking = new Booking;
			$booking->restaurant_id = $data['res_id'];
			$booking->user_id = $data['user_id'];
			$booking->for_time = $data['for_time'];
			$booking->for_date = $data['for_date'];
			$booking->no_of_person = $data['no_of_person'];
			$booking->status = $data['booking_status'];
			$booking->category_id = $data['category_id'];
			$booking->tag_id = $data['tag_id'];
			$booking->floor_id = $data['floor_id'];
			$booking->table_id = $data['table_id'];
			$booking->table_no = $data['table_no'];
			if($booking->save()){			
				return redirect()->route('owner.restaurant.guestuser',['id' => $data['user_id']])->with('success','Booking added successfully. booking is '.$booking->id);			
			}
		
		}
	}

	public function addgustuser(Request $request)
	{
		$data = $request->all();
		$rules = [
			'first_name'=>'required',
			'last_name'=>'required',
			'email'=>'required|email|unique:users,email',
			'mobile'=>'required|unique:users,mobile',
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{
			$user = new User;
			$user->first_name = ucwords($data['first_name']);
			$user->last_name = ucwords($data['last_name']);
			$user->name =  ucwords($data['first_name']).' '.ucwords($data['last_name']);
			$user->email = $data['email'];
			$user->mobile = $data['mobile'];
			$user->password = Hash::make( "123123123"); 
			$user->status = 1;
			$user->type = 4;
			if($user->save()){	
				return redirect()->route('owner.restaurant.bookingNew')->with('success','New User add successfully');			
			}
		}		
		
	}

	public function setdefaultfloor($id)
	{
		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id',$id)
		->orderBy('type','asc')
		->get();
		
		return view('restaurant.defaultfloor',['restaurant_list'=>$restaurantFloorList,'res_id'=>$id]);
	}

	public function defaultfloor(Request $request)
	{
		$data = $request->all();	
		$updata = ['type'=>2];
		$result = DB::table('restaurant_floors')->where('restaurant_id', $data['res_id'])->update($updata);

		if($data['defaultfloor']!=null){
			$updatedefault = ['type'=>1];
			$upresult = DB::table('restaurant_floors')
			->where('restaurant_id', $data['res_id'])
			->where('id', $data['defaultfloor'])
			->update($updatedefault);
			return redirect()->route('owner.restaurant.list',['id' => $data['res_id']])->with('success','Default floor added successfully.');
		}
		
	}

	public function guest(Request $request)
	{	 		
		$id_restaurant = session('id_restaurant');
		$viptagList = VipTag::pluck('name','id');	

		// $users = DB::table('bookings')
		// ->select('users.name','users.id')
		// ->distinct('users.name')
		// ->join('users','bookings.user_id','=','users.id')		
		// ->where('bookings.restaurant_id',$id_restaurant )	
		// ->where('users.type', 4)	
		// ->orderBy('users.name', 'ASC')	
		// ->get();		

		$users = DB::table('users')
		->select('id','name')
		->distinct()	
		->where('type', 4)	
		->orderBy('name', 'ASC')	
		->get();


		$groupedUsers = $users->groupBy(function($item,$key) {
			return $item->name[0]; 
		})->sortBy(function($item,$key){      
			return $key;
		});
		return view('restaurant.guestlist',['users'=>$groupedUsers, 'vips'=>$viptagList]);
	}

	

	public function addvipgust(Request $request)
	{
		$data = $request->all();
		$rules = [
			'first_name'=>'required',
			//'last_name'=>'required',
			'email'=>'required|email|unique:users,email',
			'phone'=>'required|unique:users,mobile',
			'id_restaurant'=>'required',
			'updated_by'=>'required',
			'images.*'=>'mimes:png,jpeg,jpg,webp'
		];

		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{

			$user = new User;
			$user->first_name = ucwords($data['first_name']);
			$user->last_name = ucwords($data['last_name']);
			$user->name =  ucwords($data['first_name']).' '.ucwords($data['last_name']);
			$user->email = $data['email'];
			$user->mobile = $data['phone'];
			$user->password = Hash::make( "123123123"); 			
			$user->status = 1;
			$user->type = 4;

			if($request->hasfile('image')) {
				$image      = $request->file('image');						
				$directory = 'user_images';
				$imageName = time().'.'.$request->image->extension();   
				$image->storeAs('public/'.$directory, $imageName);				
				$file_name = $directory.'/'.$imageName;				
				$user->image = $file_name;
			}
	
			if($user->save()){
				if(isset($data['vip_tag']) && ($data['vip_tag'] > 0 )){
					$vipuser = new VipUser;
					$vipuser->user_id = $user->id;
					$vipuser->restaurant_id = $data['id_restaurant'];
					$vipuser->vip_tag_id = $data['vip_tag'];
					$vipuser->updated_by = $data['updated_by'];
					$vipuser->vip_note = $data['vip_note'];		
					if($vipuser->save()	){
						$vipsave = true;
					}
				}
				return redirect()->route('owner.restaurant.guestuser',$user->id)->with('success','Guest updated successfully.');
			}

		}
	}

	

	public function guestuser($id)
	{
		$selectuser = User::find($id);
		$id_restaurant = session('id_restaurant');
		$viptagList = VipTag::pluck('name','id');	

		$count = Booking::where('user_id',$id)->where('restaurant_id',$id_restaurant)->count();

		$visitcount = Booking::
		where('user_id',$id)
		->where('restaurant_id',$id_restaurant)
		->where('status',1)
		->where('table_visit',2)
		->count();
		
		$cancelcount = Booking::
		where('user_id',$id)
		->where('restaurant_id',$id_restaurant)
		->where('status',2)
		->count();
		
		$vip = VipUser::select('vip_tag_id', 'vip_note')
		->where('restaurant_id',$id_restaurant)
		->where('user_id',$id)
		->first();

		// $users = DB::table('bookings')
		// ->select('users.name','users.id')
		// ->distinct('users.name')
		// ->join('users','bookings.user_id','=','users.id')		
		// ->where('bookings.restaurant_id',$id_restaurant )	
		// ->where('users.type', 4)	
		// ->orderBy('users.name', 'ASC')	
		// ->get();

		$users = DB::table('users')
		->select('id','name')
		->distinct()	
		->where('type', 4)	
		->orderBy('name', 'ASC')	
		->get();

		$groupedUsers = $users->groupBy(function($item,$key) {
			return $item->name[0]; 
		})->sortBy(function($item,$key){      
			return $key;
		});

		$bookings = Booking::
		select('bookings.id as booking_id','bookings.floor_id','restaurant_floors.name as floor_name','bookings.table_id','bookings.table_no','bookings.tag_id', 'bookings.status','bookings.category_id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.table_visit','users.name as user_name','users.mobile as mobile','categories.id as categories_id','categories.name as categories_name')
		->leftJoin('categories','categories.id','=','bookings.category_id')
		->leftJoin('restaurant_floors','restaurant_floors.id','=','bookings.floor_id')
		->leftJoin('users','bookings.user_id','=','users.id')
		->where('bookings.user_id',$id)
		->where('bookings.restaurant_id',$id_restaurant)
		->get();	

		$categories = Category::pluck('name','id');
		$tags = Tag::pluck('name','id');			
		$floors = RestaurantFloor::where('restaurant_id',$id_restaurant)->pluck('name','id');
		 
		return view('restaurant.guestluser',
			[
				'users'=>$groupedUsers, 
				'selectuser'=>$selectuser, 
				'vips'=>$viptagList, 
				'bookings'=>$bookings , 
				'vip' => $vip, 
				'count'=> $count, 
				'visitcount'=> $visitcount,
				'cancelcount'=> $cancelcount,
				'categories'=>$categories,
				'tags'=>$tags,
				'floors'=>$floors,
				'id_restaurant'=>$id_restaurant
			]);
	}

	public function vipgust(Request $request)
	{
		$data = $request->all();	
		
		$rules = [
			'first_name'=>'required',
			//'last_name'=>'required',
			'email'=>'required|email|string|max:255',
			'phone'=>'required|numeric|min:10',
			'user_id'=>'required',
			'id_restaurant'=>'required',
			'updated_by'=>'required',
			'images.*'=>'mimes:png,jpeg,jpg,webp'
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{
						
			if(filter_var($data['email'], FILTER_VALIDATE_EMAIL))
			{
					$userData =  [
						'first_name'	=> ucwords($data['first_name']),
						'last_name'		=> ucwords($data['last_name']),
						'name'			=> ucwords($data['first_name']).' '.ucwords($data['last_name']),
						'email'			=> $data['email'],
						'mobile'    	=> $data['phone'],
					];	
					
					if($request->hasfile('image')) {
						$image      = $request->file('image');						
						$directory = 'user_images';
						$imageName = time().'.'.$request->image->extension();   
						$image->storeAs('public/'.$directory, $imageName);						
						$file_name = $directory.'/'.$imageName;						
						$userData =  ['image' => $file_name];						
					}
					
					$userupdate = User::where('id',$data['user_id'])->update($userData);

					if(isset($data['vip_tag']) && ($data['vip_tag'] > 0 )){

						if (VipUser::where('restaurant_id',$data['id_restaurant'])
						->where('user_id',$data['user_id'])
						->exists()) {
							$vipdata = [
								'vip_tag_id' => $data['vip_tag'],
								'updated_by' => $data['updated_by'],
								'vip_note' => $data['vip_note']	
							];
							VipUser::where('restaurant_id',$data['id_restaurant'])
							->where('user_id',$data['user_id'])
							->update($vipdata);
						
							
						}else{

							$vipuser = new VipUser;
							$vipuser->user_id = $data['user_id'];
							$vipuser->restaurant_id = $data['id_restaurant'];
							$vipuser->vip_tag_id = $data['vip_tag'];
							$vipuser->updated_by = $data['updated_by'];
							$vipuser->vip_note = $data['vip_note'];		
							if($vipuser->save()	){
								$vipsave = true;
							}
						}						
					} 		
				
				return redirect()->route('owner.restaurant.guestuser',$data['user_id'])->with('success','Guest updated successfully.');
			}else{
				return redirect()->route('owner.restaurant.guestuser',$data['user_id'])->with('danger','Error in: email not valid.');
			}
		}			
	}

	public function restaurantsTimeSlot(Request $request)
	{
		$id_restaurant = session('id_restaurant');	

		if($request->floorid!=null){
			$restaurantDetail = $request->floorid;
		}else{
			
			$restaurantDetail = RestaurantFloor::select('id')->where('restaurant_id', $id_restaurant)
			->where('type',1)
			->first()->id;
		}
				
		$restaurantFloorList = RestaurantFloor::where('restaurant_id', $id_restaurant)
		->orderBy('type','asc')
		->get();

		//dd($restaurantFloorList);

		$rts = $this->restaurantSlot();
		return view('restaurant.reservetimeslots',['rts'=>$rts, 'floorList'=>$restaurantFloorList, 'defaultfloor'=>$restaurantDetail]);
	}
	public function restaurantSlot()
	{
		$openinghour = '11:00:00';
		$closeinghour = '15:00:00';
		$maininterval = ' +60 minutes';
		$hourslots = $this->timeslots($openinghour, $maininterval, $closeinghour);
		$restaurants_slots = array_map(function ($arr){
			$mt = ' +15 minutes';
			$arr['minuteslots'] = $this->timeslots($arr['start'], $mt, $arr['end']);
			return $arr;
		},$hourslots);		
		return $restaurants_slots;
		
	}

	protected function timeslots($oh, $int ,$ch)
	{
		//$todayDate = Carbon::now()->format('H:i:m');
		$start_time = strtotime($oh);
		$end_time = strtotime($ch);
		$slot = strtotime(date('h:i A',$start_time) . $int);	
		$datytohours = [];	
		for ($i=0; $slot <= $end_time; $i++) { 	
			$datytohours[$i] = [ 
				'start' => date('h:i A', $start_time),
				'end' => date('h:i A', $slot),
			];	
			$start_time = $slot;
			$slot = strtotime(date('h:i A',$start_time) . $int);			
		}
		return $datytohours;
	}


	

}
