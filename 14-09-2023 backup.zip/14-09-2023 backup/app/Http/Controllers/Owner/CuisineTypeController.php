<?php

namespace App\Http\Controllers\Owner;

use App\Models\Restaurant;
use App\Models\WeeklyHour;
use App\Models\CuisineType;
use App\Models\RestaurantImage;
use App\Models\RestaurantCuisineType;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use DB,Storage;

class CuisineTypeController extends Controller
{
    
    public function index(){
        
        if(Auth::user()->type == 1)
            $cuisine_types = CuisineType::orderBy('id','desc')->paginate(10); 
        return view('cuisine_types.list',['cuisine_types'=>$cuisine_types]);
    }

    public function insert(Request $request){
        $data = $request->all();
        $rules=[
            'name'=>'required|max:50',
            'country_id'=>'required|numeric',
            'city_id'=>'required|numeric',
            'images.*'=>'mimes:png,jpeg,jpg,webp',
            'images_360.*'=>'mimes:png,jpeg,jpg,webp',
            'menu_files.*'=>'mimes:png,jpeg,jpg,webp,pdf'
        ];
        $request->validate($rules);
        $restaurant = new Restaurant;
        $restaurant->user_id = Auth::user()->id;
        $restaurant->name = $data['name'];
        $restaurant->country_id = $data['country_id']; 
        $restaurant->city_id = $data['city_id'];

        $restaurant->home_delivery = $data['home_delivery'];
        $restaurant->takeout = $data['takeout'];
        $restaurant->open_status = $data['open_status'];
 
        if( $restaurant->save() ){ 

        $upload_cuisine_type_array = [];
        if (isset($data['cuisine_type_id'])) {
        foreach ($data['cuisine_type_id'] as $key => $value) {
            $upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
        }

        $restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();   
        if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) { 
        RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
        RestaurantCuisineType::insert($upload_cuisine_type_array); 
        }
        } else {
        if ($request->restaurant_cuisine_types_saved != "") { 
        RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
        }
        }


            if (isset($data['images'])) {
            $images = [];
            foreach($data['images'] as $image) {  
            $directory = 'restaurant_images';
            $image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
            $image->storeAs(
            'public/'.$directory, $image_name
            );
            $images[] = [
                'restaurant_id' => $restaurant->id,
                'image' => $directory.'/'.$image_name,
                'doc_for' => 1,
                'doc_type' => 1,
                'image_type' => 1
            ];
            } 
            RestaurantImage::insert($images);
        }

        if (isset($data['images_360'])) {
            $images_360 = [];
            foreach($data['images_360'] as $image) {  
            $directory = 'restaurant_images';
            $image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
            $image->storeAs(
            'public/'.$directory, $image_name
            );
            $images_360[] = [
                'restaurant_id' => $restaurant->id,
                'image' => $directory.'/'.$image_name,
                'doc_for' => 1,
                'doc_type' => 1,
                'image_type' => 2

            ];
            }
            RestaurantImage::insert($images_360);
        }

        if (isset($data['menu_files'])) {
            $menu_files = [];
            foreach($data['menu_files'] as $image) {  
            $directory = 'restaurant_menu_files';
            $image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
            $image->storeAs(
            'public/'.$directory, $image_name
            ); 
            $menu_files[] = [
                'restaurant_id' => $restaurant->id,
                'image' => $directory.'/'.$image_name,
                'doc_for' => 2,
                'doc_type' => $image->extension() != 'pdf' ? 1 : 2,
                'image_type' => 1

            ];
            }
            RestaurantImage::insert($menu_files);
        }

        $WeeklyHour = WeeklyHour::where('restaurant_id',$restaurant->id)->first();

        if (empty($WeeklyHour)) {
        WeeklyHour::create([
            'restaurant_id' => $restaurant->id,
            'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
            'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
            'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
            'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
            'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
            'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
            'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
            'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
            'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
            'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
            'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
            'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
            'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
            'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
        ]);
        } else {
        WeeklyHour::where('restaurant_id',$restaurant->id)->update([
            'mon_from' => $request->monday_open_time,
            'tue_from' => $request->tuesday_open_time,
            'wed_from' => $request->wednesday_open_time,
            'thu_from' => $request->thursday_open_time,
            'fri_from' => $request->friday_open_time,
            'sat_from' => $request->saturday_open_time,
            'sun_from' => $request->sunday_open_time,
            'mon_to' => $request->monday_close_time,
            'tue_to' => $request->tuesday_close_time,
            'wed_to' => $request->wednesday_close_time,
            'thu_to' => $request->thursday_close_time,
            'fri_to' => $request->friday_close_time,
            'sat_to' => $request->saturday_close_time,
            'sun_to' => $request->sunday_close_time,
        ]);
        }


            return redirect('restaurants')->with('success','Restaurant added successfully.');
        }
        return view('restaurant.add');
    }

    public function edit($id){
        $restaurant = Restaurant::where('id',$id)->where('user_id',Auth::user()->id)->first();
        $countries = DB::table("countries")->pluck("country_name","id");
        $cities = DB::table("cities")->pluck("city_name","id");
        $openingHours = WeeklyHour::where('restaurant_id',$id)->first();

        if (!empty($openingHours)) {
            $openingHours = $openingHours->toArray();
        }
        if(!$restaurant){
            return redirect('restaurants')->with('success','Restaurant not found.');
        }

        $cuisineTypes = CuisineType::pluck("name","id"); 

        $restaurantCuisineTypes = RestaurantCuisineType::where('restaurant_id',$id)->pluck('cuisine_type_id')->toArray();   
        $homeDeliveryArray = ['No','Yes'];
        $openStatusArray = ['Closed','Open'];

        return view('restaurant.add',['countries'=>$countries,'restaurant'=>$restaurant,'cities'=>$cities,'openingHours'=>$openingHours,'cuisineTypes'=>$cuisineTypes,'restaurantCuisineTypes'=>$restaurantCuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray]);
    }

    public function update(Request $request){
        $data = $request->all(); 
        $rules= [
            'id'=>'required|numeric',
            'name'=>'required|max:50',
            'country_id'=>'required|numeric',
            'city_id'=>'required|numeric',
            'images.*'=>'mimes:png,jpeg,jpg,webp',
            'images_360.*'=>'mimes:png,jpeg,jpg,webp',
            'menu_files.*'=>'mimes:png,jpeg,jpg,webp,pdf'
        ];
        $request->validate($rules);
        $restaurant = Restaurant::where('id',$data['id'])->where('user_id',Auth::user()->id)->first();
        if(!$restaurant){
            return redirect('restaurants')->with('success','Restaurant not found.');
        }
        $restaurant->name = $data['name'];
        $restaurant->country_id = $data['country_id'];
        $restaurant->city_id = $data['city_id'];
        $restaurant->home_delivery = $data['home_delivery'];
        $restaurant->takeout = $data['takeout'];
        $restaurant->open_status = $data['open_status'];

        $upload_cuisine_type_array = [];
        if (isset($data['cuisine_type_id'])) {
        foreach ($data['cuisine_type_id'] as $key => $value) {
            $upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
        }

        $restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();   
        if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) { 
        RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
        RestaurantCuisineType::insert($upload_cuisine_type_array); 
        }
        } else {
        if ($request->restaurant_cuisine_types_saved != "") { 
        RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
        }
        }



            // START:RESTAURANT IMAGE SAVE CODE
    //         if( $request->has('images') ){
    //          $restaurantImageList = [];
    //          foreach ($request->file('images') as $key => $imgFile) {
       //              $newFileName = $request->user()->id.$data['id'].time().rand(1,999999999);
       //              $newFileName = $newFileName.'.'.$imgFile->getClientOriginalExtension();
       //           // RESTAURANT IMAGES SAVE INTO restaurant_images FOLDER
       //              $imgFile->move(storage_path('app/public/restaurant_images'), $newFileName);

                //  $restaurantImageList[$key]['restaurant_id'] = $data['id'];
                //  $restaurantImageList[$key]['image'] = $newFileName;
                //  $restaurantImageList[$key]['doc_for'] = 1;
                //  $restaurantImageList[$key]['doc_type'] = 1;
                //  $restaurantImageList[$key]['image_type'] = 1;
    //          }
    //          // RESTAURANT IMAGES SAVE INTO restaurant_image TABLE
                // RestaurantImage::insert($restaurantImageList); 
    //         }
            // END:RESTAURANT IMAGE SAVE CODE
 
        if (isset($data['images'])) {
            $images = [];
            foreach($data['images'] as $image) {  
            $directory = 'restaurant_images';
            $image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
            $image->storeAs(
            'public/'.$directory, $image_name
            );

            $images[] = [
                'restaurant_id' => $data['id'],
                'image' => $directory.'/'.$image_name,
                'doc_for' => 1,
                'doc_type' => 1,
                'image_type' => 1];
            }
            RestaurantImage::insert($images);
        }

        if (isset($data['images_360'])) {
            $images_360 = [];
            foreach($data['images_360'] as $image) {  
            $directory = 'restaurant_images';
            $image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
            $image->storeAs(
            'public/'.$directory, $image_name
            ); 
            $images_360[] = [
                'restaurant_id' => $data['id'],
                'image' => $directory.'/'.$image_name,
                'doc_for' => 1,
                'doc_type' => 1,
                'image_type' => 2 
            ];
            }
            RestaurantImage::create($images_360);
        }

        if (isset($data['menu_files'])) {
            $menu_files = [];
            foreach($data['menu_files'] as $image) {  
            $menu_files[] = [
                'restaurant_id' => $data['id'],
                'image' => $directory.'/'.$image_name,
                'doc_for' => 2,
                'doc_type' => $image->extension() != 'pdf' ? 1 : 2,
                'image_type' => 1

            ];
            $directory = 'restaurant_menu_files';
            $image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
            $image->storeAs(
            'public/'.$directory, $image_name
            ); 
            }
            RestaurantImage::create($menu_files);
        }

        $WeeklyHour = WeeklyHour::where('restaurant_id',$request->id)->first();

        if (empty($WeeklyHour)) {
        WeeklyHour::create([
            'restaurant_id' => $request->id,
            'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
            'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
            'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
            'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
            'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
            'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
            'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
            'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
            'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
            'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
            'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
            'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
            'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
            'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
        ]);
        } else {
        WeeklyHour::where('restaurant_id',$request->id)->update([
            'mon_from' => $request->monday_open_time,
            'tue_from' => $request->tuesday_open_time,
            'wed_from' => $request->wednesday_open_time,
            'thu_from' => $request->thursday_open_time,
            'fri_from' => $request->friday_open_time,
            'sat_from' => $request->saturday_open_time,
            'sun_from' => $request->sunday_open_time,
            'mon_to' => $request->monday_close_time,
            'tue_to' => $request->tuesday_close_time,
            'wed_to' => $request->wednesday_close_time,
            'thu_to' => $request->thursday_close_time,
            'fri_to' => $request->friday_close_time,
            'sat_to' => $request->saturday_close_time,
            'sun_to' => $request->sunday_close_time,
        ]);
        }

        if (isset($request->delete_list)) {
        $restaurantImages = RestaurantImage::whereIn('id', explode(',', $request->delete_list) )->select(DB::raw('GROUP_CONCAT(id) AS ids,GROUP_CONCAT(CONCAT("public/",image)) AS images'))->first();
            if (!empty($restaurantImages) && !empty($restaurantImages->ids)) {
                RestaurantImage::whereIn('id', explode(',', $restaurantImages->ids) )->delete();
                // print_r(explode(',', $restaurantImages->images));die;
                Storage::delete(explode(',', $restaurantImages->images)); 
            } 
        }

        if( $restaurant->save() ){
            return redirect('restaurants')->with('success','Restaurant added successfully.');
        }else{
            return redirect('restaurants')->with('error','Error in: Update restaurant.');
        }
    }

    public function getCity($id){
        $getCity = DB::table("cities")->where("country_id",$id)->pluck("city_name","id");
        return json_encode($getCity);
    }

    public function delete($id){ 
        if(RestaurantCuisineType::where('cuisine_type_id',$id)->delete() && CuisineType::where('id',$id)->delete()){
            return redirect('cuisine_types/list')->with('success','Cuisine Type deleted successfully.');
        }else{
            return redirect('cuisine_types/list')->with('error','Error in: Delete Cuisine Type.');
        }
    }
    public function add(){
        $countries = DB::table("countries")->pluck("country_name","id");
        $cuisineTypes = CuisineType::pluck("name","id"); 
        $restaurantCuisineTypes = [];

        $homeDeliveryArray = ['No','Yes'];
        $openStatusArray = ['Closed','Open'];
        return view('restaurant.add',['countries'=>$countries,'cuisineTypes'=>$cuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray,'restaurantCuisineTypes'=>$restaurantCuisineTypes]);
    }

}
