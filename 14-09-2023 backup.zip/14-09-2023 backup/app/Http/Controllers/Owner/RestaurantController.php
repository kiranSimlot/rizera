<?php

namespace App\Http\Controllers\Owner;

use App\Models\User;
use App\Models\Facility;
use App\Models\Restaurant;
use App\Models\WeeklyHour;
use App\Models\CuisineType;
use App\Models\RestaurantImage;
use App\Models\RestaurantChef;
use App\Models\RestaurantHoliday;
use App\Models\RestaurantFacility;
use App\Models\RestaurantCuisineType;
use App\Models\RestaurantFloor;
use App\Models\Category;
use App\Models\Tag;
use App\Models\VipTag;
use App\Models\VipUser;
use App\Models\UserFoodIntolerance;
use App\Models\UserAllergy;
use Session;
use App\Models\Booking;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use DB,Storage,Hash;
use DataTables;
use Str;

class RestaurantController extends Controller
{
	public function index(){


		if(Auth::user()->type == 1) {
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->orderBy('id','desc')->paginate(10);
		}

		elseif (Auth::user()->type == 2) {
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->where('user_id',Auth::user()->id)->orderBy('make_primary','desc')->paginate(10);
			if (count($restaurants)) {
			session()->put('id_restaurant',$restaurants[0]->id);
			} else {
				return redirect()->route('owner.restaurant.add');
			}
		}
		elseif (Auth::user()->type == 3) {
			session()->put('id_restaurant',Auth::user()->restaurant_id);
		}
		return redirect()->route('owner.restaurant.floorManagement');
	}



		public function ownerBookingList()
		 {
		  $categories = Category::where('status',1)->pluck('name','id');
		  $tags = Tag::where('status',1)->pluck('name','id');

		  return view('bookingList',['categories'=>$categories, 'tags'=>$tags]);
		 }



		public function ownerBookingListfn(Request $request)
		 {

		$id_restaurant = session('id_restaurant');

		$restaurant_arr = Restaurant::where('user_id', '=', Auth::user()->id)->select('id','name');
        $restaurant_arr_data = $restaurant_arr->get();
		$restaurant_ids = array();
		if(isset($restaurant_arr_data) && count($restaurant_arr_data) > 0)
		{
		foreach($restaurant_arr_data as $restids)
		{
		 $restaurant_ids[] = $restids['id'];
		}
		}



		$booking = Booking::join('restaurants','restaurants.id','=','bookings.restaurant_id')
                 ->join('users','users.id','=','bookings.user_id')
                 //->join('categories','categories.id','=','bookings.category_id')
				 ->leftJoin('categories','categories.id','=','bookings.category_id')
                 //->join('tags','tags.id','=','bookings.tag_id')
                 ->leftJoin('tags','tags.id','=','bookings.tag_id')
				 //->whereIn('bookings.restaurant_id',$restaurant_ids);
				 ->where('bookings.restaurant_id',$id_restaurant);

				 if(isset($request->search_keyword) && $request->search_keyword != '')
				  {
				   $booking->where('users.name', 'LIKE', '%'.$request->search_keyword.'%')
				           ->orwhere('users.mobile', 'LIKE', '%'.$request->search_keyword.'%')
				           ->orwhere('categories.name', 'LIKE', '%'.$request->search_keyword.'%')
						   ->orwhere('tags.name', 'LIKE', '%'.$request->search_keyword.'%');
                  }

				 if(isset($request->guest_name) && $request->guest_name != '')
				  {
				   $booking->where('users.name', 'LIKE', '%'.$request->guest_name.'%');
                  }

				 if(isset($request->status) && $request->status != '')
				  {
				   $status_ids = rtrim($request->status, ',');
				   $status_ids_arr = explode(',',$status_ids);
				   //echo $status_ids; echo "<pre>"; print_r($status_ids_arr); die;
				   $booking->whereIn('bookings.status',$status_ids_arr);
				   //$booking->where('bookings.status',$request->status);
                  }

				 if(isset($request->tag_id) && $request->tag_id != '')
				  {
				   $tag_ids = rtrim($request->tag_id, ',');
				   $tag_ids_arr = explode(',',$tag_ids);
				   $booking->whereIn('bookings.tag_id',$tag_ids_arr);
				   //$booking->where('bookings.tag_id', $request->tag_id);
                  }

				 if(isset($request->category_id) && $request->category_id != '')
				  {
				   $category_ids = rtrim($request->category_id, ',');
				   $category_ids_arr = explode(',',$category_ids);
				   $booking->whereIn('bookings.category_id',$category_ids_arr);
				   //$booking->where('bookings.category_id',$request->category_id);
                  }

				 //$booking->whereBetween('bookings.created_at', [$start_date, $end_date])
				 if(isset($request->from_date) && $request->from_date != '')
				  {
				   //$start_date = date("Y-m-d", strtotime($request->from_date)).' '.date("H:i:s");
				   $start_date = $request->from_date;
				   $booking->where('bookings.for_date', '>=', $start_date);
                  }

				 if(isset($request->to_date) && $request->to_date != '')
				  {
				   //$end_date = date("Y-m-d", strtotime($request->to_date)).' '.date("H:i:s");
				   $end_date = $request->to_date;
				   $booking->where('bookings.for_date', '<=', $end_date);
                  }

				 if(isset($request->month) && $request->month != '')
				  {
				   //echo $request->month; die;   //July 2021
				   $month = date('m');
				   $year = date('Y');
				   $month_year_data = explode(" ", $request->month);
				   if($month_year_data[0] == 'January') { $month = 1; }
				   if($month_year_data[0] == 'February') { $month = 2; }
				   if($month_year_data[0] == 'March') { $month = 3; }
				   if($month_year_data[0] == 'April') { $month = 4; }
				   if($month_year_data[0] == 'May') { $month = 5; }
				   if($month_year_data[0] == 'June') { $month = 6; }
				   if($month_year_data[0] == 'July') { $month = 7; }
				   if($month_year_data[0] == 'August') { $month = 8; }
				   if($month_year_data[0] == 'September') { $month = 9; }
				   if($month_year_data[0] == 'October') { $month = 10; }
				   if($month_year_data[0] == 'November') { $month = 11; }
				   if($month_year_data[0] == 'December') { $month = 12; }
				   $year = $month_year_data[1];
			      $booking->whereMonth('bookings.for_date', $month)->whereYear('bookings.for_date', $year);
                  }

				 if(isset($request->week) && $request->week != '')
				  {
				   //echo $request->week; die;  //2021-W01
				   $week = date('W');
				   $year = date('Y');

				   $year_week_data = explode("-", $request->week);
				   $year = $year_week_data[0];
				   $week = substr($year_week_data[1], 1);

				   $week_start_date = date('Y-m-d');
				   $week_end_date = date('Y-m-d');

				  $date_string = $year . 'W' . sprintf('%02d', $week);
				  $week_start_date = date('Y-n-j', strtotime($date_string));
				  $week_end_date = date('Y-n-j', strtotime($date_string . '7'));

				  $booking->whereBetween('bookings.for_date', [$week_start_date, $week_end_date]);
                  }

				 if(isset($request->daily) && $request->daily != '' && $request->daily == 'today')
				  {
				   $today_date = date('Y-m-d');
				   $booking->where('bookings.for_date', '=', $today_date);
                  }

				//current date
				//$booking->whereDate('bookings.for_date', Carbon::today());

				//current week
				//$booking->whereBetween('bookings.for_date', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()]);

				//current month
				//$booking->whereMonth('bookings.for_date', date('m'))->whereYear('bookings.for_date', date('Y'));

				 $booking->select('bookings.id','bookings.for_date','bookings.for_time','bookings.booking_amount','bookings.booking_by','bookings.table_no','bookings.no_of_person','bookings.status as status','bookings.created_at as month','restaurants.name as Rname','users.name as Uname','users.mobile as Umobile','categories.name as Cname','tags.name as Tname');


        $booking = $booking->get();




		//$booking = $booking->toSql();
		//print_r($booking); die;

        return DataTables::collection($booking)

			->addColumn('date',function ($result){
            return $result->for_date;
        })
			->addColumn('time',function ($result){
            return $result->for_time;
        })
			->addColumn('name',function ($result){
            return $result->Uname;
        })
			->addColumn('phone',function ($result){
            return $result->Umobile;
        })
			->addColumn('category',function ($result){
            return $result->Cname;
        })
		    ->addColumn('tag',function ($result){
            return $result->Tname;
        })
			->addColumn('capacity',function ($result){
            return $result->no_of_person;
        })
			->addColumn('table',function ($result){
            return $result->table_no;
        })
			->addColumn('booking_type',function ($result){
            if($result->booking_by == 1)
			{
			 return 'Online';
			}
			else  //2
			{
			 return 'Offline';
			}
        })
			->addColumn('status',function ($result){
            if($result->status == 4)
			{
			 return 'Visited';
			}
			elseif($result->status == 1)
			{
			 return 'Confirmed';
			}
			elseif($result->status == 2)
			{
			 return 'Cancelled';
			}
			elseif($result->status == 3)
			{
			 return 'Waiting';
			}
			else  //0
			{
			 return 'Pending';
			}
        })
			->addColumn('billing',function ($result){
            return '$ '.$result->booking_amount;
        })


            /*->addColumn('restaurant',function ($result){
            return $result->Rname;
        })
		    ->addColumn('created_date',function ($result){
            return $result->month;
        })*/

        ->make(true);


 }



	public function restaurantlist(Request $request){
		//$data = $request->all();
		if(Auth::user()->type != 1)
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->where('user_id',Auth::user()->id)->orderBy('id','desc')->where('status','!=',2)->paginate(10);
		else
			$restaurants = Restaurant::with('getCountry','getCity','getOwner')->orderBy('id','desc')->paginate(10);

		foreach($restaurants as $key => $list){
			$list->default_floor_name = DB::table('restaurant_floors')
								->where('restaurant_id',$list->id)
								->where('type',1)
								->select('name','id')
								->orderBy('type','asc')
								->first();
		}

		return view('restaurant.list',['restaurants'=>$restaurants]);
	}





	public function bookingrestaurantlist(Request $request){

		$id_restaurant = session('id_restaurant');

		if(session('id_floor') == null)
		{
		 $rest_floor_id = DB::table('restaurant_floors')->where('restaurant_id',$id_restaurant)->select('id')->first();
		 //echo "<pre>"; print_r($rest_floor_id); echo "</pre>";
		 $id_floor = '';
		 if(isset($rest_floor_id->id))
		 {
		 $id_floor = $rest_floor_id->id;
		 }
		}
		else
		{
		 $id_floor = session('id_floor');
		}
		//echo $id_floor;

		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id', $id_restaurant)
		->orderBy('id','asc')
		->get();

		$bookings = Booking::join('users','users.id','=','bookings.user_id')
		         ->leftJoin('categories','categories.id','=','bookings.category_id')
				 ->where('bookings.status',1)
				 ->where('bookings.table_reserved_status','=',1)
				 ->where('bookings.floor_id',$id_floor)
				 ->where('bookings.restaurant_id',$id_restaurant);

			$bookings->select('bookings.id','bookings.user_id','bookings.for_time','bookings.no_of_person','bookings.table_no','users.name as Uname','categories.name as Cname','bookings.reserved_table_detail','bookings.table_detail');

        $bookings = $bookings->get();

		$bookings = $bookings->toArray();

		$bookings_all = array();
		$i = 0;
		foreach($bookings as $booking)
		{

			$rr = json_decode($booking['reserved_table_detail']);
			$ff = json_decode($booking['table_detail']);

			$booking['reserved_table_detail'] =$rr;
		   	$booking['table_detail'] =$ff;




			if($booking['reserved_table_detail'] == ""){
				$booking['table_no ']=$ff[0]->table_no;
			 }else{
				$booking['table_no'] =$rr[0]->table_no;
			}

		  $allergies = '';
		  $intolerances = '';

		  $allergies = UserAllergy::select()
			->select('allergy_types.name')
			->where('users_allergies.user_id',$booking['user_id'])
			->join('allergy_types', 'allergy_types.id', '=', 'users_allergies.allergy_id')
			->pluck('allergy_types.name');
			//->get();

			$skips = ["[","]","\""];
			if(isset($allergies) && $allergies != '')
			{
            $allergies = str_replace($skips, ' ',$allergies);
			}

		  $intolerances = UserFoodIntolerance::select()
			->select('foodintolerance_types.name')
			->where('users_food_intolerance.user_id',$booking['user_id'])
			->join('foodintolerance_types', 'foodintolerance_types.id', '=', 'users_food_intolerance.food_intolerance_id')
			->pluck('foodintolerance_types.name');
			//->get();

			 if(isset($intolerances) && $intolerances != '')
			{
			 $intolerances = str_replace($skips, ' ',$intolerances);
			 }

		  $bookings_all[$i]['id'] = $booking['id'];
		  $bookings_all[$i]['user_id'] = $booking['user_id'];
		  $bookings_all[$i]['for_time'] = $booking['for_time'];
		  $bookings_all[$i]['no_of_person'] = $booking['no_of_person'];
		  $bookings_all[$i]['table_no'] = $booking['table_no'];
		  $bookings_all[$i]['Uname'] = $booking['Uname'];
		  $bookings_all[$i]['Cname'] = $booking['Cname'];
		  $bookings_all[$i]['allergies'] = $allergies;
		  $bookings_all[$i]['intolerances'] = $intolerances;

		  $i++;
		}

		//echo "<pre>"; print_r($bookings_all); die;

		return view('restaurant.bookingrestaurantlist',['bookings_all'=>$bookings_all,'restaurantFloorList'=>$restaurantFloorList,'id_floor'=>$id_floor]);

	}

	public function restauranttimeline(Request $request){

		$id_restaurant = session('id_restaurant');


		$WeeklyHour = WeeklyHour::where('restaurant_id',$id_restaurant)->first()->toArray();
		$start_time = '';
		$end_time = '';
		$today_day = date('l');   //Monday
		if($today_day == 'Monday')
		{
		  $start_time = $WeeklyHour['mon_from'];
		  $end_time = $WeeklyHour['mon_to'];
		}
		if($today_day == 'Tuesday')
		{
		  $start_time = $WeeklyHour['tue_from'];
		  $end_time = $WeeklyHour['tue_to'];
		}
		if($today_day == 'Wednesday')
		{
		  $start_time = $WeeklyHour['wed_from'];
		  $end_time = $WeeklyHour['wed_to'];
		}
		if($today_day == 'Thursday')
		{
		  $start_time = $WeeklyHour['thu_from'];
		  $end_time = $WeeklyHour['thu_to'];
		}
		if($today_day == 'Friday')
		{
		  $start_time = $WeeklyHour['fri_from'];
		  $end_time = $WeeklyHour['fri_to'];
		}
		if($today_day == 'Saturday')
		{
		  $start_time = $WeeklyHour['sat_from'];
		  $end_time = $WeeklyHour['sat_to'];
		}
		if($today_day == 'Sunday')
		{
		  $start_time = $WeeklyHour['sun_from'];
		  $end_time = $WeeklyHour['sun_to'];
		}
		$timeframes = array();
		$start_date = date('Y-m-d '.$start_time.'');
		$end_date = date('Y-m-d '.$end_time.'');
		$hourdiff = (int)round((strtotime($end_date) - strtotime($start_date))/3600, 1);  //14
		for($t = 0; $t<$hourdiff; $t++)
		{
		  if($t == 0)
		  {
		   $timestampa = strtotime($start_time);
           $timea = date('H:i', $timestampa);
		   $timeframes[$t] = $timea;
		  }
		  else
		  {
		  $timestamp = strtotime($start_time)+60*60*$t;
          $time = date('H:i', $timestamp);
		  $timeframes[$t] = $time;
		  }
		}

		$timelines = RestaurantFloor::where('restaurant_floors.restaurant_id',$id_restaurant)->where('restaurant_floors.status',1);

			$timelines->select('restaurant_floors.id','restaurant_floors.name','restaurant_floors.floor_table_view','restaurant_floors.floor_info','restaurant_floors.type');

        $timelines = $timelines->get();

		$timelines = $timelines->toArray();

		$timelines_all = array();
		$i = 0;
		foreach($timelines as $timeline)
		{

		  $total_tables = 0;

		  if(isset($timeline['floor_info']) && $timeline['floor_info'] != '')
			{
		  $floor_info_arr = json_decode($timeline['floor_info']);

		  $total_tables = $floor_info_arr->totaltables;
		  }

		  $floor_table_view_arr_pre = array();
		  if(isset($timeline['floor_table_view']) && $timeline['floor_table_view'] != '')
		   {
		    $floor_table_view_arr_pre = (array)json_decode($timeline['floor_table_view']);
		   }

		  $floor_table_view_arr = array();
		  for($k=0;$k<count($floor_table_view_arr_pre);$k++)
		  {

            $bookings = '';
            $bookings = Booking::join('users','users.id','=','bookings.user_id')
                                ->leftJoin('categories','categories.id','=','bookings.category_id')
                                ->where('bookings.status',1)
                                ->where('bookings.table_id',$floor_table_view_arr_pre[$k]->table_id)
                                ->where('bookings.floor_id',$timeline['id']);
            $bookings->select('bookings.id','bookings.user_id','bookings.for_time','bookings.for_date','bookings.no_of_person','users.name as Uname','categories.name as Cname');
            $bookings = $bookings->get();
            $bookings = $bookings->toArray();

		   $floor_table_view_arr[$k]['table_id'] = $floor_table_view_arr_pre[$k]->table_id;
		   $floor_table_view_arr[$k]['table_no'] = $floor_table_view_arr_pre[$k]->table_no;
		   $floor_table_view_arr[$k]['capacity'] = $floor_table_view_arr_pre[$k]->capacity;
		   $floor_table_view_arr[$k]['min_capacity'] = $floor_table_view_arr_pre[$k]->min_capacity;
		   $floor_table_view_arr[$k]['max_capacity'] = $floor_table_view_arr_pre[$k]->max_capacity;
		   $floor_table_view_arr[$k]['id'] = $floor_table_view_arr_pre[$k]->id;
		   $floor_table_view_arr[$k]['bookings'] = $bookings;
		  }

		  //echo "<pre>";
		  //print_r($floor_info_arr);
		  //print_r($floor_table_view_arr);
		  //die;

		  $timelines_all[$i]['id'] = $timeline['id'];
		  $timelines_all[$i]['name'] = $timeline['name'];
		  $timelines_all[$i]['floor_table_view'] = $timeline['floor_table_view'];
		  $timelines_all[$i]['floor_info'] = $timeline['floor_info'];
		  $timelines_all[$i]['type'] = $timeline['type'];

		  $timelines_all[$i]['total_tables'] = $total_tables;
		  $timelines_all[$i]['floor_table_view_arr'] = $floor_table_view_arr;

		  $i++;
		}

		//echo "<pre>"; print_r($timelines_all); die;

		return view('restaurant.restauranttimeline',['timelines_all'=>$timelines_all,'timeframes'=>$timeframes,'start_time'=>$start_time,'end_time'=>$end_time]);
	}






public function booking_status_change(Request $request){

 $id = $request->input('id');
 //$type = $request->input('type');
 $res_data = Booking::find($id);
 $res_data->status = 1;
 $res_data->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$res_data]);
    }


	public function insert(Request $request){
		$data = $request->all();

		$rules=[
			'name'=>'required|max:50',
			'ar_name'=>'required|max:50',
			'fr_name'=>'required|max:50',
			'online_book_tnc'=>'required|max:500',
			'notes'=>'required|max:500',
			'description'=>'required|max:500',
			'min_payment'=>'required|min:0',
			'home_delivery'=>'required',
			'email'=>'required|email',
			'mobile'=>'required',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric',
			'expensive'=>'required',
            'address'=>'required',
			'images.*'=>'required|mimes:png,jpeg,jpg,webp',
			'images_360.*'=>'mimes:png,jpeg,jpg,webp',
		    'cover_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=1900,min_height=500',
			'menu_files'=>'required|mimes:pdf',
			'cuisine_type_id' =>'required',
		];
		$message = [
            'cover_image.required'=>'Image is required.',
            'cover_image.mime'=>'file is not image',
            'cover_image.dimensions'=>'file size is not correct',
            'online_book_tnc.max'=>'The online book terms&conditions must not be greater than 200 characters.',
        ];
        $request->validate($rules,$message);

			if($data['latitude'] == null){
			$data['latitude']= 0.000000;
			}
			if($data['longitude'] == null){
			$data['longitude']= 0.000000;
			}
			// if($data['notes'] == '<p>&nbsp;</p>'){
			// $data['notes']= "";
			// }
			// if($data['description'] == '<p>&nbsp;</p>'){
			// $data['description']= "";
			// }


			//	print_r($data);die;
		$restaurant = new Restaurant;
		$restaurant->user_id = Auth::user()->id;
		$restaurant->name = ucwords($data['name']);
		$restaurant->ar_name = $data['ar_name'];
		$restaurant->fr_name = $data['fr_name'];
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];
		$restaurant->home_delivery = $data['home_delivery'];
		$restaurant->min_payment = $data['min_payment'];
		$restaurant->takeout = $data['takeout'];
		$restaurant->mobile = $data['mobile'];
		$restaurant->twitter_link = $data['twitter_link'];
		$restaurant->facebook_link = $data['facebook_link'];
		$restaurant->instagram_link = $data['instagram_link'];
		$restaurant->email = $data['email'];
		$restaurant->address = $data['address'];
		$restaurant->notes = $data['notes'];
		$restaurant->website = $data['website'];
		$restaurant->description = $data['description'];
		$restaurant->online_book_tnc = $data['online_book_tnc'];
		$restaurant->notification_emails = $data['notification_emails'];
		$restaurant->notification_mobiles = $data['notification_mobiles'];
		$restaurant->expensiveness = $data['expensive'];
		$restaurant->latitude = $data['latitude'];
		$restaurant->longitude = $data['longitude'];
		$restaurant->resturant_key = Str::random(8);
		$restaurant->status = 0;




		if( $restaurant->save() ){

			if (isset($data['occasion_name']) and isset($data['occasion_date'])) {
				$holidays = [];
				foreach ($data['occasion_name'] as $key => $value) {
					$holidays[] = ['occasion'=>$value,'date'=> date('Y-m-d',strtotime($data['occasion_date'][$key])) ,'restaurant_id'=>$restaurant->id];
				}
					RestaurantHoliday::insert($holidays);
			}

			$upload_cuisine_type_array = [];
			if (isset($data['cuisine_type_id'])) {
				foreach ($data['cuisine_type_id'] as $key => $value) {
					$upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
				}

				$restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();
				if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) {
					RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete();
					RestaurantCuisineType::insert($upload_cuisine_type_array);
				}
			} else {
				if ($request->restaurant_cuisine_types_saved != "") {
				RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete();
				}
			}


		$upload_facility_array = [];
		if (isset($data['facility_id'])) {
		foreach ($data['facility_id'] as $key => $value) {
			$upload_facility_array[] = array('restaurant_id'=>$restaurant->id,'facility_id'=>$value);
		}

		$restaurant_facility_array = RestaurantFacility::where('restaurant_id',$restaurant->id)->pluck('facility_id')->toArray();
		if (!empty(array_diff($data['facility_id'], $restaurant_facility_array)) || !empty(array_diff($restaurant_facility_array,$data['facility_id']))) {
		RestaurantFacility::where('restaurant_id',$restaurant->id)->delete();
		RestaurantFacility::insert($upload_facility_array);
		}
		} else {
		if ($request->restaurant_facilities_saved != "") {
		RestaurantFacility::where('restaurant_id',$restaurant->id)->delete();
		}
		}


			if (isset($data['images'])) {
			$images = [];
			foreach($data['images'] as $image) {
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);
			$images[] = [
				'restaurant_id' => $restaurant->id,
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 1
			];
			}
			RestaurantImage::insert($images);
		}

		if (isset($data['images_360'])) {
			$images_360 = [];
			foreach($data['images_360'] as $image) {
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);
			$images_360[] = [
				'restaurant_id' => $restaurant->id,
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 2

			];
			}
			RestaurantImage::insert($images_360);
		}

		if (isset($data['cover_image'])) {
		  $image=$data['cover_image'];

			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);

			RestaurantImage::insert([
						    'restaurant_id' => $restaurant->id,
							'image' => $directory.'/'.$image_name,
							'doc_for' => 1,
							'doc_type' => 1,
							'image_type' => 1,
							'default' => 1,
			]);
			}


		if (isset($data['menu_files'])) {
			$image=$data['menu_files'];

			$directory = 'restaurant_menu_files';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);

			RestaurantImage::insert([
						   'restaurant_id' => $restaurant->id,
							'image' => $directory.'/'.$image_name,
							'doc_for' => 2,
							'doc_type' => $image->extension() != 'pdf' ? 1 : 2,
							'image_type' => 1
			]);

		}


		RestaurantFloor::insert([
  					 'restaurant_id' => $restaurant->id,
  					 'name' => 'Default Floor',
  					 'type' => 1,
  					 'status' => 1,

		]);




		$chef_name = $data['chef_name'];
		$chef_mobile = $data['chef_mobile'];
		$chef_fb_link = $data['chef_fb_link'];
		$chef_insta_link = $data['chef_insta_link'];

		if (isset($data['chef_image']))
		{

			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$data['chef_image']->extension();
			$data['chef_image']->storeAs(
	    	'public/'.$directory, $image_name
			);
			$values[] = [
				'restaurant_id' => $restaurant->id,
				'chef_name' => $chef_name,
				'chef_mobile' => $chef_mobile,
				'chef_fb_link' => $chef_fb_link,
				'chef_insta_link' => $chef_insta_link,
				'chef_image' => $directory.'/'.$image_name,

			];

			DB::table('restaurant_chef')->insert($values);
		}



		$WeeklyHour = WeeklyHour::where('restaurant_id',$restaurant->id)->first();

		if (empty($WeeklyHour)) {
		WeeklyHour::create([
			'restaurant_id' => $restaurant->id,
			'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
			'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
			'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
			'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
			'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
			'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
		]);
		} else {
		WeeklyHour::where('restaurant_id',$restaurant->id)->update([
			'mon_from' => $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time,
			'fri_from' => $request->friday_open_time,
			'sat_from' => $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time,
			'mon_to' => $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time,
			'fri_to' => $request->friday_close_time,
			'sat_to' => $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time,
		]);
		}


			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant added successfully.');
		}
		return view('restaurant.add');
	}

   public function edit($id){


		$restaurant = Restaurant::where('id',$id)->where('user_id',Auth::user()->id)->first();
		//print_r($restaurant); die();
		$countries = DB::table("countries")->pluck("country_name","id");
		$cities = DB::table("cities")->pluck("city_name","id");
		$openingHours = WeeklyHour::where('restaurant_id',$id)->first();

		if (!empty($openingHours)) {
			$openingHours = $openingHours->toArray();
		}
		if(!$restaurant){
			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant not found.');
		}

		$cuisineTypes = CuisineType::pluck("name","id");
		$facilities = Facility::pluck("name","id");


		$restaurantCuisineTypes = RestaurantCuisineType::where('restaurant_id',$id)->select('cuisine_type_id')->first();
		$restaurantHolidays = RestaurantHoliday::where('restaurant_id',$id)->select('id','date','occasion')->get()->toArray();
		$restaurantFacilities = RestaurantFacility::where('restaurant_id',$id)->pluck('facility_id')->toArray();
		$restaurantChef= 	DB::table('restaurant_chef')->where('restaurant_id',$id)->first();
		$homeDeliveryArray = ['No','Yes'];
		$openStatusArray = ['Closed','Open'];
		$images = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',1)->get();
		$images_360 = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',2)->get();
		$cover_image = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',1)->where('default',1)->first();
		$menu_files = RestaurantImage::where('restaurant_id',$id)->where('doc_for',2)->first();

	 //	print_r($restaurantCuisineTypes);die;
		return view('restaurant.add',['countries'=>$countries,'restaurant'=>$restaurant,'cities'=>$cities,'openingHours'=>$openingHours,'cuisineTypes'=>$cuisineTypes,'restaurantCuisineTypes'=>$restaurantCuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray,'restaurantFacilities'=>$restaurantFacilities,'facilities'=>$facilities,'restaurantHolidays'=>$restaurantHolidays,'images'=>$images,'images_360'=>$images_360,'menu_files'=>$menu_files,'restaurantChef'=>$restaurantChef,'cover_image'=>$cover_image]);
   	}

	public function update(Request $request){
		$data = $request->all();
		$rules= [
			'id'=>'required|numeric',
			'name'=>'required|max:50',
			'ar_name'=>'required|max:50',
			'fr_name'=>'required|max:50',
			//'description'=>'nullable|max:250',
			//'notes'=>'nullable|max:250',
			'min_payment'=>'required|min:0',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric',
			'images.*'=>'mimes:png,jpeg,jpg,webp',
			'images_360.*'=>'mimes:png,jpeg,jpg,webp',
			'cover_image' => 'image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=1900,min_height=500',
			'menu_files'=>'mimes:pdf',
			'cuisine_type_id' =>'required',

		];
	 $message = [

                    'cover_image.mime'=>'file is not image',
                    'cover_image.dimensions'=>'file size is not correct',
                ];

      $request->validate($rules,$message);

		$restaurant = Restaurant::where('id',$data['id'])->where('user_id',Auth::user()->id)->first();
		if(!$restaurant){
			return redirect()->route('owner.restaurant.list')->with('success','Restaurant not found.');
		}
			if($data['latitude'] == null){
			$data['latitude']= 0.000000;
		}
			if($data['longitude'] == null){
			$data['longitude']= 0.000000;
		}
			if($data['notes'] == '<p>&nbsp;</p>'){
			$data['notes']= "";
			}
			if($data['description'] == '<p>&nbsp;</p>'){
			$data['description']= "";
			}

		$restaurant->name = ucwords($data['name']);
		$restaurant->ar_name = $data['ar_name'];
		$restaurant->fr_name = $data['fr_name'];
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];
		$restaurant->home_delivery = $data['home_delivery'];
		$restaurant->min_payment = $data['min_payment'];
		$restaurant->takeout = $data['takeout'];
		$restaurant->mobile = $data['mobile'];
		$restaurant->facebook_link = $data['facebook_link'];
		$restaurant->instagram_link = $data['instagram_link'];
		$restaurant->twitter_link = $data['twitter_link'];
		$restaurant->email = $data['email'];
		$restaurant->website = $data['website'];
		$restaurant->address = $data['address'];
		$restaurant->notes = $data['notes'];
		$restaurant->description = $data['description'];
		$restaurant->online_book_tnc = $data['online_book_tnc'];
		$restaurant->notification_emails = $data['notification_emails'];
		$restaurant->notification_mobiles = $data['notification_mobiles'];
		$restaurant->expensiveness = $data['expensive'];
		$restaurant->latitude = $data['latitude'];
		$restaurant->longitude = $data['longitude'];

		if (isset($data['delete_holiday_list'])) {
			RestaurantHoliday::whereIn('id',explode(',', $data['delete_holiday_list']))->delete();
		}

		if (isset($data['occasion_name']) and isset($data['occasion_date'])) {
			$holidays = [];
			foreach ($data['occasion_name'] as $key => $value) {
				$holidays[] = ['occasion'=>$value,'date'=> date('Y-m-d',strtotime($data['occasion_date'][$key])),'restaurant_id'=>$restaurant->id];
			}
				RestaurantHoliday::insert($holidays);
		}

		// print_r($data['id']);die;
		if (isset($data['saved_occasion_name']) and isset($data['saved_occasion_date'])) {
			foreach ($data['saved_occasion_id'] as $key => $value) {
				$restaurantHolidayFind = RestaurantHoliday::find($data['saved_occasion_id'][$key]);
				$restaurantHolidayFind->date = $data['saved_occasion_date'][$key];
				$restaurantHolidayFind->occasion = $data['saved_occasion_name'][$key];
				if ($restaurantHolidayFind->isDirty('occasion') || $restaurantHolidayFind->isDirty('date')) {
					$restaurantHolidayFind->save();
				}
			}
		}

		$upload_cuisine_type_array = [];
		if (isset($data['cuisine_type_id'])) {
		foreach ($data['cuisine_type_id'] as $key => $value) {
			$upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
		}

		$restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();
		if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) {
		RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete();
		RestaurantCuisineType::insert($upload_cuisine_type_array);
		}
		} else {
		if ($request->restaurant_cuisine_types_saved != "") {
		RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete();
		}
		}



		$upload_facility_array = [];
		if (isset($data['facility_id'])) {
			foreach ($data['facility_id'] as $key => $value) {
				$upload_facility_array[] = array('restaurant_id'=>$restaurant->id,'facility_id'=>$value);
			}

			$restaurant_cuisine_type_array = RestaurantFacility::where('restaurant_id',$restaurant->id)->pluck('facility_id')->toArray();
			if (!empty(array_diff($data['facility_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['facility_id']))) {
				RestaurantFacility::where('restaurant_id',$restaurant->id)->delete();
				RestaurantFacility::insert($upload_facility_array);
			}
		} else {
			if ($request->restaurant_cuisine_types_saved != "") {
			RestaurantFacility::where('restaurant_id',$restaurant->id)->delete();
			}
		}
            // START:RESTAURANT IMAGE SAVE CODE
    		//         if( $request->has('images') ){
    		//         	$restaurantImageList = [];
    		//         	foreach ($request->file('images') as $key => $imgFile) {
	   		//              $newFileName = $request->user()->id.$data['id'].time().rand(1,999999999);
	   		//              $newFileName = $newFileName.'.'.$imgFile->getClientOriginalExtension();
	   		//          	// RESTAURANT IMAGES SAVE INTO restaurant_images FOLDER
	   		//              $imgFile->move(storage_path('app/public/restaurant_images'), $newFileName);

						// 	$restaurantImageList[$key]['restaurant_id'] = $data['id'];
						// 	$restaurantImageList[$key]['image'] = $newFileName;
						// 	$restaurantImageList[$key]['doc_for'] = 1;
						// 	$restaurantImageList[$key]['doc_type'] = 1;
						// 	$restaurantImageList[$key]['image_type'] = 1;
    		//         	}
    		//         	// RESTAURANT IMAGES SAVE INTO restaurant_image TABLE
				// RestaurantImage::insert($restaurantImageList);
    		//         }
            // END:RESTAURANT IMAGE SAVE CODE

		if (isset($data['images'])) {
			$images = [];
			foreach($data['images'] as $image) {
			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);

			$images[] = [
				'restaurant_id' => $data['id'],
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 1];
			}
			RestaurantImage::insert($images);
		}



		if (isset($data['images_360'])) {
			$images_360 = [];
			foreach($data['images_360'] as $image) {

			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			// $image_name = 'hello'.'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);
			// $images_360[] = [
			// 	'restaurant_id' => $data['id'],
			// 	'image' => $directory.'/'.$image_name,
			// 	'doc_for' => 1,
			// 	'doc_type' => 1,
			// 	'image_type' => 2
			// ];

			$images_360[] = [
				'restaurant_id' => $data['id'],
				'image' => $directory.'/'.$image_name,
				'doc_for' => 1,
				'doc_type' => 1,
				'image_type' => 2];
			}
			RestaurantImage::insert($images_360);
		}


		  if (isset($data['cover_image'])) {
		  $image=$data['cover_image'];

			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);

			RestaurantImage::insert([
						   'restaurant_id' => $restaurant->id,
							'image' => $directory.'/'.$image_name,
							'doc_for' => 1,
							'doc_type' => 1,
							'image_type' => 1,
							'default' => 1,
			]);
			}


		   if (isset($data['menu_files'])) {
			 $image=$data['menu_files'];


			$directory = 'restaurant_menu_files';
			$image_name = $request->user()->id.$data['id'].time().rand(1,999999999).'.'.$image->extension();
			$image->storeAs(
	    	'public/'.$directory, $image_name
			);

			RestaurantImage::insert([
						   'restaurant_id' => $data['id'],
							'image' => $directory.'/'.$image_name,
							'doc_for' => 2,
							'doc_type' => $image->extension() != 'pdf' ? 1 : 2,
							'image_type' => 1
			]);
		}

		$chef_name = $data['chef_name'];
		$chef_mobile = $data['chef_mobile'];
		$chef_fb_link = $data['chef_fb_link'];
		$chef_insta_link = $data['chef_insta_link'];

		if (isset($data['chef_image']))
		{

			$directory = 'restaurant_images';
			$image_name = $request->user()->id.$restaurant->id.time().rand(1,999999999).'.'.$data['chef_image']->extension();
			$data['chef_image']->storeAs(
	    	'public/'.$directory, $image_name
			);
			$values[] = [
				'restaurant_id' => $restaurant->id,
				'chef_name' => $chef_name,
				'chef_mobile' => $chef_mobile,
				'chef_fb_link' => $chef_fb_link,
				'chef_insta_link' => $chef_insta_link,
				'chef_image' => $directory.'/'.$image_name,

			];
			DB::table('restaurant_chef')->where('restaurant_id',$restaurant->id)->delete();
			DB::table('restaurant_chef')->insert($values);
		}


		$WeeklyHour = WeeklyHour::where('restaurant_id',$request->id)->first();

		if (empty($WeeklyHour)) {
		WeeklyHour::create([
			'restaurant_id' => $request->id,
			'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
			'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
			'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
			'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
			'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
			'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
		]);
		} else {
		WeeklyHour::where('restaurant_id',$request->id)->update([
			'mon_from' => $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time,
			'fri_from' => $request->friday_open_time,
			'sat_from' => $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time,
			'mon_to' => $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time,
			'fri_to' => $request->friday_close_time,
			'sat_to' => $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time,
		]);
		}

			if (isset($request->delete_list)) {
			$restaurantImages = RestaurantImage::whereIn('id', explode(',', $request->delete_list) )->select(DB::raw('GROUP_CONCAT(id) AS ids,GROUP_CONCAT(CONCAT("public/",image)) AS images'))->first();
			if (!empty($restaurantImages) && !empty($restaurantImages->ids)) {
				RestaurantImage::whereIn('id', explode(',', $restaurantImages->ids) )->delete();
				Storage::delete(explode(',', $restaurantImages->images));
			}
      	}

      	if($restaurant->isDirty() && $restaurant->status !=3){
      	if( $restaurant->save() ){
			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant details updated successfully.');
			}else{
				return redirect()->route('owner.restaurant.restaurantlist')->with('error','Error in: Update restaurant.');
			}
      	}
      	elseif($restaurant->isDirty() && $restaurant->status ==3){
      		$restaurant->status=0;
      	if( $restaurant->save() ){
			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant details updated successfully.');
			}else{
				return redirect()->route('owner.restaurant.restaurantlist')->with('error','Error in: Update restaurant.');
			}
      	}
      	else{
      		return redirect()->route('owner.restaurant.restaurantlist');
      	}




	 }

	public function getCity($id){
		$getCity = DB::table("cities")->where("country_id",$id)->pluck("city_name","id");
        return json_encode($getCity);
	}
	public function getCuisine($id){
		$getCuisine = CuisineType::where("country_id",$id)->where("status",1)->orderBy('name')->select("id","name")->get();
		return response()->json(['status'=>true,'cuisine'=>$getCuisine]);
	}

	public function delete($id){

	//	print_r($id); die();
		$restaurant = Restaurant::find($id);
		$restaurant->status = 2;
		if( $restaurant->save() ){
			return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant deleted successfully.');
		}else{
			return redirect()->route('owner.restaurant.restaurantlist')->with('error','Error in: Delete restaurant.');
		}
	}
	public function add(){
		$countries = DB::table("countries")->pluck("country_name","id");


		$cuisineTypes = CuisineType::pluck("name","id");
		$facilities = Facility::pluck("name","id");
		$restaurantCuisineTypes = [];
		$restaurantFacilities = [];

		$homeDeliveryArray = ['No','Yes'];
		$openStatusArray = ['Closed','Open'];

		//print_r($restaurantCuisineTypes); die();
		return view('restaurant.add',['countries'=>$countries,'cuisineTypes'=>$cuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray,'restaurantCuisineTypes'=>$restaurantCuisineTypes,'facilities'=>$facilities,'restaurantFacilities'=>$restaurantFacilities]);
	}
	public function account(){
		$account = Auth::user();
		return view('restaurant.account',['account'=>$account]);
	}

	public function updateAccount(Request $request){
		$rules= [
		'name' => 'required',
		'password' => 'nullable|string|confirmed|min:8|required'
		];

		  $message = [
            'name.required'=>'Name is required.',
            'password.required'=>'Password is required.',

        ];
        $request->validate($rules,$message);

		$formData  = [
			'name'	=> $request->name,
		];
		$formData['password'] = Hash::make($request->password);
		User::where('id',Auth::id())->update($formData);

		$account = User::find(Auth::id());
		return redirect()->route('owner.account.detail');
	}

	public function logout(Request $request) {
        Auth::logout();
        // return redirect('/login');
        return redirect()->Route('owner.login');
    }

   public function floorManagement(Request $request){
		$data = $request->all();
		$id_restaurant = Session::get('id_restaurant');
		// dd($data );
		// $id_restaurant = session('id_restaurant');

		$restaurantDetail = DB::table('restaurant_floors')
		->where('restaurant_id',$id_restaurant)
		->where('type',1)
		->first();

		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id',	$id_restaurant)
		->orderBy('type','asc')
		->get();
		// dd($restaurantFloorList);

		$bookingList = $this->bookingList($id_restaurant,0);
		$categoriesList = Category::
		with(['booking'=>function($query)use($id_restaurant){
			$query->where('bookings.table_reserved_status','=',1)
			->where('bookings.status','=',1)

			->where('restaurant_id',$id_restaurant);
		},'booking.getUser'])
		->where('categories.status','=',1)
		->get();

		$count = $this->reservationWaitlistCount($id_restaurant);
		$minutesSlots = $this->restaurantSlot2($id_restaurant,$default_floor=0,$category_id=0);
	//print_r($minutesSlots);exit;
		return view('restaurant.floor_management',['restaurant_detail'=>$restaurantDetail,
			'restaurant_list'=>$restaurantFloorList,'booking_list'=>$bookingList,'categories_list'=>$categoriesList,'restaurant_id'=>	$id_restaurant,'waitlist_count'=>$count['waitlistCount'],'reservation_count'=>$count['reservationCount'],'upcoming_count'=>$count['upcomingCount'] ,'minutes_Slots'=>$minutesSlots]);

   }
   public function confirmBooking(Request $request){
   	$data = $request->all();
		$bookingList = Category::
		with(['booking'=>function($query)use($data){
			$query
			->where('bookings.table_reserved_status','=',1)
			->where('bookings.status','=',1)
			// ->where('floor_id',$data['restaurantFloorId'])
			->where('category_id',$data['categoryId'])
			->where('restaurant_id',$data['restaurantId'])
			;
		},
		'booking.getUser',
		// 'booking.getRestaurantFloor'
	])
		->where('id',$data['categoryId'])
		->where('categories.status','=',1)
		->first();

			foreach($bookingList->booking as $key => $dd)
			{
				if($dd->reserved_floor_id != null){
					$dd->floor_name= RestaurantFloor::where(['id' => $dd->reserved_floor_id])->pluck('name')->first();
				 }
				 elseif($dd->floor_id != null){
					$dd->floor_name= RestaurantFloor::where(['id' => $dd->floor_id])->pluck('name')->first();
				}
				// if(isset($dd->reserved_floor_id) && $dd->reserved_floor_id != ""){
				// 	$dd->floor_name= RestaurantFloor::where(['id' => $dd->reserved_floor_id])->pluck('name')->first();
				//  }elseif(isset($dd->floor_id) && $dd->floor_id != ""){
				// 	$dd->floor_name= RestaurantFloor::where(['id' => $dd->floor_id])->pluck('name')->first();
				// }

				$rr = json_decode($dd->reserved_table_detail);
				$ff = json_decode($dd->table_detail);

				$dd->reserved_table_detail =$rr;
			   $dd->table_detail =$ff;

				if(isset($dd->reserved_table_detail) && $dd->reserved_table_detail != ""){
					$dd->table_no =$rr[0]->table_no;
				 }elseif(isset($dd->table_detail) && $dd->table_detail != ""){
					$dd->table_no =$ff[0]->table_no;
				}
			}
			//print_r($bookingList);
		return response()->json(['status'=>true,'booking_list'=>$bookingList]);
   }

	public function allBooking(Request $request){
		$restaurantId = $request->restaurant_id;
		$type = $request->type;
		// print_r($request->restaurant_id);
		$bookingList = [];
		if($type == 0){
			if( isset($request->lastBookingId) && $request->lastBookingId > 0 ){
				/*====== Pending booking list =======*/
				$bookingList = $this->bookingList($restaurantId,$type,$request->lastBookingId);
			}else{
				$bookingList = $this->bookingList($restaurantId,$type); /*====== Pending booking list =======*/
			}
		}
		if($type == 1){
			$bookingList = $this->bookingList($restaurantId,$type); /*====== Upcoming booking list ======*/
		}
		if($type == 3){
			$bookingList = $this->bookingList($restaurantId,$type); /*====== Waiting booking list =======*/
		}
		$count = $this->reservationWaitlistCount($restaurantId);

		foreach($bookingList as $key => $dd)
			{


				if($dd->reserved_floor_id != null){
					$dd->fln= RestaurantFloor::where(['id' => $dd->reserved_floor_id])->pluck('name')->first();
				 }
				 elseif($dd->floor_id != null){
					$dd->fln= RestaurantFloor::where(['id' => $dd->floor_id])->pluck('name')->first();
				}
				//print_r($dd->fln);

				$rr = json_decode($dd->reserved_table_detail);
				$ff = json_decode($dd->table_detail);

				$dd->reserved_table_detail =$rr;
			   $dd->table_detail =$ff;

				if(isset($dd->reserved_table_detail) && $dd->reserved_table_detail != ""){
					$dd->table_no =$rr[0]->table_no;
				 }elseif(isset($dd->table_detail) && $dd->table_detail != ""){
					$dd->table_no =$ff[0]->table_no;
				}
		}

	//	print_r($bookingList);

		echo json_encode(['status'=>true,'booking_list'=>$bookingList,'reservation_count'=>$count['reservationCount'],'waitlist_count'=>$count['waitlistCount'],'upcoming_count'=>$count['upcomingCount']]);
		exit;
	}

	protected function reservationWaitlistCount($restaurantId){
		$reservationCount = Booking::where('bookings.table_reserved_status','=',1)
			->where('bookings.status','=',1)
			->where('bookings.restaurant_id',$restaurantId)
			->count();
		$waitlistCount = Booking::where('status','=',3)
			->where('bookings.restaurant_id',$restaurantId)
			->count();
		$upcomingCount = Booking::where('bookings.status','=',1)
			->where('bookings.restaurant_id',$restaurantId)
			->count();
		return ['reservationCount'=>$reservationCount,'waitlistCount'=>$waitlistCount,'upcomingCount'=>$upcomingCount];
	}


	protected function bookingList($restaurant_id,$type=1,$lastBookingId='',$restaurantFloorId=''){
		if($type==0){
			if($lastBookingId>0){

			// =========== PENDING ==============
				$bookingList = DB::table('bookings')
				->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','bookings.floor_id','bookings.reserved_floor_id','bookings.table_id','bookings.table_no','users.name','restaurant_floors.name as fln','bookings.reserved_table_detail','bookings.table_detail','bookings.reserved_floor_id')
				->join('users','bookings.user_id','=','users.id')
				->join('restaurant_floors','bookings.floor_id','=','restaurant_floors.id')
				->where([ ['bookings.restaurant_id', '='	,$restaurant_id],
					['bookings.status','=',0],
					['bookings.id','>',$lastBookingId],
					// ['bookings.floor_id','=',$restaurantFloorId]
				])
				->orderBy('bookings.id','desc')
				->get();
			}else{
				// =========== PENDING ==============
				$bookingList = DB::table('bookings')
				->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','bookings.floor_id','bookings.reserved_floor_id','bookings.table_id','bookings.table_no','users.name','restaurant_floors.name as fln','bookings.reserved_table_detail','bookings.table_detail','bookings.reserved_floor_id'
				)
				->join('users','bookings.user_id','=','users.id')
				->join('restaurant_floors','bookings.floor_id','=','restaurant_floors.id')
				->where([
					['bookings.restaurant_id', '='	,$restaurant_id],
					['bookings.status','=',0],
					// ['bookings.floor_id','=',$restaurantFloorId]
				])
				->orderBy('bookings.id','desc')
				->get();

			}
		}else if($type==1){
			// =========== UPCOMING ==============
			$bookingList = DB::table('bookings')
			->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','bookings.floor_id','bookings.reserved_floor_id','bookings.table_id','bookings.table_no',
				'users.name','restaurant_floors.name as fln','bookings.reserved_table_detail','bookings.table_detail','bookings.reserved_floor_id')
			->join('users','bookings.user_id','=','users.id')
			->join('restaurant_floors','bookings.floor_id','=','restaurant_floors.id')
			->where([ ['bookings.restaurant_id', '='	,$restaurant_id],
				['bookings.status','=',1],
			])
			->get();
		}else if($type==3){
			// =========== WAITING LIST ===========
			$bookingList = DB::table('bookings')
			->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','bookings.floor_id','bookings.reserved_floor_id','bookings.table_id','bookings.table_no',
				'users.name','restaurant_floors.name as fln','bookings.reserved_table_detail','bookings.table_detail','bookings.reserved_floor_id')
			->join('users','bookings.user_id','=','users.id')
			->join('restaurant_floors','bookings.floor_id','=','restaurant_floors.id')
			->where([ ['bookings.restaurant_id', '='	,$restaurant_id],
				['bookings.status','=',3],
				// ['bookings.floor_id','=',$restaurantFloorId]
			])
			->get();
		}
		return $bookingList;
	}

    public function editFloor(Request $request){
		$data = $request->all();
		$id = session('id_restaurant');
		$restaurantDetail = DB::table('restaurant_floors')
		->where('restaurant_id',$id)
		->where('type',1)
		->first();
		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id',$id)
		->orderBy('type','asc')
		->get();

		$bookingList = DB::table('bookings')
		->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','users.name')
		->join('users','bookings.user_id','=','users.id')
		->where('bookings.restaurant_id',$id)
		->whereOr([ ['category_id',0],['category_id',null]   ])
		->get();
		$categoriesList = Category::with(['booking','booking.getUser' ])
		->where('status',1)->get();
		return view('restaurant.edit_floor',['restaurant_detail'=>$restaurantDetail,'restaurant_list'=>$restaurantFloorList,'booking_list'=>$bookingList,'categories_list'=>$categoriesList,'restaurant_id'=>$id]);

    }

	public function saveRestaurantFloor(Request $request){
		$data = $request->all();
		$response = ['status'=>0,'msg'=>'invalid Request'];
		if( isset($data['restaurant_floor_id']) ){
				$data['table_view'] = isset($data['table_view'])?$data['table_view']:null;
				$data['floor_info'] = isset($data['floor_info'])?$data['floor_info']:null;
				$data['floor_name'] = isset($data['floor_name'])?ucwords($data['floor_name']):null;
				$updateData = ['floor_table_view'=>$data['table_view'],'floor_info'=>$data['floor_info'], 'name' => $data['floor_name']];
				$result = DB::table('restaurant_floors')
				->where('id',$data['restaurant_floor_id'])
				->update($updateData);
			if($result)
				$response = ['status'=>1,'msg'=>'Floor view saved successfully'];
			else
				$response = ['status'=>0,'msg'=>'Error in: insert request'];

		}
		return $response;
	}

	public function getRestaurantFloorDetail(Request $request){
		$data = $request->all();
		// print_r($data);
		$restaurantDetail = DB::table('restaurant_floors')
		->where('id',$data['restaurant_floor_id'])
		->first();

		$floorname = DB::table('restaurant_floors')
		->select('name')
		->where('id',$data['restaurant_floor_id'])
		->first();

		$bookingsDetail = DB::table('bookings')
			->select('bookings.id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.status','bookings.category_id','bookings.floor_id','bookings.reserved_floor_id','bookings.table_id','bookings.table_no',
				'users.name','restaurant_floors.name as fln')
		->join('users','bookings.user_id','=','users.id')
		->join('restaurant_floors','bookings.floor_id','=','restaurant_floors.id')
		// ->where('floor_id',$data['restaurant_floor_id'])
		->where('bookings.restaurant_id',$data['restaurant_id'])
		->where('bookings.status',0)
		->orderby('bookings.id', 'desc')
		->get();
		if(!$restaurantDetail){
			$response = ['status'=>0,'msg'=>'Error in: not found'];
		}else{
			if(!$bookingsDetail){
				$bdata = '';
			}else{
				$bdata = $bookingsDetail;
			}
			$response = ['status'=>1,'msg'=>'Restaurant Detail','data'=>$restaurantDetail, 'bdata'=> $bdata, 'floorname'=> $floorname];
		}
		return $response;
	}

	public function createFloor(Request $request){
		$data = $request->all();
		if( isset($data['type']) && $data['type'] ){
			if (RestaurantFloor::where('restaurant_id',$data['restaurant_id'])
			->where('name',ucwords($data['floor_name']))
			->exists()) {
				$response = ['status'=>0,'msg'=>'Restaurant Floor already created.'];
			}else{
				$restaurantFloor = new RestaurantFloor;
				$restaurantFloor->restaurant_id=$data['restaurant_id'];
				$restaurantFloor->type=2;
				$restaurantFloor->name=ucwords($data['floor_name']);
				if($restaurantFloor->save())
					$response = ['status'=>1,'msg'=>'Restaurant create Floor.','data'=>$restaurantFloor];
				else
					$response = ['status'=>0,'msg'=>'Error in : Create Restaurant Floor.'];
			}
		}else{
			$restaurantFloorDetail = RestaurantFloor::where('restaurant_id',$data['restaurant_id'])
			->where('id',ucwords($data['restaurant_floor_id']))->first();
			if ( isset($restaurantFloorDetail->id) && $restaurantFloorDetail->id>0 ) {
				$restaurantFloorDetail->name=ucwords($data['floor_name']);
				if($restaurantFloorDetail->save()){
					// $restaurantFloor->restaurant_id=$data['restaurant_id'];
					// $restaurantFloor->type=2;
					// $restaurantFloor->name=ucwords($data['floor_name']);

					$response = ['status'=>1,'msg'=>'Floor name updated.','data'=>$restaurantFloorDetail];
				}else{
					$response = ['status'=>0,'msg'=>'Error in : Create Restaurant Floor.'];
				}
			}else{
				$response = ['status'=>0,'msg'=>'Restaurant Floor already created.'];
			}
		}
		return $response;
	}

	public function deleteRestaurantFloor(Request $request){
		$data = $request->all();
		if( isset($data['delete_restaurant_floor_id']) ){
			$restaurantFloor = new RestaurantFloor;
			if (Booking::where('floor_id', '=',$data['delete_restaurant_floor_id'])->exists()) {
				$response = ['status'=>0,'msg'=>'Default Restaurant Floor have Booking.'];
			}else{
				$restaurantFloorDetail = $restaurantFloor->where('id',$data['delete_restaurant_floor_id'])->first();
				if($restaurantFloorDetail->type !=1){
					$deleteStatus = $restaurantFloorDetail->delete();
					if($deleteStatus){
						$response = ['status'=>1,'msg'=>'Delete successfully.'];
					}else{
						$response = ['status'=>0,'msg'=>'Error in : Delete Restaurant Floor.'];
					}
				}else{
					$response = ['status'=>0,'msg'=>'Default Restaurant Floor can\'t be delete.'];
				}
			}
		}else{
			$response = ['status'=>0,'msg'=>'Invalid request.'];
		}
		return $response;
	}

	public function deleteRestaurantFloorTable(Request $request)
	{
		$data = $request->all();
		$current_date =  date('Y-m-d');


		//print_r($data_exitst->for_date < $current_date); die();
		if( isset($data['delete_table_id']) ){
			$data_exitst =Booking::where('table_id', '=',$data['delete_table_id'])->first();
			if (isset($data_exitst) && $data_exitst->for_date >= $current_date) {

				$response = ['status'=>0,'msg'=>'Table has a booking.'];

			}else{


				$response = ['status'=>1,'msg'=>''];

			}
		}else{
			$response = ['status'=>0,'msg'=>'Invalid request.'];
		}
		return $response;

	}

	public function bookingSave(Request $request){
		$data = $request->all();
		$rules = [
			'user_id'=>'required',
			'no_of_person'=>'required',
			'for_date'=>'required',
			'for_time'=>'required',
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			$response = ['status'=>false,'msg'=>$validation_error[0]];
		}else{

			$dateArr = explode('/', $data['for_date']);
			$newDateFormat = $dateArr['2'].'/'.$dateArr['1'].'/'.$dateArr['0'];
			$insertData = ['restaurant_id'=>1,'user_id'=>$data['user_id'],'no_of_person'=>$data['no_of_person'],'for_date'=>$newDateFormat,'for_time'=>$data['for_time']];
			$insertResult = DB::table('bookings')->insert($insertData);
			if($insertResult){
				$response = ['status'=>true,'msg'=>'Booking saved successfully'];
			}else{
				$response = ['status'=>false,'msg'=>'Booking request Failed'];
			}
		}
		return $response;

	}

	public function updateCategoryOfBooking(Request $request){
		$data = $request->all();
		//print_r($data);
		// foreach ($data['category_booking'] as $bookingId => $booking){
		if( isset($data['category_booking']['booking_id']) ){
			// print_r($bookingId);
			// print_r($booking);
			if($data['category_booking']['table_reserve']){
				$updateField = [
					'for_time'=>($data['category_booking']['for_time']==0?0:$data['category_booking']['for_time']),
					'for_date'=>($data['category_booking']['for_date']==0?0:$data['category_booking']['for_date']),
					'no_of_person'=>($data['category_booking']['no_of_person']==0?0:$data['category_booking']['no_of_person']),
					'category_id'=>($data['category_booking']['category_id']==0?0:$data['category_booking']['category_id']),
					// 'reserved_floor_id'=>($data['category_booking']['reserved_floor_id']==0?0:$data['category_booking']['reserved_floor_id']),
					// 'table_id'=>($data['category_booking']['table_id']==0?0:$data['category_booking']['table_id']),
					// 'table_no'=>($data['category_booking']['table_no']==0?0:$data['category_booking']['table_no']),
					'tag_id'=>($data['category_booking']['tag_id']==0?0:$data['category_booking']['tag_id']),
					'status'=>($data['category_booking']['booking_status']==0?0:$data['category_booking']['booking_status']),
					'table_id'=>($data['category_booking']['table_id']==0?0:$data['category_booking']['table_id']),
					'reserved_table_detail'=>( isset($data['table_detail_json']) ?$data['table_detail_json']:''),
					'reserved_floor_id'=>($data['category_booking']['floor_id']==0?0:$data['category_booking']['floor_id']),
					'table_reserved_status'=>$data['category_booking']['table_reserve']
					];
			}else{
				$updateField = [
					'for_time'=>($data['category_booking']['for_time']==0?0:$data['category_booking']['for_time']),
					'for_date'=>($data['category_booking']['for_date']==0?0:$data['category_booking']['for_date']),
					'no_of_person'=>($data['category_booking']['no_of_person']==0?0:$data['category_booking']['no_of_person']),
					'category_id'=>($data['category_booking']['category_id']==0?0:$data['category_booking']['category_id']),
					// 'table_no'=>($data['category_booking']['table_no']==0?0:$data['category_booking']['table_no']),
					// 'tag_id'=>($data['category_booking']['tag_id']==0?0:$data['category_booking']['tag_id']),
					'status'=>($data['category_booking']['booking_status']==0?0:$data['category_booking']['booking_status']),
					'reserved_floor_id'=>'',
					'reserved_table_detail'=>'',
					'table_reserved_status'=>$data['category_booking']['table_reserve']
					];
			}


			$affectedRows = Booking::where('id',$data['category_booking']['booking_id'])->update( $updateField );

			$floor_name = DB::table('restaurant_floors')
	          ->select('name')
	          ->where('id','=', $data['category_booking']['floor_id'])
	          ->first();

			$new_time =  Carbon::parse($data['category_booking']['for_time'])->format('g:i A');
			$bookingDetail = Booking::where('id',$data['category_booking']['booking_id'])->first();

			$count = $this->reservationWaitlistCount($bookingDetail->restaurant_id);
			$categoryBookingCount = $this->categoryBookingCount($bookingDetail->restaurant_id,$bookingDetail->floor_id);

			$resp = [
				'booking_id'=>$data['category_booking']['booking_id'],
				'for_time'=>$new_time,
				'for_date'=>$data['category_booking']['for_date'],
				'no_of_person'=>$data['category_booking']['no_of_person'],
				'category_id'=>$data['category_booking']['category_id'],
				// 'floor_name'=>$floor_name->name,
				// 'reserved_floor_id'=>$data['category_booking']['category_id'],
				// 'reserved_table_detail'=>$data['category_booking']['category_id'],
				// 'table_id'=>$data['category_booking']['table_id'],
				// 'table_no'=>$data['category_booking']['table_no'],
				'table_detail'=>'',
				'status'=>true,
				'booking_status'=>$data['category_booking']['booking_status'],
				'msg'=>'Category successfully update in booking',
				'reservation_count'=>$count['reservationCount'],
				'waitlist_count'=>$count['waitlistCount'],
				'category_booking_count'=>$categoryBookingCount
			];
		}
		return $resp;
	}
	protected function categoryBookingCount($restaurantId, $restaurantFloorId){
		// SELECT  count(id), category_id FROM `bookings` WHERE `restaurant_id`=5 AND `floor_id`=34 AND status = 1 AND table_reserved_status = 1  group by category_id
			$reservationCount = Booking::select(array('category_id', \DB::raw('COUNT(id) as category_booking_count')))
			->where('bookings.table_reserved_status','=',1)
			->where('bookings.status','=',1)
			->where('bookings.restaurant_id',$restaurantId)
			// ->where('bookings.floor_id',$restaurantFloorId)
			->groupBy('category_id')
			->get();
		return $reservationCount;
	}
	public function bookingUpdate(Request $request){
		$data = $request->all();
		$updateField = ['table_no'=>$data['table_no'],'status'=>$data['status']];
		$result = Booking::where('id', $data['booking_id'])->update($updateField);
		if($result){
			$response = ['status'=>true,'msg'=>'Booking Confirmed','booking_id'=>$data['booking_id']];
		}else{
			$response = ['status'=>false,'msg'=>'Booking Confirmed','booking_id'=>$data['booking_id']];
		}
		return $response;
	}

	public function bookingDetail(Request $request){

		if($request->ajax()){
			$data = $request->all();
			$categoryList = Category::where('status',1)->pluck('name','id');
			$tagList = Tag::where('status',1)->pluck('name','id');

			$bookingDetail = Booking::
			select('bookings.user_id as user_id','bookings.id as booking_id','bookings.floor_id','bookings.table_id','bookings.table_no','bookings.tag_id','bookings.status','bookings.category_id','bookings.no_of_person','bookings.for_date','bookings.for_time','users.name as user_name','users.mobile as mobile',
				'bookings.table_reserved_status','bookings.reserved_floor_id','bookings.reserved_table_detail',

			)
			// ->leftJoin('categories','categories.id','=','bookings.category_id')
			->join('users','bookings.user_id','=','users.id')
			->where('bookings.id',$data['booking_id'])
			->first();
			$restaurantfloorslist = RestaurantFloor::where('restaurant_id',$data['restaurant_id'])->pluck('name','id');
			if(isset($data['reserved_floor_id']) == $data['floor_id'] ){
				$restauranttableslist = RestaurantFloor::select('floor_table_view')->where('id',$data['floor_id'])->first();
			}else{
				$restauranttableslist = RestaurantFloor::select('floor_table_view')->where('id',$data['floor_id'])->first();
			}
			$userFoodIntolerance = UserFoodIntolerance::select()
			->select('foodintolerance_types.name')
			->where('users_food_intolerance.user_id',$bookingDetail->user_id)
			->join('foodintolerance_types', 'foodintolerance_types.id', '=', 'users_food_intolerance.food_intolerance_id')
			->pluck('foodintolerance_types.name');
			$userAllergy = UserAllergy::select()
			->select('allergy_types.name')
			->where('users_allergies.user_id',$bookingDetail->user_id)
			->join('allergy_types', 'allergy_types.id', '=', 'users_allergies.allergy_id')
			->pluck('allergy_types.name');
			// ->get();


			if($bookingDetail->booking_id > 0){
				$response = ['status'=>true,'msg'=>'Booking Detail','booking_detail'=>$bookingDetail,'category_list'=>$categoryList, 'tag_list'=>$tagList, 'floor_list'=>$restaurantfloorslist, 'table_list'=>$restauranttableslist,'user_food_intolerance'=>implode(',', $userFoodIntolerance->toArray()),
					'user_allergy'=>implode(',', $userAllergy->toArray())];
			}else{
				$response = ['status'=>false,'msg'=>'Booking Confirmed'];
			}
		}else{
			$response = ['status'=>false,'msg'=>'Request is invalid'];
		}
		return $response;
	}





	/////////////////////////////////////////[fresh]///////////////////////////////////
	public function bookingNew(Request $request)
	{
		$id_restaurant = session('id_restaurant');
		$bookings = Booking::
		select('bookings.user_id As user_id','bookings.restaurant_id  As restaurant_id','users.name','users.email','users.mobile','users.image')
		->distinct('user_id')
		->rightJoin('users','bookings.user_id','=','users.id')
		->where('users.type',4)
		->where('bookings.restaurant_id',$id_restaurant)
		->get();

		//print_r($bookings); die();

		$restaurantUserList = [];
		$resUserList = $bookings->map(
			function($items){
				$restaurantUserList ['user_id'] = $items->user_id;
				$restaurantUserList ['name'] = $items->name;
				$restaurantUserList ['email'] = $items->email;
				$restaurantUserList ['mobile'] = $items->mobile;
				$restaurantUserList ['image'] = $items->image;
				$restaurantUserList ['total_record'] = Booking::where('user_id',$items->user_id)->where('restaurant_id',$items->restaurant_id)->count();
				$restaurantUserList ['visit'] = Booking::where('user_id',$items->user_id)->where('restaurant_id',$items->restaurant_id)->where('status',4)->count();
				$restaurantUserList ['cancel'] = Booking::where('user_id',$items->user_id)->where('restaurant_id',$items->restaurant_id)->where('status',2)->count();
					$foodTolerance = UserFoodIntolerance::
					// select('foodintolerance_types.name')
					where('users_food_intolerance.user_id',$items->user_id)
					->join('foodintolerance_types', 'foodintolerance_types.id', '=', 'users_food_intolerance.food_intolerance_id')
					->orderBy('foodintolerance_types.name')
					->pluck('foodintolerance_types.name');


					$restaurantUserList['userFoodIntolerance']=implode(",",$foodTolerance->toArray());
					$userAllergy = UserAllergy::select()
					->select('allergy_types.name')
					->where('users_allergies.user_id',$items->user_id)
					->join('allergy_types', 'allergy_types.id', '=', 'users_allergies.allergy_id')
					->orderBy('allergy_types.name')
					->pluck('allergy_types.name');
					$restaurantUserList['userAllergy']=implode(", ",$userAllergy->toArray());
					// ->get();
					// print_r($restaurantUserList['userFoodIntolerance'][0]);exit;
				return $restaurantUserList;
				}
			);

		// foreach($resUserList as $key=>$dd){



		//   $dd->gg = (isset($dd['userFoodIntolerance']) ? explode(',', $dd['userFoodIntolerance']) : []);

		//   //print_r($gg); die();


		// }
//print_r($resUserList); die();

		$categories = Category::where('status',1)->pluck('name','id');
		$tags = Tag::where('status',1)->pluck('name','id');
		//print_r($tags); die();
		$floors = RestaurantFloor::where('restaurant_id',$id_restaurant)->pluck('name','id');


		return view('restaurant.booking',['restaurant_id'=>$id_restaurant, 'userlist'=> $resUserList,'categories'=>$categories, 'tags'=>$tags, 'floors'=>$floors]);
	}

	public function bookingby(Request $request)
	{
		if($request->ajax()){
			$data = $request->all();
			$userdata = "";
			if($data['serchdata']!=null){
				if(is_numeric($data['serchdata'])){
					$userdata = User::select('id','name','email','mobile')->where('type',4)->where('mobile',$data['serchdata'])->first();
				}elseif(filter_var($data['serchdata'], FILTER_VALIDATE_EMAIL)){
					$userdata = User::select('id','name','email','mobile')->where('type',4)->where('email',$data['serchdata'])->first();
				}else{
					$userdata = User::select('id','name','email','mobile')->where('type',4)->where('name',$data['serchdata'])->first();
				}
			}else{

				$response = ['status'=>false,'msg'=>'fill valid value'];
			}

			if($userdata != null){
				$response = ['status'=>true,'msg'=>'user exists' , 'data'=> $userdata];

			}else{
				$response =['status'=>false,'msg'=>'user not exists' , 'data'=> ''];
			}

			return $response;
		}

	}

	public function tablelistbyfloorid(Request $request)
	{
		$data = $request->all();
		$tableslist = RestaurantFloor::select('floor_table_view')->where('id',$data['floor_id'])->first();
		$response = ['table_list'=>$tableslist];
		return $response;
	}

	public function newbooking(Request $request)
	{
		$data = $request->all();

		//print_r($data); die();
		$rules = [
			'user_id'=>'required',
			'res_id' => 'required',
			'for_date'=>'required',
			'for_time'=>'required',

			'booking_status'=>'required',
			'category_id'=>'required',
			'floor_id'=>'required',

		];


		    $message = [

            'for_date.required'=>'Date of booking is required.',
            'for_time.required'=>'Time of booking is required.',

            'booking_status.required'=>'Booking status is required.',
            'category_id.required'=>'Category of booking is required.',
            'floor_id.required'=>'Floor Id is required.',


        ];

      //  print_r($message); die();

        $request->validate($rules,$message);
			$booking = new Booking;
			$booking->restaurant_id = $data['res_id'];
			$booking->user_id = $data['user_id'];
			$booking->for_time = $data['for_time'];
			$booking->for_date = $data['for_date'];
			$booking->no_of_person = $data['no_of_person'];
			$booking->status = $data['booking_status'];
			$booking->category_id = $data['category_id'];
			$booking->tag_id = $data['tag_id'];
			$booking->floor_id = $data['floor_id'];
			$booking->table_id = $data['table_id'];
			$booking->table_no = $data['table_no'];
			$booking->table_detail = $data['table_detail'];
			$booking->booking_by = 2;
			if($booking->save()){
				return redirect()->route('owner.restaurant.bookingNew')->with('success','Booking added successfully. booking is '.$booking->id);
			}


	}

	public function newreservation(Request $request)
	{
		$data = $request->all();
		$rules = ([
			'user_id'=>'required',
			'res_id' => 'required',
			'for_date'=>'required',
			'for_time'=>'required',
			'no_of_person'=>'required',
			'booking_status'=>'required',
			'category_id'=>'required',
			'floor_id'=>'required',
			'table_no'=>'required',
		]);

		    $message = [

            'for_date.required'=>'Date of booking is required.',
            'for_time.required'=>'Time of booking is required.',
            'no_of_person.required'=>'No of person is required.',
            'booking_status.required'=>'Booking status is required.',
            'category_id.required'=>'Category of booking is required.',
            'floor_id.required'=>'Floor Id is required.',
            'table_no.required'=>'Table No is required.',

        ];
             $request->validate($rules,$message);
			$booking = new Booking;
			$booking->restaurant_id = $data['res_id'];
			$booking->user_id = $data['user_id'];
			$booking->for_time = $data['for_time'];
			$booking->for_date = $data['for_date'];
			$booking->no_of_person = $data['no_of_person'];
			$booking->status = $data['booking_status'];
			$booking->category_id = $data['category_id'];
			$booking->tag_id = $data['tag_id'];
			$booking->floor_id = $data['floor_id'];
			$booking->table_id = $data['table_id'];
			$booking->table_no = $data['table_no'];
			$booking->table_detail = $data['table_detail'];
			$booking->booking_by = 2;
			if($booking->save()){
				return redirect()->route('owner.restaurant.guestuser',['id' => $data['user_id']])->with('success','Booking added successfully. booking is '.$booking->id);
			}

	}

	public function addgustuser(Request $request)
	{
		$id_restaurant = session('id_restaurant');
		$data = $request->all();
	   $rules= ([
			'first_name'=>'required',
			'email'=>'required',
			'mobile'=>'required',
	     ]);
		    $message = [
            'first_name.required'=>'Name is required.',
            'email.required'=>'Email is required.',
            'mobile.required'=>'Mobile Number is required.',

        ];

         $request->validate($rules,$message);

			$findUser= DB::table('users')->select('*')->where('mobile', $data['mobile'])->orWhere('email', $data['email'])->first();
			$categories = Category::where('status',1)->pluck('name','id');
			$tags = Tag::where('status',1)->pluck('name','id');
			$floors = RestaurantFloor::where('restaurant_id',$id_restaurant)->pluck('name','id');
			if(!empty($findUser))
			{
				$foodTolerance = UserFoodIntolerance::
			// select('foodintolerance_types.name')
			where('users_food_intolerance.user_id',$findUser->id)
			->join('foodintolerance_types', 'foodintolerance_types.id', '=', 'users_food_intolerance.food_intolerance_id')
			->orderBy('foodintolerance_types.name')
			->pluck('foodintolerance_types.name');


			$findUser->userFoodIntolerance=implode(",",$foodTolerance->toArray());
			$userAllergy = UserAllergy::select()
			->select('allergy_types.name')
			->where('users_allergies.user_id',$findUser->id)
			->join('allergy_types', 'allergy_types.id', '=', 'users_allergies.allergy_id')
			->orderBy('allergy_types.name')
			->pluck('allergy_types.name');
			$findUser->userAllergy=implode(", ",$userAllergy->toArray());


				//print_r($findUser); die();
			Session::flash('error', 'User already added!!');
 			return view('restaurant.new_booking',['id'=>$findUser->id, 'user_detail'=> $findUser,'categories'=>$categories, 'tags'=>$tags, 'floors'=>$floors,'restaurant_id'=>$id_restaurant,]);

 			 // return redirect()->route('bookingNewGuest')->with(compact(['id'=>$findUser->id, 'user_detail'=> $findUser,'categories'=>$categories, 'tags'=>$tags, 'floors'=>$floors,'restaurant_id'=>$id_restaurant,])
     //        ->with('success', 'thank you');
       //  return redirect()->back()->with('error', 'User already added!!');
			}
			else
			{
			$user = new User;
			$user->first_name = ucwords($data['first_name']);
			$user->name =  ucwords($data['first_name']);
			$user->email = $data['email'];
			$user->mobile = $data['mobile'];
			$user->country_id = null;
			$user->lang_id = null;
			$user->password = Hash::make( "123123123");
			$user->status = 1;
			$user->type = 4;


			if($user->save()){
				$id= $user->id;
				$user_detail = DB::table('users')->select('*')->where('id', $id)->first();
			//	print_r($user_detail);
				//print_r($id);
			Session::flash('success', 'New User added succesfully!!');
		     return view('restaurant.new_booking',['id'=>$user->id, 'user_detail'=> $user_detail,'categories'=>$categories, 'tags'=>$tags, 'floors'=>$floors,'restaurant_id'=>$id_restaurant,]);
				// return redirect()->route('owner.restaurant.bookingNew',['id'=>$user->id,'user_detail'=>$user_detail])->with('success','New User add successfully');
			}
			}



	}

	public function setdefaultfloor($id)
	{
		$restaurantFloorList = DB::table('restaurant_floors')
		->where('restaurant_id',$id)
		->orderBy('type','asc')
		->get();

		//print_r($restaurantFloorList); die();

		return view('restaurant.defaultfloor',['restaurant_list'=>$restaurantFloorList,'res_id'=>$id]);
	}

	public function getdata(Request $request)
	{

        $id = $request->restaurantId;
      //  print_r($request->all());
          //  print_r($id );

		$restaurantFloorList = DB::table('restaurant_floors')
								->where('restaurant_id',$id)
								->select('id','name','type')
								->orderBy('type','asc')
								->get();


	//	print_r($restaurantFloorList);

		return $restaurantFloorList;
	}

	public function primaryUpdate(Request $request)
		{

	      $data = $request->all();

	      //print_r($data);
			Restaurant::where('id',$data['primary'])->where('user_id',Auth::user()->id)->update([
			'make_primary' => 1,

				]);
			Restaurant::where('id','!=',$data['primary'])->where('user_id',Auth::user()->id)->update([
			'make_primary' => 0,

				]);

		return redirect()->route('owner.restaurant.list')->with('success','Restaurant default added successfully.');
		}




	public function defaultfloor(Request $request)
	{
		$data = $request->all();

	//	print_r($data);	die();

		if($data['florr']!=null){
			$updatedefault = ['type'=>1];
			$updateUnDefault = ['type'=>2];
			$upresult = DB::table('restaurant_floors')
			->where('restaurant_id', $data['name_restaurant'])
			->where('id', $data['florr'])
			->update($updatedefault);
			$upresult1 = DB::table('restaurant_floors')
			->where('restaurant_id', $data['name_restaurant'])
			->where('id','!=',$data['florr'])
			->update($updateUnDefault);
			return redirect()->route('owner.restaurant.list')->with('success','Default floor added successfully.');
		}

	}

	public function guest(Request $request)
	{
		$id_restaurant = session('id_restaurant');
		$viptagList = VipTag::where('status',1)->pluck('name','id');

		// $users = DB::table('bookings')
		// ->select('users.name','users.id')
		// ->distinct('users.name')
		// ->join('users','bookings.user_id','=','users.id')
		// ->where('bookings.restaurant_id',$id_restaurant )
		// ->where('users.type', 4)
		// ->orderBy('users.name', 'ASC')
		// ->get();

		// $users = DB::table('users')
		// ->select('id','name')
		// ->distinct()
		// ->where('type', 4)
		// ->orderBy('name', 'ASC')
		// ->get();

		$users = Booking::
		select('bookings.user_id As id','users.name as name')
		->distinct('user_id')
		->join('users','bookings.user_id','=','users.id')
		->where('users.type',4)
		->where('bookings.restaurant_id',$id_restaurant)
		->get();



		$groupedUsers = $users->groupBy(function($item,$key) {
			return $item->name[0];
		})->sortBy(function($item,$key){
			return $key;
		});
		//print_r($groupedUsers); die();
		return view('restaurant.guestlist',['users'=>$groupedUsers, 'vips'=>$viptagList]);
	}



	public function addvipgust(Request $request)
	{
		$data = $request->all();
		$rules = [
			//'first_name'=>'required',
			//'last_name'=>'required',
			//'email'=>'required|email|unique:users,email',
			//'phone'=>'required|unique:users,mobile',
			'id_restaurant'=>'required',
			'updated_by'=>'required',
			'images.*'=>'mimes:png,jpeg,jpg,webp'
		];

		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{

			$user = new User;
			//$user->first_name = ucwords($data['first_name']);
			//$user->last_name = ucwords($data['last_name']);
			//$user->name =  ucwords($data['first_name']).' '.ucwords($data['last_name']);
			//$user->email = $data['email'];
			//$user->mobile = $data['phone'];
			$user->password = Hash::make( "123123123");
			$user->status = 1;
			$user->type = 4;

			if($request->hasfile('image')) {
				$image      = $request->file('image');
				$directory = 'user_images';
				$imageName = time().'.'.$request->image->extension();
				$image->storeAs('public/'.$directory, $imageName);
				$file_name = $directory.'/'.$imageName;
				$user->image = $file_name;
			}

			if($user->save()){
				if(isset($data['vip_tag']) && ($data['vip_tag'] > 0 )){
					$vipuser = new VipUser;
					$vipuser->user_id = $user->id;
					$vipuser->restaurant_id = $data['id_restaurant'];
					$vipuser->vip_tag_id = $data['vip_tag'];
					$vipuser->updated_by = $data['updated_by'];
					$vipuser->vip_note = $data['vip_note'];
					if($vipuser->save()	){
						$vipsave = true;
					}
				}
				return redirect()->route('owner.restaurant.guestuser',$user->id)->with('success','Guest updated successfully.');
			}

		}
	}



	public function guestuser($id)
	{
		$selectuser = User::find($id);
		$id_restaurant = session('id_restaurant');
		$viptagList = VipTag::where('status',1)->pluck('name','id');

		$count = Booking::where('user_id',$id)->where('restaurant_id',$id_restaurant)->count();

		$visitcount = Booking::
		where('user_id',$id)
		->where('restaurant_id',$id_restaurant)
		->where('status',4)
		->count();

		$cancelcount = Booking::
		where('user_id',$id)
		->where('restaurant_id',$id_restaurant)
		->where('status',2)
		->count();

		$vip = VipUser::select('vip_tag_id', 'vip_note')
		->where('restaurant_id',$id_restaurant)
		->where('user_id',$id)
		->first();



		// $users = DB::table('bookings')
		// ->select('users.name','users.id')
		// ->distinct('users.name')
		// ->join('users','bookings.user_id','=','users.id')
		// ->where('bookings.restaurant_id',$id_restaurant )
		// ->where('users.type', 4)
		// ->orderBy('users.name', 'ASC')
		// ->get();

		// $users = DB::table('users')
		// ->select('id','name')
		// ->distinct()
		// ->where('type', 4)
		// ->orderBy('name', 'ASC')
		// ->get();

		$users =Booking::
				select('bookings.user_id As id','users.name as name')
				->distinct('user_id')
				->join('users','bookings.user_id','=','users.id')
				->where('users.type',4)
				->where('bookings.restaurant_id',$id_restaurant)
				->get();


		$groupedUsers = $users->groupBy(function($item,$key) {
			return $item->name[0];
		})->sortBy(function($item,$key){
			return $key;
		});

		$bookings = Booking::
		select('bookings.id as booking_id','bookings.floor_id','restaurant_floors.name as floor_name','bookings.table_id','bookings.table_no','bookings.tag_id', 'bookings.status','bookings.category_id','bookings.no_of_person','bookings.for_date','bookings.for_time','bookings.table_visit','users.name as user_name','users.mobile as mobile','categories.id as categories_id','categories.name as categories_name','bookings.booking_by','bookings.reserved_table_detail','bookings.table_detail')
		->leftJoin('categories','categories.id','=','bookings.category_id')
		->leftJoin('restaurant_floors','restaurant_floors.id','=','bookings.floor_id')
		->leftJoin('users','bookings.user_id','=','users.id')
		->where('bookings.user_id',$id)
		->where('bookings.restaurant_id',$id_restaurant)
		->get();

		//print_r($bookings); die();
		foreach($bookings as $key => $dd)
		{
			$rr = json_decode($dd->reserved_table_detail);
			 $ff = json_decode($dd->table_detail);

			$dd->reserved_table_detail =$rr;
		   $dd->table_detail =$ff;

			if(isset($dd->reserved_table_detail) && $dd->reserved_table_detail != ""){
				$dd->table_updated =$rr[0]->table_no;
			 }elseif(isset($dd->table_detail) && $dd->table_detail != ""){
				$dd->table_updated =$ff[0]->table_no;
			}
		}


//print_r($bookings); die();



		foreach($bookings  as $key => $booking){
			$date=  date('d-m-Y', strtotime($booking->for_date));
            $booking->date = \Carbon\Carbon::parse($date)->format('M d, Y');
		}

		$categories = Category::where('status',1)->pluck('name','id');
		$tags = Tag::where('status',1)->pluck('name','id');
		$floors = RestaurantFloor::where('restaurant_id',$id_restaurant)->pluck('name','id');


		 //print_r($bookings); die();
		return view('restaurant.guestluser',
			[
				'users'=>$groupedUsers,
				'selectuser'=>$selectuser,
				'vips'=>$viptagList,
				'bookings'=>$bookings ,
				'vip' => $vip,
				'count'=> $count,
				'visitcount'=> $visitcount,
				'cancelcount'=> $cancelcount,
				'categories'=>$categories,
				'tags'=>$tags,
				'floors'=>$floors,
				'id_restaurant'=>$id_restaurant
			]);
	}

	public function vipgust(Request $request)
	{
		$data = $request->all();

		$rules = [
			'first_name'=>'required',
			//'last_name'=>'required',
			'email'=>'required|email|string|max:255',
			'phone'=>'required|numeric|min:10',
			'user_id'=>'required',
			'id_restaurant'=>'required',
			'updated_by'=>'required',
			'images.*'=>'mimes:png,jpeg,jpg,webp'
		];
		$validation = validator::make($data,$rules);
		if($validation->fails()){
			$validation_error = $validation->errors()->all();
			return redirect()->to(url()->previous())->withErrors($validation_error);
		}else{

			if(filter_var($data['email'], FILTER_VALIDATE_EMAIL))
			{
					$userData =  [
						'first_name'	=> ucwords($data['first_name']),
						'last_name'		=> ucwords($data['last_name']),
						'name'			=> ucwords($data['first_name']).' '.ucwords($data['last_name']),
						'email'			=> $data['email'],
						'mobile'    	=> $data['phone'],
					];

					if($request->hasfile('image')) {
						$image      = $request->file('image');
						$directory = 'user_images';
						$imageName = time().'.'.$request->image->extension();
						$image->storeAs('public/'.$directory, $imageName);
						$file_name = $directory.'/'.$imageName;
						$userData =  ['image' => $file_name];
					}

					$userupdate = User::where('id',$data['user_id'])->update($userData);

					if(isset($data['vip_tag']) && ($data['vip_tag'] > 0 )){

						if (VipUser::where('restaurant_id',$data['id_restaurant'])
						->where('user_id',$data['user_id'])
						->exists()) {
							$vipdata = [
								'vip_tag_id' => $data['vip_tag'],
								'updated_by' => $data['updated_by'],
								'vip_note' => $data['vip_note']
							];
							VipUser::where('restaurant_id',$data['id_restaurant'])
							->where('user_id',$data['user_id'])
							->update($vipdata);


						}else{

							$vipuser = new VipUser;
							$vipuser->user_id = $data['user_id'];
							$vipuser->restaurant_id = $data['id_restaurant'];
							$vipuser->vip_tag_id = $data['vip_tag'];
							$vipuser->updated_by = $data['updated_by'];
							$vipuser->vip_note = $data['vip_note'];
							if($vipuser->save()	){
								$vipsave = true;
							}
						}
					}

				return redirect()->route('owner.restaurant.guestuser',$data['user_id'])->with('success','Guest updated successfully.');
			}else{
				return redirect()->route('owner.restaurant.guestuser',$data['user_id'])->with('danger','Error in: email not valid.');
			}
		}
	}

	public function restaurantsTimeSlot(Request $request,$floor_id=null,$id=null)
	{


		$floorid =$floor_id;

		$id_restaurant = session('id_restaurant');
		Session::put('category', $id);
		$category_id =Session::get('category');
		//print_r($category_id);
		if($floorid!=null)
		{
			$restaurantDetail = $floorid;

			$totalBookings = Booking::where('restaurant_id',$id_restaurant)->where('table_reserved_status', 1)->where('reserved_floor_id', $floorid)->where('status',1)->where( function($q) use($category_id){
								if($category_id>0){
									$q->where('category_id',$category_id);
								}
							})->count();
				//print_r($restaurantDetail);
			Session::put('floor', $floorid);
			$default_floor =Session::get('floor');
		}
		else
		{
			$restaurantDetail = DB::table('restaurant_floors')->where('restaurant_id', $id_restaurant)->where('type',1)->first();
				//print_r($restaurantDetail);
			$totalBookings = Booking::where('restaurant_id',$id_restaurant)->where('table_reserved_status',1)->where('reserved_floor_id', $restaurantDetail->id)->where('status',1)->where( function($q) use($category_id){
								if($category_id>0){
									$q->where('category_id',$category_id);
								}
							})->count();
			$default_floor_id =DB::table('restaurant_floors')->where('restaurant_id', $id_restaurant)->where('type',1)->first();
			$default_floor =$default_floor_id->id;
			Session::put('floor', $default_floor);

		}



		//print_r($default_floor);
		$restaurantFloorList = RestaurantFloor::where('restaurant_id', $id_restaurant)
		->orderBy('type','asc')
		->get();
		$categories = Category::where('status',1)->select('name','id')->get();

		//print_r($default_floor);
		//	print_r($category_id);

		$rts = $this->restaurantSlot($id_restaurant,$default_floor,$category_id);
		//print_r($rts);
		return view('restaurant.reservetimeslots',['rts'=>$rts, 'floorList'=>$restaurantFloorList, 'defaultfloor'=>$restaurantDetail,'category' =>$categories,'totalBookings'=>$totalBookings,'default_floor'=>$default_floor,'category_id' => $category_id]);
	}
	public function restaurantSlot($id_restaurant,$default_floor,$category_id)
	{
		$current_day = date("l");
		$openingHours = WeeklyHour::where('restaurant_id',$id_restaurant)->first();
		if($current_day == 'Monday'){
			$closeinghour = $openingHours->mon_to;
			$openinghour = $openingHours->mon_from;
		}
		if($current_day == 'Tuesday'){
			$closeinghour = $openingHours->tue_to;
			$openinghour = $openingHours->tue_from;
		}
		if($current_day == 'Wednesday'){
			$closeinghour = $openingHours->wed_to;
			$openinghour = $openingHours->wed_from;
		}
		if($current_day == 'Thursday'){
			$closeinghour = $openingHours->thu_to;
			$openinghour = $openingHours->thu_from;
		}
		if($current_day == 'Friday'){
			$closeinghour = $openingHours->fri_to;
			$openinghour = $openingHours->fri_from;
		}
		if($current_day == 'Saturday'){
			$closeinghour = $openingHours->sat_to;
			$openinghour = $openingHours->sat_from;
		}
		if($current_day == 'Sunday'){
			$closeinghour = $openingHours->sun_to;
			$openinghour = $openingHours->sun_from;
		}

		//print_r($id_restaurant );
		//print_r($closeinghour );
	//	print_r($openinghour );
		 //$openinghour = '00:00:00';
		 //$closeinghour = '23:59:59';

		$maininterval = ' +60 minutes';
		$hourslots = $this->timeslots($openinghour, $maininterval, $closeinghour);

			$restaurants_slots = array_map(function ($arr){

			//print_r($floor);
			$mt = ' +15 minutes';
			$arr['minuteslots'] = $this->timeslots($arr['start'], $mt, $arr['end']);


						// print_r($value['start'].','.$value['end']);
						// print_r($arr);
						// print_r($query->toSql());

			return $arr;
		},$hourslots);
		return $restaurants_slots;

	}

	public function restaurantSlot2($id_restaurant,$default_floor,$category_id)
	{
		$current_day = date("l");
		$openingHours = WeeklyHour::where('restaurant_id',$id_restaurant)->first();
		// dd($openingHours);
		if($current_day == 'Monday'){
			$closeinghour = $openingHours->mon_to;
			$openinghour = $openingHours->mon_from;
		}
		if($current_day == 'Tuesday'){
			$closeinghour = $openingHours->tue_to;
			$openinghour = $openingHours->tue_from;
		}
		if($current_day == 'Wednesday'){
			$closeinghour = $openingHours->wed_to;
			$openinghour = $openingHours->wed_from;
		}
		if($current_day == 'Thursday'){
			$closeinghour = $openingHours->thu_to;
			$openinghour = $openingHours->thu_from;
		}
		if($current_day == 'Friday'){
			$closeinghour = $openingHours->fri_to;
			$openinghour = $openingHours->fri_from;
		}
		if($current_day == 'Saturday'){
			$closeinghour = $openingHours->sat_to;
			$openinghour = $openingHours->sat_from;
		}
		if($current_day == 'Sunday'){
			$closeinghour = $openingHours->sun_to;
			$openinghour = $openingHours->sun_from;
		}

		//print_r($id_restaurant );
		//print_r($closeinghour );
	//	print_r($openinghour );
		 //$openinghour = '00:00:00';
		 //$closeinghour = '23:59:59';

		$maininterval = ' +15 minutes';
		$hourslots = $this->timeslots($openinghour, $maininterval, $closeinghour);

			$restaurants_slots = array_map(function ($arr){

			//print_r($floor);
			$mt = ' +15 minutes';
			$arr['minuteslots'] = $this->timeslots($arr['start'], $mt, $arr['end']);


						// print_r($value['start'].','.$value['end']);
						// print_r($arr);
						// print_r($query->toSql());

			return $arr;
		},$hourslots);
		return $restaurants_slots;

	}

	protected function timeslots($oh, $int ,$ch)
	{
		//	print_r($oh);print_r('/////');

		//$todayDate = Carbon::now()->format('H:i:m');
		$start_time = strtotime($oh);
		$end_time = strtotime($ch);
		//print_r($start_time);
		//print_r($end_time);
		$slot = strtotime(date('h:i A',$start_time) . $int);
		$datytohours = [];

		$restaurant =Session::get('id_restaurant');
		$category =Session::get('category');


		$floor =Session::get('floor');


		//print_r($floor);

		for ($i=0; $slot <= $end_time; $i++)
		{
			$datytohours[$i] = [

				'start' => date('h:i A', $start_time),
				'end' => date('h:i A', $slot),
				// 'DD'=>DateTime::createFromFormat('h:i A', '01:00 PM'),
				//'DD' => $start_time,
				'bookings' =>  DB::table('bookings')->leftJoin('categories','categories.id','=','bookings.category_id')
							->leftJoin('restaurant_floors','restaurant_floors.id','=','bookings.floor_id')
							->leftJoin('users','bookings.user_id','=','users.id')
							->select('bookings.id as booking_id','bookings.floor_id','restaurant_floors.name as floor_name','bookings.table_id','bookings.table_no','bookings.tag_id', 'bookings.status','bookings.category_id','bookings.no_of_person','bookings.user_id','bookings.for_date','bookings.for_time','bookings.table_visit','users.name as user_name','users.mobile as mobile','categories.id as categories_id','categories.name as categories_name','bookings.booking_by','bookings.reserved_table_detail','bookings.table_detail')

							->where( function($q) use($category){
								if($category>0){
									$q->where('bookings.category_id',$category);
								}
							})

							->where('bookings.table_reserved_status',1)
							->where('bookings.reserved_floor_id', $floor)
							->where('bookings.restaurant_id',$restaurant)
							->where('bookings.status',1)
							->whereBetween('for_time',[date('H:i', $start_time),date('H:i', $slot)])->get()->toArray()



			];
						foreach($datytohours[$i]['bookings'] as $key => $dd)
							{
								$rr = json_decode($dd->reserved_table_detail);
								$ff = json_decode($dd->table_detail);

								$dd->reserved_table_detail =$rr;
							   $dd->table_detail =$ff;

								if(isset($dd->reserved_table_detail) && $dd->reserved_table_detail != ""){
									$dd->table_updated =$rr[0]->table_no;
								 }elseif(isset($dd->table_detail) && $dd->table_detail != ""){
									$dd->table_updated =$ff[0]->table_no;
								}
							}

			$start_time = $slot;
			$slot = strtotime(date('h:i A',$start_time) . $int);
		}

		//	print_r($slot );
		return $datytohours;
	}




}
