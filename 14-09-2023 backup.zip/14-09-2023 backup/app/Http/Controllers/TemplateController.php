<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Template;
//use DB;
use DataTables;
use Illuminate\Validation\Rule;
class TemplateController extends Controller
{
    public function index()
    {
        return view('template');
    }

    public function templateData(Request $request)
    {
        $template=Template::where('status','!=',0)->get();
        return DataTables::collection($template)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('type',function ($result){
            return $result->type;
        })
            ->addColumn('title',function ($result){
            return $result->title;
        })
            ->addColumn('action',function ($result){
			$edit = "<td><a href='".route('admin.template.edittemplate',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                <a href='".route('admin.template.deletetemplate',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
            </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
				
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
     
	 public function statusupdatetemplate(Request $request){
        /*$id=$request->input('id');
		$data = DB::table('templates')->select('status')->where('id', '=', $id)->get();
        if($data[0]->status==1)
        $status = 0;
        elseif($data[0]->status==0)
        $status = 1;
		DB::table('templates')->where('id', $id)->update(['status' => $status]);
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$data]);*/
		$id = $request->input('id');
         $status = Template::find($id);
         if($status->status == 1)
          $status->status = 2;
         elseif($status->status == 2)
          $status->status = 1;
         $status->save();
         return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
    public function add()
    {
        return view('addtemplate');
    }

    public function store(Request $request)
    {

        $titleUniqueRule = Rule::unique('templates')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });

        $rules=[
            'type'=>'required|max:50',
            //'title'=>'required|max:50|unique:templates,title',
            'title' => ['required', 'max:50', $titleUniqueRule],
            'subject'=>'required|max:50',
            'message'=>'required|max:1000'
        ];
        $message = [
            'type.required'=>'Type Name is required',
            'type.max'=>'Type name limit exceed',
            'title.required'=>'Title name is required.',
            'title.max'=>'Title name limit exceed',
            'subject.required'=>'Subject name is required',
            'subject.max'=>'Subject name limit exceed',
            'message.required'=>'Message content is required'
        ];
        $request->validate($rules,$message);
        $template = new Template;
        $template->type = $request->type;
        $template->title = $request->title;
        $template->subject = $request->subject;
        $template->message = $request->message;
        $template->status = 1;
        $template->save();
        return redirect()->Route('admin.template.template')->with('success','Template addded successfully');
    }

    public function edit($id)
    {
        $template=Template::find($id);
        return view('edittemplate',compact('template'));
    }
    public function update(Request $request, $id)
    {

        $titleUniqueRule = Rule::unique('templates')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);

        $rules=[
            //'title'=>'required|max:25|unique:templates,title,'.$id.'',
            'title' => ['required', 'max:25', $titleUniqueRule],
            'subject'=>'required|max:50',
            'message'=>'required|max:1000'
        ];
        $message = [
            'title.required'=>'Title name is required.',
            'subject.required'=>'Subject name is required',
            'message.required'=>'Message content is required'
        ];
        $request->validate($rules,$message);
        $template=Template::find($id);
        $template->title = $request->title;
        $template->subject = $request->subject;
        $template->message = $request->message;
        $template->save();
        return redirect()->Route('admin.template.template')->with('success','Template edited successfully');
    }

    public function delete($id)
    {
        $template=Template::find($id);
        $template->status=0;
        $template->save();
        return redirect()->Route('admin.template.template')->with('success','Template deleted successfully');
    }
}
