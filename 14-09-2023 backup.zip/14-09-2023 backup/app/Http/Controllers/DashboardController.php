<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Booking;
use App\Models\Restaurant;
use App\Models\UserSubscription;
use DB;
use Illuminate\Support\Arr;
use DataTables;
class DashboardController extends Controller
{
    public function index()
    {


$usersdata = User::select(\DB::raw('UNIX_TIMESTAMP(Date(created_at)) as dates'),\DB::raw("COUNT(*) as count"))
			->groupBy(\DB::raw('dates'))
			->get()->toArray();
			$users = '[[]]';
			if(isset($usersdata) && $usersdata != '' && count($usersdata) > 0)
			{
		     $users = '[';	
			foreach($usersdata as $usersd)
			{
			//$add_one_day = ($usersd['dates']+24*60*60);
			$add_one_day = $usersd['dates'];
			$users .= '['.$add_one_day.'000,'.$usersd['count'].'],';
			}
			 $users .= ']';
			 $total_length = (strlen($users)-2);
			 $users = substr_replace($users, '', $total_length, 1);
			}
			//$users = '[[1633391999000,4],[1633478399000,5]]';
			
            $bookingdata = Booking::select(\DB::raw('UNIX_TIMESTAMP(DATE(created_at)) as dates'),\DB::raw("COUNT(*) as count"))
			->groupBy(\DB::raw('dates'))
			->get()->toArray();
            $booking = '[[]]';
			if(isset($bookingdata) && $bookingdata != '' && count($bookingdata) > 0)
			{
		     $booking = '[';	
			foreach($bookingdata as $bookingsd)
			{
			//$add_one_day = ($bookingsd['dates']+24*60*60);
			$add_one_day = $bookingsd['dates'];
			$booking .= '['.$add_one_day.'000,'.$bookingsd['count'].'],';
			}
			 $booking .= ']';
			 $total_length = (strlen($booking)-2);
			 $booking = substr_replace($booking, '', $total_length, 1);
			}
			
            $subscriptionsdata = UserSubscription::select(\DB::raw('UNIX_TIMESTAMP(DATE(created_at)) as dates'),\DB::raw("COUNT(*) as count"))
			->groupBy(\DB::raw('dates'))
			->get()->toArray();
            $subscriptions = '[[]]';
			if(isset($subscriptionsdata) && $subscriptionsdata != '' && count($subscriptionsdata) > 0)
			{
		     $subscriptions = '[';	
			foreach($subscriptionsdata as $subscriptionssd)
			{
			 //$add_one_day = ($subscriptionssd['dates']+24*60*60);
			 $add_one_day = $subscriptionssd['dates'];
			 $subscriptions .= '['.$add_one_day.'000,'.$subscriptionssd['count'].'],';
			}
			 $subscriptions .= ']';
			 $total_length = (strlen($subscriptions)-2);
			 $subscriptions = substr_replace($subscriptions, '', $total_length, 1);
			}
		
        return view('admin-dashboard', compact('users','booking','subscriptions'));
    }
    public function dates()
    {
        $booking = Booking::select(\DB::raw('UNIX_TIMESTAMP(DATE(created_at)) as dates'),\DB::raw("COUNT(*) as count"))
                    ->whereMonth('created_at', date('m'))
                    ->groupBy(\DB::raw('dates'))
                    ->get();
        $dataPoints = [];
        foreach($booking as $value){
            $dataPoints[] = [
                "name" => $value['dates'],
                "y" => floatval($value['count'])
            ];
        }
        return view('admin-dashboard',["data" => json_encode($dataPoints)]);
    }



 //            $arr=[];
 //            foreach($booking as $value)
 //            {   
 //                $arr[] = $value['dates'].', '.$value['count']; 
 //            }
 //            foreach($arr as $a)
 //            {
 //                // $c=str_replace('"', "", $a);
                
 //                // $aaa=trim($a, '"');
 //                // $b[]=$aaa;
 //                $b[] = explode('"',$a); 
 //                // $b=preg_replace('/(^[\"\']|[\"\']$)/', '', $b);
 // //                foreach($b as $value)
 // //                {  
 // //                    $pan=implode(" ",$value);
 // // //    //           $p=explode('"',$pan); 
 // //                    // return $pan;
 // //                }

 //            }
 //            // $z[]=$pan;
 //            // $y[]=$z;
 //    //         $length = count($b);
 //    //         for ($i = 0; $i <= $length; $i++) {
 //    //             $z= implode(" ",$b);
 //    //                 $m=trim('"',$z);

 // // foreach($b as $value)
 // // {
 // //    $pan=implode(" ",$value);
 // //    // $p=explode('"',$pan); 
 // //    // return $pan;
 // // }
 //       // [[1630434600, 1],[1630521000, 2],[1630607400,5]] data Format
 //        return $b;
 //    }


    public function dashboardRest()
    {
        return view('admin-dashboard');
    }
    public function dashboardRestList()
    {
        		
		$restaurants = Restaurant::select('restaurants.id as Rid','restaurants.name as Rname','restaurants.address as Address','restaurants.created_at','restaurants.status','restaurants.verified','restaurants.admin_comment');
		$restaurants = $restaurants->where('restaurants.status', '=', 0);
		$restaurants = $restaurants->orderBy('restaurants.id','DESC');
		$restaurants = $restaurants->limit(10);
        $restaurants = $restaurants->get();

        return DataTables::collection($restaurants)
            ->addColumn('Rid',function ($result){
            return $result->Rid;
        })
            ->addColumn('Rname',function ($result){
            return $result->Rname;
        })
            ->addColumn('Address',function($result){
            return $result->Address;
        })
		
		->addColumn('actions',function ($result){
            $view = '<a href='.route('admin.details',$result->Rid).' target="_blank" class="btn btn-sm btn-info">View</a>';
			$edit = '<a href='.route('admin.editres',$result->Rid).' target="_blank" class="btn btn-sm btn-info">Edit</a>'; 
            if($result->status == 3)
            $rejected = '<a data-id="'.$result["Rid"].'"  class="btn btn-sm btn-danger ">Rejected</a>';
        	else
			$rejected = '<a data-id="'.$result["Rid"].'"  class="btn btn-sm btn-danger reject" data-toggle="modal" data-target="#modalContactForm" style="color: white;">Reject</a>';

            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-primary btn-sm status">Enable</button>'.$view.$edit.$rejected;
            elseif($result->status == 0)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-warning btn-sm status">Disable</button>'.$view.$edit.$rejected;
            elseif($result->status == 3)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-sm btn-danger c-tooltip" title="">Rejected<span class="tooltiptext">'.$result["admin_comment"].'</span></button>';
          
        })
            ->addColumn('verify',function ($result){
            	 if($result->verified == 1)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-primary btn-sm verify">Verified</button>';
            else
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-warning btn-sm verify"> Unverified</button>';
 
            
           
        })
		
		->rawColumns(['actions','verify'])
		->addIndexColumn()
        ->make(true);
    }
}
