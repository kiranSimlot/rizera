<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; 
use App\Models\AppSplashSlider; 
use File; 
use DataTables;

class SplashSliderController extends Controller
{
     public function index()
    {
        return view('splashSlider');
    }
    public function splashSliderData(Request $request)
    {
        $city=AppSplashSlider::where('status','!=',0)->get();
        return DataTables::collection($city)
            ->addColumn('id',function ($result){
            return $result->id;
        })
        ->addColumn('image',function ($result){
            if(!empty($result->image) )
                return "<td><img src='".asset('storage').'/'.$result->image."' width='100px'></td>";
            else
                return "<td><img src='".asset('storage/city/no_image.jpg')."' width='100px'></td>";
        }) 
        ->addColumn('action',function ($result){
                $edit = "<td><a href='".route('admin.splashSlider.editSplashSlider',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                    <a href='".route('admin.splashSlider.deleteSplashSlider',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
                </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit; 
        })
        ->rawColumns(['action','image'])
		->addIndexColumn()
        ->make(true);
    }
    
    public function statusUpdateSplashSlider(Request $request){
        /*$id=$request->input('id');
        $data = DB::table('cities')->select('status')->where('id', '=', $id)->get();
        if($data[0]->status==1)
        $status = 0;
        elseif($data[0]->status==0)
        $status = 1;
        DB::table('cities')->where('id', $id)->update(['status' => $status]);
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$data]);*/
        $id = $request->input('id');
 $status = AppSplashSlider::find($id);
 if($status->status == 1)
  $status->status = 2;
 elseif($status->status == 2)
  $status->status = 1;
 $status->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
    
    public function add()
    { 
        return view('addSplashSlider');
    }
    public function store(Request $request)
    {
        $city = new AppSplashSlider;
        $rules=[
            'image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=700,min_height=500'
        ];
        $message = [ 
            'image.required'=>'Image is required.',
            'image.mime'=>'file is not image',
            'image.dimensions'=>'file size is not correct',
        ];
        $request->validate($rules,$message);
        $directory = 'splash-banners';
        $image = $request->image;
        $image_name = $request->user()->id.time().rand(1,999999999).'.'.$image->extension(); 
        $image->storeAs('public/'.$directory, $image_name);  
        if($image = $request->file('image'))
        {
            $image = $directory.'/'.$image_name;
            $city->image = $image;
        }
        else
        {
            unset($request->image);
        }
        $city->status = 1;
        $city->save();
        // $request->city_image->move(public_path('city'), $city_image);
        return redirect()->Route('admin.splashSlider.list')->with('success','Splash Slider addded successfully');
    }

    public function edit($id)
    {
        $city=AppSplashSlider::find($id); 
        return view('editSplashSlider',compact(['city']));
    }
    public function update(Request $request, $id)
    {
        $rules=[ 
           'image'=>'image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=700,min_height=500'
        ];
        $message = [ 
             'image.mime'=>'file is not image',
             'image.dimensions'=>'file size is not correct',
        ];
        $request->validate($rules,$message);
        $city=AppSplashSlider::find($id);

        $cityImage = public_path("storage/{$city->image}"); // get previous image from folder
      
            $directory = 'splash-banners';
            $image = $request->image;
            $image_name = $request->user()->id.$id.time().rand(1,999999999).'.'.$image->extension(); 
            $image->storeAs('public/'.$directory, $image_name); 

        if (File::exists($cityImage)) { // unlink or remove previous image from folder
            unlink($cityImage);
        }
  
        if($image = $request->file('image'))
        {
            $image = $directory.'/'.$image_name;
            $city->image = $image;
        }
        else
        {
            unset($request->image);
        }
        $city->save(); 
        return redirect()->Route('admin.splashSlider.list')->with('success','Splash Slider edited successfully');
    }
    public function delete($id)
    {
        $city=AppSplashSlider::where('id',$id)->delete();
        
        
        return redirect()->Route('admin.splashSlider.list')->with('success','Splash Slider deleted successfully');
    }
}
