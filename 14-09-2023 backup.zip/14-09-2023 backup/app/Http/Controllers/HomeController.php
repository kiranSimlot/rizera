<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Restaurant;
use App\Models\Country;
use App\Models\City;
use App\Models\User;
use App\Models\Time;
use App\Models\Facilities;
use App\Models\CuisineType;
use App\Models\RestaurantCuisineType;
use App\Models\WeeklyHour;
use App\Models\RestaurantImage;
use App\Models\RestaurantHoliday;
use App\Models\CommonSetting;
use App\Models\Item;
use App\Models\MenuCategory;

use DB;
use Cookie;
use Session;
use App;
use DataTables;

class HomeController extends Controller
{
        public function root()
        {
            return view('root');
        }

        public function index(Request $request)
        {
            $today_date = date('Y-m-d');
            $countryId = Session::get('countryId');
            $bannerImage=DB::table('banner_images')->select('*')->where('country_id',$countryId)->where('status',1)->get();
            $restaurant = new Restaurant;
            $restaurants = $restaurant->where('status',1);

            // print_r($restaurants); die();

            if(isset($request->search) && $request->search != "")
            {
                $restaurants = $restaurants->where('restaurants.name','LIKE','%'.$request->search.'%');
            }
            if(isset($request->search) && $request->search != "")
            {
                $restaurants = $restaurants->orwhere('restaurants.address','LIKE','%'.$request->search.'%');
            }
            if(isset($request->search) && $request->search != "")
            {
                $restaurants = $restaurants->with('getCuisine.Cuisine')->orwhere('name','LIKE','%'.$request->search.'%');
            }
            if($countryId>0)
            {
                $restaurants=$restaurants->with( 'getFacilities.Facilities','getHour')
                                         ->where('country_id','=',$countryId)
                                         ->where('status','=',1)
                                         ->take(6)
                                         ->get();
            }
            else
            {
                $restaurants=$restaurants->with( 'getFacilities.Facilities','getHour')
                                         ->where('country_id','=',1)
                                         ->where('status','=',1)
                                         ->take(6)
                                         ->get();
            }

            foreach ($restaurants as $key => $value) {
            $value->images = RestaurantImage::where('restaurant_id',$value->id)
                            ->where('doc_for',1)->where('doc_type',1)
                            ->where('image_type',1)
                            ->select('image')
                            ->get();
            $value->holidaydate =RestaurantHoliday::where('restaurant_id',$value->id)
                                ->pluck('date','occasion')
                                ->toArray();
            $value->getRestaurantCuisine =CuisineType::join('restaurant_cuisine_types','restaurant_cuisine_types.cuisine_type_id','=','cuisine_types.id')
                        ->join('restaurants','restaurants.id','=','restaurant_cuisine_types.restaurant_id')
                        ->select('cuisine_types.id','cuisine_types.name','cuisine_types.name_ar','cuisine_types.name_fr','cuisine_types.country_id')
                        ->where('restaurant_cuisine_types.restaurant_id','=',$value->id)
                        ->where('cuisine_types.status','=',1)
                        ->first();


            }

           //  print_r($restaurants); die();
            $city = City::where('country_id','=',$countryId)->where('status',1)->get();
            $cuisine = CuisineType::join('restaurant_cuisine_types','restaurant_cuisine_types.cuisine_type_id','=','cuisine_types.id')
                        ->join('restaurants','restaurants.id','=','restaurant_cuisine_types.restaurant_id')
                        ->select('cuisine_types.id','cuisine_types.name','cuisine_types.name_ar','cuisine_types.name_fr','cuisine_types.country_id')
                        ->where('cuisine_types.country_id','=',$countryId)
                        ->groupBy('restaurant_cuisine_types.cuisine_type_id')
                        ->where('cuisine_types.status','=',1)
                        ->orderBy('cuisine_types.name')
                        ->get();

           //   print_r($city); die();

            $country = Country::where('id','=',$countryId)->get();
			$common_setting = CommonSetting::where('id','=',1)->get();

			// print_r($restaurants); die();
            return view('main',['restaurants'=>$restaurants,'city'=>$city,'cuisine'=>$cuisine,'countryId'=>$countryId,'country'=>$country,'banners'=>$bannerImage,'todayDate'=>$today_date,'common_setting'=>$common_setting]);
        }

        public function cuisine(Request $request, $id)
        {
            $countryId = Session::get('countryId');
            $restaurants = Restaurant::join('countries','countries.id','=','restaurants.country_id')
                        ->join('cities','cities.id','=','restaurants.city_id')
                        ->join('users','users.id','=','restaurants.user_id')
                        ->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')
                        ->join('cuisine_types','cuisine_types.id','=','restaurant_cuisine_types.cuisine_type_id')
                        ->join('weekly_hours','weekly_hours.restaurant_id','=','restaurants.id')
                        ->select('restaurants.id as rid','restaurants.name','restaurants.mobile','restaurants.email','restaurants.website','restaurants.*','restaurant_cuisine_types.*','cuisine_types.name as cname','cuisine_types.name_ar as c_arname','cuisine_types.name_fr as c_frname','countries.country_name','cities.city_name','users.name as owner','weekly_hours.*')
                        ->where('restaurant_cuisine_types.cuisine_type_id',$id)
                        ->where('restaurants.country_id','=',$countryId)
                        ->where('restaurants.status','=',1)
                        ->get();

            foreach ($restaurants as $key => $value) {
             $value->images = RestaurantImage::where('restaurant_id',$value->rid)
                             ->where('doc_for',1)
                             ->where('doc_type',1)
                             ->where('image_type',1)
                             ->select('image')
                             ->get();
            $value->holidaydate =RestaurantHoliday::where('restaurant_id',$value->rid)
                                ->pluck('date','occasion')
                                ->toArray();
            }
            return view('restaurant-cuisine-filter',['restaurants'=>$restaurants,'countryId'=>$countryId]);
        }
        public function allrest(Request $request, $id=null)
        {
            $countryId = Session::get('countryId');
            $restaurants = Restaurant::with( 'getFacilities.Facilities','getHour')
                          ->where('city_id','=',$id)
                          ->where('status','=',1)
                          ->get();

            foreach ($restaurants as $key => $value) {
             $value->images = RestaurantImage::where('restaurant_id',$value->id)->where('doc_for',1)->where('doc_type',1)->where('image_type',1)->select('image')->get();
            $value->holidaydate =RestaurantHoliday::where('restaurant_id',$value->id)->pluck('date','occasion')->toArray();
            }
                return view('listofrest',['restaurants'=>$restaurants,'countryId'=>$countryId]);

        }

        public function details(Request $request, $id){
            // dd($id);
            $today_date = date('Y-m-d');
            //print_r($today_date); die();
            $countryId = Session::get('countryId');
            $restaurants = Restaurant::with( 'getFacilities.Facilities','getWebImages','getHour')
                          ->where('restaurants.id',$id)
                          ->get();


            foreach ($restaurants as $key => $value)
            {
                $value->bannerImage=RestaurantImage::where('restaurant_id',$value->id)
                                    ->where('default',1)
                                    ->select('image')
                                    ->groupBy('restaurant_id')
                                    ->get();
                $value->restaurantChef =DB::table('restaurant_chef')->where('restaurant_id',$id)->first();
                $value->cuisine_type= DB::table('restaurant_cuisine_types')->where('restaurant_id',$id)->first();

                $value->holidaydate =RestaurantHoliday::where('restaurant_id',$id)->pluck('date','occasion')->toArray();



            }
             //print_r($restaurants); die();

            $samecuisine=DB::table('restaurant_cuisine_types')->where('restaurant_id',$id)->first();

            //print_r($samecuisine); die();
            $similar = Restaurant::with( 'getFacilities.Facilities','getHour')->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')->where('restaurants.country_id','=',$countryId)->where('restaurant_cuisine_types.cuisine_type_id',$samecuisine->cuisine_type_id)->where('restaurants.status',1)->where('restaurants.country_id',$countryId)->where('restaurants.id','!=',$id)->take(3)->get();

            //print_r($similar); die();

                foreach ($similar as $key => $values) {
                $values->images=RestaurantImage::where('restaurant_id',$values->restaurant_id)->where('doc_for',1)->select('image')->groupBy('restaurant_id')->get();
                $values->restaurantChef =DB::table('restaurant_chef')->where('restaurant_id',$values->restaurant_id)->first();
                $values->holidaydate =RestaurantHoliday::where('restaurant_id',$values->restaurant_id)->pluck('date','occasion')->toArray();
                $values->getHour =WeeklyHour::where('restaurant_id',$values->restaurant_id)->first();
                $values->getRestaurantCuisine =CuisineType::join('restaurant_cuisine_types','restaurant_cuisine_types.cuisine_type_id','=','cuisine_types.id')
                        ->join('restaurants','restaurants.id','=','restaurant_cuisine_types.restaurant_id')
                        ->select('cuisine_types.id','cuisine_types.name','cuisine_types.name_ar','cuisine_types.name_fr','cuisine_types.country_id')
                        ->where('restaurant_cuisine_types.restaurant_id','=',$values->restaurant_id)
                        ->where('cuisine_types.status','=',1)
                        ->first();
            }
       //   print_r($similar); die();
                return view('restaurant-layout.restaurant-detail',['restaurant'=>$restaurants,'countryId'=>$countryId,'todayDate'=>$today_date,'similar'=>$similar]);
        }

        public function pdf(Request $request, $id)
        {
            $restaurants = Restaurant::join('restaurant_images','restaurant_images.restaurant_id','=','restaurants.id')
                                    ->select('restaurant_images.image')
                                    ->where('restaurants.id',$id)
                                    ->where('restaurant_images.doc_type',2)
                                    ->value('restaurant_images.image');
            $file = asset('storage').'/'.$restaurants;
            return redirect($file);
        }

        public function restaurantList(Request $request)
        {
            $countryId = Session::get('countryId');
            $cuisine_types = CuisineType::get();
            $cities = City::where('country_id',$countryId)->where('status',1)->get();

            $expensiveness = [(object)['key'=>'$','is_selected'=>false],(object)['key'=>'$$','is_selected'=>false],(object)['key'=>'$$$','is_selected'=>false]];
            $restaurant = new Restaurant;
            $restaurants = $restaurant->where('status',1);
            // print_r($restaurants); die();

            if(isset($request->search) && $request->search != "")
            {
                $restaurants = $restaurants->where('restaurants.name','LIKE','%'.$request->search.'%');
            }


            if(isset($request->search) && $request->search != "")
            {
                $restaurants = $restaurants->orwhere('restaurants.address','LIKE','%'.$request->search.'%');
            }

            if(isset($request->search) && $request->search != "")
            {
                $restaurants = $restaurants->with('getCuisine.Cuisine')->orwhere('name','LIKE','%'.$request->search.'%');
            }

            if(isset($request->expensiveness) && $request->expensiveness != ""){
                $expensiveness_id = explode(',', $request->expensiveness);
                $restaurants = $restaurants->orWhereIn('restaurants.expensiveness',$expensiveness_id.'%');
            }

            if(isset($request->cuisine_type_ids) && $request->cuisine_type_ids != ""){
                $cuisine_type_ids = explode(',', $request->cuisine_type_ids);
                $restaurants = $restaurants->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')->orWhereIn('restaurant_cuisine_types.cuisine_type_id',$cuisine_type_ids);
            }

            if(isset($request->city_ids) && $request->city_ids != ""){
                $city_ids = explode(',', $request->city_ids);
                $restaurants = $restaurants->orWhereIn('city_id',$city_ids);
            }


            if(isset($request->sort_by_verified) && $request->sort_by_verified == "1") {
                $restaurants = $restaurants->orderBy('verified','ASC');

            }

            if (isset($request->sort_by_nearby) && $request->sort_by_nearby == "1") {
                $restaurants = $restaurants->orderByRaw('FIELD(country_id,'.$countryId.') DESC');
            }



            if($countryId>0)
            {
                $restaurants=$restaurants->with( 'getFacilities.Facilities','getHour')
                                        ->where('country_id','=',$countryId)
                                        ->where('status',1)
                                        ->get();
            }
            else
            {
                $restaurants=$restaurants->with( 'getFacilities.Facilities','getHour')
                                        ->where('country_id','=',1)
                                        ->where('status',1)
                                        ->get();
            }

            foreach ($restaurants as $key => $value) {
             $value->images = RestaurantImage::where('restaurant_id',$value->id)
                             ->where('doc_for',1)
                             ->where('doc_type',1)
                             ->where('image_type',1)
                             ->select('image')
                             ->get();
            $value->holidaydate =RestaurantHoliday::where('restaurant_id',$value->id)->pluck('date','occasion')->toArray();
            }



                 return view('listofrest',['restaurants'=>$restaurants,'countryId'=>$countryId,'cuisine_types'=>$cuisine_types,'cities'=> $cities,'expensiveness'=> $expensiveness]);
        }

        public function lang_change(Request $request, $locale)
        {
            App::setlocale($locale);
            session()->put('locale',$locale);
            $value= $request->session()->get('id');
                 return redirect(url()->previous());


        // App::setLocale($request->lang);
        // session()->put('locale', $request->lang);
        // return redirect()->back();
        // $data = $request->all();
        // App::setlocale($data);
        // session()->put('locale',$data);
        // $value = $request->cookie('id');
        // $value=Cookie::get('id');
        // return response()->json(['status'=>true,'success'=>'language value find successfully']);

        }

        public function defaultCountrySet(Request $request)
        {
            $data = $request->all();
            Session::put('countryId', $data['countryId']);
            $countryId = Session::get('countryId');
            return response()->json(['status'=>true,'success'=>'cookie value find successfully']);
        }

//Kiran
        public function restaurantItemList(Request $request, $key){
            return view('restaurant_item_list',compact('key'));
        }
        public function restaurantMenuListHtml(Request $request,$restaurant_id){
            $countryId = Session::get('countryId');
            // print_r(Session::get('restaurantId'));
            // exit;
            $categoryItemList = MenuCategory::with(['getItems'=>function($query) use($restaurant_id){
                return $query->where('resturant_id',$restaurant_id)->where('status',1);
            },'getItems.itemImage','getItems.itemPrice'])->get();
            // echo"<pre>";
            // print_r($categoryItemList);
            // exit;
            // $restaurant_id
            return view('restaurant_menu_list_html',compact('countryId','categoryItemList'));
        }
        public function allResturant(Request $request, $key)
        {
            $allrestaurant = Restaurant::with('getItemList','getItemList.category','getItemList.itemPrice','getItemList.itemImages')->where('resturant_key',$key)->first();

            $item_list =[];
            foreach ($allrestaurant->getItemList as $key => $value) {
                $item_list[$key]['restaurant_name']= $allrestaurant->name??'-';
                foreach ($value->itemPrice as $pricess) {
                    if(isset($pricess->price)){
                        $item_list[$key]['prices'] = $pricess->price;
                    }else{
                        $item_list[$key]['prices'] = "";
                    }
                }
                $item_list[$key]['name']= $value->name??'-';
                $item_list[$key]['category_name'] = $value->category->name??'-';
                $item_list[$key]['description']= $value->description??'-';
                foreach ($value->itemImages as $image) {
                    if(isset($image->image_name)){
                        $item_list[$key]['image_name'] = url('/files/' . $image->image_name);
                    }else{
                        $item_list[$key]['image_name'] ="";
                    }
                }
            }
            // echo('<pre>');
            // print_r($item_list);
            // die;
            return DataTables::collection($item_list)

            ->rawColumns([])
            ->addIndexColumn()
            ->make(true);
        }
}
