<?php

namespace App\Http\Controllers;

use App\Models\Restaurant;
use App\Models\Country;
use App\Models\City;
use App\Models\WeeklyHour;
use App\Models\Facility;
use App\Models\RestaurantHoliday;
use App\Models\RestaurantFacility;
use App\Models\RestaurantImage;
use App\Models\User;
use App\Models\Cuisine;
use App\Models\CuisineType;
use App\Models\RestaurantCuisineType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use DB;
use Carbon\Carbon;
use DataTables;
class RestaurantController extends Controller
{
	public function index()
	{
		return view('restaurant.adminlist');
	}
	public function restaurantdata(Request $request)
	{
		$month=$request->month; 
		$restaurants = Restaurant::with( ['getCountry','getCuisine','getOwner'])->select('restaurants.id as Rid','restaurants.name as Rname','restaurants.rating as Rating','restaurants.user_id','restaurants.country_id','restaurants.created_at','restaurants.status','restaurants.verified','restaurants.admin_comment')->where('restaurants.status','!=',2); 

		if(isset($month)  && $month!= "")
			$restaurants->Where('created_at','LIKE','%'.$month.'%');
 


		// Restaurant::join('countries','countries.id','=','restaurants.country_id')

  //               ->join('users','users.id','=','restaurants.user_id')
  //               ->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')
  //               // ->join('cuisine_types','cuisine_types.id','=','restaurant_cuisine_types.cuisine_type_id')
  //               // ->selectRaw("restaurant_cuisine_types.restaurant_id, GROUP_CONCAT(restaurant_cuisine_types.cuisine_type_id) as Cname")
  //       		->groupBy('restaurant_cuisine_types.restaurant_id')
  //               // ->select('restaurants.id as Rid','restaurants.name as Rname','restaurants.status as Status','restaurants.rating as Rating','restaurants.created_at as month','restaurant_cuisine_types.*','cuisine_types.name as Cname','users.name as Uname')
  //               ->Where('restaurants.created_at','LIKE','%'.$request->month.'%')
  //               ->orderBy('restaurants.id','desc');
        // $restaurants = $restaurants;
      
        			// echo "<pre>";
           //      	print_r($restaurants);
           //      	die;
		$restaurants = $restaurants->get();
        return DataTables::collection($restaurants)
            ->addColumn('Rid',function ($result){
            return $result->Rid;
        })
            ->addColumn('Rname',function ($result){
            return $result->Rname;
        })
            ->addColumn('Uname',function ($result){
            return $result->getOwner->name;
        })
		    ->addColumn('COname',function ($result){
            return $result->getCountry->country_name;
        })
            ->addColumn('Cname',function ($result){
            	$names = 'No cuisine type available';

             
            	//$restaurant_cuisine_types = RestaurantCuisineType::where('restaurant_id',$result->Rid)->selectRaw('GROUP_CONCAT(restaurant_cuisine_types.id) as cuisine_type_ids')->first();
            	$restaurant_cuisine_types = RestaurantCuisineType::where('restaurant_id',$result->Rid)->first();
//echo "vvv--"; echo "<pre>"; print_r($restaurant_cuisine_types); die;
            		//if (!empty($restaurant_cuisine_types) && $restaurant_cuisine_types->cuisine_type_ids != "") 
            		if (!empty($restaurant_cuisine_types)) 
            		{

            			 	//$array_of_cuisine_types = CuisineType::whereIn('id',explode(',',$restaurant_cuisine_types->cuisine_type_ids))->selectRaw('GROUP_CONCAT(cuisine_types.name) as names')->first();
            			 	$array_of_cuisine_types = CuisineType::whereIn('id',explode(',',$restaurant_cuisine_types->cuisine_type_id))->selectRaw('GROUP_CONCAT(cuisine_types.name) as names')->first();

            			 	if (!empty($array_of_cuisine_types) && $array_of_cuisine_types->names != "") 
            			 	{
            			 		$names = $array_of_cuisine_types->names;
            			 	}
             		}
           


            return $names;
        })
            ->addColumn('Rating',function ($result){
            return $result->Rating;
        })
            ->addColumn('actions',function ($result){
            $view = '<a href='.route('admin.details',$result->Rid).' target="_blank" class="btn btn-sm btn-info">View</a>'; 
            
            $edit = '<a href='.route('admin.editres',$result->Rid).' target="_blank" class="btn btn-sm btn-info">Edit</a>';
            //$edit = '';

            if($result->status == 3)
            //$rejected = '<a data-id="'.$result["Rid"].'"  class="btn btn-sm btn-danger ">Rejectedeeee</a>';
            $rejected = '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-primary btn-sm unreject">Rejected</button>';
        	else
			$rejected = '<a data-id="'.$result["Rid"].'"  class="btn btn-sm btn-danger reject" data-toggle="modal" data-target="#modalContactForm" style="color: white;">Reject</a>';

            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-primary btn-sm status">Enable</button>'.$view.$rejected;
            elseif($result->status == 0)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-warning btn-sm status">Disable</button>'.$view.$rejected;
            elseif($result->status == 3)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-sm btn-danger c-tooltip unreject" title="">Rejected<span class="tooltiptext">'.$result["admin_comment"].'</span></button>';
          
        })
            ->addColumn('verify',function ($result){
            	 if($result->verified == 1)
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-primary btn-sm verify">Verified</button>';
            else
                return  '<button type="button" data-id="'.$result["Rid"].'"  class="btn btn-warning btn-sm verify"> Unverified</button>';
 
            
           
        })
              

        ->rawColumns(['actions','verify'])
		->addIndexColumn()
        ->make(true);
	}



public function editres($id) {
  if(Auth::user()->type == 1)
   {
        //$restaurant = Restaurant::where('id',$id)->where('user_id',Auth::user()->id)->first();
        $restaurant = Restaurant::where('id',$id)->first();
		$countries = DB::table("countries")->pluck("country_name","id");
		$cities = DB::table("cities")->pluck("city_name","id");
		$openingHours = WeeklyHour::where('restaurant_id',$id)->first();

		if (!empty($openingHours)) {
			$openingHours = $openingHours->toArray();
		}
		if(!$restaurant){
			//return redirect()->route('owner.restaurant.restaurantlist')->with('success','Restaurant not found.');
			return redirect('restaurants')->with('success','Restaurant not found.');
		}

		$cuisineTypes = CuisineType::pluck("name","id"); 
		$facilities = Facility::pluck("name","id"); 



		$restaurantCuisineTypes = RestaurantCuisineType::where('restaurant_id',$id)->pluck('cuisine_type_id')->toArray();  	
		$restaurantHolidays = RestaurantHoliday::where('restaurant_id',$id)->select('id','date','occasion')->get()->toArray();  	 
		$restaurantFacilities = RestaurantFacility::where('restaurant_id',$id)->pluck('facility_id')->toArray();  
		$restaurantChef= 	DB::table('restaurant_chef')->where('restaurant_id',$id)->first();
		$homeDeliveryArray = ['No','Yes'];
		$openStatusArray = ['Closed','Open'];
		$images = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',1)->get(); 
		$images_360 = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',2)->get();
		$menu_files = RestaurantImage::where('restaurant_id',$id)->where('doc_for',2)->get();

	//	print_r($restaurant);die;
		return view('restaurant.restaurantedit',['countries'=>$countries,'restaurant'=>$restaurant,'cities'=>$cities,'openingHours'=>$openingHours,'cuisineTypes'=>$cuisineTypes,'restaurantCuisineTypes'=>$restaurantCuisineTypes,'homeDeliveryArray'=>$homeDeliveryArray,'openStatusArray'=>$openStatusArray,'restaurantFacilities'=>$restaurantFacilities,'facilities'=>$facilities,'restaurantHolidays'=>$restaurantHolidays,'images'=>$images,'images_360'=>$images_360,'menu_files'=>$menu_files,'restaurantChef'=>$restaurantChef]);
   } }


public function updateres(Request $request){

		$data = $request->all();
		
		$rules= [
			'id'=>'required|numeric',
			'name'=>'required|max:50',
			'description'=>'max:250',
			'online_book_tnc'=>'max:250',
			'notes'=>'max:250',
			'min_payment'=>'required|min:0',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric'
		];
		$request->validate($rules);

		$restaurant = Restaurant::where('id',$data['id'])->first();
				
		if(!$restaurant)
		{
			return redirect()->Route('admin.restaurant.list')->with('success','Restaurant not found.');
		}
		
		$restaurant->name = ucwords($data['name']);
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];
		$restaurant->home_delivery = $data['home_delivery'];
		$restaurant->min_payment = $data['min_payment'];
		$restaurant->takeout = $data['takeout'];
		$restaurant->mobile = $data['mobile'];
		$restaurant->email = $data['email'];
		$restaurant->website = $data['website'];
		$restaurant->address = $data['address'];
		$restaurant->notes = $data['notes'];
		$restaurant->description = $data['description'];
		$restaurant->online_book_tnc = $data['online_book_tnc'];
		$restaurant->notification_emails = $data['notification_emails'];
		$restaurant->notification_mobiles = $data['notification_mobiles'];
		$restaurant->open_status = $data['open_status'];
		$restaurant->expensiveness = $data['expensive'];

		if (isset($data['delete_holiday_list'])) {
			RestaurantHoliday::whereIn('id',explode(',', $data['delete_holiday_list']))->delete();	
		}
        
		
		
		// print_r($data['id']);die;   
		if (isset($data['saved_occasion_name']) and isset($data['saved_occasion_date'])) { 
			foreach ($data['saved_occasion_id'] as $key => $value) {
				$restaurantHolidayFind = RestaurantHoliday::find($data['saved_occasion_id'][$key]);
				$restaurantHolidayFind->date = $data['saved_occasion_date'][$key];
				$restaurantHolidayFind->occasion = $data['saved_occasion_name'][$key];
				if ($restaurantHolidayFind->isDirty('occasion') || $restaurantHolidayFind->isDirty('date')) {
					$restaurantHolidayFind->save();
				} 
			} 
		}

		$upload_cuisine_type_array = [];
		if (isset($data['cuisine_type_id'])) {
		foreach ($data['cuisine_type_id'] as $key => $value) {
			$upload_cuisine_type_array[] = array('restaurant_id'=>$restaurant->id,'cuisine_type_id'=>$value);
		}

		$restaurant_cuisine_type_array = RestaurantCuisineType::where('restaurant_id',$restaurant->id)->pluck('cuisine_type_id')->toArray();   
		if (!empty(array_diff($data['cuisine_type_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['cuisine_type_id']))) { 
		RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
		RestaurantCuisineType::insert($upload_cuisine_type_array); 
		}
		} else {
		if ($request->restaurant_cuisine_types_saved != "") { 
		RestaurantCuisineType::where('restaurant_id',$restaurant->id)->delete(); 
		}
		}



		$upload_facility_array = [];
		if (isset($data['facility_id'])) {
			foreach ($data['facility_id'] as $key => $value) {
				$upload_facility_array[] = array('restaurant_id'=>$restaurant->id,'facility_id'=>$value);
			}

			$restaurant_cuisine_type_array = RestaurantFacility::where('restaurant_id',$restaurant->id)->pluck('facility_id')->toArray();   
			if (!empty(array_diff($data['facility_id'], $restaurant_cuisine_type_array)) || !empty(array_diff($restaurant_cuisine_type_array,$data['facility_id']))) { 
				RestaurantFacility::where('restaurant_id',$restaurant->id)->delete(); 
				RestaurantFacility::insert($upload_facility_array); 
			}
		} else {
			if ($request->restaurant_cuisine_types_saved != "") { 
			RestaurantFacility::where('restaurant_id',$restaurant->id)->delete(); 
			}
		}
            
 
		

		$chef_name = $data['chef_name'];
		$chef_mobile = $data['chef_mobile'];
		$chef_fb_link = $data['chef_fb_link'];
		$chef_insta_link = $data['chef_insta_link'];

			$values[] = [
				'restaurant_id' => $restaurant->id,
				'chef_name' => $chef_name,
				'chef_mobile' => $chef_mobile,
				'chef_fb_link' => $chef_fb_link,
				'chef_insta_link' => $chef_insta_link,
				'chef_image' => '', 
				
			];
			DB::table('restaurant_chef')->where('restaurant_id',$restaurant->id)->delete(); 
			DB::table('restaurant_chef')->insert($values);


		$WeeklyHour = WeeklyHour::where('restaurant_id',$request->id)->first();

		if (empty($WeeklyHour)) {
		WeeklyHour::create([
			'restaurant_id' => $request->id,
			'mon_from' => $request->monday_open_time == "" ? null : $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time == "" ? null : $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time == "" ? null : $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time == "" ? null : $request->thursday_open_time,
			'fri_from' => $request->friday_open_time == "" ? null : $request->friday_open_time,
			'sat_from' => $request->saturday_open_time == "" ? null : $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time == "" ? null : $request->sunday_open_time,
			'mon_to' => $request->monday_close_time == "" ? null : $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time == "" ? null : $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time == "" ? null : $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time == "" ? null : $request->thursday_close_time,
			'fri_to' => $request->friday_close_time == "" ? null : $request->friday_close_time,
			'sat_to' => $request->saturday_close_time == "" ? null : $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time == "" ? null : $request->sunday_close_time,
		]);
		} else {
		WeeklyHour::where('restaurant_id',$request->id)->update([
			'mon_from' => $request->monday_open_time,
			'tue_from' => $request->tuesday_open_time,
			'wed_from' => $request->wednesday_open_time,
			'thu_from' => $request->thursday_open_time,
			'fri_from' => $request->friday_open_time,
			'sat_from' => $request->saturday_open_time,
			'sun_from' => $request->sunday_open_time,
			'mon_to' => $request->monday_close_time,
			'tue_to' => $request->tuesday_close_time,
			'wed_to' => $request->wednesday_close_time,
			'thu_to' => $request->thursday_close_time,
			'fri_to' => $request->friday_close_time,
			'sat_to' => $request->saturday_close_time,
			'sun_to' => $request->sunday_close_time,
		]);
		}


  //$restaurant->status = 0;
  if($restaurant->save())
   {
	return redirect()->Route('admin.restaurant.list')->with('success','Restaurant edited successfully.');
   }
  else
   { 
	return redirect()->Route('admin.restaurant.list')->with('error','Error in: Update restaurant.');
   }
          
	
	}


    public function rejectModified(Request $request)
	{
        $id=$request->input('id');
        $status=Restaurant::find($id);
        $status->status = 1;
        $status->save();
        return response()->json(['status'=>true,'success'=>'status rejected change successfully','message'=>'unrejected successfully','data'=>$status]);
    }
	

	public function statusModified(Request $request)
	{
        $id=$request->input('id');
        $status=Restaurant::find($id);
        if($status->status==1)
        $status->status = 0;
        elseif($status->status==0)
        $status->status = 1;
        $status->save();
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }

    public function verifyModified(Request $request)
    {
    	$id=$request->input('id');
        $verify=Restaurant::find($id);
        if($verify->verified==1)
        $verify->verified = 0;
        elseif($verify->verified==0)
        $verify->verified = 1;
        $verify->save();
        return response()->json(['status'=>true,'success'=>'verify value change successfully','message'=>'status successfully','data'=>$verify]);
    }
 
    public function store(Request $request)
    {
    $data = $request->all();

    //print_r($data); die();
		$rules= [
			
			'rejection_reason'=>'required|max:50',
			
		];
		$request->validate($rules);
		
		$url_change_to = $data['url_change_to'];

		
        DB::table('restaurants')->where('id',$data['hidden_id'])->update(['admin_comment' => $data['rejection_reason'], 'status' => 3]);
		
		   if(isset($url_change_to) && $url_change_to != "" && $url_change_to == "dashboard")
		   {
		   return redirect()->Route('admin.admin-dashboard')->with('success','Rejection Reason updated successfully.');
		   }
		   else
		   {
		    return redirect()->Route('admin.restaurant.list')->with('success','Rejection Reason updated successfully.');
		   }
    }
 
	public function insert(Request $request){ 
		$data = $request->all();
		$rules=[
			'name'=>'required|max:50',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric',
		];
		$request->validate($rules);
		$restaurant = new Restaurant;
		$restaurant->user_id = Auth::user()->id;
		$restaurant->name = $data['name'];
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];

		if( $restaurant->save() ){
			return redirect('restaurants')->with('success','Restaurant added successfully.');
		}
		return view('restaurant.add');
	}

	public function edit($id){
		$restaurant = Restaurant::where('id',$id)->where('user_id',Auth::user()->id)->first();
		$countries = DB::table("Countries")->pluck("country_name","id");
		if(!$restaurant){
			return redirect('restaurants')->with('success','Restaurant not found.');
		}
		return view('restaurant.add',['countries'=>$countries,'restaurant'=>$restaurant]);
	}

	public function update(Request $request){
		$data = $request->all();
		$rules= [
			'id'=>'required|numeric',
			'name'=>'required|max:50',
			'country_id'=>'required|numeric',
			'city_id'=>'required|numeric',
		];
		$request->validate($rules);
		$restaurant = Restaurant::where('id',$data['id'])->where('user_id',Auth::user()->id)->first();
		if(!$restaurant){
			return redirect('restaurants')->with('success','Restaurant not found.');
		}
		$restaurant->name = $data['name'];
		$restaurant->country_id = $data['country_id'];
		$restaurant->city_id = $data['city_id'];
		if( $restaurant->save() ){
			return redirect('restaurants')->with('success','Restaurant added successfully.');
		}else{
			return redirect('restaurants')->with('error','Error in: Update restaurant.');
		}
	}

	public function getCity($id){
		$getCity = DB::table("Cities")->where("country_id",$id)->pluck("city_name","id");
        return json_encode($getCity);
	}

	public function delete($id){
		$restaurant = Restaurant::find($id);
		$restaurant->status = 2;
		if( $restaurant->save() ){
			return redirect('restaurants')->with('success','Restaurant deleted successfully.');
		}else{
			return redirect('restaurants')->with('error','Error in: Delete restaurant.');
		}
	}
	public function add(){
		$countries = DB::table("Countries")->pluck("country_name","id");
		return view('restaurant.add',['countries'=>$countries]);
	}
	public function details($id){
		// dd($id);
		if(Auth::user()->type == 1)
			$restaurants = Restaurant::with( 'getFacilities.Facilities','getImages')->where('restaurants.id',$id)->first();

			$openingHours = WeeklyHour::where('restaurant_id',$id)->first();
			if (!empty($openingHours)) 
			{
			$openingHours = $openingHours->toArray();
			}
			$restaurantChef = DB::table('restaurant_chef')->where('restaurant_id',$id)->first();

			$images = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',1)->get(); 
			$images_360 = RestaurantImage::where('restaurant_id',$id)->where('doc_for',1)->where('doc_type',1)->where('image_type',2)->get();
			//$menu_files = RestaurantImage::where('restaurant_id',$id)->where('doc_for',2)->get();
			$menu_files = RestaurantImage::where('restaurant_id',$id)->where('doc_for',2)->first();
				
			//echo "<pre>"; print_r($restaurantChef); die;

			return view('restaurant.restaurantdetails',['restaurant'=>$restaurants,'openingHours'=>$openingHours,'restaurantChef'=>$restaurantChef,'images'=>$images,'images_360'=>$images_360,'menu_files'=>$menu_files]);
			

			// $restaurants = Restaurant::with('getCountry','getCity','getOwner')->where('id',$id)->get();
			// $restaurants= Restaurant::join('countries','countries.id','=','restaurants.country_id')
			// 		->join('cities','cities.id','=','restaurants.city_id')
			// 		->join('users','users.id','=','restaurants.user_id')
			// 		->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')
			// 		->join('cuisine_types','cuisine_types.id','=','restaurant_cuisine_types.cuisine_type_id')
			// 		->select('restaurants.id as rid','restaurants.name','restaurants.mobile','restaurants.email','restaurants.website','restaurants.*','restaurant_cuisine_types.*','cuisine_types.name as cname','countries.country_name','cities.city_name','users.name as owner')
			// 		->where('restaurants.id',$id)
			// 		->get();
			// return view('restaurant.restaurantdetails',['restaurants'=>$restaurants]);
	}
	
    public function statusChange($id){
        $restaurant = Restaurant::find($id);
        if(!$restaurant){
                return redirect('details')->with('error','not found.');
        }else{
            $restaurant->verificationUpdate();
            if($restaurant->save()){
                return redirect('details')->with('success', Str::ucfirst($restaurant->name). ' account '. ($restaurant->verified==0?'not verified':'verified'));
            }else{
                return redirect('details')->with('error','Request failed.');
            }
        }
    }
}