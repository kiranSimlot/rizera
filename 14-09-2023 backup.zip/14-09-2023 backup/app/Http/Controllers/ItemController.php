<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MenuCategory;
use App\Models\Restaurant;
use App\Models\Item;
use App\Models\ItemImage;
use DataTables;
use DB;
use Carbon\Carbon;
use Auth;
use App\Models\ItemPrice;
use Session;
class ItemController extends Controller
{
  
    public function list(){
        return view('items.items_list');

    }
    
	public function itemData(Request $request){
        $id_restaurant = Session::get('id_restaurant');
        $items = Item::with('category','itemImages')
                    ->orderBy('id','DESC')
                    ->where('resturant_id',$id_restaurant)
                    ->where('status','!=', 0)
                    ->get();

        // print_r($items->toArray());
        $data = [] ;

        foreach($items as $key=>$item){
            // if(!isset($item->name)){
            //     echo '<pre>';
            //     print_r($item);
            //     exit;

            // }
            // print_r($item->id);
            // print_r($item->name);
            // print_r(' ');
            $data[$key]['id'] = $item->id;
            $data[$key]['name'] = (isset($item->name)?$item->name:'');
            $data[$key]['category'] = (isset($item->category->name)?$item->category->name:'');
            $data[$key]['category_id'] = (isset($item->category->id)?$item->category->id:'');
            // $data[$key]['image_name'] = [];
            // foreach ($item->itemImages as $image) {
            //     $data[$key]['image_name'][] = $image->image_name;
            // }
        }
        // exit('one');

     
       
        return DataTables::collection($data)
            ->addColumn('id',function ($result){
            return $result['id'];
        })
            ->addColumn('category',function ($result){
            return $result['category'];
        })
        ->addColumn('action',function ($result){

            $btn = "<a class='btn report-edit mr-2' href='".route('owner.items.edititem',['id'=>$result['id']])."'><img src='".url('')."/admin/imgs/edit_icon.svg' style='height: 15px;'  data-toggle='tooltip' data-placement='top' title='Edit'></a> <a href='javascript:void(0)'class = 'btn report-trash mr-2 soft_item_delete' id='".$result['id']."'><img src='".url('')."/admin/imgs/trash.svg' style='height: 15px;'  data-toggle='tooltip' data-placement='top' title='Delete'></a>";


            // $btn.= "<a href='".route('#',['id'=>$result['id']])."' style='border:none;'><i class='fa-solid fa-pen' onclick='return DelFun();'>Delete</i></a>";
            return $btn;
        })


        ->rawColumns(['action','id','category'])
        ->addIndexColumn()
        ->make(true);
    }


    public function add(){
    $id_restaurant = Session::get('id_restaurant');
    $categories = MenuCategory::orderBy('id','DESC')->where('status', 0)->where('restaurant_id',$id_restaurant)->get();
    $resturant_id = Restaurant::where('user_id',Auth::user()->id)->select('id')->first();
    $id_restaurant = Session::get('id_restaurant');
    // dd($resturant_id);
        return view('items.add_items',compact('categories','resturant_id','id_restaurant'));
    }
    
    public function store(Request $request){

    $jsonString = $request->restaurant_id;
    $data = json_decode($jsonString, true);
// dd($data);
// $restaurantId = $data['restaurant_id']['id'];
           $rules = [
                    'name' => 'required',
                    // Add any additional validation rules if needed
                    ];

                    $message = [
                    'name.required' => 'Name is required.',
                    // Add custom messages for other fields if needed
                    ];

                    $request->validate($rules, $message);

                    

                    /*$files = [];
                    if ($request->hasFile('image_name')) {
                    foreach ($request->file('image_name') as $file) {
                    $name = time() . rand(1, 50) . '.' . $file->extension();
                    $file->move(public_path('files'), $name);
            $files[] = $name;
            }
            }*/
        $id_restaurant = Session::get('id_restaurant');
        $item = new Item;
        $userId = Auth::id();
        $item->name = $request->name;
        $item->resturant_id	 = $id_restaurant;
        // $item->resturant_id	 = $userId;
        $item->category_id = $request->category_id;
        $item->description = $request->description;
        $image_session = $request->image_session;
        $item->save();

        // Get the last inserted item's ID
        $lastInsertedItemId = $item->id;

        $itemImage = new ItemImage;
        $itemImage->item_id = $lastInsertedItemId;
        $itemImage->image_name = $image_session;
        $itemImage->save();

        // Create records in the 'item_images' table for each uploaded file
        /*foreach ($files as $filename) {
        $itemImage = new ItemImage;
        $itemImage->item_id = $lastInsertedItemId;
        $itemImage->image_name = $filename;
        // $itemImage->path = 'files/' . $filename;
        $itemImage->save();
        }*/

        $prices = $request->input('price');
        $quantities = $request->input('quantity');
    
        foreach ($prices as $index => $price) {
            $itemPrice = new ItemPrice;
            $itemPrice->item_id = $lastInsertedItemId;
            $itemPrice->price = $price;
            $itemPrice->quantity = $quantities[$index];
            $itemPrice->save();
        }

        return redirect()->route('owner.items.list')->with('success', 'Items added successfully');

    }


    public function cropImageUpload(Request $request)
    {
        $folderPath = public_path('files/');

        $image_parts = explode(";base64,", $request->image);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
 
        $imageName = uniqid() . '.png';
 
        $imageFullPath = $folderPath.$imageName;
 
        file_put_contents($imageFullPath, $image_base64);
        
        session()->put('imageName',$imageName);
        /*$itemImage = new ItemImage;
        $itemImage->name = $imageName;
        $itemImage->save();*/
    
        return response()->json(['success'=>'Crop Image Uploaded Successfully']);
    }

    public function getSession(Request $request)
    {
        $imageName = $request->input('imageName');
        $value = Session::get($imageName);

        return response()->json(['value' => $value]);
    }



    
   public function edit(Request $request,$id){
        
        // dd($request->all());
        $item = Item::find($id);
        $id_restaurant = Session::get('id_restaurant');
        //$categories = MenuCategory::all();
        $categories = MenuCategory::orderBy('id','DESC')->where('status', 0)->where('restaurant_id',$id_restaurant)->get();
        $ItemImage = ItemImage::where('item_id',$id)->get();
        $ItemPrice = ItemPrice::where('item_id',$id)->where('status',0)->get();
       
       
        
        return view('items.edit_items',compact('item','categories','ItemImage','ItemPrice'));
    }

    public function update(Request $request,$id){
        
        // dd($request->all());
        $item = Item::find($id);

        $item->name = $request->name;
        $item->category_id = $request->category_id;
        $item->description = $request->description;
        $image_session = $request->image_session;
        $item->update();

        $ItemImage = ItemImage::where('item_id',$id);
        $ItemImage->delete();

        /*$files = [];
        if ($request->hasFile('file')) {
            foreach ($request->file('file') as $file){

                $name = time() . rand(1,50) . '.' . $file->extension();
                $file->move(public_path('files'), $name);
                $files[] = $name ;

            }
        }*/

        $itemImage = new ItemImage;
        $itemImage->item_id = $id;
        $itemImage->image_name = $image_session;
        $itemImage->save();

        /*foreach ($files as $filename){
            $itemImage = new ItemImage;
            $itemImage->item_id = $id;
            $itemImage->image_name = $filename;
            // $itemImage->path = 'files/' . $filename;
            $itemImage->save();
        }*/

        //for price and quantity
        $prices = $request->input('prices');
        $quantities = $request->input('quantities');



    foreach ($prices as $index => $price) {
        
        $quantity = $quantities[$index];

        ItemPrice::where('item_id', $id)
           
            ->update([
                'price' => $price,
                'quantity' => $quantity
            ]);
    }



      
        return redirect()->route('owner.items.list')->with('success', 'Items added successfully');
    }

        public function removePrice(Request $request)
        {
           
             $priceId = $request->price_id;

            $updated = ItemPrice::where('id', $priceId)->update(['status' => 1]);

            if($updated){
                $message = 'ItemPrice record updated successfully.';
            }else {
            $message = 'Unable to update ItemPrice record.';
            }
            return response()->json(['message' => $message]);
        }

        public function softDeleteItem(Request $request){
            $delete = Item::where('id', $request->id)->first(); 
            $delete->status = 0;
            $result = $delete->update();
            if($result){
                return response()->json([
                    'status' => true,
                    'message' => 'Item deleted successfully',
                ]);
            }
        }


}
