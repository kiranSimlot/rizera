<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Restaurant;


use App\Http\Controllers\Controller;
use App\Mail\RizeraMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use DataTables;
use DB;
class UserController extends Controller
{

    public function ownerList()
    {
        return view('owners');
    }
    public function ownerData(Request $request)
    {
        $owner = new User;
        $owner = $owner->where('users.created_at','LIKE','%'.$request->month.'%')
                        ->where('type',2)
                        ->where(function($q) {
                            $q->where('status', '1')
                              ->orWhere('status', '2');
                            })
                        ->select('users.id','users.name','users.email','users.status')
                        ->get();
        return DataTables::collection($owner)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('email',function ($result){
            return $result->email;
        })
        ->addColumn('actions',function ($result){
            $delete = '<button type="button" data-id="'.$result["id"].'" class="btn btn-danger btn-sm del">Delete</button>';
            $detail = '<a href='.route('admin.ownersDetail',['id'=>$result->id]).' class="btn btn-sm btn-outline-primary">View</a>';
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-primary btn-sm status">Enable</button>'.$delete.$detail;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-warning btn-sm status">Disabled</button>'.$delete.$detail;
        })

        ->rawColumns(['actions']) 
		->addIndexColumn()
        ->make(true);
    }
    
    public function staffList()
    {
        return view('staffs');
    }
    public function staffData(Request $request)
    {
        $user = User::join('restaurants','restaurants.id','=','users.restaurant_id')
                        ->where('users.created_at','LIKE','%'.$request->month.'%')
                        ->Where('type',3)
                        ->select('users.id','users.name','users.email','users.status as status','users.type','restaurants.name as Rname')
                        ->get();
        return DataTables::collection($user)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('email',function ($result){
            return $result->email;
        })
            ->addColumn('Rname',function ($result){
            return $result->Rname;
        })
            ->addColumn('actions',function ($result){
                $detail = '<a href='.route('admin.staffDetail',['id'=>$result->id]).' class="btn btn-sm btn-outline-primary">View</a>';
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-primary btn-sm status">Enable</button>'.$detail;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-warning btn-sm status">Disabled</button>'.$detail;
        })
        ->rawColumns(['actions']) 
        ->make(true);
    }

    public function usersList()
    {
        return view('users');
    }
    public function usersData(Request $request)
    {
        $user = new User;
        $user = $user->where('users.created_at','LIKE','%'.$request->month.'%')
                        ->where('type',4)
                        ->select('users.id','users.name','users.email','users.status')
                        ->get();
        return DataTables::collection($user)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('email',function ($result){
            return $result->email;
        })
            
            ->addColumn('actions',function ($result){
            $detail = '<a href='.route('admin.usersDetail',['id'=>$result->id]).' class="btn btn-sm btn-outline-primary">View</a>';
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-primary btn-sm status">Active</button>'.$detail;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-warning btn-sm status">Inactive</button>'.$detail;
         })
        ->rawColumns(['actions'])
		->addIndexColumn() 
        ->make(true);
    }

    public function destroy($id){
    	$user = User::find($id);
    	if(!$user){	    	
            return redirect('owners')->with('danger','Owner not found');;
	    }else{

            if( $user->destroyIt() ){
                return redirect('owners')->with('success','Owner deleted successfully');;
            }else{
                return redirect('owners')->with('danger','Error in: Owner deleted request');;
            }
	    }
    }
    public function verifymail($token){
        $user = User::where('remember_token',$token)->first();
        if(!$user){                
            return view('auth.verified',['danger'=>'This record not found']);  
        }else{
            if($user->emailVerified()){
                return view('auth.verified',['success'=>'Email verified successfully']);
            }else{
                return view('auth.verified',['danger'=>'Invalid request']);
            }
        }
    }
    public function verifymailsend($user){
        $token = Str::random(60);
        $details = [
            'view' => 'verifyMail',
            'subject' => 'Verify Email Address',
            'url' => url('verifymail',$token),
        ];
        $user = User::find($user->id);
        $user->remember_token = $token;
        $user->save();
        Mail::to($user)->send(new RizeraMail($details));        
        return;
    }
    public function staff(){
        // dd('P');
        $staffList = User::where('type',3)->where('status','!=',0)->paginate(10);
        // $staffList = [];
        return view('staffList',['staffList'=>$staffList]);
    }
    public function addStaff(Request $request){
        $data = $request->all();
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            // 'password_confirmation ' => 'same:password',
        ];
        $request->validate($rules);
        $user = new User;
        $user->name = ucwords($data['name']);
        $user->email = $data['email'];
        $user->password = Hash::make($data['password']);
        $user->type = 3;
        $user->owner_id = $data['owner_id'];
        if($user->save()){
            return redirect('staff/list')->with('success','Staff addded successfully');
        }
        return view('staff.add');
    }
    public function editStaff($id){

        $staff = User::find($id);
        return view('staff.add',['staff'=>$staff]);
    }
    public function updateStaff(Request $request){
        $data = $request->all();
        $rules = [
            'id' =>  'required|numeric',
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,'.$data['id'],
            'password' => 'nullable|alpha_num|min:8|confirmed',
        ];
        $request->validate($rules);
        $user = User::find($data['id']);
        $user->name = ucwords($data['name']);
        $user->email = $data['email'];
        if( isset($data['password']) && !empty($data['password']) ){
            $user->password = Hash::make($data['password']);
        }
        if($user->save()){
            return redirect('staff/list')->with('success','Staff updated successfully');
        }        
        return view('staff.add',['staff'=>$staff]);
    }

    public function statusChange($id){
        $user = User::find($id);
        if(!$user){
                return redirect('owners')->with('error','Owner not found.');
        }else{
            $user->statusUpdate();
            if($user->save()){
                return redirect('owners')->with('success', Str::ucfirst($user->name). ' account '. ($user->status==2?'disabled':'enabled'));
            }else{
                return redirect('owners')->with('error','Request failed.');
            }
        }
    }

    public function logout(Request $request) { 
        Auth::logout();
        // return redirect('/login');
        return redirect()->Route('admin.login');
    }

    public function statusModified(Request $request){
        $id=$request->input('id');
        $status=User::find($id);
        if($status->status==1)
        $status->status = 2;
        elseif($status->status==2)
        $status->status = 1;
        $status->save();
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
    public function sdelete(Request $request){
        $id=$request->input('id');
        $delete=User::find($id);
        $delete->status = 0;
        $delete->save();
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$delete]);
    }
    public function detail(Request $request, $id){
        $owner = User::join('restaurants','restaurants.user_id','=','users.id')
                        ->where('users.id',$id)
                        ->select('users.name','users.*',DB::raw('group_concat(restaurants.name)'))
                        ->selectRaw('GROUP_CONCAT(restaurants.name) as Rname')
                        ->groupBy('users.name')
                        ->get();
        return view('owners-detail',['owner'=>$owner]);
    }

    public function usersdetail(Request $request, $id)
    {
        $users = User::where('users.id',$id)
                        ->select('users.*')
                        ->get();
        return view('users-detail',['users'=>$users]);
    }

    public function staffdetail(Request $request, $id)
    {
        $staff = User::join('restaurants','restaurants.id','=','users.restaurant_id')
                        ->where('users.id',$id)
                        ->select('users.*','restaurants.name as Rname')
                        ->get();
        return view('staff-detail',['staff'=>$staff]);
    }
}