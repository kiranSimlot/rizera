<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Restaurant;
use Validator,Response;

class BookingController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api', ['except' => []]);
    }


    public function createBooking(Request $request)
    {
        
        // print_r(getallheaders());  
        // print_r($request->all());die;
        $validator = Validator::make($request->all(), [
            'selected_table_data' => 'required', 
            'restaurant_id' => 'required',
            'number_of_guests' => 'required',
            'time' => 'required',
            'date' => 'required'
        ]); 

        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }

        if (auth()->user()->email_verified_at == null) {
              if (auth()->user()->lang_id == 3) {
                    $msg= "Vous devez avoir vérifié l'adresse e-mail avant de faire la réservation.";
                } elseif (auth()->user()->lang_id == 2) { 
                    $msg= 'يجب أن يكون لديك عنوان بريد إلكتروني تم التحقق منه قبل إجراء الحجز.';
                }else{
                     $msg= 'You must have verified email address before making reservation.';
                }
           return response()->json(["status"=>false,"message"=> $msg], 406);
        }

        if (auth()->user()->mobile_verified_at == null) {
              if (auth()->user()->lang_id == 3) {
                    $msg= "Vous devez avoir vérifié le numéro de téléphone portable avant de faire la réservation.";
                } elseif (auth()->user()->lang_id == 2) { 
                    $msg= 'يجب التحقق من رقم الهاتف المحمول قبل إجراء الحجز.';
                }else{
                     $msg= "You must have verified mobile number before making reservation.";
                }
           return response()->json(["status"=>false,"message"=> $msg], 406);
        }

        $floors_array = '';
        foreach ($request->selected_table_data as $key => $value) { 
            $floor_id = $value['id'];
            foreach (json_decode($value['floor_table_view']) as $key2 => $value2) {
                $table_data['table_id'] = $value2->table_id;
                $table_data['table_no'] = $value2->table_no;
                $table_data['min_capacity'] = $value2->min_capacity;
                $table_data['max_capacity'] = $value2->max_capacity; 
                $floors_data[] = $table_data;
            }
            $floors_array = json_encode($floors_data);
        }

        
        
        if (!empty($floors_array)) {
        
        Booking::create([
                'restaurant_id' => $request->restaurant_id,
                'for_date' => date('Y-m-d',strtotime($request->date)),
                'for_time' => $request->time,
                'booking_by' => 1,
                'status' => 0, 
                'user_id' => auth()->user()->id, 
                'floor_id' => $floor_id, 
                'table_detail' => $floors_array,  
                'no_of_person' => $request->number_of_guests 
            ]);

        $restaurant = Restaurant::find($request->restaurant_id);

        if (auth()->user()->lang_id == 2) {
            $restaurant->name = $restaurant->ar_name;
            $msg ="Votre demande de réservation a été envoyée à";
            $msg1 ="Vous serez averti lorsque le propriétaire du restaurant le confirmera.";
            $msg2 ="J'ai réservé une table à";
            $msg3 =". Voir le menu et l'emplacement avec";
        } elseif (auth()->user()->lang_id == 3) { 
            $restaurant->name = $restaurant->fr_name;
            $msg ="تم إرسال طلب الحجز الخاص بك إلى";
            $msg1 ="سيتم إخطارك عندما يؤكد صاحب المطعم ذلك.";
            $msg2 ="لقد حجزت طاولة في";
            $msg3 =". شاهد القائمة والموقع باستخدام";
        }else{
              $restaurant->name = $restaurant->name;
              $msg ="Your reservation request has been sent to ";
              $msg1 ="You will get notified as restaurant owner confirm it.";
              $msg2 ="I’ve reserved a table at";
              $msg3 =". See the menu and location with";
        }



           return Response::json(["status"=>true,"message"=>$msg.$restaurant->name.$msg1, "data" => (object)[
            'twitter_link' => 'https://www.twitter.com',
            'facebook_link' => 'https://www.facebook.com',
            'instagram_link' => 'https://www.instagram.com',
            'share_text' => $msg2.$restaurant->name.' at '.date('h:i a',strtotime($request->time)).' on '.date('d M, Y',strtotime($request->date)).$msg3.env('APP_NAME').' app. '. url('')        
                ]
        ]);
        }
    }

    public function bookingList(Request $request)
    { 
        $query_for_all = Booking::where('bookings.user_id',auth()->user()->id) 
        ->join('restaurants','restaurants.id','=','bookings.restaurant_id')
        ->leftjoin('restaurant_images','restaurant_images.restaurant_id','=','restaurants.id')
        ->selectRaw('
            CONCAT("'.asset('storage').'/'.'",restaurant_images.image) AS image,
            DATE_FORMAT(bookings.for_date, "%M %d, %Y") as date,
            TIME_FORMAT(bookings.for_time, "%h:%i %p") as time,
            restaurants.name,
            bookings.table_no,
            bookings.no_of_person, 
            bookings.table_detail,
            IFNULL(table_no, "") as table_no
            ')
        // .date('',strtotime($request->time)).' on '.date('d M, Y',strtotime($request->date)).'. See the menu and location with '.env('APP_NAME').' app. '. url('')'
        ->where('doc_for',1)
        ->where('doc_type',1)
        ->where('image_type',1)
        ->where('default',1)
        // ->groupBy('restaurant_images.restaurant_id')
        ->orderBy('for_date','DESC')
        ->orderBy('for_time','DESC');

        $data['new'] = $query_for_all
        ->where('for_date','>=',date('Y-m-d'))
        ->get();

        $data['all']['new'] = $query_for_all->get();
        $data['all']['previous'] = Booking::where('bookings.user_id',auth()->user()->id) 
        ->join('restaurants','restaurants.id','=','bookings.restaurant_id')
        ->leftjoin('restaurant_images','restaurant_images.restaurant_id','=','restaurants.id')
        ->selectRaw('
            CONCAT("'.asset('storage').'/'.'",restaurant_images.image) AS image,
            DATE_FORMAT(bookings.for_date, "%M %d, %Y") as date,
            TIME_FORMAT(bookings.for_time, "%h:%i %p") as time,
            restaurants.name,
            bookings.table_no,
            bookings.no_of_person, 
            bookings.table_detail,  
            IFNULL(table_no, "") as table_no')
        ->where('doc_for',1)
        ->where('doc_type',1)
        ->where('image_type',1)
        ->where('default',1)
        ->where('for_date','<',date('Y-m-d'))
        // ->groupBy('restaurant_images.restaurant_id')
        ->orderBy('for_date','DESC')
        ->orderBy('for_time','DESC')
        ->get();

        $data['new'] = $this->returnTableNamesConcatenated($data['new']); 
        $data['all']['new'] = $this->returnTableNamesConcatenated($data['all']['new']);
        $data['all']['previous'] = $this->returnTableNamesConcatenated($data['all']['previous']);
        if(auth()->user()->lang_id  == 3)
                {
                    $msg = "liste de réservation récupérée.";
                    
                }
                elseif(auth()->user()->lang_id == 2)
                {
                    $msg = 'تم جلب قائمة الحجز.';
                   
                }
                else
                {
                    $msg = 'booking list fetched.';
                 
                }
          
        return Response::json(["status"=>true,"message"=>$msg,"data"=>$data]);
    }

    public function returnTableNamesConcatenated($array)
    {
        foreach ($array as $key => $value) {

            $value->table_detail = json_decode($value->table_detail);
             
            if ($value->table_detail != "") { 
                $table_no = '';
            foreach ($value->table_detail as $key2 => $value2) {
                $table_no .= $value2->table_no.',';
            }
            $value->table_no = rtrim($table_no.',', ',');
            }

            unset($value->table_detail);
             if(auth()->user()->lang_id  == 3)
                {
                   $msg ="J'ai réservé une table à";
                   $msg1 =". Voir le menu et l'emplacement avec";
                    
                }
                 elseif(auth()->user()->lang_id == 2)
                {
                    $msg ="لقد حجزت طاولة في";
                    $msg1 =". شاهد القائمة والموقع باستخدام";
                   
                }
                else
                {
                   $msg ="I’ve reserved a table at";
                   $msg1 =". See the menu and location with";
                 
                }

            $value->share_text = 
            $msg.$value->name.' at '.date('h:i a',strtotime($value->time)).' on '.date('d M, Y',strtotime($value->date)).$msg1.env('APP_NAME').' app. '. url('');

        }

        return $array;
    }
}
