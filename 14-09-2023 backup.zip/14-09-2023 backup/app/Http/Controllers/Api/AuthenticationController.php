<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\AppSplashSlider;
use App\Models\User;
use App\Models\MenuCategory;
use App\Http\Resources\UserResource;
use App\Models\Country;
use App\Models\Language;
use App\Models\Restaurant;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\ItemPrice;
use App\Models\Invoice;
use App\Models\RestaurantFloor;
use App\Models\AddToCart;
use Str,Blade,Cache,Cookie,File,Redirect,Response,BASE_URL,View,Hash;
use Validator;
use Auth;
use Session,Storage,Password;
use JWTAuth,URL;
use Illuminate\Http\Request;

class AuthenticationController extends Controller
{

    // public function __construct()
    // {
    //     $this->middleware('auth:api', ['except' => []]);
    // }
    public function register(Request $request)
    {
        $rules = array(
            'lang_id' => 'required',
            'country_id' => 'required',
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required|email',
            'mobile' => 'required|numeric',
            'password' => 'required',
            'fcm_token' => 'required'
        );

        $validator = Validator::make($request->all() , $rules);

        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }

        $usermail = User::where('email', '=', $request->email)->first();
        if(!empty($usermail))
        {
        return Response::json(["status"=>false,"message"=> 'User account with this email already Exist, please login!'], 406);
        }

        $user = User::create([
            'email' => $request->email,
            'mobile' => $request->mobile,
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'country_id' => $request->country_id,
            'lang_id' => $request->lang_id,
            'fcm_token' => $request->fcm_token,
            'name' => $request->first_name.' '.$request->last_name,
            'type' => 4,
            'password' => Hash::make($request->password),
            'email_verified_at' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s')
        ]);


        if($user){
        app('App\Http\Controllers\UserController')->verifymailsend($user);
        if($request->lang_id == 3)
        {
            $success_message = 'Vous vous êtes inscrit avec succès et un courrier de vérification a été envoyé sur votre adresse e-mail.';
            $error_message = "Quelque chose s'est mal passé.";
        }
        elseif($request->lang_id == 2)
        {
            $success_message = 'لقد قمت بالتسجيل بنجاح وتم إرسال بريد التحقق على عنوان بريدك الإلكتروني.';
            $error_message = 'هناك خطأ ما.';
        }
        else
        {
            $success_message = 'You have registered successfully & verification mail sent on your email address.';
            $error_message = 'Something went wrong.';
        }
        if($success_message){
            return Response::json(["status"=>true,"message"=> $success_message ], 200);
        }else{
            return Response::json(["status"=>false,"message"=> $error_message], 406);
        }

        }


    }

    public function splashBanners()
    {
        $banners = AppSplashSlider::selectRaw('*,CONCAT("'.asset('storage').'/'.'",image) AS image')->where('status',1)->get();
        return Response::json(["status"=>true,"message"=> "slider image fetched successfully.","data"=>$banners], 200);
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required',
            'fcm_token' => 'required'
        ]);
         if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        $input = $request->all();

        $credentials = request(['email', 'password']);


        if(!$token = JWTAuth::attempt($credentials)){

                if($request->lang_id == 3)
                {
                    $msg = 'Veuillez saisir une adresse e-mail et un mot de passe valides.';

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'الرجاء إدخال عنوان بريد إلكتروني صالح وكلمة مرور.';

                }
                else
                {
                    $msg = 'Please enter valid Email address and Password.';

                }
             return Response::json(["status"=>false,"message"=> $msg], 406);
        } else {
              $token = 'bearer '.$token;
        }

        $user = User::where('email',$request->email)->first();
        // if ($user->email_verified_at == NULL)
        // {
        //     User::where('id',$user->id)->update(['email_verified_at' => date('Y-m-d H:i:s')]);
        // }
        // else
        // {
            $update_array['fcm_token'] = $request->fcm_token;
        // }

        if (isset($request->lang_id) and $request->lang_id != "") {
            $update_array['lang_id'] = $request->lang_id;
        }
        if (isset($request->country_id) and $request->country_id != "") {
            $update_array['country_id'] = $request->country_id;
        }
        if(isset($request->lang_id) || isset($request->country_id)){
            User::where('id',$user->id)->update($update_array);
        }

        if ($user->status == 0 || $user->status == 2){
               if($request->lang_id == 3)
                {
                    $msg = "Votre compte est désactivé par l'administrateur !";

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم إلغاء تنشيط حسابك من قبل المشرف!';

                }
                else
                {
                    $msg = 'Your account is deactivated by admin!';

                }
            return Response::json(["status"=>false,"message"=> $msg], 406);
        }


        $user = User::where('email',$request->email)->first();
        $user->jwt_token = $token;
        $data = new UserResource($user);

               if($request->lang_id == 3)
                {
                    $msg = "Connexion réussie !";

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم تسجيل الدخول بنجاح!';

                }
                else
                {
                    $msg = 'Successfully logged in!';

                }
        return Response::json(["status"=>true,"message"=> $msg, "data"=> $data], 200);
    }

    public function waiterLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required',
            // 'fcm_token' => 'required'
        ]);
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        $input = $request->all();
        $credentials = request(['email', 'password']);
        $user = User::where('email',$request->email)->first();
        if(!$token = JWTAuth::attempt($credentials)){
            if($request->lang_id == 3)
            {
                $msg = 'Veuillez saisir une adresse e-mail et un mot de passe valides.';
            }
            elseif($request->lang_id == 2)
            {
                $msg = 'الرجاء إدخال عنوان بريد إلكتروني صالح وكلمة مرور.';
            }
            else
            {
                $msg = 'Please enter valid Email address and Password.';
            }
            return Response::json(["status"=>false,"message"=> $msg], 406);
        } else {
            $token = 'bearer '.$token;
        }
        if (isset($request->lang_id) and $request->lang_id != "") {
            $update_array['lang_id'] = $request->lang_id;
        }
        if (isset($request->country_id) and $request->country_id != "") {
            $update_array['country_id'] = $request->country_id;
        }
        if(isset($request->lang_id) || isset($request->country_id)){
            User::where('id',$user->id)->update($update_array);
        }
        if($user->type == 6) {
            if ($user->status == 0 || $user->status == 2){
                if($request->lang_id == 3){
                    $msg = "Votre compte est désactivé par l'administrateur !";
                }elseif($request->lang_id == 2){
                    $msg = 'تم إلغاء تنشيط حسابك من قبل المشرف!';
                }else{
                    $msg = 'Your account is deactivated by admin!';
                }
             return Response::json(["status"=>false,"message"=> $msg], 406);
            }
            if ($user->email_verified_at == null) {
                User::where('id', $user->id)->update(['email_verified_at' => date('Y-m-d H:i:s')]);
            }
            $user->jwt_token = $token;
            $data = new UserResource($user);
            if($request->lang_id == 3) {
                $msg = "Connexion réussie !";
            } elseif($request->lang_id == 2) {
                $msg = 'تم تسجيل الدخول بنجاح!';
            } else {
                $msg = 'Successfully logged in!';
            }
            return Response::json(["status" => true,"message" => $msg, "data" => $data], 200);
        }else{
            return Response::json(["status" => false,"message" => "Login user should be waiter only"], 406);
        }
    }

    public function socialLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'nullable|email',
            'provider' => 'required',
            'provider_id' => 'required',
            'fcm_token' => 'required',
            'country_id' => 'required',
            'lang_id' => 'required',
        ]);
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        $input = $request->all();
        $user = User::where([['provider', '=', $request->provider],['provider_id', '=',  $request->provider_id]])->first();
        if (empty($user)) {
            $tempuser1 = User::where('email','=',$request->email)->where('email','<>','')->where('email','<>',null)->first();
            if (!empty($tempuser1)) {

            if (isset($request->lang_id) and $request->lang_id != "") {
            $update_array['lang_id'] = $request->lang_id;
            }
            if (isset($request->country_id) and $request->country_id != "") {
                $update_array['country_id'] = $request->country_id;
            }
            User::where('email','=',$request->email)->where('email','<>','')->where('email','<>',null)->update($update_array);
             $tempuser = User::where('email','=',$request->email)->where('email','<>','')->where('email','<>',null)->first();
             $user = $tempuser;
            } else {


            $user = User::create([
                'email' => isset($request->email) ? $request->email : null,
                'provider' => $request->provider,
                'provider_id' => $request->provider_id,
                'email_verified_at' => date('Y-m-d H:i:s'),
                'fcm_token' => $request->fcm_token,
                'country_id' => $request->country_id,
                'lang_id' => $request->lang_id,
                'type' => 4,
                'status' => 1
            ]);

            }

        }



        if(!$token = JWTAuth::fromUser($user)){
            if($request->lang_id == 3)
                {
                    $msg = 'Veuillez saisir une adresse e-mail et un mot de passe valides.';

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'الرجاء إدخال عنوان بريد إلكتروني صالح وكلمة مرور.';

                }
                else
                {
                    $msg = 'Please enter valid Email address and Password.';

                }
             return Response::json(["status"=>false,"message"=> $msg], 406);
        } else {
              $token = 'bearer '.$token;
        }

        $user->jwt_token = $token;

        if ($user->email_verified_at == NULL)
        {
               if($request->lang_id == 3)
                {
                    $msg = 'Vous vous êtes bien inscrit.';

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لقد سجلت بنجاح.';

                }
                else
                {
                    $msg ='You have registered successfully.';

                }
        User::where('id',$user->id)->update(['email_verified_at'=> date('Y-m-d H:i:s')]);
        return Response::json(["status"=>true,"message"=> $msg], 200);
        }

        if ($user->status == 0 || $user->status == 2){
            if($request->lang_id == 3)
                {
                    $msg = "Votre compte est désactivé par l'administrateur !";

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم إلغاء تنشيط حسابك من قبل المشرف!';

                }
                else
                {
                    $msg = 'Your account is deactivated by admin!';

                }
            return Response::json(["status"=>false,"message"=> $msg ], 406);
        }
               if($request->lang_id == 3)
                {
                    $msg = "Connexion réussie !";

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم تسجيل الدخول بنجاح!';

                }
                else
                {
                    $msg = 'Successfully logged in!';

                }
        return Response::json(["status"=>true,"message"=> $msg , "data"=> $user], 200);
    }


    public function forgotPassword(Request $request)
    {

        $this->validate($request, ['email' => 'required|email']);


        $find = User::where('email',$request->email)->first();
        if (empty($find)) {
               if($request->lang_id == 3)
                {
                    $msg = "Impossible de trouver un utilisateur avec cette adresse e-mail !";

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لا يمكننا العثور على مستخدم بعنوان البريد الإلكتروني هذا!';

                }
                else
                {
                    $msg = 'We cannot find a user with that email address!';

                }
            return response()->json(["status"=>false,"message"=> $msg], 406);

        } else {
            $status = Password::sendResetLink(
        $request->only('email')
    );

    $status_sent = $status === Password::RESET_LINK_SENT
                ? back()->with(['status' => __($status)])
                : back()->withErrors(['email' => __($status)]);
        if ($status_sent) {
               if($request->lang_id == 3)
                {
                    $msg = "Nous avons envoyé votre lien de réinitialisation de mot de passe par e-mail !.";

                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لقد أرسلنا عبر البريد الإلكتروني رابط إعادة تعيين كلمة المرور الخاصة بك !.';

                }
                else
                {
                    $msg = 'We have emailed your password reset link!.';

                }
        return response()->json(["status"=>true,"message"=> $msg], 200);
        }
        }


    }

    public function languagesList(Request $request)
    {
        if (count($languagesList = Language::get()) > 0) {
            return Response::json(["status"=>true,"message"=> "Success","data"=>$languagesList]);
        }
    }

    public function countriesList(Request $request)
    {
        $countriesList = Country::selectRaw('CONCAT("'.asset('storage').'/'.'",image) AS image,country_name,id')->get();
        return Response::json(["status"=>true,"message"=> "Success","data"=>$countriesList]);
    }

    public function floorData(Request $request)
    {
        if (!empty($floorData = RestaurantFloor::first())) {
            $decoded_floor_data = json_decode($floorData->floor_table_view);
            foreach ($decoded_floor_data as $key => $value) {
                $value->img = URL::to('/').'/admin/imgs/'.$value->capacity.'.png';
            }
            $floorData->floor_table_view = json_encode($decoded_floor_data);
            return Response::json(["status"=>true,"message"=> "Success","data"=>$floorData]);
        }
    }

    // public function addOrder(Request $request){
    //     $rules = [
    //         'price' => 'required',
    //         'quantity' => 'required',
    //         'item_id' => 'required',
    //         'table_id' => 'required',
    //         'resturant_id' => 'required',
    //     ];
    //     $messages = [
    //         'price.required' => 'Please enter a price',
    //         'quantity.required' => 'Please enter a quantity',
    //         'item_id.required' => 'Please enter item',
    //         'table_id.required' => 'Please enter a table',
    //         'resturant_id.required' => 'Please enter a restaurant',
    //     ];
    //     $validator = Validator::make($request->all(), $rules, $messages);
    //     if($validator->fails()){
    //         return response()->json([
    //             'errors' => $validator->errors(),
    //         ]);
    //     }else{
    //         $data = [
    //             'price' => $request->input('price'),
    //             'quantity' => $request->input('quantity'),
    //             'item_id' => $request->input('item_id'),
    //             'table_id' => $request->input('table_id'),
    //             'resturant_id' => $request->input('resturant_id'),
    //         ];
    //         $order = new Order;
    //         // print_r(auth()->user());
    //         // die;
    //         if (auth()->user()->type == 3) {
    //             $result = $order->create($data);
    //             if($result){
    //                 return response()->json([
    //                     'status' => true,
    //                     'mesaage' => 'Order saved successfully',
    //                     'data' => $result,
    //                 ]);
    //             }else{
    //                 return response()->json([
    //                     'status' => false,
    //                     'message' => 'Order not saved successfully',
    //                     'data' => $result,
    //                 ]);
    //             }
    //         }else{
    //             return response()->json([
    //                 'status' => false,
    //                 'message' => 'Login user is staff only...',
    //             ]);
    //         }

    //     }
    // }

    public function orderCancel(Request $request){
        $data = $request->all();
        $id = $data['id'];
        $order_cancele = OrderDetail::where('id', $id)->first();
        // echo "<pre>"; print_r($order_cancele); die;
        if($order_cancele['status'] != 1 && $order_cancele['status'] != 2){
            $data = ['status' => 3];
            $result = $order_cancele->update($data);
            if($result){
                return response()->json([
                    'status' => true,
                    'message' => 'Order canceled successfully',
                    // 'data' => $result,
                ]);
            }else{
                return response()->json([
                    'status' => false,
                    'message' => 'Something went wrong with order cancellation. Please try again later',
                ]);
            }
        }else{
            return response()->json([
                    'status' => false,
                    'message' => 'Order is already accepted by chef or Order is completed',
                ]);
        }

    }

    

    public function productPrice(Request $request){
        $input = $request->all();
        $item_id = $input['item_id'];
        $rules = [
            'item_id' => 'required'
        ];
        $message = [
            'item_id.required' => 'Item ID must be required',
        ];
        $validator = Validator::make($request->all(), $rules, $message);
        if($validator->fails()){
            return $validator->errors();
        }else{
            $price = ItemPrice::where('item_id', $item_id)->get();
            $result = array();
            foreach($price as $val){
                $result[] = [
                    'id' => $val->id,
                    'item_id' => $val->item_id,
                    'price' => $val->price,
                    'quantity' => $val->quantity,
                ];
            }

            return response()->json([
                'status' => 'true',
                'message' => 'Product price list',
                'data' => $result,
            ]);
        }


    }

    public function totalTableBill(Request $request){
        $rules = array(
            // 'discount' => 'required',
            'order_id' => 'required',
            'table_id' => 'required',
        );
        $message = [
            // 'discount.required' => 'Please enter a discount amount',
        ];

        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return $validator->errors();
        }else{
            $data = $request->all();
            // $discount = $data['discount'];
            $discount = $data['discount']??'0';
            $table_id = $data['table_id'];
            // $orders = Order::select('id', 'price', 'quantity')
            //                 ->where('table_id', $table_id)
            //                 ->where('status', '=', 1)
            //                 ->where('billing_status',0)
            //                 ->get();
            $orders = OrderDetail::with(['getOrderItems','getOrder'
                            // =>function($query){
                            //     $query->where('billing_status',0);
                            // }
                            ])
                            ->where('table_no', $table_id)
                            ->where('order_id', $data['order_id'])
                            ->where('status', 1)
                            ->get();
                            // echo"<pre>";
                            // print_r($orders);
                            // die;
            $order_list = [];
            foreach($orders as $key=>$order_details){
                $order_list[$key]['order_item'] = $order_details->getOrderItems->name??"";
                $order_list[$key]['quantity'] = $order_details->quantity;
                $order_list[$key]['amount'] = $order_details->amount;
                $order_list[$key]['item_amount'] = $order_details->amount * $order_details->quantity;
            }
            $orderss = Order::select('name', 'mobile_no')
            ->where('id', $data['order_id'])
            ->first();
            $total_price = 0;
            if(count($orders) > 0){
                foreach($orders as $val){
                    $result = $val->amount * $val->quantity;
                    $total_price += $result;
                }
                Order::where('id',$data['order_id'])->update(['total_amount'=>$total_price , 'discount_amt'=>$discount, 'billing_status'=>1]);
            }else{
                return response()->json([
                    'status' => false,
                    'message' => 'Firstly, Please Mark Order Status As Completed ',
                ]);
            }
            // dd($total_price);
            if($total_price > 0){
                $data = [
                    'total_amount' => $total_price,
                    'discount' => $discount,
                    'table_id' => $table_id,
                    'order_id'=> $data['order_id'],
                    'name' => $orderss->name,
                    'phone' => $orderss->mobile_no,
                    'taxes' => "00",
                ];
                $invoice = new Invoice();
                $invoice_result = $invoice->insert($data);
                // $orders = Order::where('table_id', $table_id)->where('status', '=', 1)
                // ->update(['billing_status'=> 1]);

                if($invoice_result){
                    return response()->json([
                        'status' => true,
                        'message' => 'Total table price bill has been generated',
                        'data' => $data,
                        'order_item'=>$order_list,
                        'total_table_price' => $total_price,
                    ]);
                }
            }else{
                return response()->json([
                    'status' => false,
                    'message' => 'Total table bill has not been generated!',
                    // 'data' => $orders,
                ]);
            }
        }
    }

    public function logout(){
        Auth::logout();
        return response()->json([
            'status' => true,
            'message' => 'Logged out successfully'
        ]);
    }

    public function categoryProducts(Request $request){
        $user_id = $request->user_id;
        // $restaurant_id = auth()->user()->restaurant_id;
        $restaurant_id = User::where('id',$user_id)->select('restaurant_id')->first();
        // dd($restaurant_id);
        $restro = $restaurant_id->restaurant_id;
        if(isset($restaurant_id->restaurant_id)){
            $products = MenuCategory::with(['getItems'=>function($query)  use($restro) {
                $query->where('status',1)->where('resturant_id',$restro);
            },'getItems.itemImage','getItems.itemPrice'=>function($query){
                $query->where('status',0);
            },'getItems.cartItem'=>function($query) use($restro ,$request){
                $query->where('table_no',$request->table_no)->where('status',0)->where('restaurant_id',$restro);
            }
            ])
            ->where(function($query) use($restro){
                $query->where('restaurant_id',$restro);
                // ->orWhere('restaurant_id',NULL);
            })
            ->where('status',0)
            ->orderBy('id', 'DESC')
            ->get();
            // echo "<pre>"; 
            // print_r($products); 
            // die;
            $categorie = array();
            foreach($products as $key => $product){
                $items = array();
                foreach($product->getItems as $item){
                    $price_quantity = array();
                    foreach ($item->itemPrice as $item_price) {
                        $price_quantity[] = array(
                            'price_id' => $item->id,
                            'quantity' => $item_price->quantity,
                            'price' => $item_price->price,
                        );
                    }
                    // $items[] = array(
                    //     'id' => $item->id,
                    //     'category_name' => $product->name,
                    //     'item_name' => $item->name,
                    //     'description' => $item->description ?? "",
                    //     'image' => isset($item->itemImage->image_name)?url('public/files/' . $item->itemImage->image_name):"" ,
                    //     'price_quantity' => $price_quantity,
                    // );
                    $cartDetail = [];
                    if(isset($item->cartItem)){
                        $cartDetail = $item->cartItem;
                    }
                    $items[] = [
                        'id' => $item->id,
                        'category_name' => $product->name,
                        'item_name' => $item->name,
                        'description' => $item->description ?? "",
                        'image' => isset($item->itemImage->image_name) ? url('public/files/' . $item->itemImage->image_name) : "",
                        'price_quantity' => $price_quantity,
                        'ids'=>(isset($item->cartItem->id)?$item->cartItem->id:0),
                        'quantity'=>(isset($item->cartItem->quantity)?$item->cartItem->quantity:0),
                    ];
            
                    // if ($item->cartItem) {
                    //     // Append cart item data to the same array
                    //     $items[count($items) - 1]['cart_item'] = [
                    //         'ids' => isset($item->cartItem->id)?$item->cartItem->id:$item->id,
                    //         'quantity' => isset($item->cartItem->quantity)?$item->cartItem->quantity:$price_quantity,
                    //         // Add other cart item fields here as needed
                    //     ];
                    // }
                }
                if(!empty($items )){
                    $categorie[] = [
                        'id' => $product->id,
                        'name' => $product->name,
                        'items' => !empty($items) ? $items : [],
                    ];
                }
            }
            return response()->json([
                'status' => true,
                'message' =>  'Category products',
                'data' => $categorie,
            ]);
        }else{
            return response()->json([
                'status' => false,
                'message' =>  'User Restaurant Not Exist',
            ]);
        }
    }

    public function confirmOrder(Request $request){
        $rules = [
            'id' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->errors(),
            ]);
        }else{
            $cart_id = $request->id;
            $item_id = explode(',', $cart_id);
            $add_to_cart = AddToCart::whereIn('id',$item_id)->get();
            $create_order =[];
            foreach ($add_to_cart as $item_ids) {
                // if($item_ids->billing_status == 0){
                    $create_order[] = [
                        'item_id' => $item_ids->item_id,
                        'table_no' => $item_ids->table_no,
                        'restaurant_id' => $item_ids->restaurant_id,
                        'staff_id' => $item_ids->staff_id,
                        'quantity' => $item_ids->quantity,
                        'quantity_in_variation' => $item_ids->quantity_in_variation,
                        'amount' => $item_ids->amount,
                        'order_id' => $item_ids->order_id,
                        'notes' => $item_ids->notes,
                    ];
                
                //     return response()->json([
                //         'status' => false,
                //         'message' => 'This order payment already done. Please generate the new order reservation.',
                //     ]);
                // }
            }
            // echo"<pre>";
            // print_r($create_order);
            // die;
            // if (auth()->user()->type == 6) {
                $order_create = OrderDetail::insert($create_order);
                if($order_create){
                    AddToCart::whereIn('id',$item_id)->delete();
                    return response()->json([
                        'status' => true,
                        'message' =>  'Order confirmed successfully',
                        'data' => $create_order,
                    ]);
                }else{
                    return response()->json([
                        'status' => false,
                        'message' =>  'Order not confirmed',
                    ]);
                }
            // }else{
            //     return response()->json([
            //         'status' => false,
            //         'message' => 'Login user is waiter only...',
            //     ]);
            // }
        }
    }

    // public function updateCart(Request $request){
    //     $rules = [
    //         'id' => 'required',
    //         'quantity' => 'required',
    //     ];
    //     $validator = Validator::make($request->all(), $rules);
    //     if($validator->fails()) {
    //         return response()->json([
    //             'errors' => $validator->errors(),
    //         ]);
    //     } else {
    //         $update_cart_detail = AddToCart::where('id', $request->id)->update(['quantity' => $request->quantity]);
    //         if($update_cart_detail){
    //             return response()->json([
    //                 'status' => true,
    //                 'message' =>  'Order updated successfully',
    //                 'data' => $create_order,
    //             ]);
    //         }else{
    //             return response()->json([
    //                 'status' => false,
    //                 'message' =>  'Order not updated',
    //             ]);
    //         }
    //     }
    // }
    public function cancelCart(Request $request){
        $rules = [
            'id' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ]);
        } else {
            $update_cart_detail = AddToCart::where('id', $request->id)->delete();
            if($update_cart_detail){
                return response()->json([
                    'status' => true,
                    'message' =>  'Cart item removed successfully',
                ]);
            }
        }
    }
}

