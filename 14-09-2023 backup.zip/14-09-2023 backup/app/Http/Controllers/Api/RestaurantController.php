<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\OrderDetails;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use App\Http\Resources\UserResource;
use App\Http\Resources\RestaurantResource;
use App\Models\City;
use App\Models\RestaurantFloor;
use App\Http\Resources\RestaurantListResource;
use App\Models\User;
use App\Models\Wishlist;
use App\Models\Restaurant;
use App\Models\CuisineType;
use App\Models\AllergyType;
use App\Models\FoodIntolerance;
use App\Models\UserAllergy;
use App\Models\UserCuisineType;
use App\Models\UserFoodIntolerance;
use App\Models\WeeklyHour;
use App\Models\Booking;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\AddToCart;
use Str,Blade,Cache,Cookie,File,Redirect,Response,BASE_URL,View,Hash;
use Validator;
use Session,Storage,Password;
use DB;
use URL;
use Mail;
use DataTables;
use Config;
use DateTime;
use JWTAuth;
use Resource;
use Illuminate\Http\Request;
use Carbon\Carbon;

class RestaurantController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => []]);
    }

    public function restaurantList(Request $request)
    {
        $query = Restaurant::active();


        if (isset($request->search) && $request->search != "") {
        // $cities_ids = City::where('city_name','LIKE','%'.$request->search.'%')->selectRaw('GROUP_CONCAT(id) as city_ids')->first();
        $search = $request->search;
        $query->where(function($q) use($search) {
        $q->where('name','LIKE','%'.$search.'%')->orWhere('address','LIKE','%'.$search.'%');
        });
        }

        if (isset($request->sort_by_verified) && $request->sort_by_verified == "1") {
            $query->orderBy('verified','DESC');
        }

        if (isset($request->sort_by_nearby) && $request->sort_by_nearby == "1") {
            $query->orderByRaw('FIELD(country_id,'.auth()->user()->country_id.') DESC');
        }

        if (isset($request->expensiveness) && $request->expensiveness != "") {
            $myString = $request->expensiveness;
            $myArray = explode(',', $myString);
            $query->whereIn('expensiveness',$myArray);
        }

        if (isset($request->city_ids) && $request->city_ids != "") {
            $city_ids = explode(',', $request->city_ids);
            $query->WhereIn('city_id',$city_ids);
        }

        if (isset($request->cuisine_type_ids) && $request->cuisine_type_ids != "") {
            $cuisine_type_ids = explode(',', $request->cuisine_type_ids);
            $query
            ->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')
            ->whereIn('restaurant_cuisine_types.cuisine_type_id',$cuisine_type_ids)
            ->select('restaurants.*');
        }

        $query->where('country_id',auth()->user()->country_id);
        // $query->leftJoin('wishlists','wishlists.user_id','=','users.id')
        //     ->where('users.id',auth()->user()->id)
        //     ->select('wishlists.user_id as wish_user_id','users.id');
        $restaurantList = RestaurantListResource::collection($query->get());

        return Response::json(["status"=>true,"data"=>$restaurantList]);
    }

    // public function search(Request $request)
    // {

    //     $query = Restaurant::active();
    //     if (isset($request->search) && $request->search != "") {
    //     $cities_ids = City::where('city_name','LIKE','%'.$request->search.'%')->selectRaw('GROUP_CONCAT(id) as city_ids')->first();
    //     $query->where('name','LIKE','%'.$request->search.'%');
    //     }

    //         echo "hide";die;
    //     if (isset($request->sort_by_verified) && $request->sort_by_verified == "1") {
    //         $query->orderBy('verified','DESC');
    //     }

    //     if (isset($request->sort_by_nearby) && $request->sort_by_nearby == "1") {
    //         $query->orderByRaw('FIELD(country_id,'.auth()->user()->country_id.') DESC');
    //     }

    //     if (isset($request->city_ids) && $request->city_ids != "") {
    //         $city_ids = explode(',', $request->cities_ids);
    //         $query->orWhereIn('city_id',$city_ids);
    //     }
    //     if (isset($request->cuisine_type_ids) && $request->cuisine_type_ids != "") {
    //         $cuisine_type_ids = explode(',', $request->cuisine_type_ids);
    //         $query->join('restaurant_cuisine_types','restaurant_cuisine_types.restaurant_id','=','restaurants.id')->orWhereIn('restaurant_cuisine_types.cuisine_type_id',$cuisine_type_ids)->select('restaurants.*');
    //     }
    //     $restaurantList = RestaurantListResource::collection($query->get());
    //     return Response::json(["status"=>true,"data"=>$restaurantList]);
    // }

    public function filterList(Request $request)
    {
        $cuisine_types = CuisineType::where('country_id',auth()->user()->country_id)->where('status',1);
        $cities = City::where('country_id',auth()->user()->country_id)->where('status',1);

        if (isset(auth()->user()->lang_id) and auth()->user()->lang_id != "") {
        $lang_id = auth()->user()->lang_id;
        }

        if (isset($lang_id)) {
        if ($lang_id == 2) {
        $cuisine_types = $cuisine_types->select('*','name_ar as name');
        }elseif ($lang_id == 3) {
        $cuisine_types = $cuisine_types->select('*','name_fr as name');
        }
        }

        $cuisine_types = $cuisine_types->get();
        foreach ($cuisine_types as $key => $value) {
        $value->image =asset('storage').'/'.$value->image;

        }
        $cities = $cities->get();
        $expensiveness = [(object)['id'=>1,'key'=>'$','is_selected'=>false],(object)['id'=>2,'key'=>'$$','is_selected'=>false],(object)['id'=>3,'key'=>'$$$','is_selected'=>false]];

        $data = ['cuisine_types'=>$cuisine_types,'cities'=> $cities,'expensiveness'=> $expensiveness];

        return Response::json(["status"=>true,"data"=>$data]);
    }

    public function personalisation(Request $request)
    {
    $user_food_intolerance_ids = UserFoodIntolerance::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(food_intolerance_id) as ids')->first();
    $user_allergy_ids = UserAllergy::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(allergy_id) as ids')->first();
    $user_cuisine_type_ids = UserCuisineType::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(cuisine_type_id) as ids')->first();

    if (isset(auth()->user()->lang_id) and auth()->user()->lang_id != "") {
        $lang_id = auth()->user()->lang_id;
    }

    $query_food_intorelance = FoodIntolerance::where('status',1)->where('country_id',auth()->user()->country_id)->selectRaw('IF(FIND_IN_SET(id, "'.$user_food_intolerance_ids->ids.'") > 0, true, false) as selected,foodintolerance_types.*')->orderBy('foodintolerance_types.name');
    $query_allergy_types = AllergyType::where('status',1)->where('country_id',auth()->user()->country_id)->selectRaw('IF(FIND_IN_SET(id, "'.$user_allergy_ids->ids.'") > 0, true, false) as selected,allergy_types.*')->orderBy('allergy_types.name');
    $query_cuisine_types = CuisineType::where('status',1)->where('country_id',auth()->user()->country_id)->selectRaw('IF(FIND_IN_SET(id, "'.$user_cuisine_type_ids->ids.'") > 0, true, false) as selected,cuisine_types.*')->orderBy('cuisine_types.name');

    if (isset($lang_id)) {
        if ($lang_id == 2) {
        $query_food_intorelance = $query_food_intorelance->selectRaw('name_ar as name');
        $query_allergy_types = $query_allergy_types->selectRaw('name_ar as name');
        $query_cuisine_types = $query_cuisine_types->selectRaw('name_ar as name');
        }elseif ($lang_id == 3) {
        $query_food_intorelance = $query_food_intorelance->selectRaw('name_fr as name');
        $query_allergy_types = $query_allergy_types->selectRaw('name_fr as name');
        $query_cuisine_types = $query_cuisine_types->selectRaw('name_fr as name');
        }
    }

    $personalization['food_intolerance'] = $query_food_intorelance->get();
    $personalization['allergies'] = $query_allergy_types->get();
    $personalization['cuisine_types'] = $query_cuisine_types->get();


     foreach ($personalization['allergies'] as $key => $value) {

        if($value->name == "Other" || $value->name_ar == "آخر" || $value->name_fr == "Autre"){
        $value->is_other = true;
        }else{
          $value->is_other = false;
        }

        }


     foreach ($personalization['cuisine_types'] as $key => $value) {
        $value->image =asset('storage').'/'.$value->image;

        }



    return Response::json(["status"=>true,"message"=> "Success","data"=>$personalization]);

    }


    public function updatePersonalisation(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'cuisine_types' => 'nullable|required',
        //     'food_intolerance' => 'nullable|required',
        //     'allergies' => 'nullable|required'
        // ]);
        // if($validator->fails())
        // {
        //     $message = $validator->errors()->first();
        //     return response()->json(["status"=>false,"message"=> $message], 406);
        // }


        if (isset(auth()->user()->lang_id) and auth()->user()->lang_id != "") {
            $lang_id = auth()->user()->lang_id;
        }

        $request->cuisine_types = isset($request->cuisine_types) ? $request->cuisine_types : '';
        $request->food_intolerance = isset($request->food_intolerance) ? $request->food_intolerance : '';
        $request->allergies = isset($request->allergies) ? $request->allergies : '';



         $user_food_intolerance_ids = UserFoodIntolerance::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(food_intolerance_id) as ids')->first();
        $user_allergy_ids = UserAllergy::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(allergy_id) as ids')->first();
        $user_cuisine_type_ids = UserCuisineType::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(cuisine_type_id) as ids')->first();


        $remove_food_intolerance = array_diff(explode(',', $user_food_intolerance_ids->ids), explode(',', $request->food_intolerance));
        // print_r($remove_food_intolerance);die;
        $remove_allergies = array_diff(explode(',', $user_allergy_ids->ids), explode(',', $request->allergies));
        $remove_cuisine_types = array_diff(explode(',', $user_cuisine_type_ids->ids), explode(',', $request->cuisine_types));

        UserFoodIntolerance::where('user_id',auth()->user()->id)->whereIn('food_intolerance_id',$remove_food_intolerance)->delete();
        UserCuisineType::where('user_id',auth()->user()->id)->whereIn('cuisine_type_id',$remove_cuisine_types)->delete();
        UserAllergy::where('user_id',auth()->user()->id)->whereIn('allergy_id',$remove_allergies)->delete();


        foreach (explode(',', $request->cuisine_types) as $key => $value) {
            if (empty(UserCuisineType::where('user_id',auth()->user()->id)->where('cuisine_type_id',$value)->first())) {
            UserCuisineType::create([
                'user_id' => auth()->user()->id,
                'cuisine_type_id' => $value
            ]);
            }
        }

        foreach (explode(',', $request->food_intolerance) as $key => $value) {
            if (empty(UserFoodIntolerance::where('user_id',auth()->user()->id)->where('food_intolerance_id',$value)->first())) {
            UserFoodIntolerance::create([
                'user_id' => auth()->user()->id,
                'food_intolerance_id' => $value
            ]);
            }
        }

        foreach (explode(',', $request->allergies) as $key => $value) {
            if (empty(UserAllergy::where('user_id',auth()->user()->id)->where('allergy_id',$value)->first())) {
            UserAllergy::create([
                'user_id' => auth()->user()->id,
                'allergy_id' => $value
            ]);
            }
        }


         if($request->is_other == 'true'){
            $data['user_id'] = auth()->user()->id;
            if (isset($lang_id)) {
            if ($lang_id == 2) {
            $data['name'] = "";
            $data['name_ar'] = $request->name;
            $data['name_fr'] = "";
            }
            elseif ($lang_id == 3) {
            $data['name'] = "";
            $data['name_ar'] = "";
            $data['name_fr'] =$request->name;
            }
            else{
            $data['name'] =$request->name;
            $data['name_ar'] = "";
            $data['name_fr'] ="";
            }

            $data['country_id'] = auth()->user()->country_id;
            $data['status'] = 1;

            }
            $insertid = AllergyType::insertGetId($data);
            UserAllergy::create([
                'user_id' => auth()->user()->id,
                'allergy_id' => $insertid
            ]);
        }

               if($lang_id == 3)
                {
                    $msg = "Votre personnalisation a été mise à jour avec succès.";

                }
                elseif($lang_id == 2)
                {
                    $msg = 'تم تحديث التخصيص الخاص بك بنجاح.';

                }
                else
                {
                    $msg = "Your personalisation updated successfully.";

                }



    return Response::json(["status"=>true,"message"=> $msg]);
    }

    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required',
            'confirm_password' => 'required|same:new_password'
        ]);
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }


               if(auth()->user()->lang_id == 3)
                {
                    $msg = "l'ancien mot de passe n'est pas correct.";
                    $msg1 = "Le mot de passe a été changé avec succès.";

                }
                elseif(auth()->user()->lang_id  == 2)
                {
                    $msg = "كلمة المرور القديمة ليست صحيحة.";
                    $msg1 = "تم تغيير الرقم السري بنجاح.";

                }
                else
                {
                    $msg = "old password is not currect.";
                    $msg1 = "Password changed successfully.";

                }
        if (!Hash::check($request->old_password, auth()->user()->password)) {
             return Response::json(["status"=>false,"message"=>$msg], 406);
        } else {
            User::where('id',auth()->user()->id)->update([
                'password' => Hash::make($request->new_password)
            ]);
        return Response::json(["status"=>true,"message"=> $msg1]);
        }

    }

    public function userDetail(Request $request)
    {
        $data = auth()->user();
        $data = new UserResource($data);
        return Response::json(["status"=>true,"message"=> "data fetched.","data"=> $data]);
    }


    public function uploadImage(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'image' => 'image'
        ]);

        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }


        $directory = 'profile';
        $image_name = $request->user()->id.time().'_'.rand(1,999999999).'.'.$request->image->extension();
        $request->image->storeAs(
        'public/'.$directory, $image_name
        );

        $image_path = $directory.'/'.$image_name;
        $data = (object)[];
        $data->image_path = $image_path;
        return Response::json(["status"=>true,"message"=> "Image uploaded.","data"=> $data]);
    }


    public function updateUserDetail(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'first_name' => 'string',
            'last_name' => 'string',
            'image' => 'string'
        ]);

        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }

        $update_array = [];

        if (isset($request->first_name) and $request->first_name != "") {
            $update_array['first_name'] = $request->first_name;
        }

        if (isset($request->last_name) and $request->last_name != "") {
            $update_array['last_name'] = $request->last_name;
        }

        if ($request->has('image')) {
            $update_array['image'] = $request->image;
        }

        $user = User::find(auth()->user()->id);
          if(auth()->user()->lang_id == 3)
                {
                    $msg = "Détails mis à jour avec succès et e-mail de vérification envoyé sur votre adresse e-mail.";
                    $msg1 = "Détails mis à jour avec succès.";
                    $msg2 = "Cet e-mail est déjà enregistré avec un autre compte.";

                }
                elseif(auth()->user()->lang_id  == 2)
                {
                    $msg = "تم تحديث التفاصيل بنجاح وإرسال بريد التحقق على عنوان بريدك الإلكتروني.";
                    $msg1 = "تم تحديث التفاصيل بنجاح.";
                    $msg2 = "هذا البريد الإلكتروني مسجل بالفعل مع حساب آخر.";

                }
                else
                {
                    $msg = 'Details updated successfully & verification mail sent on your email address.';
                    $msg1 = 'Details updated successfully.';
                    $msg2 = 'This email is already registered with another account.';

                }
        if (isset($request->email) and $request->email != "") {
        $exist_another = User::where('email',$request->email)->where('id','<>',auth()->user()->id)->first();
        if (!empty($exist_another)) {
        return Response::json(["status"=>false,"message"=> $msg2], 406);
        }
    }



        if (isset($request->lang_id) and $request->lang_id != "") {
            $update_array['lang_id'] = $request->lang_id;
        }
        if (isset($request->country_id) and $request->country_id != "") {
            $update_array['country_id'] = $request->country_id;
        }


        if (isset($request->email) and
            $request->email != "" and $user->email != $request->email) {
        $update_array['email'] = $request->email;
        $update_array['email_verified_at'] = null;
        User::where('id',auth()->user()->id)->update($update_array);
        app('App\Http\Controllers\UserController')->verifymailsend(auth()->user());

        $user = User::find(auth()->user()->id);
        $data = new UserResource($user);

        return Response::json(["status"=>true,"message"=> $msg,"data"=>$data], 200);

        }

        User::where('id',auth()->user()->id)->update($update_array);

        $user = User::find(auth()->user()->id);
        $data = new UserResource($user);
        return Response::json(["status"=>true,"message"=> $msg1,"data"=>$data], 200);


    }

    public function sendOtp(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'mobile' => 'required|numeric'
        ]);

        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }

        $update_array = [
            'otp' => '1234',
        ];

        $user = User::find(auth()->user()->id);

        if(auth()->user()->lang_id == 3)
        {
            $msg = "Otp a été envoyé sur votre numéro de mobile.";
            $msg1 = "Ce numéro de mobile est déjà enregistré avec un autre compte.";
            $msg2 = "Quelque chose s'est mal passé.";

        }
        elseif(auth()->user()->lang_id  == 2)
        {
            $msg = "تم إرسال OTP على رقم هاتفك المحمول.";
            $msg1 = "رقم الهاتف المحمول هذا مسجل بالفعل في حساب آخر.";
            $msg2 = "هناك خطأ ما.";

        }
        else
        {
            $msg = 'Otp has been sent on your mobile number.';
            $msg1 = 'This mobile number is already registered with another account.';
            $msg2 = 'Something went wrong.';

        }

        $exist_another = User::where('mobile',$request->mobile)->where('id','<>',auth()->user()->id)->first();
        if (!empty($exist_another)) {
        return Response::json(["status"=>false,"message"=> $msg1], 406);
        }

        if ($request->mobile != "") {
        $update_array['mobile'] = $request->mobile;
        $update_array['mobile_verified_at'] = null;
        User::where('id',auth()->user()->id)->update($update_array);
        //SEND OTP VIA THIRD PARTY
        return Response::json(["status"=>true,"message"=> $msg], 200);
        }

        return Response::json(["status"=>false,"message"=> $msg2], 406);
    }


    public function resendOtp(Request $request)
    {
        $update_array = [
            'otp' => '1234',
        ];
        $user = User::find(auth()->user()->id);
        if ($user->mobile != "") {
            $update_array['mobile_verified_at'] = null;
            User::where('id',auth()->user()->id)->update($update_array);
            if(auth()->user()->lang_id == 3)
            {
                $msg = "Otp a été envoyé sur votre numéro de mobile.";
                $msg2 = "Quelque chose s'est mal passé.";
            }
            elseif(auth()->user()->lang_id  == 2)
            {
                $msg = "تم إرسال OTP على رقم هاتفك المحمول.";
                $msg2 = "هناك خطأ ما.";
            }
            else
            {
                $msg = 'Otp has been sent on your mobile number.';
                $msg2 = 'Something went wrong.';
            }
            //SEND OTP VIA THIRD PARTY
            if($msg){
                return Response::json(["status"=>true,"message"=> $msg], 200);
            }else{
                return Response::json(["status"=>false,"message"=> $msg2], 406);
            }
        }
    }
    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required|numeric|digits:4'
        ]);
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        $user = User::find(auth()->user()->id);
         if(auth()->user()->lang_id == 3)
        {
            $msg = "Mobile vérifié avec succès.";
            $msg1 = "OTP est incorrect.";
        }
        elseif(auth()->user()->lang_id  == 2)
        {
            $msg = "تم التحقق من الهاتف المحمول بنجاح.";
            $ms1 = "OTP غير صحيح.";
        }
        else
        {
            $msg = 'Mobile verified successfully.';
            $msg1 = 'Otp is incorrect.';
        }
        if ($user->otp == $request->otp) {
            $update_array['mobile_verified_at'] = date('Y-m-d H:i:s');
            $update_array['otp'] = null;
            User::where('id',auth()->user()->id)->update($update_array);
            //SEND OTP VIA THIRD PARTY
            return Response::json(["status"=>true,"message"=> $msg], 200);
        } else {
            return Response::json(["status"=>false,"message"=> $msg1], 406);
        }
    }
    public function restaurantDetail(Request $request)
    {
        $object = Restaurant::find($request->restaurant_id);
        $restaurantList = new RestaurantResource($object);
        return Response::json(["status"=>true,"data"=>$restaurantList]);
    }
    public function restaurantFloorsData(Request $request)
    {
        $restaurantFloorData = RestaurantFloor::where('restaurant_id',$request->restaurant_id)->get();

        foreach ($restaurantFloorData as $key => $value) {
            $decoded_floor_data = json_decode($value->floor_table_view);

        if ($decoded_floor_data != "") {
        foreach ($decoded_floor_data as $key => $value2) {
            $value2->img = URL::to('/').'/admin/imgs/'.$value2->capacity.'.png';
            $value2->table_no = (string) $value2->table_no;
        }
        }
        $value->floor_table_view = $value->floor_table_view == null ? [] : $decoded_floor_data;

        // if ($value->floor_table_view == []) {
        // $value->floor_table_view = json_encode($decoded_floor_data);
        // }
        }
        // echo json_encode($restaurantFloorData);die;
        return Response::json(["status"=>true,"selectMultipleFloor"=>false,"data"=>$restaurantFloorData]);
    }


    public function waiterFloorsData(Request $request)
    {
        $restaurantFloorData = RestaurantFloor::where('restaurant_id',auth()->user()->restaurant_id)->get();
        // echo"<pre>";
        // print_r($restaurantFloorData);
        // die;
        if(auth()->user()->type != 6){
            return Response::json(["status"=>false,"selectMultipleFloor"=>false,"message"=>"Please Login with waiter"]);
        }else{
            foreach ($restaurantFloorData as $key => $value) {
                $decoded_floor_data = json_decode($value->floor_table_view);
                if ($decoded_floor_data != "") {
                    foreach ($decoded_floor_data as $key => $value2) {
                        $value2->img = URL::to('/').'/admin/imgs/'.$value2->capacity.'.png';
                        $value2->table_no = (string) $value2->table_no;
                    }
                }
                $value->floor_table_view = $value->floor_table_view == null ? [] : $decoded_floor_data;
                // if ($value->floor_table_view == []) {
                    // $value->floor_table_view = json_encode($decoded_floor_data);
                // }
            }
            // echo json_encode($restaurantFloorData);die;
            $today = Carbon::now()->toDateString();
            $reserve = [];
            // $tableImage =[];
            $order_detail = Order::where('billing_status',0)->where('restaurant_id',auth()->user()->restaurant_id)->whereDate('created_at', $today)->get();
            foreach ($order_detail as $key => $order_details) {
                if($order_details->billing_status == 0){
                    $reserveItem = [
                        'table_no' => $order_details->table_no,
                        'table_image' => URL::to('/admin/imgs/checkdefault.png'), // Use the correct URL format
                    ];
                    $reserve[] = $reserveItem;
                    // $reserve[$key]['table_no']= $order_details->table_no;
                    // // $reserve[0]['table_image'] = URL::to('/').'/admin/imgs/'.'checkdefault'.'.png';
                    // $reserve[$key]['table_image'] = URL::to('/').'/admin/imgs/'.'checkdefault'.'.png';
                }
            }
            $responseData = [
                'total_width' => "550",
                'total_height' => "600",
                'restaurantFloorData' => $restaurantFloorData,
                'Reserve' => $reserve,
            ];
            if(!empty($restaurantFloorData)){
                return Response::json(["status"=>true,"selectMultipleFloor"=>false,"message"=>"Restaurant floor data","data"=>$responseData]);
            }else{
                return Response::json(["status"=>false,"selectMultipleFloor"=>false,"message"=>"Restaurant floor data for this restaurant do not exists."]);
            }
        }
    }

    public function addOrRemoveWishlist(Request $request) {
        $validator = Validator::make($request->all(), [
            'restaurant_id' => 'required',
            'type'  => 'required|string'
        ]);
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        if ($request->type == 'remove') {
            $status = (Wishlist::where('restaurant_id',$request->restaurant_id)->where('user_id',auth()->user()->id)->delete() ? true : false);
            $message = "Restaurant removed from Wishlist.";
            if (!$status) {
                $message = "Already removed.";
            }
        } elseif($request->type == 'add') {
            try {
                $status = (Wishlist::create([
                        'restaurant_id' => $request->restaurant_id,
                        'user_id' => auth()->user()->id
                    ]) !== null ? true : false);
                $message = "Restaurant added to Wishlist.";
            } catch(\Illuminate\Database\QueryException $ex){
            // $message = $ex->getMessage();
                $message = 'Something went wrong.';
                $status = false;
            }
        }
        if ($status) {
            return Response::json(["status"=>$status,"message"=> $message, "data"=>(object)[]]);
        } else {
            return Response::json(["status"=>$status,"message"=> $message, "data"=>(object)[]], 406);
        }
    }

    public function getWishlist(Request $request) {

      /*  $wishlist = Wishlist::where('user_id',auth()->user()->id)->with('restaurants')->get();

        foreach($wishlist as $key => $value) {
        $data[] = RestaurantResource::collection($value->restaurants);
        }
        return Response::json(["status"=>true,"message"=> 'Wishlist loaded successfully.', "data"=>$wishlist]);*/


        $data = [];
        $wishlist = Wishlist::where('user_id',auth()->user()->id)->selectRaw('GROUP_CONCAT(restaurant_id) as restaurant_ids')->first();
        if (!empty($wishlist) && $wishlist->restaurant_ids) {
            $result = Restaurant::whereIn('id',explode(',',$wishlist->restaurant_ids))->get();
        if (count($result) > 0) {
            $data = RestaurantListResource::collection($result);
        }
        }
        return Response::json(["status"=>true,"message"=> 'Wishlist loaded successfully.', "data"=>$data]);
    }

    public function addOrder(Request $request){
        // dd(auth()->user()->id);
        $rules = [
            'price' => 'required',
            'quantity' => 'required',
            'item_id' => 'required',
            'table_id' => 'required',
            'resturant_id' => 'required',
            // 'order_id' => 'required',
            // 'staff_id' => 'required',
            // 'notes' => 'required',
            // 'quantity_in_variation' => 'required',
        ];
        $messages = [
            'price.required' => 'Please enter a price',
            'quantity.required' => 'Please enter a quantity',
            'item_id.required' => 'Please enter item',
            'table_id.required' => 'Please enter a table',
            'resturant_id.required' => 'Please enter a restaurant',
            // 'notes.required' => 'Please enter a notes',
            // 'quantity_in_variation.required' => 'Please enter a quantity_in_variation',
        ];
        $validator = Validator::make($request->all(), $rules, $messages);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->errors(),
            ]);
        }else{
            $orders = Order::where('table_no', $request->input('table_id'))
                        ->where('restaurant_id', $request->input('resturant_id'))
                        ->orderBy('id','desc')
                        ->first();
            // $orders = OrderDetail::with(['getOrder' 
            // =>function($query) use($request){
            //     $query->orderBy('id','desc')->where('billing_status',0);
            // }
            // ])->where('table_no', $request->input('table_id'))
            // ->where('restaurant_id', $request->input('resturant_id'))
            // ->orderBy('id','desc')
            // ->first();
            // echo"<pre>";
            // print_r($orders);
            // die;
            if(!empty($orders) ){
                if($orders->billing_status == 0){
                    $data = [
                        'amount' => $request->input('price'),
                        'quantity' => $request->input('quantity'),
                        'item_id' => $request->input('item_id'),
                        'table_no' => $request->input('table_id'),
                        'staff_id' => auth()->user()->id,
                        'order_id' => $orders->id,
                        'restaurant_id' => $request->input('resturant_id'),
                        'notes' => $request->input('notes'),
                        'quantity_in_variation' => $request->input('quantity_in_variation'),
                    ];
                    $order = new OrderDetail;
                    if (auth()->user()->type == 6) {
                        $result = $order->create($data);
                            if($result){
                                AddToCart::where('order_id',$orders->id)->delete();
                                return response()->json([
                                    'status' => true,
                                    'mesaage' => 'Order saved successfully',
                                    'data' => $request->all(),
                                ]);
                            }else{
                                return response()->json([
                                    'status' => false,
                                    'message' => 'Order not saved successfully',
                                ]);
                            }
                    }else{
                        return response()->json([
                            'status' => false,
                            'message' => 'Login user is waiter only...',
                        ]);
                    }
                }else{
                    return response()->json([
                        'status' => false,
                        'message' => 'This order payment already done. Please generate the new order reservation.',
                    ]);
                }
            }else{
                return response()->json([
                    'status' => false,
                    'message' => 'Please reserve the table first & then order again.',
                ]);
            }
        }
    }
    public function orderReservation(Request $request){
        $rules = [
            'name' => 'required',
            'mobile_no' => 'required',
            // 'email_id' => 'required',
            'table_no' => 'required',
            'floor_no' => 'required',
            'restaurant_id' =>'required',
        ];
        $messages = [
            'name.required' => 'Please enter a name',
            'mobile_no.required' => 'Please enter a Mobile_no',
            // 'email_id.required' => 'Please enter a Email_id',
        ];
        $validator = Validator::make($request->all(), $rules, $messages);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->errors(),
            ]);
        }else{
            $orders = OrderDetail::with(['getOrder' =>function($query){
                $query->where('billing_status',0);
            }])->where('table_no', $request->input('table_id'))
            ->where('restaurant_id', $request->input('resturant_id'))
            ->orderBy('id','desc')
            ->first();
            if(!empty($orders) || $orders != null){
                $order_data = [
                    'restaurant_id' => $request->input('restaurant_id'),
                    'name' => $request->input('name'),
                    'mobile_no' => $request->input('mobile_no'),
                    'email_id' => $request->input('email_id'),
                    'table_no' => $request->input('table_no'),
                    'floor_no' => $request->input('floor_no'),
                    'order_no' => $orders->getOrder->order_no,
                ];
                $order = new Order;
                if (auth()->user()->type == 6) {
                    $result = $order->create($order_data);
                    if($result){
                        return response()->json([
                            'status' => true,
                            'mesaage' => 'Order saved successfully',
                            'data' => $request->all(),
                        ]);
                    }else{
                        return response()->json([
                            'status' => false,
                            'message' => 'Order not saved successfully',
                        ]);
                    }
                }else{
                    return response()->json([
                        'status' => false,
                        'message' => 'Login user is waiter only...',
                    ]);
                }
            }else{
                $order_data = [
                    'restaurant_id' => $request->input('restaurant_id'),
                    'name' => $request->input('name'),
                    'mobile_no' => $request->input('mobile_no'),
                    'email_id' => $request->input('email_id'),
                    'table_no' => $request->input('table_no'),
                    'floor_no' => $request->input('floor_no'),
                    'order_no' => Str::random(8),
                ];
                $order = new Order;
                // print_r(auth()->user());
                // die;
                if (auth()->user()->type == 6) {
                    $result = $order->create($order_data);
                    if($result){
                        return response()->json([
                            'status' => true,
                            'message' => 'Order saved successfully',
                            'data' => $request->all(),
                        ]);
                    }else{
                        return response()->json([
                            'status' => false,
                            'message' => 'Order not saved successfully',
                        ]);
                    }
                }else{
                    return response()->json([
                        'status' => false,
                        'message' => 'Login user should be waiter only...',
                    ]);
                }
            }
        }
    }
    public function notifyWaiter(Request $request)
    {
        $currentDate = Carbon::now()->format('Y-m-d');
        $order = OrderDetail::with('getOrderItems','getOrder')
                ->where('staff_id',auth()->user()->id)
                ->where('restaurant_id',auth()->user()->restaurant_id)
                ->where('status',1)
                ->whereDate('created_at', $currentDate)
                ->orderBy('id','Desc')
                ->get();
        $order_array = [];
        foreach ($order as $key => $value) {
            $order_array[$key]['item_name'] = $value->getOrderItems->name??"";
            $order_array[$key]['table_no'] = $value->table_no." (".(isset($value->getOrder->floor_no)?$value->getOrder->floor_no:"").")";
            $order_array[$key]['quantity_in_variation'] = $value->quantity_in_variation??"";
            $order_array[$key]['quantity'] = $value->quantity??"";
            $order_array[$key]['amount'] = $value->amount??"";
            $order_array[$key]['notes'] = $value->notes??"";
            $order_array[$key]['status'] = "Food Prepared";
        }
        return Response::json(["status"=>true,"data"=>$order_array]);
    }

    public function orderList(Request $request)
    {
        $currentDate = Carbon::now()->format('Y-m-d');
        $query = OrderDetail::with(['getOrderItems','getOrderItems.itemImage','getOrder']);
        if(!empty($request->table_no)){
            $query->where('table_no',$request->table_no);
        }
        $order = $query->where('restaurant_id',auth()->user()->restaurant_id)->orderBy('id', 'Desc')->whereDate('created_at', $currentDate)->get();
        // dd($request->all());
        // echo"<pre>";
        // print_r($order);
        // die;
        $order_array = [];
        $order_id = [];
        foreach ($order as $key => $value) {
            if($value->getOrder->billing_status != 1){
                $order_array[$key]['id'] = $value->id??"";
                $order_array[$key]['item_name'] = $value->getOrderItems->name??"";
                $order_array[$key]['table_no'] = $value->table_no." (".(isset($value->getOrder->floor_no)?$value->getOrder->floor_no:"").")";
                $order_array[$key]['quantity_in_variation'] = $value->quantity_in_variation??"";
                $order_array[$key]['quantity'] = $value->quantity??"";
                $order_array[$key]['amount'] = $value->amount??"";
                $order_array[$key]['notes'] = $value->notes??"";
                $order_array[$key]['ordered_at'] = $value->created_at->format('H:i A');
                $order_array[$key]['image_name'] = isset($value->getOrderItems->itemImage->image_name)?url('public/files/' . $value->getOrderItems->itemImage->image_name):"" ;
                if($value->status == 1){
                    $order_array[$key]['status'] = "Completed";
                }else if($value->status == 0){
                    $order_array[$key]['status'] = "Pending";
                }else if($value->status == 2){
                    $order_array[$key]['status'] = "Order Accepted By Chef";
                }else if($value->status == 3){
                    $order_array[$key]['status'] = "Cancel";
                }
            
            $order_id = $value->order_id??"";
            }
        }
        // if($order_array == ""){
        //     return Response::json(["status"=>false,"order_id"=>[],"data"=>[]]);
        // }else{
            return Response::json(["status"=>true,"order_id"=>$order_id,"data"=>$order_array]);
        // }
        
    }
    public function addToCart(Request $request){
        // dd(auth()->user()->id);
        // $orders = OrderDetail::with(['getOrder' 
        // =>function($query) use($request){
        //     $query->orderBy('id','desc')->where('billing_status',0);
        // }
        // ])->where('table_no', $request->input('table_id'))
        // ->where('restaurant_id', $request->input('resturant_id'))
        // ->orderBy('id','desc')
        // ->first();
        // echo"<pre>";
        // print_r($orders);
        // die;
        $cart_update = AddToCart::find($request->ids);
        if ($cart_update === null) {
            $rules = [
                'price' => 'required',
                'quantity' => 'required',
                'item_id' => 'required',
                'table_id' => 'required',
                'resturant_id' => 'required',
                // 'order_id' => 'required',
                // 'staff_id' => 'required',
                // 'notes' => 'required',
                // 'quantity_in_variation' => 'required',
            ];
            $messages = [
                'price.required' => 'Please enter a price',
                'quantity.required' => 'Please enter a quantity',
                'item_id.required' => 'Please enter item',
                'table_id.required' => 'Please enter a table',
                'resturant_id.required' => 'Please enter a restaurant',
                // 'notes.required' => 'Please enter a notes',
                // 'quantity_in_variation.required' => 'Please enter a quantity_in_variation',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if($validator->fails()){
                return response()->json([
                    'errors' => $validator->errors(),
                ]);
            }else{
                $orders = Order::where('table_no', $request->input('table_id'))
                            ->where('restaurant_id', $request->input('resturant_id'))
                            ->orderBy('id','desc')
                            ->first();
                if(!empty($orders) ){
                    if($orders->billing_status == 0){
                        $data = [
                            'amount' => $request->input('price'),
                            'quantity' => $request->input('quantity'),
                            'item_id' => $request->input('item_id'),
                            'table_no' => $request->input('table_id'),
                            'staff_id' => auth()->user()->id,
                            'order_id' => $orders->id,
                            'restaurant_id' => $request->input('resturant_id'),
                            'notes' => $request->input('notes'),
                            'quantity_in_variation' => $request->input('quantity_in_variation'),
                        ];
                        $order = new AddToCart;
                        if (auth()->user()->type == 6) {
                            $result = $order->create($data);
                                if($result){
                                    return response()->json([
                                        'status' => true,
                                        'mesaage' => 'Order added to cart successfully',
                                        'data' => $result,
                                    ]);
                                }else{
                                    return response()->json([
                                        'status' => false,
                                        'message' => 'Order not added to cart successfully',
                                    ]);
                                }
                        }else{
                            return response()->json([
                                'status' => false,
                                'message' => 'Login user is waiter only...',
                            ]);
                        }
                    }else{
                        return response()->json([
                            'status' => false,
                            'message' => 'This order payment already done. Please generate the new order reservation.',
                        ]);
                    }
                }else{
                    return response()->json([
                        'status' => false,
                        'message' => 'Please reserve the table first & then order again.',
                    ]);
                }
            }
        }else{
            $rules = [
                'ids' => 'required',
            ];
            $validator = Validator::make($request->all(), $rules);
            if($validator->fails()){
                return response()->json([
                    'errors' => $validator->errors(),
                ]);
            }else{
                $cart_updates = AddToCart::find($request->ids);
                if($request->quantity == 0 || $cart_updates->quantity == 0){
                    $update_cart_detail = AddToCart::where('id', $request->ids)->delete();
                    return response()->json([
                        'status' => true,
                        'message' => 'Cart item removed.',
                    ]);
                }else{
                    $update_cart_detail = AddToCart::where('id', $request->ids)->update(['quantity' => $request->quantity]);
                    if($update_cart_detail){
                        return response()->json([
                            'status' => true,
                            'message' =>  'Order updated successfully',
                        ]);
                    }else{
                        return response()->json([
                            'status' => false,
                            'message' =>  'Order not updated',
                        ]);
                    }
                }
            }
        }   
    }
    public function viewCart(Request $request){
        $order = AddToCart::with('getOrderItems','getOrderItems.itemImage','getOrder')
                ->where('table_no',$request->table_no)
                ->where('staff_id',auth()->user()->id)
                ->where('restaurant_id',auth()->user()->restaurant_id)
                ->where('status','!=',3)
                ->orderBy('id', 'ASC')
                ->get();
        $order_array = [];
        foreach ($order as $key => $value) {
            $order_array[$key]['cart_id'] = $value->id;
            $order_array[$key]['item_name'] = $value->getOrderItems->name??"";
            $order_array[$key]['quantity_in_variation'] = $value->quantity_in_variation??"";
            $order_array[$key]['quantity'] = $value->quantity??"";
            $order_array[$key]['amount'] = $value->amount??"";
            $order_array[$key]['notes'] = $value->notes??"";
            $order_array[$key]['name'] = $value->getOrder->name??"";
            $order_array[$key]['order_id'] = $value->getOrder->id??"";
            $order_array[$key]['table_no'] = $value->getOrder->table_no." (".(isset($value->getOrder->floor_no)?$value->getOrder->floor_no:"").")";
            $order_array[$key]['mobile_no'] = $value->getOrder->mobile_no??"";
            $order_array[$key]['image_name'] = isset($value->getOrderItems->itemImage->image_name)?url('public/files/' . $value->getOrderItems->itemImage->image_name):"" ;
            // if($value->status == 1){
            //     $order_array[$key]['status'] = "Completed";
            // }else if($value->status == 0){
            //     $order_array[$key]['status'] = "Pending";
            // }else if($value->status == 2){
            //     $order_array[$key]['status'] = "Order Accepted By Chef";
            // }else if($value->status == 3){
            //     $order_array[$key]['status'] = "Cancel";
            // }
        }
        return Response::json(["status"=>true,"data"=>$order_array]);
    }
}