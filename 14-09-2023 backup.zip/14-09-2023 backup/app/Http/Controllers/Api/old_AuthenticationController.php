<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;   
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use App\Models\City; 
use App\Models\AppSplashSlider; 
use App\Models\User; 
use App\Models\Category;
use App\Models\MenuCategory; 
use App\Http\Resources\UserResource; 
use App\Models\AllergyType; 
use App\Models\CuisineType; 
use App\Models\FoodIntolerance; 
use App\Models\Country; 
use App\Models\Language; 
use App\Models\Item; 
use App\Models\Order; 
use App\Models\ItemPrice; 
use App\Models\Invoice; 
use App\Models\RestaurantFloor; 
use Str,Blade,Cache,Cookie,File,Redirect,Response,BASE_URL,View,Hash;
use Validator;
use Session,Storage,Password; 
use Mail;
use DB;
use DataTables;
use Config;
use DateTime; 
use JWTAuth,URL;
use Illuminate\Http\Request;
use Carbon\Carbon;


class AuthenticationController extends Controller
{ 
        
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => []]);
    }
    public function register(Request $request)
    {

        $rules = array(
            'lang_id' => 'required',
            'country_id' => 'required', 
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required|email',
            'mobile' => 'required|numeric',
            'password' => 'required',
            'fcm_token' => 'required'

        );

        $validator = Validator::make($request->all() , $rules);


        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
      
        $usermail = User::where('email', '=', $request->email)->first();  
        if(!empty($usermail))
        { 
        return Response::json(["status"=>false,"message"=> 'User account with this email already Exist, please login!'], 406); 
        }
  
        $user = User::create([
            'email' => $request->email, 
            'mobile' => $request->mobile,  
            'first_name' => $request->first_name,  
            'last_name' => $request->last_name,  
            'country_id' => $request->country_id,  
            'lang_id' => $request->lang_id,  
            'fcm_token' => $request->fcm_token,  
            'name' => $request->first_name.' '.$request->last_name,  
            'type' => 4, 
            'password' => Hash::make($request->password),    
            'created_at' => date('Y-m-d H:i:s')
        ]); 

         
        if($user){ 
        app('App\Http\Controllers\UserController')->verifymailsend($user);
        if($request->lang_id == 3)
        {
            $success_message = 'Vous vous êtes inscrit avec succès et un courrier de vérification a été envoyé sur votre adresse e-mail.';
            $error_message = "Quelque chose s'est mal passé.";
        }
        elseif($request->lang_id == 2)
        {
            $success_message = 'لقد قمت بالتسجيل بنجاح وتم إرسال بريد التحقق على عنوان بريدك الإلكتروني.';
            $error_message = 'هناك خطأ ما.';
        }
        else
        {
            $success_message = 'You have registered successfully & verification mail sent on your email address.';
            $error_message = 'Something went wrong.';
        }

        return Response::json(["status"=>true,"message"=> $success_message ], 200);  
        }
 
        return Response::json(["status"=>false,"message"=> $error_message], 406); 
    } 

    public function splashBanners()
    {
        $banners = AppSplashSlider::selectRaw('*,CONCAT("'.asset('storage').'/'.'",image) AS image')->where('status',1)->get();
        return Response::json(["status"=>true,"message"=> "slider image fetched successfully.","data"=>$banners], 200);  
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required', 
            'fcm_token' => 'required'
        ]); 
         if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        $input = $request->all();

        $credentials = request(['email', 'password']);


        if(!$token = JWTAuth::attempt($credentials)){

                if($request->lang_id == 3)
                {
                    $msg = 'Veuillez saisir une adresse e-mail et un mot de passe valides.';
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'الرجاء إدخال عنوان بريد إلكتروني صالح وكلمة مرور.';
                   
                }
                else
                {
                    $msg = 'Please enter valid Email address and Password.';
                 
                }
             return Response::json(["status"=>false,"message"=> $msg], 406);
        } else {  
              $token = 'bearer '.$token;
        }

        $user = User::where('email',$request->email)->first();
        

        if ($user->email_verified_at == NULL)
        {
                if($request->lang_id == 3)
                {
                    $msg = "L'email n'est pas verifié!";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لم يتم التحقق من البريد الإلكتروني!';
                   
                }
                else
                {
                    $msg = 'Email is not verified!';
                 
                }
            return Response::json(["status"=>false,"message"=> $msg ], 406);
        }
        else
        { 
            $update_array['fcm_token'] = $request->fcm_token;
        } 

        if (isset($request->lang_id) and $request->lang_id != "") {
            $update_array['lang_id'] = $request->lang_id;
        }
        if (isset($request->country_id) and $request->country_id != "") {
            $update_array['country_id'] = $request->country_id;
        }

        User::where('id',$user->id)->update($update_array);

        if ($user->status == 0 || $user->status == 2){ 
               if($request->lang_id == 3)
                {
                    $msg = "Votre compte est désactivé par l'administrateur !";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم إلغاء تنشيط حسابك من قبل المشرف!';
                   
                }
                else
                {
                    $msg = 'Your account is deactivated by admin!';
                 
                }
            return Response::json(["status"=>false,"message"=> $msg], 406);
        }
       
         
        $user = User::where('email',$request->email)->first();
        $user->jwt_token = $token;
        $data = new UserResource($user);

               if($request->lang_id == 3)
                {
                    $msg = "Connexion réussie !";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم تسجيل الدخول بنجاح!';
                   
                }
                else
                {
                    $msg = 'Successfully logged in!';
                 
                }
        return Response::json(["status"=>true,"message"=> $msg, "data"=> $data], 200);
    }

    public function socialLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'nullable|email',
            'provider' => 'required', 
            'provider_id' => 'required',
            'fcm_token' => 'required',
            'country_id' => 'required',
            'lang_id' => 'required',
        ]);  
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }
        $input = $request->all(); 
        $user = User::where([['provider', '=', $request->provider],['provider_id', '=',  $request->provider_id]])->first();
        if (empty($user)) {
            $tempuser1 = User::where('email','=',$request->email)->where('email','<>','')->where('email','<>',null)->first();
            if (!empty($tempuser1)) {
           
            if (isset($request->lang_id) and $request->lang_id != "") {
            $update_array['lang_id'] = $request->lang_id;
            }
            if (isset($request->country_id) and $request->country_id != "") {
                $update_array['country_id'] = $request->country_id;
            }
            User::where('email','=',$request->email)->where('email','<>','')->where('email','<>',null)->update($update_array);
             $tempuser = User::where('email','=',$request->email)->where('email','<>','')->where('email','<>',null)->first();
             $user = $tempuser;
            } else {

                
            $user = User::create([
                'email' => isset($request->email) ? $request->email : null,
                'provider' => $request->provider,
                'provider_id' => $request->provider_id,
                'email_verified_at' => date('Y-m-d H:i:s'),
                'fcm_token' => $request->fcm_token,
                'country_id' => $request->country_id,
                'lang_id' => $request->lang_id,
                'type' => 4,
                'status' => 1
            ]);

            }

        }  

        
 
        if(!$token = JWTAuth::fromUser($user)){
            if($request->lang_id == 3)
                {
                    $msg = 'Veuillez saisir une adresse e-mail et un mot de passe valides.';
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'الرجاء إدخال عنوان بريد إلكتروني صالح وكلمة مرور.';
                   
                }
                else
                {
                    $msg = 'Please enter valid Email address and Password.';
                 
                }
             return Response::json(["status"=>false,"message"=> $msg], 406);
        } else {  
              $token = 'bearer '.$token;
        }
 
        $user->jwt_token = $token;

        if ($user->email_verified_at == NULL)
        { 
               if($request->lang_id == 3)
                {
                    $msg = 'Vous vous êtes bien inscrit.';
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لقد سجلت بنجاح.';
                   
                }
                else
                {
                    $msg ='You have registered successfully.';
                 
                }
        User::where('id',$user->id)->update(['email_verified_at'=> date('Y-m-d H:i:s')]);
        return Response::json(["status"=>true,"message"=> $msg], 200);   
        }
        
        if ($user->status == 0 || $user->status == 2){ 
            if($request->lang_id == 3)
                {
                    $msg = "Votre compte est désactivé par l'administrateur !";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم إلغاء تنشيط حسابك من قبل المشرف!';
                   
                }
                else
                {
                    $msg = 'Your account is deactivated by admin!';
                 
                }
            return Response::json(["status"=>false,"message"=> $msg ], 406);
        }
               if($request->lang_id == 3)
                {
                    $msg = "Connexion réussie !";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'تم تسجيل الدخول بنجاح!';
                   
                }
                else
                {
                    $msg = 'Successfully logged in!';
                 
                }
        return Response::json(["status"=>true,"message"=> $msg , "data"=> $user], 200);
    }


    public function forgotPassword(Request $request)
    {

        $this->validate($request, ['email' => 'required|email']);


        $find = User::where('email',$request->email)->first();
        if (empty($find)) {
               if($request->lang_id == 3)
                {
                    $msg = "Impossible de trouver un utilisateur avec cette adresse e-mail !";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لا يمكننا العثور على مستخدم بعنوان البريد الإلكتروني هذا!';
                   
                }
                else
                {
                    $msg = 'We cannot find a user with that email address!';
                 
                }
            return response()->json(["status"=>false,"message"=> $msg], 406);
        
        } else {
            $status = Password::sendResetLink(
        $request->only('email')
    );

    $status_sent = $status === Password::RESET_LINK_SENT
                ? back()->with(['status' => __($status)])
                : back()->withErrors(['email' => __($status)]);
        if ($status_sent) { 
               if($request->lang_id == 3)
                {
                    $msg = "Nous avons envoyé votre lien de réinitialisation de mot de passe par e-mail !.";
                    
                }
                elseif($request->lang_id == 2)
                {
                    $msg = 'لقد أرسلنا عبر البريد الإلكتروني رابط إعادة تعيين كلمة المرور الخاصة بك !.';
                   
                }
                else
                {
                    $msg = 'We have emailed your password reset link!.';
                 
                }
        return response()->json(["status"=>true,"message"=> $msg], 200);
        }
        }


    }

    public function languagesList(Request $request)
    {
        if (count($languagesList = Language::get()) > 0) { 
            return Response::json(["status"=>true,"message"=> "Success","data"=>$languagesList]);
        }  
    }

    public function countriesList(Request $request)
    {
        $countriesList = Country::selectRaw('CONCAT("'.asset('storage').'/'.'",image) AS image,country_name,id')->get();  
        return Response::json(["status"=>true,"message"=> "Success","data"=>$countriesList]);  
    }
 
    public function floorData(Request $request)
    {
        if (!empty($floorData = RestaurantFloor::first())) { 
            $decoded_floor_data = json_decode($floorData->floor_table_view);
            foreach ($decoded_floor_data as $key => $value) {
                $value->img = URL::to('/').'/admin/imgs/'.$value->capacity.'.png';
            } 
            $floorData->floor_table_view = json_encode($decoded_floor_data);
            return Response::json(["status"=>true,"message"=> "Success","data"=>$floorData]);
        }  
    }

    public function addOrder(Request $request){
        $rules = [
            'price' => 'required',
            'quantity' => 'required',
            'item_id' => 'required',
            'table_id' => 'required',
            'resturant_id' => 'required',
        ];
        $messages = [
            'price.required' => 'Please enter a price',
            'quantity.required' => 'Please enter a quantity',
            'item_id.required' => 'Please enter item',
            'table_id.required' => 'Please enter a table',
            'resturant_id.required' => 'Please enter a restaurant',
        ];
        $validator = Validator::make($request->all(), $rules, $messages);
        if($validator->fails()){
            return response()->json([
                'errors' => $validator->errors(),
            ]);
        }else{
            $data = [
                'price' => $request->input('price'),
                'quantity' => $request->input('quantity'),
                'item_id' => $request->input('item_id'),
                'table_id' => $request->input('table_id'),
                'resturant_id' => $request->input('resturant_id'),
            ];
            $order = new Order;
            // print_r(auth()->user());
            // die;
            if (auth()->user()->type == 3) {
                $result = $order->create($data);
                if($result){
                    return response()->json([
                        'status' => true,
                        'mesaage' => 'Order saved successfully',
                        'data' => $result,
                    ]);
                }else{
                    return response()->json([
                        'status' => false,
                        'message' => 'Order not saved successfully',
                        'data' => $result,
                    ]);
                }
            }else{
                return response()->json([
                    'status' => false,
                    'message' => 'Login user is staff only...',
                    'data' => $result,
                ]);
            }
            
        }        
    }

    public function orderCancel(Request $request){
        $data = $request->all();
        $id = $data['id'];
        $order_cancele = Order::where('id', $id);
        // echo "<pre>"; print_r($order_cancele); die;
        $data = ['status' => 2];
        $result = $order_cancele->update($data);
        if($result){
            return response()->json([
                'status' => true,
                'message' => 'Order canceled successfully canceled',
                'data' => $result,
            ]);
        }else{
            return response()->json([
                'status' => false,
                'message' => 'Something went wrong with order cancellation. Please try again later',
            ]);
        }
    }
}

