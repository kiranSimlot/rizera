<?php

namespace App\Http\Controllers\Api;
use App\Models\SupportQuery;        
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Response,Validator;

class MoreController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => []]);
    }

    public function createSupportRequest(Request $request)
    { 
        $rules = array( 
            'name' => 'required|string|max:100', 
            'email' => 'required|email|max:100', 
            'message' => 'required|string|max:500'  
        );

        $validator = Validator::make($request->all() , $rules);
 
        if($validator->fails())
        {
            $message = $validator->errors()->first();
            return response()->json(["status"=>false,"message"=> $message], 406);
        }


         if(auth()->user()->lang_id == 3)
        {
            $msg = "Votre requête a été envoyée à notre équipe d'assistance.";
            
        }
        elseif(auth()->user()->lang_id  == 2)
        {
            $msg = "تم إرسال استفسارك إلى فريق الدعم لدينا.";                 
        }
        else
        {
            $msg = 'Your query has been sent to our support team.';
              
        }

        SupportQuery::create([
            'name' => $request->name,
            'email' => $request->email,
            'message' => $request->message
        ]);

        return Response::json(["status"=>true,"message"=>$msg]);

    } 

}
