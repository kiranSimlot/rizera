<?php

namespace App\Http\Controllers\Api;
use App\Models\Notification;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Response;

class NotificationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => []]);
    }

    public function notifications(Request $request)
    { 
        $query = Notification::where('user_id',auth()->user()->id);
        $notifications = $query->selectRaw('title,description,notifications.read,DATE_FORMAT(created_at,"%Y-%m-%d %H:%i:%s") as created')->get();

        return Response::json(["status"=>true,"message"=>"notification list fetched.","data"=>$notifications]);

    }


    public function markNotificationsRead(Request $request)
    {
        $query = Notification::where('user_id',auth()->user()->id);
        $notifications = $query->update([
            'read' => 1
        ]);

        return Response::json(["status"=>true,"message"=>"notifications marked read."]);

    }

}
