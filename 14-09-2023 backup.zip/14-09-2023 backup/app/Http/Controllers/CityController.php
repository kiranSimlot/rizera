<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City;
use App\Models\Country;
use File;
//use DB;
use DataTables;

use Illuminate\Validation\Rule;


class CityController extends Controller
{
    public function index()
    {
        return view('city');
        
    }
    public function cityData(Request $request)
    {
        $city=City::with('getCountry')->where('cities.status','!=',0)->get();
        return DataTables::collection($city)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('city_image',function ($result){
            if(!empty($result->city_image))
                return "<td><img src='".asset('storage').'/'.$result->city_image."' width='100px'></td>";
            else
                return "<td><img src='".asset('storage/city/no_image.jpg')."' width='100px'></td>";
        })
            ->addColumn('city_name',function ($result){
            return $result->city_name;
        })
            ->addColumn('country_name',function ($result){
                if(isset($result->getCountry->country_name))
                    return $result->getCountry->country_name;
        })
            ->addColumn('action',function ($result){
					$edit = "<td><a href='".route('admin.city.editcity',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.city.delete',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
                    </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
				
				
        })
        ->rawColumns(['action','country_name','city_image'])
		->addIndexColumn()
        ->make(true);
    }
	
	public function statusupdatecity(Request $request){
        /*$id=$request->input('id');
		$data = DB::table('cities')->select('status')->where('id', '=', $id)->get();
        if($data[0]->status==1)
        $status = 0;
        elseif($data[0]->status==0)
        $status = 1;
		DB::table('cities')->where('id', $id)->update(['status' => $status]);
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$data]);*/
		$id = $request->input('id');
 $status = City::find($id);
 if($status->status == 1)
  $status->status = 2;
 elseif($status->status == 2)
  $status->status = 1;
 $status->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
	
    public function add()
    {
        $country = Country::all();
        return view('addcity',compact('country'));
    }
    public function store(Request $request)
    {
        

        $city_nameUniqueRule = Rule::unique('cities')->where('country_id', request()->get('country_id', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });

        $rules=[
            //'city_name'=>'required|max:25|unique:cities,city_name',
            //'country_id'=>'required',
            'city_name' => ['required', 'max:25', $city_nameUniqueRule],
			'name_ar'=>'required|max:25',
			'name_fr'=>'required|max:25',
            'country_id' => 'required',
            'city_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=500,min_height=500'
        ];
        $message = [
            'city_name.required'=>'City name is required.',
            'city_name.max'=>'City name limit exceed',
			'name_ar.required'=>'Cuisine name is required.',
            'name_ar.max'=>'Cuisine name limit exceed',
			'name_fr.required'=>'Cuisine name is required.',
            'name_fr.max'=>'Cuisine name limit exceed',
            'country_id.required'=>'Country name is required.',
            'city_image.required'=>'Image is required.',
            'city_image.mime'=>'file is not image',
            'city_image.dimensions'=>'file size is not correct'
        ];
        $request->validate($rules,$message);
     
     $city = new City;

        $directory = 'city';
        $city_image = $request->city_image;
        $image_name = $request->user()->id.time().rand(1,999999999).'.'.$city_image->extension(); 
        $city_image->storeAs('public/'.$directory, $image_name); 
        $city->city_name = $request->city_name;
		$city->name_ar = $request->name_ar;
        $city->name_fr = $request->name_fr;
        $city->country_id = $request->country_id;
        if($city_image = $request->file('city_image'))
        {
            $city_image = $directory.'/'.$image_name;
            $city->city_image = $city_image;
        }
        else
        {
            unset($request->city_image);
        }

$city->status = 1;
        $city->save();
        // $request->city_image->move(public_path('city'), $city_image);
        return redirect()->Route('admin.city.cities')->with('success','City addded successfully');
    }

    public function edit($id)
    {
        $city=City::find($id);
        $country=Country::all();
        return view('editcity',compact(['city','country']));
    }
    public function update(Request $request, $id)
    {

        $city_nameUniqueRule = Rule::unique('cities')->where('country_id', request()->get('country_id', ''))->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);

        $rules=[
            //'city_name'=>'required|max:25|unique:cities,city_name,'.$id.'',
            'city_name' => ['required', 'max:25', $city_nameUniqueRule],
			'name_ar'=>'required|max:25',
			'name_fr'=>'required|max:25',
            'country_id'=>'required',
            'city_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=500,min_height=500'
        ];
        $message = [
            'city_name.required'=>'city name is required.',
            'city_name.max'=>'city name limit exceed',
			'name_ar.required'=>'Cuisine name is required.',
            'name_ar.max'=>'Cuisine name limit exceed',
			'name_fr.required'=>'Cuisine name is required.',
            'name_fr.max'=>'Cuisine name limit exceed',
            'country_id.required'=>'Country name is required.',
            'city_image.required'=>'Image is required.',
            'city_image.mime'=>'file is not image',
            'city_image.dimensions'=>'file size is not correct',
        ];
        $request->validate($rules,$message);
        $city=City::find($id);

        $cityImage = public_path("storage/{$city->city_image}"); // get previous image from folder
      
            $directory = 'city';
            $city_image = $request->city_image;
            $image_name = $request->user()->id.$id.time().rand(1,999999999).'.'.$city_image->extension(); 
            $city_image->storeAs('public/'.$directory, $image_name); 

        if (File::exists($cityImage)) { // unlink or remove previous image from folder
            unlink($cityImage);
        }

        $city->city_name = $request->city_name;
		$city->name_ar = $request->name_ar;
        $city->name_fr = $request->name_fr;
        $city->country_id = $request->country_id;
        if($city_image = $request->file('city_image'))
        {
            $city_image = $directory.'/'.$image_name;
            $city->city_image = $city_image;
        }
        else
        {
            unset($request->city_image);
        }
        $city->save();
        // $request->city_image->move(public_path('city'), $city_image);
        return redirect()->Route('admin.city.cities')->with('success','City edited successfully');
    }
    public function delete($id)
    {
        $city=City::find($id);
        $city->status=0;
        $city->save();
       
        return redirect()->Route('admin.city.cities')->with('success','City deleted successfully');
    }
}
