<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
class ManageController extends Controller
{
    public function index()
    {
        $categorys=Category::paginate(10);
        return view('category',compact('categorys'));
    }
    public function add()
    {
        return view('addcategory');
    }
    public function store(Request $request)
    {
        $rules=[
            'name'=>'required|max:25'
        ];
        $message = [
            'name.required'=>'Category name is required.',
            'name.max'=>'Category name limit exceed'
        ];
        $request->validate($rules,$message);
        $category = new Category;
        $category->name = $request->name;
        $category->save();
        return redirect()->Route('admin.category.list');
    }
    public function delete($id)
    {
        $category=Category::find($id);
        $category->delete();
        return redirect()->Route('admin.category.list');
    }
    public function edit($id)
    {
        $category=Category::find($id);
        return view('editcategory',compact('category'));
    }
    public function update(Request $request, $id)
    {
        $rules=[
            'name'=>'required|max:25'
        ];
        $message = [
            'name.required'=>'Category name is required.',
            'name.max'=>'Category name limit exceed'
        ];
        $request->validate($rules,$message);
        $category=Category::find($id);
        $category->name = $request->name;
        $category->save();
        return redirect()->Route('admin.category.list');
    }
    
}
