<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MenuCategory;
use App\Models\Restaurant;
use DataTables;
use DB;
use Auth;
use Session;
use Carbon\Carbon;

class MenuCategoryController extends Controller
{
  
    public function list(){

        return view('menu_category.category_list');
    }
    
	public function categoryData(Request $request){
       
        // $category = MenuCategory::all();
        $category = MenuCategory::orderBy('id', 'desc')->get();
       
        return DataTables::collection($category)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('category_name',function ($result){
            return $result->name;
        })
          
         ->addColumn('action',function ($result){
           
            $btn = "<a href='".route('admin.menu_category.editcategory',['id'=>$result->id])."' style='border:none;'><i class='fas fa-edit'></i></i></a>";

            $btn.= "<button class='btn btn-sm btn-outline-danger category_delete' data-id='".$result['id']."' title='Delete'><i class='fas fa-trash-alt'></i></button>";

            // $btn.= "<a href='".route('admin.menu_category.delete',['id'=>$result->id])."' style='border:none;'><i class='btn btn-danger btn-sm del' onclick='return DelFun();'>Delete</i></a>";
            return $btn;

           
        })


        ->rawColumns(['action'])
        ->addIndexColumn()
        ->make(true);
    }

    public function add(){
        return view('menu_category.add_category');
    }
    
	public function store(Request $request){
        $rules=[
            'name'=>'required|',
             
        ];
        $message = [
            'name.required'=>'Name is required.',
        ];
        $request->validate($rules,$message);
        $category = new MenuCategory;
        $category->name = $request->name;
        $category->save();
        return redirect()->Route('admin.menu_category.list')->with('success','Category addded successfully');
    }
	
	public function edit($id){
        $category = MenuCategory::find($id);
        return view('menu_category.edit_category',compact('category'));
    }
    
	public function update(Request $request,$id){
       $rules=[
            'name'=>'required',
            
        ];

        $message = [
            'name.required'=>'Name is required.',
            
        ];
        $request->validate($rules,$message);
        $category = MenuCategory::find($id);
        $category->name = $request->name;
        $category->save();
        return redirect()->Route('admin.menu_category.list')->with('success','Category edited successfully');
    }
    
    

    public function delete($id){

        $queryResult = MenuCategory::where('id',$id);
        if($queryResult){
            $queryResult->update(array('status' => 1));
            $response = ['status'=>true,'message'=>'Category deleted successfully'];
            return $response;
        }else{
            $response = ['status'=>false,'message'=>'Category not remove'];
            return $response;
        }

        // $category = MenuCategory::find($id);
        // $category->delete();
    
        return redirect()->Route('admin.menu_category.list')->with('success','Category deleted successfully');
    }
	
	public function addcategory(){
	$resturant_id = Restaurant::where('user_id',Auth::user()->id)->select('id')->first();
    $id_restaurant = Session::get('id_restaurant');
    return view('menucategory.add_menu_category',compact('resturant_id','id_restaurant'));
    }
	
	public function storecategory(Request $request){
        $rules=[
            'name'=>'required|unique:menu_categories,name',
             
        ];
        $message = [
            'name.required'=>'Name is required.',
        ];
        $request->validate($rules,$message);
        $category = new MenuCategory;
        $category->name = $request->name;
		$category->restaurant_id = $request->restaurant_id;
        $category->save();
        return redirect()->Route('owner.menucategory.menu-list')->with('success','Category addded successfully');
    }
	public function menuCategoryList(Request $request){
		return view('menucategory.menu_category_list');
	}
	
	public function menucategoryData(Request $request){
       
        // $category = MenuCategory::all();
		//$resturant_id = Restaurant::where('user_id',Auth::user()->id)->select('id')->first();
		//$resturant_ids = $resturant_id['id'];
        $resturant_ids = Session::get('id_restaurant');
        /*print_r($resturant_ids);
        die;*/

        $category = MenuCategory::orderBy('id', 'desc')->where('restaurant_id',$resturant_ids)
                    ->where('status','!=', 1)
                    ->get();
       
        return DataTables::collection($category)
           
            ->addColumn('category_name',function ($result){
            return $result->name;
        })
          
         ->addColumn('action',function ($result){
           
            $btn = "<a class='btn report-edit mr-2' href='".route('owner.menucategory.editcategory',['id'=>$result['id']])."'><img src='".url('')."/admin/imgs/edit_icon.svg' style='height: 15px;'  data-toggle='tooltip' data-placement='top' title='Edit'></a>";

            $btn.= "<a href='javascript:void(0)'class = 'btn report-trash mr-2 soft_item_delete' id='".$result['id']."'><img src='".url('')."/admin/imgs/trash.svg' style='height: 15px;'  data-toggle='tooltip' data-placement='top' title='Delete'></a>";

            // $btn.= "<a href='".route('admin.menu_category.delete',['id'=>$result->id])."' style='border:none;'><i class='btn btn-danger btn-sm del' onclick='return DelFun();'>Delete</i></a>";
            return $btn;

           
        })


        ->rawColumns(['action'])
        ->addIndexColumn()
        ->make(true);
    }
	
	
	public function editcategory(Request $request,$id){
        
        // dd($request->all());
        $category = MenuCategory::find($id);
        return view('menucategory.editcategory',compact('category'));
    }
	
	public function updatecategory(Request $request,$id){
       $rules=[
            'name'=>'required|unique:menu_categories,name',
            
        ];

        $message = [
            'name.required'=>'Name is required.',
            
        ];
        $request->validate($rules,$message);
        $category = MenuCategory::find($id);
        $category->name = $request->name;
        $category->save();
        return redirect()->Route('owner.menucategory.menu-list')->with('success','Category edited successfully');
    }
	
	public function softDeleteCategory(Request $request){
		$delete = MenuCategory::where('id', $request->id)->first(); 
            $delete->status = 1;
            $result = $delete->update();
            if($result){
                return response()->json([
                    'status' => true,
                    'message' => 'Category deleted successfully',
                ]);
            }
	    }
   
}
