<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Demo;
class FrontController extends Controller
{
    public function demoStore(Request $request)
    {
        $rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'country_code' => 'required',
            'mobile_no' => 'required',
            'email'=>'required|email',
            'restaurant_name' => 'required',
        ];

        $message = [
            'first_name.required'=>'First name is required.',
            'last_name.required'=>'Last name is required.',
            'country_code.required'=>'Country code is required.',
            'mobile_no.required'=>'Mobile Number is required.',
            'email.required'=>'Email is required.',
            'restaurant_name.required'=>'Restaurant name is required.',
        ];
        $request->validate($rules,$message);
        Demo::create($request->all());
     
       return redirect()->back()->with('message', 'Your request has been received from your side our team will contact you soon!!!');
    }
}
