<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
//use DB;
use DataTables;
use Illuminate\Validation\Rule;
class CategoryController extends Controller
{
    public function index()
    {
        return view('category');
    }

    public function categoryData(Request $request)
    {
        $categorys= Category::where('status','!=',0)->get();

        return DataTables::collection($categorys)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('action',function ($result){
            
			$edit = "<td><a href='".route('admin.menu_category.editcategory',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
                        <a href='".route('admin.menu_category.delete',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete
                        </a>
                    </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
				
					
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
	
	
	public function statusUpdatecategory(Request $request){
        /*$id=$request->input('id');
		$data = DB::table('categories')->select('status')->where('id', '=', $id)->get();
        if($data[0]->status==1)
        $status = 0;
        elseif($data[0]->status==0)
        $status = 1;
		DB::table('categories')->where('id', $id)->update(['status' => $status]);
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$data]);*/
		$id = $request->input('id');
 $status = Category::find($id);
 if($status->status == 1)
  $status->status = 2;
 elseif($status->status == 2)
  $status->status = 1;
 $status->save();
 return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
	
    public function add()
    {
        return view('addcategory');
    }
    public function store(Request $request)
    {

        $nameUniqueRule = Rule::unique('categories')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                });

        $rules=[
            //'name'=>'required|max:25|unique:categories,name'
            'name' => ['required', 'max:25', $nameUniqueRule]
        ];
        $message = [
            'name.required'=>'Category name is required.',
            'name.max'=>'Category name limit exceed'
        ];
        $request->validate($rules,$message);
        $category = new Category;
        $category->name = $request->name;
        $category->status = 1;
        $category->save();
        return redirect()->Route('admin.category.category')->with('success','Category addded successfully');
    }
    public function delete($id)
    {
        $category=Category::find($id);
         $category->status = 0;
        $category->save();
        return redirect()->Route('admin.category.category')->with('success','Category deleted successfully');
    }
    public function edit($id)
    {
        $category=Category::find($id);
        return view('editcategory',compact('category'));
    }
    public function update(Request $request, $id)
    {
        $nameUniqueRule = Rule::unique('categories')->where(function ($query) {
                    $query->where('status', 1)->orwhere('status', 2);
                })->ignore($id);
        $rules=[
            //'name'=>'required|max:25|unique:categories,name,'.$id.''
            'name' => ['required', 'max:25', $nameUniqueRule]
        ];
        $message = [
            'name.required'=>'Category name is required.',
            'name.max'=>'Category name limit exceed'
        ];
        $request->validate($rules,$message);
        $category=Category::find($id);
        $category->name = $request->name;
        $category->save();
        return redirect()->Route('admin.category.category')->with('success','Category edited successfully');
    }
    
}
