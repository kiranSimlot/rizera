<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\User;
use App\Models\Apitest;
use Redirect;
use File;
use Validator;
use DB;

class Dashboard extends Controller
{
    public function index()
    {
        return view('charts');
    }
        public function update(Request $request, $id) {
        if(Apitest::where('id', $id)->exists()) {
        $user = Apitest::find($id);
        $user->name = ucwords($request->input('name'));
        $user->email = $request->input('email');
        $user->save();

        return response()->json(["message" => "User updated successfully"], 200);
        } else {
        return response()->json(["message" => "User not found"], 404);
      }
    }
    public function latest()
    {
        $latest=User::all()->take(10);
        return view('latest',compact('latest'));
    }
    public function layout()
    {
        return view('layouts.admin');
    }

// Api test functions

//     public function show(Request $request){
//         // $user = Apitest::select('id','name','email')->get();
//         // $user->count()
//         $user = Apitest::paginate(2);
//         return ['status'=>true, 'message'=>'List of all Users', 'data'=>$user];

// }

// Apitest::offset(0)->limit(10)->get();

// Apitest::skip(3)->take(3)->get()；


//i use it in my project, work fine ~




public function show(Request $request){
    $page = $request->has('page') ? $request->get('page') : 1;
    $limit = $request->has('limit') ? $request->get('limit') : 5;
    $user = Apitest::select('id', 'name', 'email')->limit($limit)->offset(($page - 1) * $limit)->get()->toArray();
        return ['status'=>true, 'message'=>'List of all Users', 'data'=>$user, 'Total'=>count($user)];
}





    public function delete($id)
    {
        $user=Apitest::find($id);
        if(is_null($user)) {
            return ['status'=>true, 'message'=>'User Not Found!'];
        }
        unlink($user->image);
        $image = public_path("apiImage/$user->image");
        $user->delete();
        return ['status'=>true, 'message'=>'User deleted successfully', 'data'=>$user];
    }

    public function single($id)
    {
        $user = Apitest::find($id);
        if(is_null($user)) {
            return ['status'=>true, 'message'=>'User Not Found!'];
        }
        return ['status'=>true, 'message'=>'User Information', 'data'=>$user];
    }

    public function create(Request $request){
        $validator = Validator::make($request->all(), 
              [ 
              'name' => 'required',
              'email' => 'required',
              'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
             ]);   
 
            if($validator->fails()) {          
                return response()->json(['error'=>$validator->errors()], 401);
            }
        if($files = $request->file('file')) {
            $file = $request->file->move('apiImage');
            $user = new Apitest;
            $user->name = ucwords($request->input('name'));
            $user->email = $request->input('email');
            $user->image = $file;
            $user->save();
              
            return response()->json([
                "success" => true,
                "message" => "File successfully uploaded",
                "file" => $file
            ]);
        }else{
            return response()->json(["message" => "File not upload"]);
        }
    }

    public function search($name){
        $user = Apitest::where('name', 'like', "%{$name}%")->get();
        return ['status'=>true, 'message'=>'List of search Users', 'data'=>$user];
    }



}
