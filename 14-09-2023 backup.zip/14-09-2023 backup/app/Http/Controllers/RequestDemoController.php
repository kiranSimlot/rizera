<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Demo;
use DataTables;

class RequestDemoController extends Controller
{
    public function index()
    {
        return view('request-demo');
    }

    public function requestData(Request $request)
    {
        $request=Demo::select("*")
                        ->orderBy("id", "desc")
                        ->get();
        return DataTables::collection($request)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('first_name',function ($result){
            return $result->first_name;
        })
            ->addColumn('last_name',function ($result){
            return $result->last_name;
        })
            ->addColumn('country_code',function ($result){
            return $result->country_code;
        })            
            ->addColumn('mobile_no',function ($result){
            return $result->mobile_no;
        })            
            ->addColumn('email',function ($result){
            return $result->email;
        })            
            ->addColumn('restaurant_name',function ($result){
            return $result->restaurant_name;
        })
            ->addColumn('action',function ($result){
                $reject ='<button type="button" data-id="'.$result["id"].'" class="btn btn-danger reject">Reject</button>';
                if($result->read == 0)
            return  '<button type="button" data-id="'.$result["id"].'" class="btn btn-warning mark">Pending</button>'.$reject;
                else if($result->read == 1)
            return '<button type="button" data-id="'.$result["id"].'" class="btn btn-success">Accepted</button>';
        else
             return '<button type="button" data-id="'.$result["id"].'" class="btn btn-danger">Rejected</button>';
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
    public function update(Request $request)
    {
        $id=$request->input('id');
        $mark=Demo::find($id);
        $mark->read = 1;
        $mark->save();
        return response()->json(['status'=>true,'success'=>'readmark value change successfully','message'=>'request mark successfully','data'=>$mark]);
    }

     public function reject(Request $request)
    {
        $id=$request->input('id');
        $mark=Demo::find($id);
        $mark->read = 2;
        $mark->save();
        return response()->json(['status'=>true,'success'=>'Request Demo rejected successfully','message'=>'rRequest Demo rejected successfully','data'=>$mark]);
    }
}
