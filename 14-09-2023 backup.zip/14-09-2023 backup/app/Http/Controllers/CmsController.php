<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cms;
use DataTables;
use DB;
use Carbon\Carbon;
class CmsController extends Controller
{
  
    public function list()
    {
        return view('cmslist');
    }
    public function cmsData(Request $request)
    {
        $cms=Cms::all();
        return DataTables::collection($cms)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('heading',function ($result){
            return $result->heading;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
             // <a href='".route('admin.cms.delete',['id'=>$result->id])."' class='btn btn-sm btn-outline-danger'>Delete</a>
        
            ->addColumn('action',function ($result){
            $edit = "<td><a href='".route('admin.cms.editcms',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
               
            </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
        })
        ->rawColumns(['action'])
        ->make(true);
    }


    public function add()
    {
        return view('addcms');
    }
    public function store(Request $request)
    {
        $rules=[
            'name'=>'required',
            'heading'=>'required',
            'content'=>'required'   
        ];
        $message = [
            'name.required'=>'Name is required.',
            'heading.numeric'=>'Heading is required.',
            'content.required'=>'Content name is required.',
        ];
        $request->validate($rules,$message);
        $cms = new Cms;
        $cms->name = $request->name;
        $cms->heading = $request->heading;
        $cms->content = $request->content;
        $cms->save();
        return redirect()->Route('admin.cms.cms')->with('success','CMS addded successfully');
    }
    public function update(Request $request, $id)
    {
       $rules=[
            'name'=>'required',
            'heading'=>'required',
            'content'=>'required'   
        ];

        $message = [
            'name.required'=>'Name is required.',
            'heading.numeric'=>'Heading is required.',
            'content.required'=>'Content name is required.',
        ];
        $request->validate($rules,$message);
        $cms=Cms::find($id);
        $cms->name = $request->name;
        $cms->heading = $request->heading;
        $cms->content = $request->content;
        $cms->save();
        return redirect()->Route('admin.cms.cms')->with('success','CMS edited successfully');
    }
    
     public function statusUpdate(Request $request){
        $id=$request->input('id');
        $status=Cms::find($id);
        if($status->status==1)
        $status->status = 2;
        elseif($status->status==2)
        $status->status = 1;
        $status->save();
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
    
    
    public function edit($id)
    {
        $cms=Cms::find($id);
        return view('editcms',compact('cms'));
    }

    


     

    public function delete($id)
    {
        $cms=Cms::find($id);
        //$cms->status=0;
        $cms->delete();
    
        return redirect()->Route('admin.cms.cms')->with('success','CMS deleted successfully');
    }
   
}
