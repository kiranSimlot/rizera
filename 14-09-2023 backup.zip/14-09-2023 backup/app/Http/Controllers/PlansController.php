<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Plan;
use App\Models\Cms;
use DataTables;
use DB;
use Carbon\Carbon;
class PlansController extends Controller
{
    public function index(Request $request)
    {

        $plans = Plan::where('status','=',1)->get();
       // print_r($plans ); die();
        return view("restaurant-layout.restaurant-price",['plan'=>$plans]);
    }
    public function list()
    {
        return view('planslist');
    }
    public function planData(Request $request)
    {
        $plans=Plan::all();
        return DataTables::collection($plans)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('mark',function ($result){
            return $result->mark;
        })
            ->addColumn('amount',function ($result){
            return $result->amount;
        })     
            ->addColumn('description',function ($result){
            //return strip_tags($result->description);
			return substr(strip_tags($result->description), 0, 80).'...';
        })
            ->addColumn('action',function ($result){
            $edit = "<td><a href='".route('admin.plan.editplan',['id'=>$result->id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
               <a href='".route('admin.plan.delete',['id'=>$result->id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
            </td>";
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->status == 2)
                return  '<button type="button" data-id="'.$result["id"].'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
    public function add()
    {
        return view('addplans');
    }
    public function store(Request $request)
    {
        $rules=[
            'name'=>'required|unique:plans,name',
            'mark'=>'required',
            'amount'=>'required|numeric',
            'yearly_amount'=>'required|numeric',
            'description'=>'required'   
        ];
        $message = [
            'name.required'=>'Plan name is required.',
            'mark.required'=>'mark name is required.',
            'amount.required'=>'amount name is required.',
            'yearly_amount.required'=>'yearly amount name is required.',
            'amount.numeric'=>'monthly amount value is required.',
            'yearly_amount.numeric'=>'yearly amount value is required.',
            'description.required'=>'description name is required.',
        ];
        $request->validate($rules,$message);
        $plans = new Plan;
        $plans->name = $request->name;
        $plans->mark = $request->mark;
        $plans->monthly_amount = $request->amount;
        $plans->yearly_amount = $request->yearly_amount;
        $plans->description = $request->description;
        $plans->save();
        return redirect()->Route('admin.plan.plan')->with('success','Plan addded successfully');
    }
    public function update(Request $request, $id)
    {
        $rules=[
            'name'=>'required|max:25|unique:plans,name,'.$id.'',
            'mark'=>'required|max:50',
            'amount'=>'required|max:1000',
            'yearly_amount'=>'required|max:1000',
            'description'=>'required'
        ];
        $message = [
            'name.required'=>'Plan name is required.',
            'Mark.required'=>'Mark name is required',
            'amount.required'=>'amount is required',
            'yearly_amount.required'=>'yearly amount is required',
            'description.required'=>'description is required',
        ];
        $request->validate($rules,$message);
        $plans=Plan::find($id);
        $plans->name = $request->name;
        $plans->mark = $request->mark;
        $plans->monthly_amount = $request->amount;
        $plans->yearly_amount = $request->yearly_amount;
        $plans->description = $request->description;
        $plans->save();
        return redirect()->Route('admin.plan.plan')->with('success','Plan edited successfully');
    }
    
	 public function statusUpdate(Request $request){
        $id=$request->input('id');
        $status=Plan::find($id);
        if($status->status==1)
        $status->status = 2;
        elseif($status->status==2)
        $status->status = 1;
        $status->save();
        return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
	
    public function edit($id)
    {
        $plans=Plan::find($id);
        return view('editplan',compact('plans'));
    }

    
    public function terms_conditions()
    {

        $cms=Cms::where('name','Terms and Conditions')->first();
        return view("restaurant-layout.terms_conditions",compact('cms'));
    }

    public function privacy_policy()
    {
        $cms=Cms::where('name','Privacy Policy')->first();
        return view("restaurant-layout.privacy_policy",compact('cms'));
    }

      public function contact_us()
    {
  
        return view("restaurant-layout.contact_us");
    }

     public function buy_subscription(Request $request)
    {
       

        $currentDateTime = Carbon::now();
        $type=$request->type;
        if($type=='month'){
           $newDateTime = Carbon::now()->addMonth(); 
        }
        else{

         $newDateTime = Carbon::now()->addYear();
        }
        $expired_at =
        $id= $request->auth_id;
        $plan_id = $request->plan_id;
        $plan= Plan::find($plan_id);
        $user=DB::table('user_subscriptions')->where('user_id',$id)->where('plan_id',$plan_id)->where('active',1)->get();
        $data=array('user_id'=>$id,"plan_id"=>$plan_id,"active_from"=>$currentDateTime,"expires_at"=>$newDateTime,'type'=>$type,'active'=>1);
        $data1=array('subscription_status'=>1);

        if(isset($user))
        {
             return redirect()->back()->with('error','Already you buyed a plan.');  
            
        }
        else{
            DB::table('user_subscriptions')->insert($data);
            DB::table('users')->update($data1);
            return redirect()->back()->with('message','Subscription buyed successfully.');
            
        }
       
       }

    public function delete($id)
    {
        $plan=Plan::find($id);
        $plan->status=0;
        $plan->save();
        
    
        return redirect()->Route('admin.plan.plan')->with('success','Plan deleted successfully');
    }
}
