<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Demo;
use App\Models\SupportQuery;
use DataTables;

class SupportController extends Controller
{
    public function index()
    {
           // $request=SupportQuery::select("*")
           //              ->orderBy("id", "desc")
           //              ->get();

                       // print_r($request); die();
       return view('support');
    }

    public function requestData(Request $request)
    {
        $request=SupportQuery::select("*")
                        ->orderBy("id", "desc")
                        ->get();

                        
        return DataTables::collection($request)
            ->addColumn('id',function ($result){
            return $result->id;
        })
            ->addColumn('name',function ($result){
            return $result->name;
        })
            ->addColumn('email',function ($result){
            return $result->email;
        })
            ->addColumn('message',function ($result){
            return $result->message;
        })            
           
      
      ->addColumn('action',function ($result){
                  
            if($result->status == 1)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-success btn-sm status">Resolved</button>';
            else if($result->status == 0)
                return  '<button type="button" data-id="'.$result->id.'"  class="btn btn-warning btn-sm status">Pending</button>';
                
        })
        ->rawColumns(['action'])
		->addIndexColumn()
        ->make(true);
    }
     
    public function supportstatusupdate(Request $request){
       
        $id = $request->input('id');
         $data = SupportQuery::find($id);
         if($data->status == 1)
          $data->status = 0;
         elseif($data->status == 0)
          $data->status = 1;
         $data->save();
         return response()->json(['status'=>true,'success'=>'Resolved query successfully','message'=>'status successfully','data'=>$data]);
    }
    
}
