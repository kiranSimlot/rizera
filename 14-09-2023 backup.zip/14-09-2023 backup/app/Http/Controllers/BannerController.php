<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Country;
use App\Models\BannerImage;
use File;
use Session;
//use DB;
use DataTables;


class BannerController extends Controller
{
    public function index()
    {  
        return view('banner-image');
    }
    public function bannerIamge(Request $request) {
        //$country=Country::all();
        //$country=DB::table('banner_images')->join('countries','countries.id','=','banner_images.country_id')->select('countries.id as country_id','countries.country_name','banner_images.image as banner_images','banner_images.id as banner_id','banner_images.status as banner_status')->get();
		$country= BannerImage::join('countries','countries.id','=','banner_images.country_id')
                 ->select('countries.id as country_id','countries.country_name','banner_images.image as banner_image','banner_images.id as banner_id','banner_images.status as banner_status')->where('banner_images.status','!=',0);
        $country = $country->get();

        //print_r($country); die();
        return DataTables::collection($country)
            ->addColumn('id',function ($result){
            return $result->banner_id;
        })
            ->addColumn('image',function ($result){
            if(!empty($result->banner_image))
                return "<td><img src='".asset('storage').'/'.$result->banner_image."' width='100px'></td>";
            else
                return "<td><img src='".asset('storage/city/no_image.jpg')."' width='100px'></td>";
        })
            ->addColumn('country_name',function ($result){
            return $result->country_name;
        })
		
		
		
            ->addColumn('action',function ($result){
			 $edit = "<td>
            <a href='".route('admin.banner.banner-edit',['id'=>$result->banner_id])."' class='btn btn-sm btn-outline-primary'>Edit</a>
            <a href='".route('admin.banner.delete',['id'=>$result->banner_id])."' onclick='return DelFun();' class='btn btn-sm btn-outline-danger'>Delete</a>
             </td>";
            if($result->banner_status == 1)
                return  '<button type="button" data-id="'.$result->banner_id.'"  class="btn btn-success btn-sm status">Active</button>'.$edit;
            else if($result->banner_status == 2)
                return  '<button type="button" data-id="'.$result->banner_id.'"  class="btn btn-warning btn-sm status">Inactive</button>'.$edit;
        })
        ->rawColumns(['action','image'])
		->addIndexColumn()
        ->make(true);
    }
	
	public function statusupdatebanner(Request $request){
        
         $id = $request->input('id');
         $status = BannerImage::find($id);
         if($status->status == 1)
          $status->status = 2;
         elseif($status->status == 2)
          $status->status = 1;
         $status->save();
    
         return response()->json(['status'=>true,'success'=>'status value change successfully','message'=>'status successfully','data'=>$status]);
    }
	
	public function add() {
            $country = Country::all();
            return view('addBannerImage',compact('country'));
        }
    public function store(Request $request) {
                
				$banner = new BannerImage;
				
                $rules=[
                  
                    'country_name'=>'required',
                    'banner_image'=>'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=1900,min_height=700'
                 
                ];
                $message = [
                   
                    'country_name.required'=>'Country name is required.',
                    'banner_image.required'=>'Image is required.',
                    'banner_image.mime'=>'file is not image',
                    'banner_image.dimensions'=>'file size is not correct',
                ];
                $request->validate($rules,$message);

              
                $directory = 'country';
                $banner_image = $request->banner_image;
                $image_name = $request->user()->id.time().rand(1,999999999).'.'.$banner_image->extension(); 
                $banner_image->storeAs('public/'.$directory, $image_name); 
               
                $country_id = $request->country_name;
                if($banner_image = $request->file('banner_image'))
                {
                    $banner_image = $directory.'/'.$image_name;
                    
                }
                else
                {
                    unset($request->banner_image);
                }

         
                
                
				$banner->country_id = $country_id;
				$banner->image = $banner_image;
                $banner->status = 1;
								
				$banner->save();
				//$data=array('country_id'=>$country_id,"image"=>$banner_image);
                //DB::table('banner_images')->insert($data);
               
                // $request->city_image->move(public_path('city'), $city_image);
                return redirect()->Route('admin.banner.banner')->with('success','Banner addded successfully');
            }
  
    public function edit($id) {
        
		$country=BannerImage::find($id);
		$country_list = Country::all();
        return view('editbanner',compact('country','country_list'));
		
    }
    public function update(Request $request, $id) {
        $rules=[
		    'country_id'=>'required',
            'image'=>'image|mimes:jpeg,png,jpg,gif,svg|dimensions:min_width=1900,min_height=700'
        ];
        $message = [
		     'country_id.required'=>'Country name is required.',
             'image.mime'=>'file is not image',
             'image.dimensions'=>'file size is not correct',
        ];
        $request->validate($rules,$message);
		
       //$country=DB::table('banner_images')->where('id',$id)->first();
	   $country=BannerImage::find($id);
	   
	     
		if (isset($request->image) && $request->image != '') 
		{ 
            $bannerImage = public_path("storage/{$country->image}"); 
      
            $directory = 'country';
            $banner_image = $request->image;
            $image_name = $id.time().rand(1,999999999).'.'.$banner_image->extension(); 
            $patt = $banner_image->storeAs('public/'.$directory, $image_name);
            //print_r($patt); die;
			if($banner_image = $request->file('image'))
			{
				$banner_image = $directory.'/'.$image_name;
			}
			else
			{
				unset($request->banner_image);
			}
			
		    $country->image = $banner_image;
		 }
		

         //$data=array('country_id'=>$id,"image"=>$banner_image);
         //DB::table('banner_images')->update($data);
		 $country->country_id = $request->country_id;
		 $country->save();

        return redirect()->Route('admin.banner.banner')->with('success','Banner edited successfully');
    }
  
    public function delete($id) {
		$delete=BannerImage::find($id);
        $delete->status = 0;
        $delete->save();
       
	 return redirect()->Route('admin.banner.banner')->with('success','Banner deleted successfully');
		
    }



}
