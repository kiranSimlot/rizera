<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CommonSetting;
use DataTables;

class CommonSettingController extends Controller
{
    public function index()
    {
	    $id = 1;
        $common_setting = CommonSetting::find($id);
        return view('editcommon_setting',compact('common_setting'));
    }

    public function update(Request $request, $id)
    {
        $rules=[
            'address'=>'required',
            'helpline'=>'required',
            'timing'=>'required|max:75'
        ];
        $message = [
            'address.required'=>'Address is required.',
            'helpline.required'=>'Helpline is required.',
            'timing.required'=>'Timimg is required.'
        ];
        $request->validate($rules,$message);
        $common_setting=CommonSetting::find($id);
        $common_setting->address = $request->address;
        $common_setting->helpline = $request->helpline;
        $common_setting->timing = $request->timing;
        $common_setting->save();
        return redirect()->Route('admin.common_setting.common_setting');
    }
}
