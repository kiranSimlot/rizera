<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class owner
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // if( Auth::user()->type != 3 ){
        //     return redirect('noaccess');
        // }
        // if( Auth::user()->type != 2 || Auth::user()->type != 3 ){
        //     return redirect('noaccess');
        // } 

        if( Auth::user()->type == 1){
            return redirect('noaccess');
        } 
        elseif( Auth::user()->type == 4){
            return redirect('noaccess');
        } 

        return $next($request);
    }
}
