<?php

return [
    'Welcome_to_Rizera'=>'Welcome to Rizera',
    'Please_login_to_your_account'=>'Please login to your account',
];