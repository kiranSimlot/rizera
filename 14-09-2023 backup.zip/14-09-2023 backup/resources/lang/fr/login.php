<?php

return [
    'Welcome_to_Rizera'=>'Welcome to Rizera',
];