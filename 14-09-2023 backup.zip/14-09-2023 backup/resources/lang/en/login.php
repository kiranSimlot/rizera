<?php

return [
    'Welcome_to_Rizera'=>'Welcome to Rizera',
    'Please_login_to_your_account'=>'Please login to your account',
    'Forgot_Password' => 'Forgot Password?',
    'No_account' => 'Don’t have an account?',
    'create_account' =>'Create an Account'
];