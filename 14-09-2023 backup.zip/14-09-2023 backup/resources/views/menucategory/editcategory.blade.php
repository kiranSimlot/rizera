@extends('layouts.default')
@section('content')
<div class="container-fluid">
	<div class="fix-width">
		@include('layouts.floor_management_left_menu')

		<main class="main-box w-100 border-main-box report-chart" role="main">

			<div class="add-restaurant-form">

				<div class="d-inline">
					<h2>Edit Category List</h2>
				</div>

				<form method="post" action="{{url('/restaurant-owner/updatecategory',$category->id)}}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left row g-lg-5 g-4" enctype="multipart/form-data">
					@csrf
					<div class="card w-100">
						<div class="card-body">
							
							<div class="form-group">
								<label class="col-form-label label-align" for="question">Name<span class="required spanColor">*</span></label>
								<input class="form-control" type="text" name="name" value="{{old('name',$category->name)}}">
								@error('name')
								<div class="error-box" style="color: red">{{$message}}</div>
									@enderror
							</div>

							<div class="form-group mt-4 mb-0">
								<button class="btn btn-black w-100 py-3" type="submit">Submit</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</main>
	</div>
</div>

<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Crop Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">�</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="img-container">
                        <div class="row">
                            <div class="col-md-8">
                                <img id="image" src="https://avatars0.githubusercontent.com/u/3456749">
                            </div>
                            <div class="col-md-4">
                                <div class="preview"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="crop">Crop</button>
                </div>
            </div>
        </div>
    </div>


@endsection
