@extends('layouts.default')
@section('content')
<style type="text/css">
    .openinghours {
        font-family: Lucida Console;
        border-radius: 4px;
        margin: 10px;
        box-shadow: 0 0 10px black;
        padding: 0 10px 0 10px;
        overflow: hidden;
        display: inline-block;
    }
    .openinghourscontent {
        float: left;
    }
    .openinghourscontent h2 {
        display: block;
        text-align: center;
        margin-top: .33em;
    }
    .openinghourscontent button {
        color: white;
        font-family: Courier New;
        font-size: large;
        font-weight: bolder;
        background-color: #4679BD;
        border-radius: 4px;
        width: 100%;
        margin-bottom: 10px;
    }
    .today {
        color: #8AC007;
    }
    .opening-hours-table tr td:first-child {
        font-weight: bold;
    }
    #open-status {
        display: block;
        margin-top: -1em;
        text-align: center;
        border: dotted lightgrey 3px;
    }
    .openorclosed:after {
        content: " open during these hours:";
    }
    .open {
        color: green;
    }
    .open:after {
        content: " Open";
        color: #6C0;
    }
    .closed:after {
        content: " Closed";
        color: red;
    }
    .opening-hours-table tr td {
        padding: 5px;
    }
    .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }
    /* Style the buttons inside the tab */
    .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
    }
    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #ddd;
    }
    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #ccc;
    }
    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }
</style>
<div class="container-fluid">
    <div class="fix-width">
        @include('layouts.floor_management_left_menu')
        <main class="main-box w-100 border-main-box report-chart" role="main">
            <div class="dis-header">
                <div class="row align-items-center">
                    <div class=" col-md-6 text-left">
                        <b style="font-size: 20px;">All Order View List</b>
                    </div>
                </div>
            </div>
            <div class="container-main">
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            @if(session()->has('success'))
                            <div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                                <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                                <strong>Success!</strong> {{ \Session::get('success') }}.
                            </div>
                            @endif
                            <input type="hidden" id="order_id" name="order_id" value="{{$order_id}}">
                            <div class="card-box faqlisttable table-responsive">
                                <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th data-searchable="false" width="20%">Sr No.</th>
                                            <th width="30%">Item</th>
                                            <th width="30%">Quantity</th>
                                            <th width="30%">Quantity In Variation</th>
                                            <th width="30%">Amount</th>
                                            <th width="30%">Notes</th>
                                            <th width="30%">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        data();
        function data() {
            $('#datatable').DataTable().clear().destroy();
            var order_id = $('#order_id').val();
            var mytable = $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    url: '{{ route("owner.order.order_view_data", ["order_id" => $order_id]) }}',
                    data: {
                        "_token": "{{ csrf_token() }}"
                    }
                },
                "bAutoWidth": false,
                "columns": [
                    {"data": 'DT_RowIndex', orderable: false, searchable: false, sWidth: '30px'},
                    {data: 'item_name', name: 'item_name'},
                    {data: 'quantity', name: 'quantity'},
                    {data: 'quantity_in_variation', name: 'quantity_in_variation'},
                    {data: 'amount', name: 'amount'},
                    {data: 'notes', name: 'notes'},
                    {data: 'status', name: 'status'},
                ],
                success: function(data) {
                    mytable.ajax.reload();
                }
            });
        }
    });
</script>
@endsection
