@extends('layouts.default')   
@section('content')


<link rel="stylesheet" href="{{asset('admin/css/custom_for_datatable.min.css')}}" >
<!--this is testing-->
<div class="container-fluid">
         <div class="fix-width">
            @include('layouts.floor_management_left_menu')
            <!-- main -->
            <main role="main" class="main-box w-100 border-main-box p-0">
               <!-- main header -->
               <div class="filter_header">
                  <div class="row align-items-center">

                     <div class="col-xl-4 col-lg-5 col-md-6">
                        <div class="side-search">
                        <form class="form-inline">
                           <span class="icon">
                              <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M12.5847 11.8409L9.4907 8.623C10.2862 7.67732 10.7221 6.48745 10.7221 5.24874C10.7221 2.35463 8.36747 0 5.47335 0C2.57924 0 0.224609 2.35463 0.224609 5.24874C0.224609 8.14286 2.57924 10.4975 5.47335 10.4975C6.55984 10.4975 7.59522 10.1698 8.48043 9.5477L11.598 12.7901C11.7283 12.9254 11.9035 13 12.0913 13C12.2691 13 12.4378 12.9322 12.5658 12.809C12.8378 12.5472 12.8465 12.1132 12.5847 11.8409ZM5.47335 1.36924C7.61256 1.36924 9.35286 3.10954 9.35286 5.24874C9.35286 7.38795 7.61256 9.12825 5.47335 9.12825C3.33415 9.12825 1.59385 7.38795 1.59385 5.24874C1.59385 3.10954 3.33415 1.36924 5.47335 1.36924Z" fill="#838383"></path>
                              </svg>
                           </span>
                           
<input class="form-control mr-sm-2" type="text" name="search_keyword" onkeyup="filter();" id="search_keyword" placeholder="Search" aria-label="Search">
						   
                           <a class="btn report_filter_btn" type="submit">
                              <svg width="17" height="19" viewBox="0 0 17 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M14.0056 3.77756C14.1099 3.48227 14.1667 3.16452 14.1667 2.83351C14.1667 2.50221 14.1098 2.18418 14.0053 1.88867H17V3.77756H14.0056ZM8.66108 3.77756H0V1.88867H8.66136C8.55686 2.18418 8.5 2.50221 8.5 2.83351C8.5 3.16452 8.55676 3.48227 8.66108 3.77756Z" fill="#484848"/>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M12.2786 3.77778C12.8002 3.77778 13.2231 3.35494 13.2231 2.83333C13.2231 2.31173 12.8002 1.88889 12.2786 1.88889C11.757 1.88889 11.3342 2.31173 11.3342 2.83333C11.3342 3.35494 11.757 3.77778 12.2786 3.77778ZM12.2786 5.66667C13.8435 5.66667 15.112 4.39814 15.112 2.83333C15.112 1.26853 13.8435 0 12.2786 0C10.7138 0 9.44531 1.26853 9.44531 2.83333C9.44531 4.39814 10.7138 5.66667 12.2786 5.66667Z" fill="#484848"/>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M8.33905 10.3889C8.44343 10.0935 8.50022 9.77569 8.50022 9.44458C8.50022 9.11338 8.44339 8.79544 8.33895 8.5H17V10.3889H8.33905ZM2.99473 10.3889H0V8.5H2.99483C2.89038 8.79544 2.83355 9.11338 2.83355 9.44458C2.83355 9.77569 2.89035 10.0935 2.99473 10.3889Z" fill="#484848"/>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M4.72201 10.3891C5.24361 10.3891 5.66645 9.96626 5.66645 9.44466C5.66645 8.92306 5.24361 8.50022 4.72201 8.50022C4.2004 8.50022 3.77756 8.92306 3.77756 9.44466C3.77756 9.96626 4.2004 10.3891 4.72201 10.3891ZM4.72201 12.278C6.28681 12.278 7.55534 11.0095 7.55534 9.44466C7.55534 7.87985 6.28681 6.61133 4.72201 6.61133C3.1572 6.61133 1.88867 7.87985 1.88867 9.44466C1.88867 11.0095 3.1572 12.278 4.72201 12.278Z" fill="#484848"/>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M14.0055 17.0002C14.1099 16.7049 14.1667 16.3871 14.1667 16.056C14.1667 15.7248 14.1098 15.4068 14.0054 15.1113H17V17.0002H14.0055ZM8.66115 17.0002H0V15.1113H8.6613C8.55684 15.4068 8.5 15.7248 8.5 16.056C8.5 16.3871 8.55678 16.7049 8.66115 17.0002Z" fill="#484848"/>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M12.2786 17.0004C12.8002 17.0004 13.2231 16.5776 13.2231 16.056C13.2231 15.5344 12.8002 15.1115 12.2786 15.1115C11.757 15.1115 11.3342 15.5344 11.3342 16.056C11.3342 16.5776 11.757 17.0004 12.2786 17.0004ZM12.2786 18.8893C13.8435 18.8893 15.112 17.6208 15.112 16.056C15.112 14.4912 13.8435 13.2227 12.2786 13.2227C10.7138 13.2227 9.44531 14.4912 9.44531 16.056C9.44531 17.6208 10.7138 18.8893 12.2786 18.8893Z" fill="#484848"/>
                              </svg>

                           </a>
                        </form>
                        </div>
                     </div>

                     <div class="col-xl-8 col-lg-7 col-md-6 text-right pr-4">
                        <a class="btn graph-report" href="{{ url('restaurant-owner/staff/ownerPanelReport') }}"> <svg width="15" height="16" class="graph-class" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.02109 8.04577C1.01446 8.04577 1.0081 8.0484 1.00342 8.05309C0.998728 8.05778 0.996094 8.06414 0.996094 8.07077V15.3999V15.4208H4.91693C4.92356 15.4208 4.92992 15.4181 4.9346 15.4134C4.93929 15.4088 4.94193 15.4024 4.94193 15.3958V8.07077C4.94193 8.06414 4.93929 8.05778 4.9346 8.05309C4.92992 8.0484 4.92356 8.04577 4.91693 8.04577H1.02109ZM6.08776 0.579102C6.08187 0.580096 6.07654 0.583162 6.07272 0.587748C6.0689 0.592333 6.06684 0.598134 6.06693 0.604102V15.3999V15.4208H9.98776C9.99439 15.4208 10.0007 15.4181 10.0054 15.4134C10.0101 15.4088 10.0128 15.4024 10.0128 15.3958V0.604102C10.0128 0.597471 10.0101 0.591112 10.0054 0.586424C10.0007 0.581735 9.99439 0.579102 9.98776 0.579102H6.08776ZM14.9794 3.62077H11.0669C11.0603 3.62077 11.0539 3.6234 11.0492 3.62809C11.0446 3.63278 11.0419 3.63914 11.0419 3.64577V15.3999V15.4208H14.9628C14.9694 15.4208 14.9757 15.4181 14.9804 15.4134C14.9851 15.4088 14.9878 15.4024 14.9878 15.3958V3.64577C14.9888 3.64124 14.9886 3.6365 14.9872 3.63208C14.9857 3.62766 14.983 3.62375 14.9794 3.62077Z" fill="#939393"/>
                        </svg>Report Graphs</a>
                            <a class="btn advanced-report" onclick="download_records();"> <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" style=" vertical-align: inherit;">
                            <path d="M15.8327 7.5H12.4993V2.5H7.49935V7.5H4.16602L9.99935 13.3333L15.8327 7.5ZM4.16602 15V16.6667H15.8327V15H4.16602Z" fill="#37B63E"/>
                            </svg>Download Report</a>
                     </div>

                     <div class="filter-sidebar hide_filter">



                  <div class="report_filter" id="report_filter">
                    <div class="card">
                        <div class="card-header" id="faqhead1">
                            <a href="#" class="btn btn-header-link" data-toggle="collapse" data-target="#faq1"aria-expanded="true" aria-controls="faq1">Dates</a>
                        </div>

                        <div id="faq1" class="collapse show" aria-labelledby="faqhead1">
                            <div class="card-body">
                                
                                <div class="form-row">
                                  <div class="col">
                                    <label>Date From</label>
                                    <input type="date" id="from_date" name="from_date"/>
                                  </div>
                                  <div class="col">
                                    <label>Date To</label>
                                    <input type="date" id="to_date" name="to_date"/>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="faqhead2">
                            <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq2"
                            aria-expanded="true" aria-controls="faq2">Tags</a>
                        </div>

                        <div id="faq2" class="collapse" aria-labelledby="faqhead2">
                            <div class="card-body">
                                <div class=" btn-group-toggle sub_category_list" data-toggle="buttons">
                                  
								  @foreach  ($tags as $key => $value)
								  <label class="btn checkbox_btn">
                              <input type="checkbox" name="tag_id" value="{{$key}}" autocomplete="off"> {{$value}}
                                  </label>
                                  @endforeach
                                  
                                 </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="faqhead3">
                            <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq3"
                            aria-expanded="true" aria-controls="faq3">Booking Status</a>
                        </div>

                        <div id="faq3" class="collapse" aria-labelledby="faqhead3">
                            <div class="card-body">
                                 <div class=" btn-group-toggle sub_category_list" data-toggle="buttons">
                                  <label class="btn checkbox_btn active">
                                      <input type="checkbox" name="status" value="1" autocomplete="off"> Confirmed
                                  </label>
                                  <label class="btn checkbox_btn">
                                      <input type="checkbox" name="status" value="4" autocomplete="off"> Visited
                                  </label>
                                  <label class="btn checkbox_btn">
                                      <input type="checkbox" name="status" value="2" autocomplete="off"> Cancelled
                                  </label>
                                  <label class="btn checkbox_btn">
                                      <input type="checkbox" name="status" value="3" autocomplete="off"> Waiting
                                  </label>
                                 
                                 </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header" id="faqhead4">
                            <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq4"
                            aria-expanded="true" aria-controls="faq4">Categories</a>
                        </div>

                        <div id="faq4" class="collapse" aria-labelledby="faqhead4">
                            <div class="card-body">
                                 <div class=" btn-group-toggle sub_category_list" data-toggle="buttons">
                                  
								  @foreach  ($categories as $key => $value)
								  <label class="btn checkbox_btn">
                         <input type="checkbox" name="category_id" value="{{$key}}" autocomplete="off"> {{$value}}
                                  </label>
                                  @endforeach
								  
                                 </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header" id="faqhead5">
                            <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq5"
                            aria-expanded="true" aria-controls="faq5">Guest Name</a>
                        </div>

                        <div id="faq5" class="collapse" aria-labelledby="faqhead5">
                            <div class="card-body">
                                 <input type="text" name="guest_name" id="guest_name" class="form-control" placeholder="Enter name...">
                            </div>
                        </div>
                    </div>

                    
                </div>

                       <div class="filter_bottom_button">
                       <button class="btn  btn-black w-100" type="button" id="search">Show Results</button>
                    </div>
                     </div>

                  </div>
               </div>
               <!-- end  main header -->
               <!-- container-main -->
               <div class="container-main p-0">

<div class="table-responsive report_table">
  <table id="datatable" class="table datatable">
    <thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
      <th scope="col">Name</th>
      <th scope="col">Phone</th>
      <th scope="col">Category</th>
      <th scope="col">Tag</th>
      <th scope="col">Capicity</th>
      <th scope="col">Table</th>
      <th scope="col">Booking Type</th>
      <th scope="col">Status</th>
      <th scope="col">Billing</th>
    </tr>
  </thead>
  <tbody>
    
  </tbody>
  </table>
</div>

               </div>
               <!-- end container-main -->
            </main>
            <!-- end main -->

         </div>
      </div>



<!--<script src="js/jquery.min.js" ></script>
<script src="assets/bootstrap/js/bootstrap.bundle.min.js" ></script>
<script type="text/javascript" src="assets/slick/slick.min.js"></script>-->
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
<!--<script type="text/javascript" src="js/custom.js"></script>-->	  
<script>
(function () {
  $('.report_filter_btn').on('click', function() {
    $('.bar').toggleClass('animate');
    var mobileNav = $('.filter-sidebar');
    mobileNav.toggleClass('hide_filter show_filter');
    var mobileNav = $('body');
    mobileNav.toggleClass('mobile-body');
  })
})();

 //$('#datepicker').datepicker({
 $('#from_date').datepicker({
            uiLibrary: 'bootstrap4'
        });

  //$('#datepicker1').datepicker({
  $('#to_date').datepicker({
            uiLibrary: 'bootstrap4'
        });
</script>		

<script>

	function filter()
 {
  data();
 }
$(document).ready(function() {
    
	//$("#datatable_filter").hide();
    //$("#datatable_length").hide();
 
    data();
	
    /*$("#search_keyword").onkeyup(function() {
      data();
    });*/
	
    $("#search").click(function() {
      data();
    });

    
		
});

function data (){
      $('#datatable').DataTable().clear().destroy();
      
	   var daily = '';
	   var week = '';
	   var month = '';
	   
	   //var from_date = $('#datepicker').val();
	   //var to_date = $('#datepicker1').val();
	   var from_date = $('#from_date').val();
	   var to_date = $('#to_date').val();
	   
	   var search_keyword = $('#search_keyword').val();
	   
	   var guest_name = $('#guest_name').val();
	   
	  /*var date_type = $('#date_type :selected').val();
	  
	  if(date_type == 'today')
	  {
	   var daily = 'today';
	  } 
	  
	  if(date_type == 'week')
	  {
	   var week = $('#week').val();
	  } 
	  
	  if(date_type == 'month')
	  {
	   var month = $('#month').val();
	  } 
	  
	  if(date_type == 'date')
	  {
	   var from_date = $('#from_date').val();
	   var to_date = $('#to_date').val();
	  }*/ 
	  
      
	  var status = ''; //$('#status').val();
      var tag_id = ''; //$('#tag_id').val();
      var category_id = ''; //$('#category_id').val();
	  
$('input:checkbox[name=status]').each(function() {    
if($(this).is(':checked'))
{
 status += $(this).val()+",";
}
});

$('input:checkbox[name=tag_id]').each(function() {    
if($(this).is(':checked'))
{
 tag_id += $(this).val()+",";
}
});

$('input:checkbox[name=category_id]').each(function() {    
if($(this).is(':checked'))
{
 category_id += $(this).val()+",";
}
});

	  
      $('#datatable').DataTable({
	       "dom": 'Blfrtip',
           "buttons": ['csv','excel','print','pdf'],
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('owner.restaurant.ownerBookingListfn') !!}',
             data : {"_token": "{{ csrf_token() }}",daily:daily,month:month,week:week,status:status,tag_id:tag_id,category_id:category_id,from_date:from_date,to_date:to_date,search_keyword:search_keyword,guest_name:guest_name}
           },
           "columns": [
              {data:'date', name:'date'},
              {data:'time', name:'time'},
              {data:'name', name:'name'},
              {data:'phone', name:'phone'},
              {data:'category', name:'category'},
              {data:'tag', name:'tag'},
              {data:'capacity', name:'capacity'},
              {data:'table', name:'table'},
			  {data:'booking_type', name:'booking_type'},
			  {data:'status', name:'status'},
			  {data:'billing', name:'billing'},
           ]
       });
    }

function download_records()
 {
  $(".buttons-csv").click();
 }

 
</script>


<style>

.dt-buttons { display:none; }

#datatable_filter { display:none; }
#datatable_length { display:none; }

.filter-sidebar { z-index:1; }

</style>
<style type="text/css">
.subscription-list .dt-buttons.btn-group {
    float: left;
}
.subscription-list div#datatable_length {
    float: right;
}
.subscription-list div#datatable_filter {
    float: right;
    margin-right: 20px;
}
.subscription-list a.btn.btn-default {
    font-size: 12px;
    font-weight: 500;
    border: 1px solid #dee2e6;
    background: rgba(0,0,0,.05);
}
</style>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>


@endsection