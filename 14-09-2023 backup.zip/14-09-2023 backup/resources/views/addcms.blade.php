@extends('layouts.admin')    
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>s
<div class="row">
	<div class="col-md-12 col-sm-12 ">
		<a href="{{Route('admin.cms.cms')}}" class="btn btn-primary">Back</a>
		<div class="x_panel">
			<div class="x_title">
				<h2> Add New CMS Page</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
			<br />
			<form method="post" action="{{ route('admin.cms.storecms') }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
				@csrf
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Name <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="name" value="{{old('name')}}" name="name" class="form-control ">
					    @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="heading">Heading <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="heading" value="{{old('heading')}}" name="heading" class="form-control ">
					    @error('heading')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>

				
				
				<div class="item form-group">
                	<label class="col-form-label col-md-3 col-sm-3 label-align" for="content">Content<span class="required spanColor">*</span></label>
                	<div class="col-md-9 col-sm-9 ">
                    <textarea class="resizable_textarea form-control" name="content" id="message">{{old('content')}}</textarea>
                        @error('content')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                	</div>
            	</div>	
				<div class="ln_solid"></div>
				<div class="item form-group">
					<div class="col-md-6 col-sm-6 offset-md-3">
						<button type="submit" class="btn btn-success" value="submit">Submit</button>
					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
</div>
<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script>
CKEDITOR.replace('message');
</script>
@endsection