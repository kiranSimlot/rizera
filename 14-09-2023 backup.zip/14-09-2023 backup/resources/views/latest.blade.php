@extends('layouts.admin')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b> Latest </b>
        </div>
    </div>
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem; border-radius:5px;">

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                    	<th scope="col">Name</th>
                    	<th scope="col">Email</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($latest as $key =>$new)
                    <tr>
                    	
                        <th scope="row">{{++$key}}</th>
                        <td>{{$new->name}}</td>
                        <td>{{$new->email}}</td>
                       
                    </tr>
                    @endforeach 
                </tbody>
            </table>
            <div class="d-felx justify-content-center">
                {{-- {{$latest->links()}} --}}
            </div>
    	</div>
    </div>


@endsection