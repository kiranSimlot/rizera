@extends('layouts.admin')    
@section('content')

  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
  
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>

        <div class="col" role="main">
          <div class="">
            <div class="row">
              <div class="col-md-12 col-sm-12 ">

               <!--  <div class="row">

                  <div class="input-group mb-3 datedesign">
                    <input type="text" id="month" name="month" max="{{date('Y-m')}}" min="1970-01" class="form-control monthPicker" >
                    <div class="input-group-append">
                      <button class="btn btn-outline-secondary" type="button" id="search">search</button>
                    </div>
                  </div>
                </div> -->
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Owners List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        <div class="col-sm-12">

                          @if(session()->has('success'))
<div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                           <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">×</span>
                           </button>
                           <strong>Success!</strong> {{ \Session::get('success') }}.
                        </div>
@endif

                            <div class="card-box table-responsive">
                       <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                              <thead>
                                <tr>

                                    <th data-searchable=false>S. No.</th>

                                    <th>Username</th>
                                    <th>Email</th>
                                    <th data-searchable=false>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<script type="text/javascript">

/*$('#month').datepicker({
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            dateFormat: 'yy-mm',
            onClose: function(dateText, inst) { 
                $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, ''));
            }
            });*/

$(document).ready(function() {

$(".monthPicker").datepicker({
        //dateFormat: 'MM yy',
        dateFormat: 'yy-mm',
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,

        onClose: function(dateText, inst) {
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).val($.datepicker.formatDate('yy-mm', new Date(year, month, 1)));
        }
    });

    $(".monthPicker").focus(function () {
        $(".ui-datepicker-calendar").hide();
        $("#ui-datepicker-div").position({
            my: "left top",
            at: "left bottom",
            of: $(this)
        });
    });
	
data();
    $("#search").click(function() {
      data();
    });

    function data (){
      $('#datatable').DataTable().clear().destroy();
      var month = $('#month').val();
      //var table = $('#datatable').DataTable({
      $('#datatable').DataTable({
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.ownersData') !!}',
             data : {"_token": "{{ csrf_token() }}",month:month}
           },
       'columnDefs': [
                 { "targets": 3, "className": "text-center" }
              ],
           "columns": [
          { "data": 'DT_RowIndex', orderable: false, searchable: false },
              {data:'name', name:'name'},
              {data:'email', name:'email'},
              {data:'actions', name:'actions'},
           ]
       });

    }
});
</script>
<script type="text/javascript">
  $('#datatable').on('click','.status',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.supdate") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  });
</script>
<script type="text/javascript">
  $('#datatable').on('click','.del',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    if(confirm('Are you sure to delete')){
    $.ajax({
      url:'{!! route("admin.sdelete") !!}',
      type:'post',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
        //return redirect()->Route('admin.ownerList')->with('success','Owners deleted successfully');
      }
    });
  }
  });
</script>



@endsection