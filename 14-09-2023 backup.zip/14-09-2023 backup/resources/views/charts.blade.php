@extends('layouts.admin')

    
@section('content')
 <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b> Daily Chart </b>
        </div>
  </div>
 {{--  <html> --}}
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Date', 'Daily Registration', 'Daily Subscriptions', 'Daily Bookings'],
          ['2021-06-03',  19,      15, 10],
          ['2021-06-04',  21,      17, 8],
          ['2021-06-05',  18,       18, 11],
          ['2021-06-06',  30,      20, 15]
        ]);

        var options = {
          title: 'Rezira dashboard',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  {{-- <body> --}}
    <div id="curve_chart" style="width: 900px; height: 500px"></div>
{{--   </body>
</html> --}}
@endsection