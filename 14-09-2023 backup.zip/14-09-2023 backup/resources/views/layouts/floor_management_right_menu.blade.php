<!-- end main -->
<div role="side" class="right-side">
   <!-- [Start Right Side Tab Button] -->
   <div class="top-tabing list-side-item">
      <ul class="list-unstyled nav nav-tabs" id="nav-tab" role="tablist">
         <li>
            <a id="nav-Reservations-tab" data-toggle="tab" href="#nav-Reservations" role="tab" aria-controls="nav-Reservations" aria-selected="true" class="active" >{{ __('owner.Reservations') }}<span class="bage bg-yellow booking-tab"  id="reservation-count">{{$reservation_count}}</span></a>
         </li>
         <li>
            <a id="nav-Waitlist-tab" data-toggle="tab" href="#nav-Waitlist" role="tab" aria-controls="nav-Waitlist" aria-selected="false">{{ __('owner.Waitlist') }}<span class="bage bg-red booking-tab" id="waitlist-count">{{$waitlist_count}}</span></a>
         </li>
         <li>
            <a id="nav-Upcoming-tab" data-toggle="tab" href="#nav-Upcoming" role="tab" aria-controls="nav-Upcoming" aria-selected="false" class="booking-tab">{{ __('owner.Upcoming') }}<span class="bage bg-orange booking-tab" id="upcoming-count">0</span></a>
         </li>
      </ul>
   </div>
   <!-- [End Right Side Tab Button] -->
   <!-- [Start Right Side Tab Area] -->
   <div class="tab-content" id="nav-tabContent">
      <!-- [Start Reservations Tab] -->
      <div class="tab-pane fade show active" id="nav-Reservations" role="tabpanel" aria-labelledby="nav-Reservations-tab">
        
         <!--[ Start Booking By Catagory]  -->
         <div class="side_food_list">
            @foreach($categories_list as $key => $categories)
            <div class="accordian-list item-{{@$categories->name}}">
               <div class="item" data-toggle="collapse" data-target="#{{@$categories->name}}">
                  <div class="left">
                     <div class="icon {{@$categories->name}}">
                     @switch($categories->name)
                        @case("Breakfast")                                  
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @case("Lunch") 
                              <img src="{{url('admin/imgs/Lunch-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @case("Dinner")
                              <img src="{{url('admin/imgs/Dinner-icon.png')}}" alt="" width="22px">                                    
                        @break
                        @case("New_category")                                   
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                    
                        @break
                        @case("Brunch")                                   
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @default                                    
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                                                    
                     @endswitch
                        </div>                                     
                     
                     <div class="name">
                        <h3>{{@$categories->name}}</h3>
                        <p><span class="category-booking-count" id='category-{{@$categories->id}}'>{{count($categories->booking)}}</span> Booking</p>
                     </div>
                  </div>
                  <div class="right">                         
                     <div class="arrow-icon">
                        <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path class="fill-{{@$categories->name}}" d="M4.99998 6C4.82076 6 4.64156 5.92797 4.50493 5.78422L0.205142 1.25832C-0.0683806 0.970413 -0.0683806 0.503627 0.205142 0.21584C0.478554 -0.0719468 0.921935 -0.0719468 1.19548 0.21584L4.99998 4.22061L8.80451 0.21598C9.07803 -0.0718069 9.52137 -0.0718069 9.79476 0.21598C10.0684 0.503767 10.0684 0.970553 9.79476 1.25846L5.49504 5.78436C5.35834 5.92814 5.17914 6 4.99998 6Z" fill="#57A78A"/>
                        </svg>
                     </div>
                  </div>
               </div>
               <div id="{{@$categories->name}}" class="collapse">
                  <div id="category-list-{{++$key}}" class="lists child-category-booking-ul"  data-category-id="{{$categories->id}}" data-capacity="0">
                        <!-- {{@$categories}}  -->
                     <div class="order-list-item dawnlist-toggle" style="display: block;">
                        @foreach($categories->booking as $key => $booking)
                        <div id='booking-{{$booking->id}}' class='booking-li'>
                           <div id='div-booking-{{$booking->id}}'  ondragstart="dragStart(event)" draggable="true" onmousedown="get_pos(event)" data-booking-id="{{$booking->id}}">
                              <!-- ///////////////////////////////////////// -->
                              <div class="item">
                                 <div class="left">
                                    <div class="icon-item-row">
                                       <div class="icon-row">
                                          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M13.204 9.15761C12.0038 8.40036 10.6296 7.98488 9.20947 7.90717C9.53781 8.06086 9.8628 8.22317 10.171 8.41763C10.9135 8.88546 11.375 9.7327 11.375 10.6282V13.125H14V10.6282C14 10.0309 13.6949 9.46737 13.204 9.15761Z" fill="white"></path>
                                             <path d="M9.70406 9.15759C7.04402 7.47937 3.45557 7.47937 0.796379 9.15759C0.305061 9.46691 0 10.0305 0 10.6282V13.125H10.5V10.6282C10.5 10.0305 10.1949 9.46691 9.70406 9.15759Z" fill="white"></path>
                                             <path d="M7.87 6.85507C8.15284 6.94069 8.44473 7.00002 8.75007 7.00002C10.4385 7.00002 11.8126 5.626 11.8126 3.93752C11.8126 2.24904 10.4385 0.874985 8.75007 0.874985C8.44473 0.874985 8.15284 0.934319 7.87 1.01994C8.67251 1.74123 9.18756 2.77593 9.18756 3.93749C9.18756 5.09905 8.67254 6.13374 7.87 6.85507Z" fill="white"></path>
                                             <path d="M7.41553 1.77197C8.61152 2.96796 8.61152 4.907 7.41553 6.103C6.21953 7.29899 4.28049 7.29899 3.0845 6.103C1.8885 4.907 1.8885 2.96796 3.0845 1.77197C4.28049 0.575976 6.21953 0.576003 7.41553 1.77197Z" fill="white"></path>
                                          </svg>
                                       </div>
                                       <h4 id="no_of_person_{{$booking->id}}"> {{@$booking->no_of_person}}</h4>
                                    </div>
                                    <div class="name">
                                       <div class="nav-d-inline">                       
                                          <span  class="booking-box btn btn-booking" data-floor-id="{{$booking->floor_id}}" data-booking-id="{{$booking->id}}"> {{ __('owner.Booking') }}</span>
                                          <h4>{{@$booking->getUser->name}}</h4>
                                       </div>                    
                                       <div class="nav-d-inline">
                                          <h3 id="b_time_{{$booking->id}}">{{ Carbon\Carbon::parse($booking->for_time)->format('g:i A' ) }}</h3>
                                          @if($booking->status==1)
                                             <span class="text-Confirmed" id="booking-status-{{$booking->id}}">{{ __('owner.Confirmed') }}</span>
                                             
                                          @else
                                             <span class="text-pending" id="booking-status-{{$booking->id}}">{{ __('owner.Pending') }}</span>
                                          @endif                                            
                                       </div>
                                       <p><span id="floor_name_{{$booking->id}}">{{ $flooe_name= App\Models\RestaurantFloor::where(['id' => $booking->floor_id])->pluck('name')->first(); }}</span>  | Table no. <span id="table_no__{{$booking->id}}">{{@$booking->table_no}}</span><!-- |Table id. <div id="table_id">{{@$booking->table_id}}</div> --></p>
                                    </div>
                                 </div>                              
                              </div>
                              <!-- /////////////////////////////////////// -->
                           </div>  
                        </div>                           
                        @endforeach                   
                     </div>
                      <!-- {{@$categories}}  -->
                  </div>
               </div>   
               </div>            
            @endforeach
         </div>
         <!-- [ End Booking By Catagory] -->   
         @php
         $bookingId = 0;
         if(isset($booking->id)){
            $bookingId = $booking->id;
         }
         @endphp               

                         
               
         <!-- [Start Uncategory order list] -->
         <div  id="booking-list" class="order-list-item" data-category-id="0">
            <div id='div-booking-$bookingId'  ondragstart="dragStart(event)" draggable="true" onmousedown="get_pos(event)" data-booking-id="$bookingId">
               <!-- ///////// -->
               @foreach($booking_list as $key=>$booking)
                     @if($key==0)
                        <input type="hidden" id="last_booking_id" value="{{$booking->id}}">
                     @endif


                     <div  id='booking-{{$booking->id}}'  ondragstart="dragStart(event)"  onmousedown="get_pos(event)"  class='booking-li' data-booking-id="{{$booking->id}}"  draggable="true" >
                        
                        <div class="item">   
                           <div class="left">
                              <div class="icon-item-row">
                                 <div class="icon-row">
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M13.204 9.15761C12.0038 8.40036 10.6296 7.98488 9.20947 7.90717C9.53781 8.06086 9.8628 8.22317 10.171 8.41763C10.9135 8.88546 11.375 9.7327 11.375 10.6282V13.125H14V10.6282C14 10.0309 13.6949 9.46737 13.204 9.15761Z" fill="white"></path>
                                       <path d="M9.70406 9.15759C7.04402 7.47937 3.45557 7.47937 0.796379 9.15759C0.305061 9.46691 0 10.0305 0 10.6282V13.125H10.5V10.6282C10.5 10.0305 10.1949 9.46691 9.70406 9.15759Z" fill="white"></path>
                                       <path d="M7.87 6.85507C8.15284 6.94069 8.44473 7.00002 8.75007 7.00002C10.4385 7.00002 11.8126 5.626 11.8126 3.93752C11.8126 2.24904 10.4385 0.874985 8.75007 0.874985C8.44473 0.874985 8.15284 0.934319 7.87 1.01994C8.67251 1.74123 9.18756 2.77593 9.18756 3.93749C9.18756 5.09905 8.67254 6.13374 7.87 6.85507Z" fill="white"></path>
                                       <path d="M7.41553 1.77197C8.61152 2.96796 8.61152 4.907 7.41553 6.103C6.21953 7.29899 4.28049 7.29899 3.0845 6.103C1.8885 4.907 1.8885 2.96796 3.0845 1.77197C4.28049 0.575976 6.21953 0.576003 7.41553 1.77197Z" fill="white"></path>
                                    </svg>
                                 </div>
                                 <h4 id="no_of_person_{{$booking->id}}">{{@$booking->no_of_person}}</h4>
                              </div>
                              <div class="name">
                                 <div class="nav-d-inline">                       
                                    <span  class="booking-box btn btn-booking" data-floor-id="{{$booking->floor_id}}" data-booking-id="{{$booking->id}}">{{ __('owner.Booking') }}</span>
                                    <h4>{{@$booking->name}}</h4>
                                 </div>  

                                 <div class="nav-d-inline">
                                    <h3 id="b_time_{{$booking->id}}">{{ Carbon\Carbon::parse($booking->for_time)->format('g:i A' ) }}</h3>
                                    @if($booking->status==1)
                                       <span class="text-Confirmed" id="booking-status-{{$booking->id}}">{{ __('owner.Confirmed') }}</span>
                                    @else
                                       <span class="text-pending" id="booking-status-{{$booking->id}}">{{ __('owner.Pending') }}</span>
                                    @endif                                            
                                 </div>
                                 <p><span id="floor_name_{{$booking->id}}">{{ $flooe_name= App\Models\RestaurantFloor::where(['id' => $booking->floor_id])->pluck('name')->first(); }}</span>  | Table no. <span id="table_no__{{$booking->id}}">{{@$booking->table_no}}</span><!-- |Table id. <div id="table_id">{{@$booking->table_id}}</div> --></p>

                              </div>
                             
                           </div>
                            
                        </div>
                     </div>
               @endforeach   
            </div>         
         </div>

         <div style="display: none;">
            <img id="iconbreakfast" src="{{url('admin/imgs/breakfast.png')}}" alt="" width="22px">    
            <img id="icondinner" src="{{url('admin/imgs/dinner.png')}}" alt="" width="22px">    
            <img id="iconlunch" src="{{url('admin/imgs/lunch.png')}}" alt="" width="22px">   
         </div>    
         <!-- [End Uncategory order list]-->
      </div>
      <!-- [End Reservations Tab] -->
      <!-- [Start Waitlist Tab] -->
      <div class="tab-pane fade" id="nav-Waitlist" role="tabpanel" aria-labelledby="nav-Waitlist-tab">
      </div>
      <!-- [End Waitlist Tab] -->
      <!-- [Start Upcoming Tab] -->
      <div class="tab-pane fade" id="nav-Upcoming" role="tabpanel" aria-labelledby="nav-Upcoming-tab">
      </div>
      <!-- [End Upcoming Tab] -->
   </div>
   <!-- [End Right Side Tab Area] -->
</div>


<script type="text/javascript">
     $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);

    //alert(maxDate);
    $('#modal-select-for-date').attr('min', maxDate);
});

      // $(function(){
      //   var dtTime = new Date();
      //   var time = dtTime.getHours();
      //     console.log(time)
      //     //var year = 2016;

      //       $('#for-time').filter(function() {
      //           return $(this).val() < time;
      //       });
         
      //   });
</script>