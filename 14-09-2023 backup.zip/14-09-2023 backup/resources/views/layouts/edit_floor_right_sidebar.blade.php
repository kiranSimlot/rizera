<div role="side" class="right-side">
   <div class="box-edit-right">
      <input type="text" id="edit_floor_name" value="" maxlength="15" placeholder="Enter Floor Name" class="form-control" onfocus="changeFloorName()">
      <input type="hidden" id="edit_floor_id">
   </div>
   <div class="edit-form-res">
      <h3>{{ __('owner.Table Details') }}</h3>
      <!-- [Start Edit Table Form] -->
      <form>
         <div class="row">
            <div class="form-group col-md-12">
               <label>{{ __('owner.Table name') }}</label>
               <input type="text" value="" maxlength="5"  placeholder=""  id="table_no"  class="form-control">
               <input type="hidden" id="floor_no">
            </div>
         </div>
         <div class="row">
            <div class="form-group col-md-6">
               <label>{{ __('owner.Min Capacity') }}</label>
               <input type="text" value=""  placeholder="" id="min_capacity" class="form-control">
            </div>
            <div class="form-group col-md-6">
               <label>{{ __('owner.Max Capacity') }}</label>
               <input type="text" value=""  placeholder="" id="max_capacity" class="form-control">
            </div>
         </div>
         <div class="w-100">
            <a href="javascript:void(0);" class="btn btn-red w-100"  onclick="deleteDrawBox()"><i class="fa fa-trash-alt "></i><span class="pl-2">{{ __('owner.Delete') }}</span></a>
         </div>
      </form>
       <!-- [End Edit Table Form] -->
   </div>
   <div class="table_layouts">
      <h3>{{ __('owner.Table Layouts') }}</h3>
      <div class="items row">
         <div class="item col-12">
            <img  id="1-person-round-table" class="table-img" src="{{asset('admin/imgs/t-1.svg')}}" draggable="true"  onmousedown="get_pos(event)" ontouchstart="get_pos(event)" data-capacity="1" data-width="37" data-height="44" ondragstart="drag(event)" touchmove="drag(event)"  alt="" class="img-fluid " >
            
            <img  id="2-person-round-table" class="table-img"  src="{{asset('admin/imgs/t-2.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="2" data-width="45"  class="table-img" data-height="60"  ondragstart="drag(event)" alt="" class="img-fluid ">
            
            <img id="t-4-person-round-table"  class="table-img" src="{{asset('admin/imgs/tt-4.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="4" data-width="60" data-height="60"  ondragstart="drag(event)" alt="" class="img-fluid ">         
            
            <img id="4-person-round-table" class="table-img"  src="{{url('admin/imgs/t-s-4.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="4" data-width="79" data-height="60"  ondragstart="drag(event)" alt="" class="img-fluid "  alt="">          
            
            <img id="6-person-round-table" class="table-img"  src="{{asset('admin/imgs/t-6.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="6" data-width="110" data-height="61"  ondragstart="drag(event)" alt="" class="img-fluid ">        


            <img  id="1-person-round-table-t" class="table-img"  src="{{asset('admin/imgs/tt-1.svg')}}" draggable="true"  onmousedown="get_pos(event)"  data-capacity="1" data-width="80" data-height="94" style="display:none;"  ondragstart="drag(event)">

            <img  id="2-person-round-table-t" class="table-img"  src="{{asset('admin/imgs/tt-2.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="2" data-width="80" data-height="108"  style="display:none;" ondragstart="drag(event)">

            <img id="t-4-person-round-table-t" class="table-img"  src="{{asset('admin/imgs/ttt-4.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="4" data-width="138" data-height="138"  style="display:none;" ondragstart="drag(event)">

            <img id="4-person-round-table-t" class="table-img"  src="{{url('admin/imgs/tt-s-4.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="4" data-width="80" data-height="60"  style="display:none;" ondragstart="drag(event)">
            
            <img id="6-person-round-table-t" class="table-img"  src="{{asset('admin/imgs/tt-6.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="6" data-width="214" data-height="118"  style="display:none;" ondragstart="drag(event)">


            
            <!-- <img  id="8-person-round-table" src="{{asset('admin/imgs//8.svg')}}" draggable="true" onmousedown="get_pos(event)"  data-capacity="8"  data-width="186" data-height="186"   ondragstart="drag(event)" src="{{url('admin/imgs/8.svg')}}" alt="" class="img-fluid"> -->
            <!-- <img src="imgs/Table-Layouts.svg" alt="" class="img-fluid"> -->
         </div>
      </div>
   </div>
</div>
