<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <!-- Custom CSS -->
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" >
      <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/slick/slick.css') }}"/>
      <link rel="stylesheet" href="{{ asset('admin/css/owl.carousel.min.css') }}" >
      <link rel="stylesheet" href="{{ asset('admin/css/owl.theme.default.css') }}" >
      <link rel="stylesheet" href="{{ asset('front/assets/bootstrap/css/bootstrap.min.css') }}"> 
      <link rel="icon" href="{{ asset('front/imgs/favicon.jpg') }}" type="image/x-icon">
      @if(app()->getLocale() == 'ara')
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css">
        @endif


          


      <link rel="stylesheet" href="{{ asset('front/css/style.css') }}" >
      <link rel="stylesheet" href="{{ asset('front/css/responsive.css') }}" >
       @if(app()->getLocale() == 'ara')
        <link rel="stylesheet" href="{{ asset('front/css/style-rtl.css') }}" > 
        @endif
      <title>Rizera</title>
   </head>

  <body>


<!-- header -->
    @include('restaurant-layout.restaurant-main-header')
<!-- end of header -->


   @yield('content')

     <!-- download section -->
      @include('restaurant-layout.download-section')
      <!-- end of download  -->
      
      <!-- Footer -->
      @include('restaurant-layout.restaurant-footer')
      <!-- end of footer -->

 

 <script type="text/javascript">
        $(document).ready(function(){
            $('#countrySelectButton').click(function() {
                var countryId = $('input[name=country]:checked').val(); 
                //alert(countryId);
                if (!$('input[name=country]').is(':checked')) {
                   $('#errordiv').css('display','block');
                    return false;
                }
                else{
                
                $.ajax({
                    url: "{{url('defaultCountrySet')}}",
                    type: 'post',
                    data: {
                            "_token": "{{ csrf_token() }}",
                            "countryId":countryId
                        },
                    success: function(data){
                        console.log(data);
                        if(data.status == true){
                            
                            // $('#countryselect').addClass('hh');
                            // $('#countryselect').css('display','block !important');
                            window.location.reload();
                       }
                    }
                });  
                }
           
            });
        });

        <?php if( !empty(Session::get('countryId')) && Session::get('countryId') > 0 ){  ?>
           // alert('one');
           $('#countryselect').removeClass('hh');
        <?php } ?>

        </script>

     


      <script type="text/javascript">
         $(document).ready(function(){
            $('.choose-country').click(function(e){
               e.preventDefault();
               var countryId = $(this).attr('country-id');
               $.ajax({
                  url: "{{url('defaultCountrySet')}}",
                  type: 'post',
                  data: {
                     "_token": "{{ csrf_token() }}",
                     "countryId":countryId
                  },
                  success: function(data){
                     if(data.status == true){
                        window.location.reload();
                     }
                  }
               });
            });
         });
      </script>

      <script type="text/javascript">
         $(document).ready(function(){
      $('#selesct-modal').modal({backdrop: 'static', keyboard: false})  
            var countryId = '{{$countryId}}';
         if( countryId ){ 
            //console.log({{$countryId}})
        }else{
            $('#selesct-modal').modal('show');
         }
     
         });


      </script>

      <script type="text/javascript">
         $('.header-hero').owlCarousel({
          loop:true,
          margin:0,
          nav:true,
          dots:false,
          responsive:{
              0:{
                  items:1,
                  dots:true,
              },
              600:{
                  items:1
              },
              1000:{
                  items:1
              }
          }
         })
      </script>

    
       

</body>
</html>

