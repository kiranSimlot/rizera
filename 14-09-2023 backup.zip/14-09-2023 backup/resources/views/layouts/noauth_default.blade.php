<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="{{asset('admin/assets/bootstrap/css/bootstrap.min.css')}}" >
      <!-- Custom CSS -->
      
      <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
      <link rel="stylesheet" type="text/css" href="{{asset('admin/assets/slick/slick.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('admin/css/style.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('admin/css/responsive.css')}}">
        <link rel="icon" href="{{ asset('front/imgs/favicon.jpg') }}" type="image/x-icon">

   <link href="{{asset('admin_theme/vendors/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">

      <title>Rizera | Book your table online</title>
   </head>
   <body>
                @yield("content")
       <script type="text/javascript" src="{{asset('admin/js/jquery.min.js')}}" ></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.js" integrity="sha512-ia48mJh6IXv6baAI07Ib/crgsG/MD4tbSnOndWLo3GSExMhYsn1xPbni40VamCaXWk79t1dxi/JahsqOFazkew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> 
      <script type="text/javascript" src="{{asset('admin/assets/bootstrap/js/bootstrap.bundle.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/assets/slick/slick.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/js/custom.js')}}" ></script>
   </body>
</html>