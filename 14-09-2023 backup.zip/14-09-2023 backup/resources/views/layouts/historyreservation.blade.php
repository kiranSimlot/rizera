<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ config('app.name') }}</title>         
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
         <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{asset('admin/assets/bootstrap/css/bootstrap.min.css')}}" >
        <!-- Custom CSS -->      
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" >
        <link rel="stylesheet" type="text/css" href="{{asset('admin/assets/slick/slick.css')}}"/>
        <link rel="stylesheet" href="{{asset('admin/css/style.css')}}" >
        <link rel="stylesheet" href="{{asset('admin/css/dev.css')}}" >
        <link rel="stylesheet" href="{{asset('admin/css/responsive.css')}}" >
        <link rel="icon" href="{{ asset('front/imgs/favicon.jpg') }}" type="image/x-icon">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    </head>
    <style type="text/css">
        .error-box{
            padding:0.2rem;
            background-color:#f8d7da;
            color:#842029; 
            border:solid 1px #f5c2c7; 
            border-radius:3px;
            font-size:0.9rem;            
        }
    </style>

<body style="    --tw-bg-opacity: 1;
    background-color: rgba(243, 244, 246, var(--tw-bg-opacity));" >

            @if(isset(Auth::user()->type))
                @if( Auth::user()->type == 1  )
                    @include('layouts.navigation.admin')
                @elseif(Auth::user()->type == 2)
                    @include('layouts.navigation.owner')
                @else(Auth::user()->type == 3)
                    @include('layouts.navigation.staff')
                @endif
            @endif   
        <div>
        <!-- <div class="container"> -->
            @if(Session::has('success'))
            <div class="alert alert-success " role="alert" style="margin:1rem;">
                {{Session::get('success')}}
            </div>
            @elseif(Session::has('danger'))
            <div class="alert alert-danger " role="alert" style="margin:1rem;">
                {{Session::get('danger')}}
            </div>
            @endif

            @if($errors->any())
                @foreach ($errors->all() as $error)
                    <div class="alert alert-danger " role="alert" style="margin:1rem;" >{{ $error }}</div>
                @endforeach                
            @endif

            @yield("content")
        </div>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.js" integrity="sha512-ia48mJh6IXv6baAI07Ib/crgsG/MD4tbSnOndWLo3GSExMhYsn1xPbni40VamCaXWk79t1dxi/JahsqOFazkew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> 

      <script type="text/javascript" src="{{asset('admin/js/jquery.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/assets/bootstrap/js/bootstrap.bundle.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/assets/slick/slick.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/js/custom.js')}}" ></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" integrity="sha512-mSYUmp1HYZDFaVKK//63EcZq4iFWFjxSL+Z3T/aCt4IO9Cejm03q3NKKYN6pFQzY0SBOr8h+eCIAZHPXcpZaNw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdn.ckeditor.com/ckeditor5/11.0.1/classic/ckeditor.js"></script>
     
      <script>
        ClassicEditor
            .create( document.querySelector( '#description' ) )
            
            .catch( error => {
                console.error( error );
            } );
            ClassicEditor
            .create( document.querySelector( '#editor2' ) )
            
            .catch( error => {
                console.error( error );
            } );
            ClassicEditor
            .create( document.querySelector( '.editor2' ) )
            
            .catch( error => {
                console.error( error );
            } );
            $('.datepicker').datepicker({
    startDate: '-3d'
});
    </script>
        <script type="text/javascript">
            $(".alert-success").fadeTo(2000, 500).slideUp(500, function(){
                $(".alert-success").slideUp(500);
            });
            $(".alert-danger").fadeTo(2000, 500).slideUp(500, function(){
                $(".alert-danger").slideUp(500);
            });
        </script>      
    </body>
</html>
     