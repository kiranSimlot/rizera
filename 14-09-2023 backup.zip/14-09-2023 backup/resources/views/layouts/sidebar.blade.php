            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="{{ asset('admin_theme/production/images/img.jpg') }}" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome, Rizera</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                	
                  <li><a href="{{ url('admin/admin-dashboard') }}"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard </a></li>
                  <li><a href="{{ url('admin/banner') }}"><i class="fa fa-picture-o" aria-hidden="true"></i> Banner Image</a></li>
                  <li><a href="{{ url('admin/owners') }}"><i class="fa fa-home" aria-hidden="true"></i> Owners </a></li>
                  <li><a href="{{ url('admin/users') }}"><i class="fa fa-users" aria-hidden="true"></i> Users </a></li>
                  <!-- <li><a href="{{ url('admin/staffs') }}"><i class="fa fa-users" aria-hidden="true"></i> Staffs </a></li> -->
                  <li><a href="{{ url('admin/restaurant/list') }}"><i class="fa fa-cutlery" aria-hidden="true"></i> Restaurant </a></li>
                  <li><a href="{{ url('admin/category') }}"><i class="fa fa-coffee" aria-hidden="true"></i> Category </a></li>
                  <!-- <li><a href="{{ url('admin/list') }}"><i class="fa fa-coffee" aria-hidden="true"></i> Menu Category </a></li> -->
                  <li><a href="{{ url('admin/cuisine') }}"><i class="fa fa-glass" aria-hidden="true"></i> Cuisine </a></li>

                  <li><a href="{{ url('admin/allergy') }}"><i class="fa fa-spoon" aria-hidden="true"></i> Allergy </a></li>
                  
                  <li><a href="{{ url('admin/foodintolerance') }}"><i class="fa fa-cutlery" aria-hidden="true"></i> Food Intolerance </a></li>

                  <li><a href="{{ url('admin/tag') }}"><i class="fa fa-tags" aria-hidden="true"></i> Tag </a></li>
                  <li><a href="{{ url('admin/viptag') }}"><i class="fa fa-star" aria-hidden="true"></i> Vip-Tag </a></li>
                  <li><a href="{{ url('admin/template') }}"><i class="fa fa-bell" aria-hidden="true"></i> Templates </a></li>
                  <li><a href="{{ url('admin/cities') }}"><i class="fa fa-globe" aria-hidden="true"></i> City </a></li>
                  <li><a href="{{ url('admin/splash-slider') }}"><i class="fa fa-globe" aria-hidden="true"></i> App Splash Banners </a></li>
                  <li><a><i class="fa fa-table"></i> Subscriptions <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ url('admin/subscriptionReports') }}">Subscription reports</a></li>
                      <li><a href="{{ url('admin/monthlyBookingsReport') }}">Monthly bookings report</a></li>
                    </ul>
                  </li>
                  <li><a href="{{ url('admin/request-demo') }}"><i class="fa fa-plus-circle" aria-hidden="true"></i> Request Demo   
                    <span class="rcount">
                      @if( ($data=\App\Models\Demo::where('read',0)->count())>0)
                          {{$data}} 
                      @else
                          {{0}}
                      @endif 
                    </span>
                  </a></li>
          <li><a href="{{ url('admin/plan') }}"><i class="fa fa-money" aria-hidden="true"></i> Plans </a></li> 
				  <li><a href="{{ url('admin/common_setting') }}"><i class="fa fa-cog" aria-hidden="true"></i> Common Settings </a></li>
          <li><a href="{{ url('admin/support') }}"><i class="fa fa-question-circle" aria-hidden="true"></i>Support</a></li>  
                   <li><a href="{{ url('admin/cms') }}"><i class="fa fa-home" aria-hidden="true"></i> CMS </a></li> 
                </ul>
              </div>
            </div>
            <!-- /sidebar menu -->
<script type="text/javascript">
  setInterval(function() {
    window.location.reload();
}, 3000000); 
</script>