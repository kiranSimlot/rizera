<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ config('app.name') }}</title>
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
     <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous"> -->
         <!-- Required meta tags -->
<!--<script src="{{ asset('admin_theme/build/js/custom.min.js') }}"></script>-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{asset('admin/assets/bootstrap/css/bootstrap.min.css')}}" >
        <!-- Custom CSS -->
        <link href="{{ asset('admin_theme/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
        <link rel="icon" href="{{ asset('front/imgs/favicon.jpg') }}" type="image/x-icon">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" >
        <link rel="stylesheet" type="text/css" href="{{asset('admin/assets/slick/slick.css')}}"/>
        <link rel="stylesheet" href="{{asset('admin/css/style.css')}}" >
        <!-- <link rel="stylesheet" href="{{asset('admin/css/custom_for_datatable.min.css')}}" > -->
        <link rel="stylesheet" href="{{asset('admin/css/dev.css')}}" >
        <link rel="stylesheet" href="{{asset('admin/css/responsive.css')}}" >
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<link href="{{ asset('admin_theme/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin_theme/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin_theme/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin_theme/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin_theme/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css') }}" rel="stylesheet">
        <!--<script src="{{ asset('admin_theme/vendors/jquery/dist/jquery.min.js') }}"></script>-->






    </head>
    <style type="text/css">
        .error-box{
            padding:0.2rem;
            background-color:#f8d7da;
            color:#842029;
            border:solid 1px #f5c2c7;
            border-radius:3px;
            font-size:0.9rem;
        }

        .active_resto:after {

            position: absolute;
            width: 100%;
            height: 100%;
            content: "";
            top: 0px;
            left: 0px;

        }
         .active_resto nav.navbar {
            z-index: 1000 !important;
        }
        .active_resto nav#sidebarMenu {
            position: relative;
            z-index: 100;
        }
    </style>


<body>

            @if(isset(Auth::user()->type))
                @if( Auth::user()->type == 1  )
                    @include('layouts.navigation.admin')
                @elseif(Auth::user()->type == 2)
                    @include('layouts.navigation.owner')
                @else
                    @include('layouts.navigation.staff')
                @endif
            @endif

    <!--Modal: modalYT-->
<div class="modal fade" id="modalYT" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">

    <!--Content-->
    <div class="modal-content">

      <!--Body-->
      <div class="modal-body mb-0 p-0">

      <div class="priti">
           <h5>Your free trail is expired please contact to us through whats app</h5>

      </div>



      </div>

      <!--Footer-->
      <div class="modal-footer justify-content-center flex-column flex-md-row">
        <span class="mr-4">Spread the word!</span>
        <div>
          <a type="button" class="btn-floating btn-sm btn-fb">
            <i class="fab fa-facebook-f"></i>
          </a>
          <!--Twitter-->
          <a type="button" class="btn-floating btn-sm btn-tw">
            <i class="fab fa-twitter"></i>
          </a>
          <!--Google +-->
          <a type="button" class="btn-floating btn-sm btn-gplus">
            <i class="fab fa-google-plus-g"></i>
          </a>
          <!--Linkedin-->
          <a type="button" class="btn-floating btn-sm btn-ins">
            <i class="fab fa-linkedin-in"></i>
          </a>
        </div>
          <button type="button" class="btn btn-outline-primary btn-rounded btn-md ml-4"><a href="//api.whatsapp.com/send?phone=9680299418&text=hello" target="_blank">Contact Us</a></button>

        <button type="button" class="btn btn-outline-primary btn-rounded btn-md ml-4 close"
          data-bs-dismiss="modal" aria-label="Close">Close</button>


      </div>

    </div>
    <!--/.Content-->

  </div>
</div>
        <?php
        $today_date = date('Y-m-d');
        ?>
        <input type="hidden" name="today_date" id="today_date" value="<?php echo $today_date; ?>">
<style type="text/css">
   .priti{
      margin-top: 35px;
    margin-bottom: 35px;
    text-align: center;
   }
</style>
<!--Modal: modalYT-->
      <!-- Start Modal: This modal are using in canvas -->
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog booking-modal" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> {{ __('owner.Reservation Details') }}</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>

              <div class="modal-body" id="modal-body">


              </div>
              <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                <button type="button" class="btn btn-black booking-update-button" style="width: 100%;">{{ __('owner.Finish Reservation') }}</button>
              </div>
            </div>
          </div>
        </div>
        <!-- End Modal: This modal are using in canvas -->



        <!-- Start Messge Box: Ajax response show in message box in edit/update floor and booking -->
      <div id="text-message-div" style="width: 100%; height: 100%; position: fixed; opacity: .7;background-color: #000000; display:none;z-index: 99999;">
         <div style="top:25%; left:40%; position:absolute;">
             <img src="{{url('admin/imgs/loading-image.gif')}}">
             <div id="text-message" style="text-align:center; color:#ffffff;">
                {{ __('owner.Work in progress') }}
             </div>
         </div>
      </div>
        <!-- End Messge Box: Ajax response show in message box in edit/update floor and booking -->


        <div>

            @yield("content")

        </div>


         <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.js" integrity="sha512-ia48mJh6IXv6baAI07Ib/crgsG/MD4tbSnOndWLo3GSExMhYsn1xPbni40VamCaXWk79t1dxi/JahsqOFazkew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

      <script type="text/javascript" src="{{asset('admin/js/jquery.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/assets/bootstrap/js/bootstrap.bundle.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/assets/slick/slick.min.js')}}" ></script>
      <script type="text/javascript" src="{{asset('admin/js/custom.js')}}" ></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" integrity="sha512-mSYUmp1HYZDFaVKK//63EcZq4iFWFjxSL+Z3T/aCt4IO9Cejm03q3NKKYN6pFQzY0SBOr8h+eCIAZHPXcpZaNw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdn.ckeditor.com/ckeditor5/11.0.1/classic/ckeditor.js"></script>
        @if( isset($restaurant_id) && $restaurant_id > 0 && Route::current()->getName()=='owner.restaurant.floorManagement')
            <script type="text/javascript" src="{{asset('admin/js/floor_management.min.js')}}" ></script>
        @endif

      <script>
        ClassicEditor
            .create( document.querySelector( '#description' ) )

            .catch( error => {
                console.error( error );
            } );
            ClassicEditor
            .create( document.querySelector( '#editor2' ) )

            .catch( error => {
                console.error( error );
            } );
            ClassicEditor
            .create( document.querySelector( '.editor2' ) )

            .catch( error => {
                console.error( error );
            } );
            $('.datepicker').datepicker({
    startDate: '-3d'
});
    </script>


<script type="text/javascript">
$(".alert-success").fadeTo(2000, 500).slideUp(500, function(){
    $(".alert-success").slideUp(500);
});
$(".alert-danger").fadeTo(2000, 500).slideUp(500, function(){
    $(".alert-danger").slideUp(500);
});

</script>
        @if( isset($restaurant_id) && $restaurant_id > 0  && Route::current()->getName()=='owner.restaurant.floorManagement')


      <script type="text/javascript">
        // let tableViewSaveUrl = "{{ url('/restaurant-owner/restaurant/saveRestaurantFloor') }}";
        // let createNewFloorUrl = "{{ url('/restaurant-owner/restaurant/createRestaurantFloor')}}";
        // let deleteFloorUrl = "{{ url('/restaurant-owner/restaurant/deleteRestaurantFloor')}}";
        // let deleteFloorTableUrl = "{{ url('/restaurant-owner/restaurant/deleteRestaurantFloorTable')}}";
        let getFloorViewUrl = "{{ url('/restaurant-owner/restaurant/getRestaurantFloorDetail') }}/"+restaurantId+'/'+restaurantFloorId;
        let bookingDetailUrl =  "{{url('/restaurant-owner/restaurant/bookingDetail')}}";
        let updateCategoryBookingUrl =  "{{url('/restaurant-owner/restaurant/updateCategoryBooking')}}";
        let bookingUpdateUrl = "{{url('/restaurant-owner/restaurant/bookingUpdate')}}";
        let bookingListUrl = "{{ url('/restaurant-owner/restaurant/allBooking')}}";
        let confirmBookingListUrl = "{{ url('/restaurant-owner/restaurant/confirmBookingList')}}";

        let token = '{{ csrf_token() }}';
      </script>
      <script type="text/javascript" src="{{asset('admin/js/floor_ajax.js')}}" ></script>
        @endif


<!--<script src="{{ asset('admin_theme/build/js/custom.min.js') }}"></script>-->

<script src="{{ asset('admin_theme/vendors/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-buttons/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-buttons/js/buttons.flash.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-buttons/js/buttons.html5.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-buttons/js/buttons.print.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js') }}"></script>
<script src="{{ asset('admin_theme/vendors/datatables.net-scroller/js/dataTables.scroller.min.js') }}"></script>

<!-- This links added by Pankaj -->

    <script type="text/javascript">

    $(document).ready(function(){
        var today_date= $('#today_date').val();
      ///  console.log($today_date);
        @if(isset(Auth::user()->type) && Auth::user()->type == 2)
            @if(Auth::user()->demo_expired_at < $today_date && Auth::user()->subscription_status ==0)

                if ($(".main-box").length > 0)
                {
                $(".main-box").each(function()
                {
                $(this).addClass("active_resto");
                });
                }

            @endif
            $('.active_resto').on('click', function(e)
            {
            $("#modalYT").modal('show');
            });

        @endif

    });
</script>



<!-- /This links added by Pankaj -->
    </body>
</html>
