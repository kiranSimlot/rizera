
<?php
$to =   date('Y-m-d', strtotime(Auth::user()->created_at));
$datetime1 = date_create($to);
$from= date('Y-m-d', strtotime(Auth::user()->demo_expired_at));
$datetime2 = date_create($from);

$today_date = date_create(date('Y-m-d'));
$interval = date_diff($today_date, $datetime2);
$expiration_date=$interval->format('%a days');
 //print_r($datetime2);
 //print_r($today_date);
 //die();
?>

@if( Auth::user()->subscription_status == 0  )
@if( $datetime2 < $today_date)
<a href="#modalYT" data-toggle="modal" data-target="#modalYT">
<nav class="navbar navbar-yellow flex-md-nowrap">
   <h6>Your free trial is expired.
   </h6>
<a href="{{ route('restaurant-price') }}" class="btn btn-black btn-sm">Subscribe</a>
</nav>
</a>
@else
<a>
<nav class="navbar navbar-yellow flex-md-nowrap">
   <h6>You have {{$expiration_date}} remaining on your free trial. Subscribe today and let’s make this official!
   </h6>
  <a href="{{ route('restaurant-price') }}" class="btn btn-black btn-sm">Subscribe</a>
</nav>
</a>

 @endif
@endif

<nav class="navbar navbar-yellow  bg-yellow flex-md-nowrap   header-rizera">
      <div class="hamburger-menu">
          <div class="bar"></div>
      </div>
        <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="{{url('/restaurant-owner/restaurant/floorManagement')}}"><img src="{{ asset('admin/imgs/logo.png') }}" alt="" class="img-fuild" height="45px"></a>
         <div class="date-header">
            <h6 class="mb-0">{{ date('D, M d Y')}}<span class="pl-2"  id="timer">{{date('h:i:s A')}}</span></h6>
         </div>
         <ul class="nav">
            <li class="nav-item dropdown">
            @if(session('id_restaurant') == null)
            @else
             <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            @endif

               <?php
               $dd=session('id_restaurant');
               //print_r($dd); die();
               $list =App\Models\Restaurant::where(['user_id' => Auth::user()->id])->whereNotIn('status', [2])->get() ;
                 foreach($list as $rrr){
                  if($dd==$rrr->id){
                     echo ucwords($rrr->name);
                  }
                 }

              //   print_r($list); die();
                ?>




               </a>
               <div class="dropdown-menu dropdown-menu-md-right" aria-labelledby="bd-versions">
                  @foreach(App\Models\Restaurant::where(['user_id' => Auth::user()->id])->whereNotIn('status', [2])->get() as $restlist)


                      <a class="dropdown-item" href="{{ url('changerestaurant',$restlist->id) }}">{{ ucwords($restlist->name) }}</a>

                     <div class="dropdown-divider"></div>
                  @endforeach
               </div>
            </li>
            <li class="nav-item dropdown">
               <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               Opening Hours
               </a>
                @php $hh =App\Models\WeeklyHour::where(['restaurant_id' => session('id_restaurant')])->first() ;   @endphp
               <div class="dropdown-menu dropdown-menu-md-right" aria-labelledby="bd-versions">


                     @if(!empty($hh))
                     @if(isset($hh->mon_to))

                     <a class="dropdown-item" href="#">Monday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-right">{{ date('h:i a', strtotime($hh->mon_from))}} - {{ date('h:i a', strtotime($hh->mon_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Tuesday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-right">{{ date('h:i a', strtotime($hh->tue_from))}} - {{ date('h:i a', strtotime($hh->tue_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Wednesday   <span class="text-right">{{ date('h:i a', strtotime($hh->wed_from))}} - {{ date('h:i a', strtotime($hh->wed_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Thursday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-right">{{ date('h:i a', strtotime($hh->thu_from))}} - {{ date('h:i a', strtotime($hh->thu_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Friday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-right">{{ date('h:i a', strtotime($hh->fri_from))}} - {{ date('h:i a', strtotime($hh->fri_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Saturday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-right">{{ date('h:i a', strtotime($hh->sat_from))}} - {{ date('h:i a', strtotime($hh->sat_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Sunday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-right">{{ date('h:i a', strtotime($hh->sun_from))}} - {{ date('h:i a', strtotime($hh->sun_to))}}</span></a>
                     <div class="dropdown-divider"></div>
                     @endif
                     @endif

               </div>

            </li>
         </ul>


      </nav>

      <script type="text/javascript">
         $(function(){
            $(".dropdown-menu li a").click(function(){
               $(".btn:first-child").text($(this).text());
               $(".btn:first-child").val($(this).text());
            });
         });
         setInterval(function(){
            var d = new Date(); // for now
            d.getHours(); // => 9
            d.getMinutes(); // =>  30
            d.getSeconds(); // => 51
            let currentTime = '';
            currentTime += (d.getHours()-12)>0?('0'+(d.getHours()-12)):d.getHours();
            currentTime += ':'+(!(d.getMinutes()>9)?'0'+d.getMinutes():d.getMinutes());
            currentTime += ':'+(!(d.getSeconds()>9)?'0'+d.getSeconds():d.getSeconds()) ;
            currentTime += ' '+(d.getHours()>=12?'PM':'AM');
            // if(d.getSeconds()==0){
            //    countAndReserevedBooking();
            // }

            $("#timer").text(currentTime);
         },1000)

      </script>
