<!-- Modal -->
<div class="modal fade" id="Add-New-Guest" tabindex="-1" role="dialog" aria-labelledby="Add-New-GuestLabel" aria-hidden="true">
  <div class="modal-dialog booking-modal" role="document">
    <div class="modal-content ">
      <div class="modal-header">
        <h5 class="modal-title" id="Add-New-GuestLabel">{{ __('owner.Add New Guest') }}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">        
         <form method="POST" action="{{ route('owner.restaurant.addgustuser') }}" style="margin: 20px;" >
            @csrf
            <div class="row">                             
               <div class="form-group col-md-12">
                  <label>{{ __('owner.Name') }}</label>
                  <input class="form-control" type="text" id="first_name" name="first_name" required>
               </div>
          
                           <div class="form-group col-md-12">
                  <label>{{ __('owner.Email') }}</label>
                  <input class="form-control" type="email" id="email" name="email" required>
               </div>
               <div class="form-group col-md-12">
                  <label>{{ __('owner.Mobile') }}</label>
                  <input class="form-control" type="number" id="mobile" name="mobile" required> 
               </div>
                  <div class="form-group col-md-12 mb-0">
                  <button class="btn  btn-black w-100">{{ __('owner.Save_Details') }}</button>
               </div>
            </div>
         </form>
      </div>      
    </div>
  </div>
</div>






<!-- <nav class="navbar navbar-yellow  bg-yellow flex-md-nowrap   header-rizera">
   <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="{{ route('owner.restaurant.list') }}"><img src="{{ asset('admin/imgs/logo.png') }}" alt="" class="img-fuild" width="96px"></a>
   <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
   </button>
   <div class="date-header text-center w-100">
      <h6 class="mb-0">{{ __('owner.New Reservation') }}</h6>
   </div>      
</nav> -->