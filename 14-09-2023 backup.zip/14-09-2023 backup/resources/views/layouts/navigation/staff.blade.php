<nav class="navbar navbar-yellow  bg-yellow flex-md-nowrap   header-rizera">
      <div class="hamburger-menu">
          <div class="bar"></div>
      </div>
        <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="{{ route('owner.restaurant.list') }}"><img src="{{ asset('admin/imgs/logo.png') }}" alt="" class="img-fuild" width="96px"></a>
         <div class="date-header">
            <h6 class="mb-0">{{ date('D M d Y h:i:A') }}</h6>
         </div>

         <ul class="nav">
            <!-- <li class="nav-item dropdown">
               <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <?php
               $dd=session('id_restaurant');
               $list = App\Models\Restaurant::where(['id' => session('id_restaurant')])->get() ;


              foreach($list as $rrr){
               if($dd==$rrr->id){
                  echo ucwords($rrr->name);
               }
              }
                ?>




               </a>

               <div class="dropdown-menu dropdown-menu-md-right" aria-labelledby="bd-versions">
                <?php   $staff = App\Models\User::where(['id' => Auth::user()->id])->select('owner_id')->first() ; ?>

                   @foreach(App\Models\Restaurant::where(['user_id' => $staff->owner_id])->whereNotIn('status', [2])->get() as $restlist)
                     <a class="dropdown-item" href="{{ url('changerestaurant',$restlist->id) }}">{{ ucwords($restlist->name) }}</a>
                     <div class="dropdown-divider"></div>
                   @endforeach
               </div>
            </li> -->

                      <!-- <li class="nav-item dropdown">
               <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               Opening Hours
               </a>
                @php $hh =App\Models\WeeklyHour::where(['restaurant_id' => session('id_restaurant')])->first() ;   @endphp
               <div class="dropdown-menu dropdown-menu-md-right" aria-labelledby="bd-versions">


                     @if(!empty($hh))
                     @if(isset($hh->mon_to))

                     <a class="dropdown-item" href="#">Monday   <spna class="text-right">{{ date('h:i a', strtotime($hh->mon_from))}} - {{ date('h:i a', strtotime($hh->mon_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Tuesday   <spna class="text-right">{{ date('h:i a', strtotime($hh->tue_from))}} - {{ date('h:i a', strtotime($hh->tue_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Wednesday   <spna class="text-right">{{ date('h:i a', strtotime($hh->wed_from))}} - {{ date('h:i a', strtotime($hh->wed_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Thursday   <spna class="text-right">{{ date('h:i a', strtotime($hh->thu_from))}} - {{ date('h:i a', strtotime($hh->thu_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Friday   <spna class="text-right">{{ date('h:i a', strtotime($hh->fri_from))}} - {{ date('h:i a', strtotime($hh->fri_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Saturday   <spna class="text-right">{{ date('h:i a', strtotime($hh->sat_from))}} - {{ date('h:i a', strtotime($hh->sat_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="#">Sunday   <spna class="text-right">{{ date('h:i a', strtotime($hh->sun_from))}} - {{ date('h:i a', strtotime($hh->sun_to))}}</spna></a>
                     <div class="dropdown-divider"></div>
                     @endif
                     @endif

               </div>

            </li> -->
         </ul>
         <a class="nav-link" href="{{route('owner.logout')}}">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path fill-rule="evenodd" clip-rule="evenodd" d="M11.0022 3.96126C11.3772 3.58641 11.985 3.58649 12.3599 3.96144L15.719 7.32144C16.0937 7.69633 16.0937 8.30403 15.719 8.67891L12.3599 12.0389C11.985 12.4139 11.3772 12.4139 11.0022 12.0391C10.6273 11.6642 10.6272 11.0564 11.002 10.6814L13.6826 8.00018L11.002 5.31891C10.6272 4.94396 10.6273 4.33612 11.0022 3.96126Z" fill="#E3E3E3"/>
                           <path fill-rule="evenodd" clip-rule="evenodd" d="M5.12 8.00004C5.12 7.46985 5.5498 7.04004 6.07999 7.04004H15.0376C15.5678 7.04004 15.9976 7.46985 15.9976 8.00004C15.9976 8.53023 15.5678 8.96004 15.0376 8.96004H6.07999C5.5498 8.96004 5.12 8.53023 5.12 8.00004Z" fill="#E3E3E3"/>
                           <path fill-rule="evenodd" clip-rule="evenodd" d="M1.91999 1.92H6.07998C6.61017 1.92 7.03997 1.49019 7.03997 0.96C7.03997 0.429807 6.61017 0 6.07998 0H1.59999C1.17565 0 0.768684 0.168572 0.468628 0.468629C0.168571 0.768687 0 1.17565 0 1.6V14.4C0 14.8243 0.16857 15.2313 0.468628 15.5314C0.768686 15.8314 1.17565 16 1.59999 16H6.07998C6.61017 16 7.03997 15.5702 7.03997 15.04C7.03997 14.5098 6.61017 14.08 6.07998 14.08H1.91999V1.92Z" fill="#E3E3E3"/>
                        </svg>

                           {{ __('owner.Log out') }}
                        </a>

      </nav>

      <!-- <script type="text/javascript">
          $(function(){

    $(".dropdown-menu li a").click(function(){

      $(".btn:first-child").text($(this).text());
      $(".btn:first-child").val($(this).text());

   });

});
      </script> -->
