<nav class="navbar navbar-yellow  bg-yellow flex-md-nowrap   header-rizera">
         <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="{{route('admin.owners')}}"><img src="{{ asset('admin/imgs/logo.png') }}" alt="" class="img-fuild" width="96px"></a>
         <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <!-- <div class="date-header text-center w-100">
            <h6 class="mb-0">Edit Floor</h6>
         </div> -->
         <ul class="nav"> 
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">User</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="{{ url('owners') }}">Owner</a>
                        </li>
                       <!--  <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="{{ url('restaurant/list') }}">Restaurant</a>
                        </li> 
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="{{ url('cuisine_types/list') }}">Cuisine Types</a>
                        </li> -->

            <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                {{ ucfirst(Auth::user()->name) }}
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <li>
                                <!-- Authentication -->
                                <a href="{{url('logout')}}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item">
                                    {{ __('Log out') }}
                                </a>
                                <form method="POST" id="logout-form" action="{{ route('logout') }}">
                                    @csrf
                                </form>

                                </li>
                            </ul>
                        </li>
         </ul>
      </nav>


<!-- 
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">{{ config('app.name') }}</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="{{ url('staff/list') }}">Staff</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="{{ url('restaurants') }}">Restaurant</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                {{ ucfirst(Auth::user()->name) }}
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <li> 
                                <a href="{{url('account')}}" class="dropdown-item">
                                    Account
                                </a> 
                                </li>
                                <li> 
                                <a href="{{url('logout')}}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item">
                                    {{ __('Log out') }}
                                </a>
                                <form method="POST" id="logout-form" action="{{ route('logout') }}">
                                    @csrf
                                </form>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
 -->




     