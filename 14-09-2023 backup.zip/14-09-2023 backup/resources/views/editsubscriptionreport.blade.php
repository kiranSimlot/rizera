@extends('layouts.admin')

    
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
        <div class="row mt-5">
        <div class="col-md-12 col-sm-12 ">
            <a href="{{Route('admin.report.subscriptionReports')}}" class="btn btn-primary">Back</a>
            <div class="x_panel">
                <div class="x_title">
                    <h2>Edit Subscription List</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.report.update-subscription-list',$subscription_list->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                    @csrf
                 <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Owner Name <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="owner_name" id="owner_name" class="form-control " readonly value="{{$subscription_list->ownername}}">
                        @error('name')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Plan Name <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="plan_name" id="plan_name" class="form-control " readonly value="{{$subscription_list->plan_name}}">
                        @error('name')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Type <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="type" id="type" class="form-control " readonly value="{{$subscription_list->type}}">
                        @error('name')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                </div>

                 <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Active From <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="active_from" id="active_from" class="form-control " readonly value="{{date('Y-m-d', strtotime($subscription_list->active_from))}}">
                        @error('name')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                </div>

                 <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Expires At <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="expires_at" id="expires_at" class="form-control datepicker" value="{{date('Y-m-d', strtotime($subscription_list->expires_at))}}" >
                        @error('name')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                </div>

                {{-- </div> --}}
                <div class="ln_solid"></div>
                <div class="item form-group">
                    <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" class="btn btn-success" value="submit">Update</button>
                    </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>

 


@endsection
<!-- <script src ="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>  
 <script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<script type="text/javascript">
 $('#datepicker').datepicker({
   todayHighlight: true,
   format: 'dd/mm/yyyy',
   startDate: new Date()   
  });
 </script>    -->


