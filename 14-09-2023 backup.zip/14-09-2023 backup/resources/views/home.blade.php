<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>{{ __('message.Rizera') }}</title>
  </head>
<body>
{{-- nav bar --}}
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">{{ __('message.Rizera') }}</a>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
  	</ul>
    <a href="lang/fr" class="pr-2">{{ __('message.French') }}</a>
    <a href="lang/ara" class="pr-2">{{ __('message.Arabic') }}</a>
    <a href="lang/en" class="pr-2">{{ __('message.English') }}</a>
    <a href="{{ route('restaurant.home') }}" class="btn btn-outline-primary">{{ __('message.For Restaurant') }}</a>
  </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-3 "></div>
        <div class="col-md-6 ">
            <ul class="list-group list-group-horizontal">
            @foreach($cuisine as $key=>$name)
            <li class="list-group-item">
                {{$name->name}}
            </li>
            @endforeach
            </ul>
        </div>
        <div class="col-md-3 "></div>
    </div>
</div>


{{-- /nav bar --}}
<div class="container">
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <form action="{{route('home-kuwait')}}" method="post">
                    @csrf
                    <div class="input-group mb-3 col-md-6 text-center">
                        <input type="text" name="search" class="form-control" placeholder="{{ __('message.Name, Location, Cuisine') }}" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-outline-primary" type="submit" value="submit">{{ __('message.search') }}</button>
                        </div>
                    </div>
                </form>
        </div>
    </div>
{{-- /search bar --}}
</div>

<div class="container d-flex justify-content-center mt-50 mb-50">
    <div class="row">
        <div class="col-md-10">
            @foreach($restaurants as $key =>$detail)
            <div class="card card-body mt-3">
                <div class="media align-items-center align-items-lg-start text-center text-lg-left flex-column flex-lg-row">
                    <div class="mr-2 mb-3 mb-lg-0"> <img src="{{ asset('admin_theme/production/images/rest.jpg') }}" width="150" height="150" alt=""> </div>
                    <div class="media-body">
                        <h6 class="media-title font-weight-semibold"><a href="#">{{$detail->name}}</a></h6>
                        <ul class="list-inline list-inline-dotted mb-3 mb-lg-2">
                            <li class="list-inline-item"><a href="#" class="text-muted" data-abc="true">{{$detail->address}}</a></li>
                            <li class="list-inline-item"><a href="#" class="text-muted" data-abc="true">{{$detail->getCity->city_name}}</a></li>
                            <li class="list-inline-item"><a href="#" class="text-muted" data-abc="true">{{$detail->getCountry->country_name}}</a></li>
                        </ul>
                        <p class="mb-3">{{$detail->description}}</p>
                        <ul class="list-inline list-inline-dotted mb-0">
                            <li class="list-inline-item"><a href="#" data-abc="true">
                                @if($detail->home_delivery == 1)
                                    <p class="card-text">Delivery Provide</p>
                                @elseif($detail->home_delivery == 0)
                                    <p class="card-text">Delivery Not Provide</p>
                                @endif</a>
                            </li>
                            <li class="list-inline-item"><a href="#" data-abc="true">
                                @if($detail->takeout == 1)
                                    <p class="card-text">TakeOut</p>
                                @elseif($detail->takeout == 0)
                                    <p class="card-text">No TakeOut</p>
                                @endif</a>
                            </li>
                            <li class="list-inline-item"><b>Cuisine Type:</b>
                                @foreach($detail->getCuisine as $cuisine)
                                {{$cuisine->Cuisine['name']}}
                                @endforeach
                            </li>
                            
                            <li class="list-inline-item">Rating <a href="#" data-abc="true">{{$detail->rating}}</a></li>
                        </ul>
                    </div>
                    <div class="mt-3 mt-lg-0 ml-lg-3 text-center">
                        <h3 class="mb-0 font-weight-semibold">

                            {{-- open/close --}}

                        @if( isset($detail->getHour->mon_to) )
                            @if((($detail->getHour->mon_to <= date("H:i:s")) 
                                    && ($detail->getHour->mon_from >= date("H:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->getHour->tue_to <= date("H:i:s")) 
                                    && ($detail->getHour->tue_from >= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->getHour->wed_to <= date("H:i:s")) 
                                    && ($detail->getHour->wed_from >= date("H:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->getHour->thu_to <= date("H:i:s"))
                                    && ($detail->getHour->thu_from >= date("H:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->getHour->fri_to <= date("H:i:s"))
                                    && ($detail->getHour->fri_from >= date("H:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->getHour->sat_to <= date("H:i:s"))
                                    && ($detail->getHour->sat_from >= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->getHour->sun_to <= date("H:i:s"))
                                    && ($detail->getHour->sun_from >= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                )
                                <span class="badge badge-pill badge-success"> {{ __('message.open') }}  </span>
                                @else
                                <span class="badge badge-pill badge-danger"> {{ __('message.close') }} </span>
                            @endif
                        @endif

                        </h3>
                        <div> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> </div>
                        <div class="text-muted"></div><a href="{{route('restdetails',$detail['id'])}}" class="btn btn-primary mt-4 text-white">{{ __('message.visit') }}</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
<div class="container mt-5">
  <a href="{{ route('listofrest') }}" class="btn btn-success">{{ __('message.See All Restaurants') }}</a>
</div>
{{-- city --}}
@foreach($city as $key =>$cities)
<div class="container mt-5">
    <div class="card" style="width: 18rem;">
      <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">

      <img class="card-img-top" src="/city/{{ $cities->city_image }}" alt="Card image cap"></a>
      <a>{{$cities->city_name}}</a>
    </div>
</div>
@endforeach

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
{{-- @endsection --}}

