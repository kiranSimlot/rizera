@extends('layouts.admin')    
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
<div class="row">
	<div class="col-md-12 col-sm-12 ">
		<a href="{{Route('admin.cms.cms')}}" class="btn btn-primary">Back</a>
		<div class="x_panel">
			<div class="x_title">
				<h2> Edit CMS page</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
			<br />
			<form method="post" action="{{ route('admin.cms.updatecms',$cms->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
				@csrf
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Name 
					  <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="name" name="name" value="{{old('name', $cms->name)}}" class="form-control ">
					    @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="mark">Heading <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="heading" name="heading" value="{{old('heading', $cms->heading)}}" class="form-control ">
					    @error('heading')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
				
				<div class="item form-group">
                	<label class="col-form-label col-md-3 col-sm-3 label-align" for="description">Content<span class="required spanColor">*</span></label>
                	<div class="col-md-9 col-sm-9 ">
                    <textarea class="resizable_textarea form-control" name="content" id="message">{{old('content', $cms->content)}}</textarea>
                        @error('content')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                	</div>
            	</div>	
				<div class="ln_solid"></div>
				<div class="item form-group">
					<div class="col-md-6 col-sm-6 offset-md-3">
						<button type="submit" class="btn btn-success" value="submit">Submit</button>
					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
</div>
<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script>
CKEDITOR.replace('message');
</script>
@endsection