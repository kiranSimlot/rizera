@extends('layouts.admin')
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
      <div class="row">
        <div class="col-md-12 col-sm-12 ">
            <a href="{{Route('admin.cuisine.cuisine')}}" class="btn btn-primary">Back</a>
            <div class="x_panel">
                <div class="x_title">
                    <h2>Edit Cuisine</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.cuisine.updatecuisine',$cuisine->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                    @csrf


                    <div class="item form-group">
                        <label for="country" class="col-form-label col-md-3 col-sm-3 label-align">Country <span class="required spanColor">*</span></label>
                        <div class="col-md-6 col-sm-6 ">
                        <select name="country_id" class="form-control" id="country_id">
                        <option value="">select country</option>
                        <?php
                          foreach($country_list as $list)
                           {
                            $chk_id = $list->id;  
                            $checked_ser = '';
                            if(old('country_id'))
                            {
                              if($chk_id == old('country_id'))
                              {
                                $checked_ser = 'selected="selected"'; 
                              }
                              else
                              {
                                $checked_ser = ''; 
                              }
                            }
                            else
                            {
                              if($chk_id == $cuisine->country_id)
                              {
                                $checked_ser = 'selected="selected"'; 
                              }
                              else
                              {
                                $checked_ser = '';  
                              } 
                            }
                            ?>
                        <option value="<?php echo $list->id; ?>" <?php echo $checked_ser; ?>> <?php echo $list->country_name; ?></option>
                         <?php } ?>
                        </select>
                        @error('country_id')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                        </div>
                    </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Cuisine Name(En) <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name" value="{{old('name', $cuisine->name)}}" id="name" class="form-control ">
                        @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                    </div>
                </div>
				
				
				
				<div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Cuisine Name(Ar) <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name_ar" value="{{old('name_ar', $cuisine->name_ar)}}" id="name_ar" class="form-control ">
                        @error('name_ar')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                    </div>
                </div>
				
				<div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Cuisine Name(Fr) <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name_fr" value="{{old('name_fr', $cuisine->name_fr)}}" id="name_fr" class="form-control ">
                        @error('name_fr')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                    </div>
                </div>

                    <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="image">Choose Image <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="file" name="image" id="image" class="form-control " onchange="previewss_image(event)" value="{{$cuisine->image}}">
                        @error('image')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                    </div>

                  <div class="item form-group">
                 
                    
                         <label class="col-form-label col-md-3 col-sm-3 label-align" for="name"> <span class="required spanColor"></span></label>
                         <div class="col-md-6 col-sm-6 ">
                        @if(!empty($cuisine->image))
                            <img src="{{ asset('storage').'/'.$cuisine->image }}" width='100px' id="outputss_image">
                        @else
                            <img src="{{ asset('storage/city/no_image.jpg') }}" width='100px' id="outputss_image">
                        @endif

                      
                    </div>
                    </div>
                     <p style="margin-left: 255px;"> Resolution &gt; 500*500</p>
				
				
                <div class="ln_solid"></div>
                <div class="item form-group">
                    <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" class="btn btn-success" value="submit">Update</button>
                    </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>
@endsection


<script type="text/javascript">
    function previewss_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('outputss_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}

</script>