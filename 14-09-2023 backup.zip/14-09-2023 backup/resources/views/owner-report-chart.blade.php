@extends('layouts.default')
@section('content')

<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />


<div class="container-fluid">
         <div class="fix-width">
@include('layouts.floor_management_left_menu')
            
            <main role="main" class="main-box w-100 border-main-box report-chart">
               <!-- main header -->
               <div class="dis-header">
                  <div class="row align-items-center">
                     
                     <div class="col-xl-12 col-lg-12 text-right">
                        <a href="{{ url('restaurant-owner/restaurant/bookinglist') }}" class="btn advanced-report">Advanced Report</a>
                     </div>
                  </div>
               </div>
               <!-- end  main header -->
               <!-- container-main -->
               <div class="container-main">
                  <div class="row">

                    <div class="col-md-4">
                      <div class="chart_box">
                        <h4>Online / Offline Reservations</h4>
                        <canvas id="online-offline"></canvas>
                        <ul class="pie-chart-legend">
                          <li><label style="background: #179a6b;"></label> Online</li>
                          <li><label style="background: #fccc00;"></label> Offline</li>
                        </ul>
                      </div>
                    </div>


                    <div class="col-md-4">
                      <div class="chart_box">
                        <h4>Cancelled / Confirmed Bookings</h4>
                        <canvas id="bookings"></canvas>
                        <ul class="pie-chart-legend">
                          <li><label style="background: #BF0404;"></label> Cancelled</li>
                          <li><label style="background: #fccc00;"></label> Confirmed</li>
                        </ul>
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="chart_box">
                        <h4>Visited / Waiting List Tables</h4>
                         <canvas id="tables"></canvas>
                         <ul class="pie-chart-legend">
                          <li><label style="background: #179a6b;"></label> Visited</li>
                          <li><label style="background: #fccc00;"></label> Waiting List</li>
                        </ul>
                      </div>
                    </div>
                  </div>


                  <div class="row">
                    <div class="col-md-12">
                      <div class="chart_box">
                        
                        <div class="row">
                          <div class="col-md-4">
                            <h4 onclick="ajax_demo();">Online / Offline Reservations Statistics</h4>
                          </div>
                          <div class="col-md-3">
                            <ul class="pie-chart-legend pt-0">
                          <!--<li><label style="background: #179a6b;"></label> Released</li>
                          <li><label style="background: #fccc00;"></label> Waiting List</li>-->
						  <li><label style="background: #179a6b;"></label> Online</li>
                          <li><label style="background: #fccc00;"></label> Offline</li>
                        </ul>
                          </div>
                          <div class="col-md-5">
                            <div class="form-group d-flex align-items-center justify-content-end">
                              <label>Month</label>

                              <select name="month" id="month" class="form-control" onchange="month_sel();" style="margin-left: 15px; width: 110px; margin-right: 10px;">
    <!--<option>Choose...</option>-->
    <option value="1" <?php if($current_month == 1) { ?> selected="selected" <?php } ?> >January</option>
    <option value="2" <?php if($current_month == 2) { ?> selected="selected" <?php } ?> >February</option>
    <option value="3" <?php if($current_month == 3) { ?> selected="selected" <?php } ?> >March</option>
    <option value="4" <?php if($current_month == 4) { ?> selected="selected" <?php } ?> >April</option>
    <option value="5" <?php if($current_month == 5) { ?> selected="selected" <?php } ?> >May</option>
    <option value="6" <?php if($current_month == 6) { ?> selected="selected" <?php } ?> >June</option>
    <option value="7" <?php if($current_month == 7) { ?> selected="selected" <?php } ?> >July</option>
    <option value="8" <?php if($current_month == 8) { ?> selected="selected" <?php } ?> >August</option>
    <option value="9" <?php if($current_month == 9) { ?> selected="selected" <?php } ?> >September</option>
    <option value="10" <?php if($current_month == 10) { ?> selected="selected" <?php } ?> >October</option>
    <option value="11" <?php if($current_month == 11) { ?> selected="selected" <?php } ?> >November</option>
    <option value="12" <?php if($current_month == 12) { ?> selected="selected" <?php } ?> >December</option>
</select>
                              <label style="margin-left:20px;">Year</label>
							  
							  <?php 
							  $start_year = 2021;
							  $end_year = date('Y');  
							  ?>
                              <select name="year" id="year" class="form-control" onchange="month_sel();" style="margin-left: 15px; width: 110px;">
    <!--<option>Choose...</option>-->
	<?php for($yr = $start_year; $yr <= $end_year; $yr++) { ?>
	 <option value="<?php echo $yr; ?>" <?php if($yr == $current_year) { ?> selected="selected" <?php } ?> ><?php echo $yr; ?></option>
	<?php } ?>
</select>
                            </div>
							
                          </div>
                        </div>
                        <div class="mx-3"><canvas id="myGraph"></canvas></div>
                      </div>
                    </div>
                  </div>
               </div>
               <!-- end container-main -->
            </main>
            <!-- end main -->

         </div>
      </div>


    
    
    <!--<script src="js/jquery.min.js" ></script> 
    <script src="assets/bootstrap/js/bootstrap.bundle.min.js" ></script>
    <script type="text/javascript" src="assets/slick/slick.min.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js"></script> 
    <!--<script type="text/javascript" src="js/custom.js"></script>-->
    <script type="text/javascript">
  


Chart.defaults.global = {
    // Boolean - Whether to animate the chart
    animation: true,

    // Number - Number of animation steps
    animationSteps: 60,

    // String - Animation easing effect
    // Possible effects are:
    // [easeInOutQuart, linear, easeOutBounce, easeInBack, easeInOutQuad,
    //  easeOutQuart, easeOutQuad, easeInOutBounce, easeOutSine, easeInOutCubic,
    //  easeInExpo, easeInOutBack, easeInCirc, easeInOutElastic, easeOutBack,
    //  easeInQuad, easeInOutExpo, easeInQuart, easeOutQuint, easeInOutCirc,
    //  easeInSine, easeOutExpo, easeOutCirc, easeOutCubic, easeInQuint,
    //  easeInElastic, easeInOutSine, easeInOutQuint, easeInBounce,
    //  easeOutElastic, easeInCubic]
    animationEasing: "easeOutBack",

    // Boolean - If we should show the scale at all
    showScale: true,

    // Boolean - If we want to override with a hard coded scale
    scaleOverride: false,

    // ** Required if scaleOverride is true **
    // Number - The number of steps in a hard coded scale
    scaleSteps: null,
    // Number - The value jump in the hard coded scale
    scaleStepWidth: null,
    // Number - The scale starting value
    scaleStartValue: null,

    // String - Colour of the scale line
    scaleLineColor: "rgba(0,0,0,.1)",

    // Number - Pixel width of the scale line
    scaleLineWidth: 1,

    // Boolean - Whether to show labels on the scale
    scaleShowLabels: true,

    // Interpolated JS string - can access value
    scaleLabel: "<%=value%>",

    // Boolean - Whether the scale should stick to integers, not floats even if drawing space is there
    scaleIntegersOnly: true,

    // Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
    scaleBeginAtZero: false,

    // String - Scale label font declaration for the scale label
    scaleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Scale label font size in pixels
    scaleFontSize: 12,

    // String - Scale label font weight style
    scaleFontStyle: "normal",

    // String - Scale label font colour
    scaleFontColor: "#666",

    // Boolean - whether or not the chart should be responsive and resize when the browser does.
    responsive: true,

    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio: true,

    // Boolean - Determines whether to draw tooltips on the canvas or not
    showTooltips: true,

    // Function - Determines whether to execute the customTooltips function instead of drawing the built in tooltips (See [Advanced - External Tooltips](#advanced-usage-custom-tooltips))
    customTooltips: false,

    // Array - Array of string names to attach tooltip events
    tooltipEvents: ["mousemove", "touchstart", "touchmove"],

    // String - Tooltip background colour
    tooltipFillColor: "rgba(0,0,0,0.8)",

    // String - Tooltip label font declaration for the scale label
    tooltipFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Tooltip label font size in pixels
    tooltipFontSize: 14,

    // String - Tooltip font weight style
    tooltipFontStyle: "normal",

    // String - Tooltip label font colour
    tooltipFontColor: "#fff",

    // String - Tooltip title font declaration for the scale label
    tooltipTitleFontFamily:
        "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Tooltip title font size in pixels
    tooltipTitleFontSize: 14,

    // String - Tooltip title font weight style
    tooltipTitleFontStyle: "bold",

    // String - Tooltip title font colour
    tooltipTitleFontColor: "#fff",

    // Number - pixel width of padding around tooltip text
    tooltipYPadding: 6,

    // Number - pixel width of padding around tooltip text
    tooltipXPadding: 6,

    // Number - Size of the caret on the tooltip
    tooltipCaretSize: 8,

    // Number - Pixel radius of the tooltip border
    tooltipCornerRadius: 6,

    // Number - Pixel offset from point x to tooltip edge
    tooltipXOffset: 10,

    // String - Template string for single tooltips
    tooltipTemplate: "<%if (label){%><%=label%>: <%}%><%= value %>",

    // String - Template string for multiple tooltips
    multiTooltipTemplate: "<%= value %>",

    // Function - Will fire on animation progression.
    onAnimationProgress: function () {},

    // Function - Will fire on animation completion.
    onAnimationComplete: function () {}};

/*const lineGraphData = {
    labels: <?php //echo $total_days; ?>,
    datasets: [
        {
            label: "Online",
            fillColor: "rgba(23, 154, 107, 0.3)",
            strokeColor: "#179A6B",
            pointColor: "#179A6B",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(220,220,220,1)",
            data: <?php //echo $online_bookings_day_wise; ?>
        },
        {
            label: "Offline",
            fillColor: "rgba(252, 204, 0, 0.3)",
            strokeColor: "#FCCC00",
            pointColor: "#FCCC00",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(151,187,205,1)",
            data: <?php //echo $offline_bookings_day_wise; ?>
        }
    ]};*/

const lineGraphOptions = {
    ///Boolean - Whether grid lines are shown across the chart
    scaleShowGridLines: true,

    //String - Colour of the grid lines
    scaleGridLineColor: "rgba(0,0,0,.05)",

    //Number - Width of the grid lines
    scaleGridLineWidth: 1,

    //Boolean - Whether to show horizontal lines (except X axis)
    scaleShowHorizontalLines: true,

    //Boolean - Whether to show vertical lines (except Y axis)
    scaleShowVerticalLines: true,

    //Boolean - Whether the line is curved between points
    bezierCurve: false,

    //Number - Tension of the bezier curve between points
    bezierCurveTension: 0,

    //Boolean - Whether to show a dot for each point
    pointDot: false,

    //Number - Radius of each point dot in pixels
    pointDotRadius: 4,

    //Number - Pixel width of point dot stroke
    pointDotStrokeWidth: 1,

    //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
    pointHitDetectionRadius: 20,

    //Boolean - Whether to show a stroke for datasets
    datasetStroke: true,

    //Number - Pixel width of dataset stroke
    datasetStrokeWidth: 2,

    //Boolean - Whether to fill the dataset with a colour
    datasetFill: true,

    //String - A legend template
    legendTemplate:
        '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].strokeColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'};

//const lineCtx = document.getElementById("myGraph").getContext("2d");
//const myLineChart = new Chart(lineCtx).Line(lineGraphData, lineGraphOptions);           

// Online / Offline Reservations ============================================
const doughnutData = [
    {
        value: <?php echo $online_bookings; ?>,
        color: "#179A6B",
        highlight: "#0f865b",
        label: "Online "
    },
    {
        value: <?php echo $offline_bookings; ?>,
        color: "#FCCC00",
        highlight: "#dbb100",
        label: "Offline"  
    }];
const doughnutOptions = { };
const doughnutCtx = document.getElementById("online-offline").getContext("2d");
const myDoughnutChart = new Chart(doughnutCtx).Doughnut(doughnutData,doughnutOptions);

// Cancelled / Confirmed Bookings ============================================
const doughnutData2 = [
    {
        value: <?php echo $cancelled_bookings; ?>,
        color: "#bf0404",
        highlight: "#a40404",
        label: "Cancelled"
    },
    {
        value: <?php echo $confirmed_bookings; ?>,
        color: "#FCCC00",
        highlight: "#dbb100",
        label: "Confirmed"
    }];
const doughnutOptions2 = {};
const doughnutCtx2 = document.getElementById("bookings").getContext("2d");
const myDoughnutChart2 = new Chart(doughnutCtx2).Doughnut(doughnutData2,doughnutOptions2);

// Released / Waiting List Tables ============================================
const doughnutData3 = [
    {
        value: <?php echo $released_bookings; ?>,
        color: "#179A6B",
        highlight: "#0f865b",
        label: "Visited"
    },
    {
        value: <?php echo $waiting_bookings; ?>,
        color: "#FCCC00",
        highlight: "#dbb100",
        label: "Waiting List"  
    }];
const doughnutOptions3 = { };
const doughnutCtx3 = document.getElementById("tables").getContext("2d");
const myDoughnutChart3 = new Chart(doughnutCtx3).Doughnut(doughnutData3,doughnutOptions3);

</script>
    
    <script>
      
      var graph_report_url = '<?php \URL::current(); ?>';
      
      function month_sel() { 
       var month = $('#month').find(":selected").val();
       var year = $('#year').find(":selected").val();
       $.ajax({
      url:'{!! route("owner.staff.ownerPanelReport") !!}',
      type:'GET',
      data:{
            "_token":"{{ csrf_token() }}",
            month:month
      },
      success: function(data){
        //window.location.reload();
        //window.location.replace(graph_report_url+"?month="+month);
        window.location.replace(graph_report_url+"?month="+month+"&year="+year);
      }
    });
      }
      
            /*Chart.defaults.global = {
    // Boolean - Whether to animate the chart
    animation: true,

    // Number - Number of animation steps
    animationSteps: 60,

    // String - Animation easing effect
    // Possible effects are:
    // [easeInOutQuart, linear, easeOutBounce, easeInBack, easeInOutQuad,
    //  easeOutQuart, easeOutQuad, easeInOutBounce, easeOutSine, easeInOutCubic,
    //  easeInExpo, easeInOutBack, easeInCirc, easeInOutElastic, easeOutBack,
    //  easeInQuad, easeInOutExpo, easeInQuart, easeOutQuint, easeInOutCirc,
    //  easeInSine, easeOutExpo, easeOutCirc, easeOutCubic, easeInQuint,
    //  easeInElastic, easeInOutSine, easeInOutQuint, easeInBounce,
    //  easeOutElastic, easeInCubic]
    animationEasing: "easeOutBack",

    // Boolean - If we should show the scale at all
    showScale: true,

    // Boolean - If we want to override with a hard coded scale
    scaleOverride: false,

    // ** Required if scaleOverride is true **
    // Number - The number of steps in a hard coded scale
    scaleSteps: null,
    // Number - The value jump in the hard coded scale
    scaleStepWidth: null,
    // Number - The scale starting value
    scaleStartValue: null,

    // String - Colour of the scale line
    scaleLineColor: "rgba(0,0,0,.1)",

    // Number - Pixel width of the scale line
    scaleLineWidth: 1,

    // Boolean - Whether to show labels on the scale
    scaleShowLabels: true,

    // Interpolated JS string - can access value
    scaleLabel: "<%=value%>",

    // Boolean - Whether the scale should stick to integers, not floats even if drawing space is there
    scaleIntegersOnly: true,

    // Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
    scaleBeginAtZero: false,

    // String - Scale label font declaration for the scale label
    scaleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Scale label font size in pixels
    scaleFontSize: 12,

    // String - Scale label font weight style
    scaleFontStyle: "normal",

    // String - Scale label font colour
    scaleFontColor: "#666",

    // Boolean - whether or not the chart should be responsive and resize when the browser does.
    responsive: true,

    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio: true,

    // Boolean - Determines whether to draw tooltips on the canvas or not
    showTooltips: true,

    // Function - Determines whether to execute the customTooltips function instead of drawing the built in tooltips (See [Advanced - External Tooltips](#advanced-usage-custom-tooltips))
    customTooltips: false,

    // Array - Array of string names to attach tooltip events
    tooltipEvents: ["mousemove", "touchstart", "touchmove"],

    // String - Tooltip background colour
    tooltipFillColor: "rgba(0,0,0,0.8)",

    // String - Tooltip label font declaration for the scale label
    tooltipFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Tooltip label font size in pixels
    tooltipFontSize: 14,

    // String - Tooltip font weight style
    tooltipFontStyle: "normal",

    // String - Tooltip label font colour
    tooltipFontColor: "#fff",

    // String - Tooltip title font declaration for the scale label
    tooltipTitleFontFamily:
        "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Tooltip title font size in pixels
    tooltipTitleFontSize: 14,

    // String - Tooltip title font weight style
    tooltipTitleFontStyle: "bold",

    // String - Tooltip title font colour
    tooltipTitleFontColor: "#fff",

    // Number - pixel width of padding around tooltip text
    tooltipYPadding: 6,

    // Number - pixel width of padding around tooltip text
    tooltipXPadding: 6,

    // Number - Size of the caret on the tooltip
    tooltipCaretSize: 8,

    // Number - Pixel radius of the tooltip border
    tooltipCornerRadius: 6,

    // Number - Pixel offset from point x to tooltip edge
    tooltipXOffset: 10,

    // String - Template string for single tooltips
    tooltipTemplate: "<%if (label){%><%=label%>: <%}%><%= value %>",

    // String - Template string for multiple tooltips
    multiTooltipTemplate: "<%= value %>",

    // Function - Will fire on animation progression.
    onAnimationProgress: function () {},

    // Function - Will fire on animation completion.
    onAnimationComplete: function () {}};*/
            const lineGraphData = {
             //labels: datares.total_days,
             labels: <?php echo $total_days; ?>,
             datasets: [
                   {
                    label: "Online",
                    fillColor: "rgba(23, 154, 107, 0.3)",
                    strokeColor: "#179A6B",
                    pointColor: "#179A6B",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    //data: datares.online_bookings_day_wise
					data: <?php echo $online_bookings_day_wise; ?>
                   },
                   {
                    label: "Offline",
                    fillColor: "rgba(252, 204, 0, 0.3)",
                    strokeColor: "#FCCC00",
                    pointColor: "#FCCC00",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(151,187,205,1)",
                    //data: datares.offline_bookings_day_wise
					data: <?php echo $offline_bookings_day_wise; ?>
                   }
                ]
            };
            /*const lineGraphOptions = {
    ///Boolean - Whether grid lines are shown across the chart
    scaleShowGridLines: true,

    //String - Colour of the grid lines
    scaleGridLineColor: "rgba(0,0,0,.05)",

    //Number - Width of the grid lines
    scaleGridLineWidth: 1,

    //Boolean - Whether to show horizontal lines (except X axis)
    scaleShowHorizontalLines: true,

    //Boolean - Whether to show vertical lines (except Y axis)
    scaleShowVerticalLines: true,

    //Boolean - Whether the line is curved between points
    bezierCurve: false,

    //Number - Tension of the bezier curve between points
    bezierCurveTension: 0,

    //Boolean - Whether to show a dot for each point
    pointDot: false,

    //Number - Radius of each point dot in pixels
    pointDotRadius: 4,

    //Number - Pixel width of point dot stroke
    pointDotStrokeWidth: 1,

    //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
    pointHitDetectionRadius: 20,

    //Boolean - Whether to show a stroke for datasets
    datasetStroke: true,

    //Number - Pixel width of dataset stroke
    datasetStrokeWidth: 2,

    //Boolean - Whether to fill the dataset with a colour
    datasetFill: true,

    //String - A legend template
    legendTemplate:
        '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].strokeColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'};*/
            const lineCtx = document.getElementById("myGraph").getContext("2d");
            const myLineChart = new Chart(lineCtx).Line(lineGraphData, lineGraphOptions);
      
      function ajax_demo_ABANDONED() { 
       var month = $('#month').find(":selected").val();
       $.ajax({
      url:'{!! route("owner.staff.ownerPanelReport1") !!}',
      type:'GET',
      data:{
            "_token":"{{ csrf_token() }}",
            month:month
      },
      success: function(datares){
             
             console.log(datares.total_days);
             console.log(datares.online_bookings_day_wise);
             console.log(datares.offline_bookings_day_wise);
             
             Chart.defaults.global = {
    // Boolean - Whether to animate the chart
    animation: true,

    // Number - Number of animation steps
    animationSteps: 60,

    // String - Animation easing effect
    // Possible effects are:
    // [easeInOutQuart, linear, easeOutBounce, easeInBack, easeInOutQuad,
    //  easeOutQuart, easeOutQuad, easeInOutBounce, easeOutSine, easeInOutCubic,
    //  easeInExpo, easeInOutBack, easeInCirc, easeInOutElastic, easeOutBack,
    //  easeInQuad, easeInOutExpo, easeInQuart, easeOutQuint, easeInOutCirc,
    //  easeInSine, easeOutExpo, easeOutCirc, easeOutCubic, easeInQuint,
    //  easeInElastic, easeInOutSine, easeInOutQuint, easeInBounce,
    //  easeOutElastic, easeInCubic]
    animationEasing: "easeOutBack",

    // Boolean - If we should show the scale at all
    showScale: true,

    // Boolean - If we want to override with a hard coded scale
    scaleOverride: false,

    // ** Required if scaleOverride is true **
    // Number - The number of steps in a hard coded scale
    scaleSteps: null,
    // Number - The value jump in the hard coded scale
    scaleStepWidth: null,
    // Number - The scale starting value
    scaleStartValue: null,

    // String - Colour of the scale line
    scaleLineColor: "rgba(0,0,0,.1)",

    // Number - Pixel width of the scale line
    scaleLineWidth: 1,

    // Boolean - Whether to show labels on the scale
    scaleShowLabels: true,

    // Interpolated JS string - can access value
    scaleLabel: "<%=value%>",

    // Boolean - Whether the scale should stick to integers, not floats even if drawing space is there
    scaleIntegersOnly: true,

    // Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
    scaleBeginAtZero: false,

    // String - Scale label font declaration for the scale label
    scaleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Scale label font size in pixels
    scaleFontSize: 12,

    // String - Scale label font weight style
    scaleFontStyle: "normal",

    // String - Scale label font colour
    scaleFontColor: "#666",

    // Boolean - whether or not the chart should be responsive and resize when the browser does.
    responsive: true,

    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio: true,

    // Boolean - Determines whether to draw tooltips on the canvas or not
    showTooltips: true,

    // Function - Determines whether to execute the customTooltips function instead of drawing the built in tooltips (See [Advanced - External Tooltips](#advanced-usage-custom-tooltips))
    customTooltips: false,

    // Array - Array of string names to attach tooltip events
    tooltipEvents: ["mousemove", "touchstart", "touchmove"],

    // String - Tooltip background colour
    tooltipFillColor: "rgba(0,0,0,0.8)",

    // String - Tooltip label font declaration for the scale label
    tooltipFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Tooltip label font size in pixels
    tooltipFontSize: 14,

    // String - Tooltip font weight style
    tooltipFontStyle: "normal",

    // String - Tooltip label font colour
    tooltipFontColor: "#fff",

    // String - Tooltip title font declaration for the scale label
    tooltipTitleFontFamily:
        "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",

    // Number - Tooltip title font size in pixels
    tooltipTitleFontSize: 14,

    // String - Tooltip title font weight style
    tooltipTitleFontStyle: "bold",

    // String - Tooltip title font colour
    tooltipTitleFontColor: "#fff",

    // Number - pixel width of padding around tooltip text
    tooltipYPadding: 6,

    // Number - pixel width of padding around tooltip text
    tooltipXPadding: 6,

    // Number - Size of the caret on the tooltip
    tooltipCaretSize: 8,

    // Number - Pixel radius of the tooltip border
    tooltipCornerRadius: 6,

    // Number - Pixel offset from point x to tooltip edge
    tooltipXOffset: 10,

    // String - Template string for single tooltips
    tooltipTemplate: "<%if (label){%><%=label%>: <%}%><%= value %>",

    // String - Template string for multiple tooltips
    multiTooltipTemplate: "<%= value %>",

    // Function - Will fire on animation progression.
    onAnimationProgress: function () {},

    // Function - Will fire on animation completion.
    onAnimationComplete: function () {}};
    
             const lineGraphData = {
             labels: datares.total_days,
             datasets: [
                   {
                    label: "Online",
                    fillColor: "rgba(23, 154, 107, 0.3)",
                    strokeColor: "#179A6B",
                    pointColor: "#179A6B",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    data: datares.online_bookings_day_wise
                   },
                   {
                    label: "Offline",
                    fillColor: "rgba(252, 204, 0, 0.3)",
                    strokeColor: "#FCCC00",
                    pointColor: "#FCCC00",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(151,187,205,1)",
                    data: datares.offline_bookings_day_wise
                   }
                ]
            };
            
            const lineGraphOptions = {
    ///Boolean - Whether grid lines are shown across the chart
    scaleShowGridLines: true,

    //String - Colour of the grid lines
    scaleGridLineColor: "rgba(0,0,0,.05)",

    //Number - Width of the grid lines
    scaleGridLineWidth: 1,

    //Boolean - Whether to show horizontal lines (except X axis)
    scaleShowHorizontalLines: true,

    //Boolean - Whether to show vertical lines (except Y axis)
    scaleShowVerticalLines: true,

    //Boolean - Whether the line is curved between points
    bezierCurve: false,

    //Number - Tension of the bezier curve between points
    bezierCurveTension: 0,

    //Boolean - Whether to show a dot for each point
    pointDot: false,

    //Number - Radius of each point dot in pixels
    pointDotRadius: 4,

    //Number - Pixel width of point dot stroke
    pointDotStrokeWidth: 1,

    //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
    pointHitDetectionRadius: 20,

    //Boolean - Whether to show a stroke for datasets
    datasetStroke: true,

    //Number - Pixel width of dataset stroke
    datasetStrokeWidth: 2,

    //Boolean - Whether to fill the dataset with a colour
    datasetFill: true,

    //String - A legend template
    legendTemplate:
        '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].strokeColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'};
            
            const lineCtx = document.getElementById("myGraph").getContext("2d");
            const myLineChart = new Chart(lineCtx).Line(lineGraphData, lineGraphOptions);
      }
    });
      }
      
    </script>
    
@endsection