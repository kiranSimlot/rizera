@extends('layouts.noauth_default')
@section('content')
       <div class="signin-warper" style="background-image: url({{asset('admin/imgs/login_banner.jpeg')}})">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-4">
                 <div class="signin-warper-box after_signin-warper" style="background-image: url({{asset('admin/imgs/Vector.svg')}})">     
                   <div class="container-login">
                      <div class="sing-form-logo">
                        <a href=""><img src="{{asset('admin/imgs/s-logo.png')}}" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form">
                        <h2> {{ __('login.Welcome_to_Rizera') }}</h2>
                        <p>{{ __('login.Please_login_to_your_account') }}</p>
                        <x-auth-session-status class="mb-4" :status="session('status')" />
 
                       
                        @foreach($errors as $error)
                        <div class="alert alert-danger" role="alert">
                        {{$error}}
                        </div>
                         @endforeach
                      
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                         <form method="POST" action="{{ route('login') }}">
                            @csrf
                          <div class="form-group">
                            <label for="email">Email</label>
                            <input class="form-control" type="email" name="email" value="{{old('email')}}" required autofocus>
                          </div>
                          <div class="form-group">
                            <label for="password">Password</label>
                            <input class="form-control" type="password" name="password" value="{{old('password')}}" required autofocus>
                          </div>
                           <div class="form-group text-right">
                          <a href="{{ url('forgot-password') }}" class="Forgot">{{ __('login.Forgot_Password') }}</a>
                          </div>
                          <div class="form-group">
                          <button class="btn btn-black w-100">Log in</button>
                          </div> 
                          <div class="form-group text-center">
                         <h6 class="mb-0 Create" > {{ __('login.No_account') }}
                            <a href="{{ route('owner.register') }}" class="">{{ __('login.create_account') }}</a>
                         </h6>
                          </div>
                          
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
       </div>
      <!-- end of footer -->
@endsection