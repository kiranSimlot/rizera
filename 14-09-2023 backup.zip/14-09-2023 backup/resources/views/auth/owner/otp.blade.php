@extends('layouts.noauth_default')


@section('content')
       <div class="signin-warper" style="background-image: url({{asset('admin/imgs/login_banner.jpeg')}})">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-4">
                 <div class="signin-warper-box " style="background-image: url({{asset('admin/imgs/Vector.png')}})">
                   <div class="container-login">
                      <div class="sing-form-logo">
                        <a href=""><img src="{{asset('admin/imgs/s-logo.png')}}" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form">
                        <h2>Welcome to Rizera</h2>
                        <p>Please Verify your OTP</p>
                        <x-auth-session-status class="mb-4" :status="session('status')" />

                        <!-- Validation Errors -->
                        <x-auth-validation-errors class="mb-4" :errors="$errors" />

                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif
                        
                         <form method="GET" action="{{ route('verify_otp') }}">
                            @csrf
                          <div class="form-group">
                            <label for="email">{{__('Otp')}}</label>
                            <input class="form-control" type="otp" name="otp" value="{{old('otp')}}" required autofocus>
                                 <?php  $mobile=Session::get('mobile')?>
                              <input class="form-control"  type="hidden" name="mobile" value="{{$mobile}}" >
                          </div>
                     
                          
                          <div class="form-group">
                          <button class="btn btn-black w-100"> {{ __('Verify Otp') }} </button>
                          </div> 
                        
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
       </div>
      <!-- end of footer -->
@endsection