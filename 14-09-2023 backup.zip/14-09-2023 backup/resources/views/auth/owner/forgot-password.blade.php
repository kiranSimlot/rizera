@extends('layouts.default') 
@section('content')
        <div class="signin-warper" style="background-color: #EBEFF3;">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-2">
                 <div class="signin-warper-box " style="background-color: #EBEFF3;">
                   <div class="container-login">
                      <div class="sing-form-logo">
                        <a href="{{ route('home') }}"><img src="{{ asset('front/imgs/riz-logo.png') }}" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form pb-4">
                        <h2>Forgot your password?</h2>
                        <p> {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}</p>
                        <!-- Session Status -->
                        <x-auth-session-status class="mb-4" :status="session('status')" />

                        <!-- Validation Errors -->
                        <x-auth-validation-errors class="mb-4" :errors="$errors" />
                            <form method="POST" action="{{ route('password.email') }}">
                            @csrf
                         
                          <div class="form-group">
                            <label for="email"> {{ __('Email') }} </label>

                            <input id="email" class="form-control" type="email" name="email" :value="old('email')" required autofocus />
                          </div>
                         
                          
                          
                          <div class="form-group mb-4">
                          <button class="btn btn-black w-100" type="submit">   
                            {{ __('Email Password Reset Link') }}
                          </button>
            
                          </div>
                          <div class="form-group text-center">
                         <h6 class="mb-0 Create" > <a href="{{route('owner.login')}}" class=""> Back to log In </a></h6>
                          </div>
                          
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
        </div>
@endsection



 

       
        

     
 
