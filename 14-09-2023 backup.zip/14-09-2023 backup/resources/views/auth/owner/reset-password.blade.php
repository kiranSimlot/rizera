@extends('layouts.noauth_default')
@section('content')
<div class="signin-warper" style="background-color: #EBEFF3;">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-2">
                 <div class="signin-warper-box " style="background-color: #EBEFF3;">
                   <div class="container-login">
                      <div class="sing-form-logo">
                        <a href=""><img src="imgs/logo_black.svg" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form pb-4">
                        <h2>Change your password</h2>
                        <p>Type and confirm a secure new password for that account.</p>
                         <!-- Validation Errors -->
                         <x-auth-validation-errors class="mb-4" :errors="$errors" /> 
                          <form method="POST" action="{{ route('password.update') }}">
                            @csrf
                          <input type="hidden" name="token" value="{{ $request->route('token') }}">
                          <div class="form-group">
                            <label>Email</label>
                            <input id="email" class="form-control" type="email" name="email" value="{{old('email', $request->email)}}" required autofocus>
                          </div>
                          <div class="form-group">
                            <label>Password</label>
                             <input id="password" class="form-control" type="password" name="password" value="" required autofocus>
                          </div>
                          <div class="form-group">
                            <label>Confirm Password</label>
                            <input id="password_confirmation" class="form-control" type="password" name="password_confirmation" value="" required autofocus>
                          </div> 
                          <div class="form-group mb-4">
                            <button class="btn btn-black w-100"> 
                            {{ __('Reset Password') }}
                            </button>
                          </div>   
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
       </div>
@endsection 
