@extends('layouts.noauth_default')
@section('content')

      </style>
       <div class="signin-warper" style="background-image: url({{asset('admin/imgs/login_banner.jpeg')}})">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-4">
                 <div class="signin-warper-box  after_signin-warper" style="background-image: url({{asset('admin/imgs/Vector.svg')}})">
                   <div class="container-login">
                      <div class="sing-form-logo">
                        <a href="{{ route('home') }}"><img src="{{asset('admin/imgs/riz-trans-large.png')}}" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form">
                        <h2>Welcome to Rizera</h2>
                        <p>Please login to your account</p>
                        <x-auth-session-status class="mb-4" :status="session('status')" />

                        
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif

                        @foreach($errors->getMessageBag()->toArray() as $error)
                        <div class="alert alert-danger">
                            {{ $error[0] }}
                        </div> 
                        @endforeach

                         <form method="POST" action="{{ route('login') }}">
                            @csrf
                          <div class="form-group">
                            <label for="email">{{__('Email')}}<span class="spanColor">*</span></label>
                            <input class="form-control" type="email" name="email" value="{{old('email')}}" required autofocus>
                          </div>

                       
                          <div class="form-group">
                              <label for="exampleFormControlTextarea1" class="form-label">{{ __('owner.Password') }}<span class="spanColor">*</span></label>
                            <div class="input-group date ">
                                <input type="password" name="password"  class="form-control" id="password"  value="">
                              
                                <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash">
                                        <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye-slash text-dark" aria-hidden="true"></i></button>
                                    </span>
                                    <span class="input-group-btn" id="eyeShow" style="display: none;">
                                        <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye text-dark" aria-hidden="true"></i></button>
                                    </span>
                                </div>

                            </div>
                           
                          </div>


                           <div class="form-group text-right">
                          <a href="{{ route('owner.forgot.password') }}" class="Forgot"> Forgot Password?</a>
                          </div>
                          <div class="form-group">
                          <button class="btn btn-black w-100"> {{ __('Sign in') }} </button>
                          </div> 
                          <div class="form-group text-center">
                         <h6 class="mb-0 Create" > Don’t have an account? 
                            <a href="{{ route('owner.register') }}" class=""> Create an Account </a>
                         </h6>
                          </div>
                          
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
       </div>
      <!-- end of footer -->
@endsection

<script type="text/javascript">
   
   function isNumberKey(evt){  
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }
         
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }

    function visibility3() {
  var x = document.getElementById('password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow').show();
    $('#eyeSlash').hide();
  }else {
    x.type = "password";
    $('#eyeShow').hide();
    $('#eyeSlash').show();
  }
}

 function visibility4() {
  var x = document.getElementById('confirm_password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow1').show();
    $('#eyeSlash1').hide();
  }else {
    x.type = "password";
    $('#eyeShow1').hide();
    $('#eyeSlash1').show();
  }
}

</script>