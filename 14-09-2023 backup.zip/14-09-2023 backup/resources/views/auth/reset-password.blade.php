@extends('layouts.noauth_default')
@section('content')
<div class="signin-warper" style="background-color: #EBEFF3;">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-2">
                 <div class="signin-warper-box " style="background-color: #EBEFF3;">
                   <div class="container-login">
                         <div class="sing-form-logo">
                        <a href=""><img src="{{ asset('admin/imgs/logo_black.svg') }}" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form pb-4">
                        <h2>Change your password</h2>
                        <p>Type and confirm a secure new password for that account.</p>
                         <!-- Validation Errors -->
                         <x-auth-validation-errors class="mb-4" :errors="$errors" /> 
                          <form method="POST" action="{{ route('password.update') }}">
                            @csrf
                          <input type="hidden" name="token" value="{{ $request->route('token') }}">
                          <div class="form-group">
                            <label>Email<span class="spanColor">*</span></label>
                            <input id="email" class="form-control" type="email" name="email" value="{{old('email', $request->email)}}"  autofocus>
                            @error('name')
                            <div class="error-box" style="color: red">{{$message}}</div>
                            @enderror
                          </div>
                          <div class="form-group">
                              <label for="exampleFormControlTextarea1" class="form-label">{{ __('owner.Password') }}<span class="spanColor">*</span></label>
                            <div class="input-group date ">
                                <input type="password" name="password"  class="form-control" id="password" value="">
                                      
                                <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash">
                                        <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye-slash text-dark" aria-hidden="true"></i></button>
                                    </span>
                                    <span class="input-group-btn" id="eyeShow" style="display: none;">
                                        <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye text-dark" aria-hidden="true"></i></button>
                                    </span>
                                </div>
                            </div>
                                  @error('password')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                @enderror  
                          </div>
                          <div class="form-group">
                              <label for="exampleFormControlTextarea1" class="form-label">{{ __('owner.Confirm Password') }}<span class="spanColor">*</span></label>
                            <div class="input-group date ">
                                <input type="password" name="password_confirmation"  class="form-control" id="password_confirmation" value="">
                                        
                                <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash">
                                        <button class="btn btn-default reveal" onclick="visibility4()" type="button"><i class="fa fa-eye-slash text-dark" aria-hidden="true"></i></button>
                                    </span>
                                    <span class="input-group-btn" id="eyeShow" style="display: none;">
                                        <button class="btn btn-default reveal" onclick="visibility4()" type="button"><i class="fa fa-eye text-dark" aria-hidden="true"></i></button>
                                    </span>
                                </div>
                            </div>
                                @error('password_confirmation')
                                  <div class="error-box" style="color: red">{{$message}}</div>
                                @enderror  
                          </div>
                          <div class="form-group mb-4">
                            <button class="btn btn-black w-100"> 
                            {{ __('Reset Password') }}
                            </button>
                          </div>   
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
       </div>
@endsection 


<script type="text/javascript">
   
   function isNumberKey(evt){  
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }
         
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }
    function visibility3() {
  var x = document.getElementById('password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow').show();
    $('#eyeSlash').hide();
  }else {
    x.type = "password";
    $('#eyeShow').hide();
    $('#eyeSlash').show();
  }
}

 function visibility4() {
  var x = document.getElementById('password_confirmation');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow1').show();
    $('#eyeSlash1').hide();
  }else {
    x.type = "password";
    $('#eyeShow1').hide();
    $('#eyeSlash1').show();
  }
}
    </script>
