@extends('layouts.noauth_default')
@section('content')
       <div class="signin-warper" style="background-image: url({{asset('admin/imgs/login_banner.jpeg')}})">
         <div class="container-fluid p-0">
           <div class="row no-gutters">
             <div class="col-md-8 offset-md-4">
                 <div class="signin-warper-box " style="background-image: url({{asset('admin/imgs/Vector.png')}})">
                   <div class="container-login">
                      <div class="sing-form-logo">
                        <a href=""><img src="{{asset('admin/imgs/s-logo.png')}}" width="225px" alt=""> </a>
                      </div>
                      <div class="sing-form">
                        <h2>Welcome to Rizera</h2>
                        <p>Please login to your account</p>
                        @if(!isset($message))
                        <x-auth-session-status class="mb-4" :status="session('status')" />

                        <!-- Validation Errors -->
                        <x-auth-validation-errors class="mb-4" :errors="$errors" />
                        @else
                        <div class="mb-4"> 
                        {{$message}}
                        </div>
                        @endif
                         <form method="POST" action="{{ route('login') }}">
                            @csrf
                          <div class="form-group">
                            <label for="email">{{__('Email')}}</label>
                            <input class="form-control" type="email" name="email" value="{{old('email')}}" required autofocus>
                          </div>
                          <div class="form-group">
                            <label for="password">{{__('Password')}}</label>
                            <input class="form-control" type="password" name="password" value="{{old('password')}}" required autofocus>
                          </div>
                           <div class="form-group text-right">
                          <a href="{{ route('owner.forgot.password') }}" class="Forgot"> Forgot Password?</a>
                          </div>
                          <div class="form-group">
                          <button class="btn btn-black w-100"> {{ __('Log in') }} </button>
                          </div> 
                          <div class="form-group text-center">
                         <!-- <h6 class="mb-0 Create" > Don’t have an account?  -->
                            <!-- <a href="{{ route('register') }}" class=""> Create an Account </a> -->
                         </h6>
                          </div>
                          
                         </form>
                      </div>
                   </div>
                 </div>
             </div>
           </div>
         </div>
       </div>
      <!-- end of footer -->
@endsection








 
            
 