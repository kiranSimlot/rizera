@extends('layouts.noauth_default')
@section('content')
<div class="text-center">
@if (isset($success))
<div class="alert alert-success" style="width: fit-content;">
{{ $success }}
</div>
@endif 
@if (isset($danger))
<div class="alert alert-danger" style="width: fit-content;">
{{ $danger }}
</div>
@endif
</div>
@endsection