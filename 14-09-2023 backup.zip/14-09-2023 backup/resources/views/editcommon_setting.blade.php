@extends('layouts.admin')
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>

        <div class="row">
        <div class="col-md-12 col-sm-12 ">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Edit Common Settings</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.common_setting.updatecommon_setting',$common_setting->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf


<div class="item form-group">                    
<label class="col-form-label col-md-3 col-sm-3 label-align" for="address">Address <span class="required">*</span></label>
<div class="col-md-6 col-sm-6 ">
<input type="text" name="address" value="{{$common_setting->address}}" id="address" class="form-control ">
@error('address')
<div class="error-box" style="color: red">{{$message}}</div>
@enderror
</div>
</div>

<div class="item form-group">                    
<label class="col-form-label col-md-3 col-sm-3 label-align" for="helpline">Helpline <span class="required">*</span></label>
<div class="col-md-6 col-sm-6 ">
<input type="text" name="helpline" value="{{$common_setting->helpline}}" id="helpline" class="form-control ">
@error('helpline')
<div class="error-box" style="color: red">{{$message}}</div>
@enderror
</div>
</div>

<div class="item form-group">                    
<label class="col-form-label col-md-3 col-sm-3 label-align" for="timing">Timing <span class="required">*</span></label>
<div class="col-md-6 col-sm-6 ">
<textarea class="resizable_textarea form-control" name="timing" id="timing">{{old('timing', $common_setting->timing)}}</textarea>
@error('timing')
<div class="error-box" style="color: red">{{$message}}</div>
@enderror
</div>
</div>


                <div class="ln_solid"></div>
                <div class="item form-group">
                    <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" class="btn btn-success" value="submit">Update</button>
                    </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>

<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script>
CKEDITOR.replace('timing');
</script>
	
@endsection