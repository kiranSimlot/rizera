@extends('layouts.default')

    
@section('content')

<div class="container-fluid">
    <div class="fix-width">
    @include('layouts.floor_management_left_menu')
        <!-- main -->
        <main role="main" class="main-box">
            <div class="container">

                <form action="{{ route('owner.account.update') }}" method="post" enctype="multipart/form-data">
                    <!-- end  main header -->
                    <!-- container-main -->
                    <div class="container-main">
                        <!-- Your Restaurant Details -->
                        <div class="add-restaurant-form">                        
                            <!-- <div class="d-inline">
                            <a href="{{route('owner.restaurant.list')}}" class="btn btn-black">{{ __('owner.Back') }}</a>  
                            </div> -->
                            <div class="d-inline"> 
                                <h2>{{ __('owner.Account Details') }}</h2> 
                            </div> 
                            <div class="card">
                                <div class="card-header">
                                    <h4>{{ __('owner.General Details') }}</h4>
                                </div>
                                <div class="card-body"> 
                                <div class="form-group">

                                    @csrf
                                    <label for="exampleFormControlInput1" class="form-label">{{ __('owner.Name') }}<span class="spanColor">*</span></label> 
                                    <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Name') }}" value="{{ $account->name }}" onKeyPress="return ValidateAlpha(event);"> 
                                   @error('name')
                                   <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div> 
                            </div>
                        </div> 

                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('owner.Credentials') }}</h4>
                            </div>
                            <div class="card-body"> 
                                <label for="exampleFormControlTextarea1" class="form-label">{{ __('owner.Password') }}<span class="spanColor">*</span></label>
                                <div class="input-group date ">
                                
                                    <input type="password" name="password"  class="form-control" id="password" placeholder="{{ __('owner.Password') }}" value="">
                                  
                                  
                                                      
                                  <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash">
                                   <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye-slash" aria-hidden="true"></i></button>
                                 </span>
                                 <span class="input-group-btn" id="eyeShow" style="display: none;">
                                   <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                 </span>
                             </div>
                                       
                             </div>
                               @error('password')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                     <label for="exampleFormControlTextarea1" class="form-label" style="margin-top: 30px;">{{ __('owner.Confirm Password') }}<span class="spanColor">*</span></label>
                                <div class="input-group date ">
                                
                                    <input type="password" name="password_confirmation" class="form-control" id="confirm_password" placeholder="{{ __('owner.Confirm Password') }}">
                                    @error('password_confirmation')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                    <input type="hidden" name="owner_id" class="form-control" value="{{ Auth::user()->id }}">
                                                      
                                 <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash1">
                                   <button class="btn btn-default reveal" onclick="visibility4()" type="button"><i class="fa fa-eye-slash" aria-hidden="true"></i></button>
                                 </span>
                                 <span class="input-group-btn" id="eyeShow1" style="display: none;">
                                   <button class="btn btn-default reveal" onclick="visibility4()" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                 </span>
                             </div>

                             
                            </div>
                              @error('password')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>
                            </div> 
                
                
                            <div class="form-group">
                                <button type="submit" class="btn btn-black w-100 py-3">
                                    {{ __('owner.Update') }}                                     
                                </button>
                            </div> 
                        </div>
                    </div>
                </form>

            </div>
        </main>
    </div>
</div>


@endsection

<script type="text/javascript">
   
   function isNumberKey(evt){  
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }
         
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }

    function visibility3() {
  var x = document.getElementById('password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow').show();
    $('#eyeSlash').hide();
  }else {
    x.type = "password";
    $('#eyeShow').hide();
    $('#eyeSlash').show();
  }
}

 function visibility4() {
  var x = document.getElementById('confirm_password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow1').show();
    $('#eyeSlash1').hide();
  }else {
    x.type = "password";
    $('#eyeShow1').hide();
    $('#eyeSlash1').show();
  }
}

</script>



   

   

  
 
 