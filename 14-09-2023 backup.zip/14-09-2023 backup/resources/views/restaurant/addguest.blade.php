@extends('layouts.default')

    
@section('content')

<style>
    #mobile-box{
        display: none;
    }
</style>

    <div class="container-fluid">
        <div class="fix-width">
            @include('layouts.floor_management_left_menu')          
            <div class="container" style="margin: 50px;background-color: #FFF;"> 
                <div class="row">  
                    <div class="col-md-12"><h1>{{ __('owner.Guest Booking') }}</h1></div>
                    <div class="col-md-12">    
                        <form method="POST" action="{{ route('owner.restaurant.addgustuser') }}" style="margin: 20px;" >
                        @csrf
                            <div class="row">                            
                                <div class="form-group col-md-6">
                                    <label>{{ __('owner.First_Name') }} : </label>
                                    <input class="form-control" type="text" id="first_name" name="first_name" required>                                  
                                </div>                            
                            </div> 

                            <div class="row">                            
                                <div class="form-group col-md-6">
                                    <label>{{ __('owner.Last_Name') }} : </label>
                                    <input class="form-control" type="text" id="last_name" name="last_name" required>                                  
                                </div>                            
                            </div> 
                            
                            <div class="row">                            
                                <div class="form-group col-md-6">
                                    <label>{{ __('owner.Email') }} : </label>
                                    <input class="form-control" type="email" id="email" name="email" value="{{@$data['email-input']}}" required>    
                                </div>
                            </div> 
                            <div class="row">                            
                                <div class="form-group col-md-6">
                                    <label>{{ __('owner.Mobile') }} : </label>
                                    <input class="form-control" type="number" id="mobile" name="mobile" value="{{@$data['mobile-input']}}" required> 
                                </div>
                            </div> 
                            <div class="row">                            
                                <div class="form-group col-md-6">
                                <input  type="hidden" id="resid" name="resid" value="{{$data['resid']}}" >
                                    <button class="btn btn-primary w-100">{{ __('owner.Add Guest') }}</button>     
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>            
        </div>
    </div>


<script>
$(document).ready(function(){
 
});



</script>
<!-- method="POST" action="{{ route('register') }}">  @csrf -->

@endsection


