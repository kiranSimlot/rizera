@extends('layouts.admin')
@section('content')


<!--<style type="text/css">
        .openinghours {
    font-family:Lucida Console;
    border-radius:4px;
    margin:10px;
    box-shadow: 0 0 10px black;
    padding:0 10px 0 10px;
    overflow: hidden;
    display: inline-block;
}
.openinghourscontent {
    float:left;
}
.openinghourscontent h2 {
    display:block;
    text-align:center;
    margin-top:.33em;
}
.openinghourscontent button {
    color:white;
    font-family:Courier New;
    font-size:large;
    font-weight:bolder;
    background-color:#4679BD;
    border-radius:4px;
    width:100%;
    margin-bottom:10px;
}
.today {
    color: #8AC007;
}
.opening-hours-table tr td:first-child {
    font-weight:bold;
}
#open-status {
    display:block;
    margin-top:-1em;
    text-align:center;
    border:dotted lightgrey 3px;
}
.openorclosed:after {
    content:" open during these hours:";
}
.open {
    color:green;
}
.open:after {
    content:" Open";
    color: #6C0;
}
.closed:after {
    content:" Closed";
    color: red;
}
.opening-hours-table tr td {
    padding:5px;
}
    </style>-->

<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>

<div class="row">
	<div class="col-md-12 col-sm-12 ">
		<div class="x_panel">
			<div class="x_title">
				<h2> Edit Restaurant Details</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
			<br />    
	
 <form action="{{ route('admin.updateres',$restaurant->id) }}" method="post" class="form-horizontal form-label-left" enctype="multipart/form-data">
               @csrf
    <input type="hidden" name="id" value="{{$restaurant->id}}">
	<input type="hidden" name="delete_list" value="">
	<input type="hidden" name="delete_holiday_list" value="">
	<input type="hidden" name="restaurant_cuisine_types_saved" value="{{implode(',',$restaurantCuisineTypes)}}">
	<input type="hidden" name="restaurant_facilities_saved" value="{{implode(',',$restaurantFacilities)}}">
								
<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Name<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="name" value="{{old('name', $restaurant->name)}}" class="form-control ">
  @error('name')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group" style="display:none;">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Description<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <textarea name="description" id="editor2" class="resizable_textarea form-control" >
                                  {{old('description')??$restaurant->description}}
                               </textarea>
  @error('description')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Online Booking Terms & Conditions<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="online_book_tnc"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Online Booking Terms & Conditions') }}" value="{{old('online_book_tnc')??$restaurant->online_book_tnc}}">
  @error('online_book_tnc')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Notification Emails<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="notification_emails"  class="form-control" id="exampleFormControlInput1" placeholder="e.g. example@example.com,example1@example.com" value="{{old('notification_emails')??$restaurant->notification_emails}}">
  @error('notification_emails')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Notification Mobiles<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="notification_mobiles"  class="form-control" id="exampleFormControlInput1" placeholder="e.g. 9999999999,8888888888" value="{{old('notification_mobiles')??$restaurant->notification_mobiles}}">
  @error('notification_mobiles')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Country<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
	<select name="country_id" id="country_id" class="form-control" aria-label="Default select example">
	<option value="">{{ __('Country') }}</option>
	@foreach($countries as $key=>$country)
	@if(isset($restaurant->country_id) && $restaurant->country_id == $key)
	<option selected value="{{$key}}">{{$country}}</option>
	@elseif(old('country_id')== $key)
	<option selected value="{{$key}}">{{$country}}</option>
	@else 
	<option value="{{$key}}">{{$country}}</option>
	@endif
	@endforeach
	</select>
  @error('country_id')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">City<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <select name="city_id" id="city_id" class="form-control" aria-label="Default select example" >
                            <option value="">{{ __('City') }}</option>
                        </select>
  @error('city_id')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Email<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="email"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Restaurant Email') }}" value="{{old('email')??$restaurant->email}}">
  @error('email')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Mobile<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="mobile"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Restaurant Mobile') }}" value="{{old('mobile')??$restaurant->mobile}}">
  @error('mobile')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Website<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="website"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Restaurant Website') }}" value="{{old('website')??$restaurant->website}}">
  @error('website')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

 <div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Address<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="address"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Restaurant Address') }}" value="{{old('address')??$restaurant->address}}">
  @error('address')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
 </div>


 <div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Opening Hours</label>
 <div class="col-md-6 col-sm-6 ">
  <div class="card">
                        <div class="card-body">
                           <div class="row">
                              <div class="form-group col-md-12"> 
								<label>{{ __('Monday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6"> 
                                <input type="time" name="monday_open_time" class="form-control open_time" value="{{ (old('monday_open_time') != '') ? old('monday_open_time') 
                                : (isset($openingHours['mon_from']) ? $openingHours['mon_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="monday_close_time" class="form-control close_time" value="{{ (old('monday_close_time') != '') ? old('monday_close_time') 
                                : (isset($openingHours['mon_to']) ? $openingHours['mon_to'] : '')  }}">

                                </div>
                                </div>  
                              </div>
							  <div class="form-group col-md-12"> 
								<div class="float-right"><button type="button" class="btn btn-warning copy_btn">{{ __('Copy to All') }}</button></div>
                                  
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('Tuesday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6">

                                <input type="time" name="tuesday_open_time" class="form-control open_time" value="{{ (old('tuesday_open_time') != '') ? old('tuesday_open_time') 
                                : (isset($openingHours['tue_from']) ? $openingHours['tue_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="tuesday_close_time" class="form-control close_time" value="{{ (old('tuesday_close_time') != '') ? old('tuesday_close_time') 
                                : (isset($openingHours['tue_to']) ? $openingHours['tue_to'] : '')  }}">

                                </div>
                                </div>  
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('Wednesday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6">

                                <input type="time" name="wednesday_open_time" class="form-control open_time" value="{{ (old('wednesday_open_time') != '') ? old('wednesday_open_time') 
                                : (isset($openingHours['wed_from']) ? $openingHours['wed_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="wednesday_close_time" class="form-control close_time" value="{{ (old('wednesday_close_time') != '') ? old('wednesday_close_time') 
                                : (isset($openingHours['wed_to']) ? $openingHours['wed_to'] : '')  }}">

                                </div>
                                </div>  
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('Thursday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6">

                                <input type="time" name="thursday_open_time" class="form-control open_time" value="{{ (old('thursday_open_time') != '') ? old('thursday_open_time') 
                                : (isset($openingHours['thu_from']) ? $openingHours['thu_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="thursday_close_time" class="form-control close_time" value="{{ (old('thursday_close_time') != '') ? old('thursday_close_time') 
                                : (isset($openingHours['thu_to']) ? $openingHours['thu_to'] : '')  }}">

                                </div>
                                </div>  
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('Friday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6">

                                <input type="time" name="friday_open_time" class="form-control open_time" value="{{ (old('friday_open_time') != '') ? old('friday_open_time') 
                                : (isset($openingHours['fri_from']) ? $openingHours['fri_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="friday_close_time" class="form-control close_time" value="{{ (old('friday_close_time') != '') ? old('friday_close_time') 
                                : (isset($openingHours['fri_to']) ? $openingHours['fri_to'] : '')  }}">

                                </div>
                                </div>  
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('Saturday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6">

                                <input type="time" name="saturday_open_time" class="form-control open_time" value="{{ (old('saturday_open_time') != '') ? old('saturday_open_time') 
                                : (isset($openingHours['sat_from']) ? $openingHours['sat_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="saturday_close_time" class="form-control close_time" value="{{ (old('saturday_close_time') != '') ? old('saturday_close_time') 
                                : (isset($openingHours['sat_to']) ? $openingHours['sat_to'] : '')  }}">

                                </div>
                                </div>  
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('Sunday') }}</label>
                                <div class="row"> 
                                <div class="col-md-6">

                                <input type="time" name="sunday_open_time" class="form-control open_time" value="{{ (old('sunday_open_time') != '') ? old('sunday_open_time') 
                                : (isset($openingHours['sun_from']) ? $openingHours['sun_from'] : '')  }}">
                               
                                </div>
                                <div class="col-md-6"> 

                                <input type="time" name="sunday_close_time" class="form-control close_time" value="{{ (old('sunday_close_time') != '') ? old('sunday_close_time') 
                                : (isset($openingHours['sun_to']) ? $openingHours['sun_to'] : '')  }}">

                                </div>
                                </div>  
                              </div> 
                           </div> 
                        </div>
  </div>						
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Restaurant Features<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  @foreach($facilities as $key=>$cuisineType) 
@if(in_array($key,$restaurantFacilities))
<div class="col-md-12"> 
<div class="form-check">
<input class="form-check-input" name="facility_id[]" value="{{$key}}" type="checkbox" id="gridCheck1" checked>
<label class="form-check-label" for="gridCheck1">
{{$cuisineType}}
</label>
</div> 
</div>
@elseif(old('facility_id')== $key)
<div class="col-md-12"> 
<div class="form-check">
<input class="form-check-input" name="facility_id[]" value="{{$key}}" type="checkbox" id="gridCheck1" checked>
<label class="form-check-label" for="gridCheck1">
{{$cuisineType}}
</label>
</div> 
</div>
@else 
<div class="col-md-12"> 
<div class="form-check">
<input class="form-check-input" name="facility_id[]" value="{{$key}}" type="checkbox" id="gridCheck1">
<label class="form-check-label" for="gridCheck1">
{{$cuisineType}}
</label>
</div> 
</div>
@endif
@endforeach
  @error('facility_id')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror						
 </div>
</div>					 

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Home Delivery available<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <select name="home_delivery" id="home_delivery" class="form-control" aria-label="Default select example"> 
                                @foreach($homeDeliveryArray as $key=>$homeDelivery)
                                    @if(isset($restaurant->home_delivery) && $key == $restaurant->home_delivery)
                                        <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                    @elseif(old('home_delivery')== $key)
                                        <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                    @else 
                                        <option value="{{$key}}">{{$homeDelivery}}</option>
                                    @endif
                                @endforeach
                            </select>
  @error('home_delivery')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Minimum Payment Required for Booking<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="min_payment"  class="form-control" id="exampleFormControlInput1" placeholder="" value="{{old('min_payment')??($restaurant->min_payment??'')}}">
  @error('min_payment')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Take-out facility available<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <select name="takeout" id="takeout" class="form-control" aria-label="Default select example"> 
                                    @foreach($homeDeliveryArray as $key=>$homeDelivery)
                                        @if(isset($restaurant->takeout) && $key == $restaurant->takeout)
                                            <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                        @elseif(old('takeout')== $key)
                                            <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                        @else 
                                            <option value="{{$key}}">{{$homeDelivery}}</option>
                                        @endif
                                    @endforeach
                                </select>
  @error('takeout')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group" style="display:none;">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Open status<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <select name="open_status" id="open_status" class="form-control" aria-label="Default select example"> 
                            @foreach($openStatusArray as $key=>$homeDelivery)
                                @if(isset($restaurant->open_status) && $key == $restaurant->open_status)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @elseif(old('open_status')== $key)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @else 
                                    <option value="{{$key}}">{{$homeDelivery}}</option>
                                @endif
                            @endforeach
                        </select>
  @error('open_status')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Our most popular cuisine type<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  @foreach($cuisineTypes as $key=>$cuisineType) 
                                @if(in_array($key,$restaurantCuisineTypes)) 
                                <div class="form-check">
                                    <input class="form-check-input" name="cuisine_type_id[]" value="{{$key}}" type="radio" id="{{ $key }}" required checked>
                                    <label class="form-check-label" for="cuisine type">
                                       {{$cuisineType}}
                                    </label>
                                </div> 
                                @elseif(old('cuisine_type_id')== $key) 
                                <div class="form-check">
                                    <input class="form-check-input" name="cuisine_type_id[]" value="{{$key}}" type="radio" id="{{ $key }}" required checked>
                                    <label class="form-check-label" for="cuisine type">
                                       {{$cuisineType}}
                                    </label>
                                </div> 
                                @else  
                                <div class="form-check">
                                    <input class="form-check-input" name="cuisine_type_id[]" value="{{$key}}" type="radio" id="{{ $key }}" required>
                                    <label class="form-check-label" for="cuisine type">
                                       {{$cuisineType}}
                                    </label>
                                </div> 
                                @endif
                                @endforeach 
  @error('cuisine_type_id')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror						
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Expensiveness<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <div class="form-check">
<input class="form-check-input" name="expensive" value="$" type="radio" id="expensive" required <?php if($restaurant->expensiveness == "$") { echo "checked"; }?> >
<label class="form-check-label" for="expensive type">
                                      $
                                    </label>
</div>
<div class="form-check">
<input class="form-check-input" name="expensive" value="$$" type="radio" id="expensive" required <?php if($restaurant->expensiveness == "$$") { echo "checked"; }?>>
                                    <label class="form-check-label" for="expensive type">
                                      $$
                                    </label>
</div>
<div class="form-check">
<input class="form-check-input" name="expensive" value="$$$" type="radio" id="expensive" required <?php if($restaurant->expensiveness == "$$$") { echo "checked"; }?>>
                                    <label class="form-check-label" for="expensive type">
                                       $$$
                                    </label>
</div>
  @error('expensiveness')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror						
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Notes(for customers)<span class="required">*</span></label>
 <div class="col-md-6 col-sm-6 ">
  <textarea name="notes" class="editor2" id="editor1" class="resizable_textarea form-control" >
                                  {{old('notes')??$restaurant->notes}}
                               </textarea>
  @error('notes')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

@php 
$chef_name = '';
if(isset($restaurantChef->chef_name) && $restaurantChef->chef_name != '') 
{  
$chef_name = $restaurantChef->chef_name;
} 

$chef_mobile = '';
if(isset($restaurantChef->chef_mobile) && $restaurantChef->chef_mobile != '') 
{  
$chef_mobile = $restaurantChef->chef_mobile;
} 

$chef_fb_link = '';
if(isset($restaurantChef->chef_fb_link) && $restaurantChef->chef_fb_link != '') 
{  
$chef_fb_link = $restaurantChef->chef_fb_link;
}

$chef_insta_link = '';
if(isset($restaurantChef->chef_insta_link) && $restaurantChef->chef_insta_link != '') 
{  
$chef_insta_link = $restaurantChef->chef_insta_link;
}
@endphp

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Chef Name</label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="chef_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Restaurant Chef') }}" value="{{old('chef_name')??$chef_name}}">
  @error('chef_name')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Chef Mobile</label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="chef_mobile"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Chef Mobile') }}" value="{{old('chef_mobile')??$chef_mobile}}">
  @error('chef_mobile')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Chef Facebook Link</label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="chef_fb_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Chef Facebook Link') }}" value="{{old('chef_fb_link')??$chef_fb_link}}">
  @error('chef_fb_link')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="item form-group">
 <label class="col-form-label col-md-3 col-sm-3 label-align" for="">Chef Instagram Link</label>
 <div class="col-md-6 col-sm-6 ">
  <input type="text" name="chef_insta_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('Chef Instagram Link') }}" value="{{old('chef_insta_link')??$chef_insta_link}}">
  @error('chef_insta_link')
  <div class="error-box" style="color: red">{{$message}}</div>
  @enderror
 </div>
</div>

<div class="ln_solid"></div>
<div class="item form-group">
					<div class="col-md-6 col-sm-6 offset-md-3">
						<button type="submit" class="btn btn-success">Update</button>
					</div>
				</div>

</form>

</div>
		</div>
	</div>
</div>



<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>

<script type="text/javascript">

    $(document).ready(function ()
    {
        var dates = ["29/06/2021"];

        $(function() {
        $("input[type=date]").datepicker({
        beforeShowDay: DisableDates
        });
        });

        $('.copy_btn').on('click', function() {
            var monday_open_time = $('input[name=monday_open_time').val();
            var monday_close_time = $('input[name=monday_close_time').val();

            $('.open_time').each(function (){
                $(this).val(monday_open_time);
            });

            $('.close_time').each(function (){
                $(this).val(monday_close_time);
            });
        });

        $('select[name="country_id"]').on('change',function(){
            var countryId = jQuery(this).val();
            if(countryId)
            {
                getCity(countryId);
            }
            else
            {
               $('select[name="city_id"]').empty();
            }
        });
		
    });

    @if( isset($restaurant->id) && $restaurant->id>0) 
        getCity({{$restaurant->country_id}},{{$restaurant->city_id}});
    @endif

$(".chosen-select").chosen({
    no_results_text: "Oops, nothing found!"
    });

(function(e, t, n, r) {
        if (e) return;
        t._appt = true;
        var i = n.createElement(r),
            s = n.getElementsByTagName(r)[0];
        i.async = true;
        i.src = '//dje0x8zlxc38k.cloudfront.net/loaders/s-min.js';
        s.parentNode.insertBefore(i, s)
    })(window._appt, window, document, "script")
	
function DisableDates(date) {
        var string = jQuery.datepicker.formatDate('dd-mm-yy', date);
        return [dates.indexOf(string) == -1];
        }

function createDate() {
    var el = $('<div class="date_div"></div>');
    el.html('<div class="row mb-2 holiday_block"> <div class="col-md-6"><div class="input-group date" data-provide="datepicker">    <input type="text" min="{{date(`Y-m-d`)}}" name="occasion_date[]" class="form-control" value=""> <div class="input-group-addon">    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M10 12C10.1978 12 10.3911 11.9414 10.5556 11.8315C10.72 11.7216 10.8482 11.5654 10.9239 11.3827C10.9996 11.2 11.0194 10.9989 10.9808 10.8049C10.9422 10.6109 10.847 10.4327 10.7071 10.2929C10.5673 10.153 10.3891 10.0578 10.1951 10.0192C10.0011 9.98063 9.80004 10.0004 9.61732 10.0761C9.43459 10.1518 9.27841 10.28 9.16853 10.4444C9.05865 10.6089 9 10.8022 9 11C9 11.2652 9.10536 11.5196 9.29289 11.7071C9.48043 11.8946 9.73478 12 10 12ZM15 12C15.1978 12 15.3911 11.9414 15.5556 11.8315C15.72 11.7216 15.8482 11.5654 15.9239 11.3827C15.9996 11.2 16.0194 10.9989 15.9808 10.8049C15.9422 10.6109 15.847 10.4327 15.7071 10.2929C15.5673 10.153 15.3891 10.0578 15.1951 10.0192C15.0011 9.98063 14.8 10.0004 14.6173 10.0761C14.4346 10.1518 14.2784 10.28 14.1685 10.4444C14.0586 10.6089 14 10.8022 14 11C14 11.2652 14.1054 11.5196 14.2929 11.7071C14.4804 11.8946 14.7348 12 15 12ZM10 16C10.1978 16 10.3911 15.9414 10.5556 15.8315C10.72 15.7216 10.8482 15.5654 10.9239 15.3827C10.9996 15.2 11.0194 14.9989 10.9808 14.8049C10.9422 14.6109 10.847 14.4327 10.7071 14.2929C10.5673 14.153 10.3891 14.0578 10.1951 14.0192C10.0011 13.9806 9.80004 14.0004 9.61732 14.0761C9.43459 14.1518 9.27841 14.28 9.16853 14.4444C9.05865 14.6089 9 14.8022 9 15C9 15.2652 9.10536 15.5196 9.29289 15.7071C9.48043 15.8946 9.73478 16 10 16ZM15 16C15.1978 16 15.3911 15.9414 15.5556 15.8315C15.72 15.7216 15.8482 15.5654 15.9239 15.3827C15.9996 15.2 16.0194 14.9989 15.9808 14.8049C15.9422 14.6109 15.847 14.4327 15.7071 14.2929C15.5673 14.153 15.3891 14.0578 15.1951 14.0192C15.0011 13.9806 14.8 14.0004 14.6173 14.0761C14.4346 14.1518 14.2784 14.28 14.1685 14.4444C14.0586 14.6089 14 14.8022 14 15C14 15.2652 14.1054 15.5196 14.2929 15.7071C14.4804 15.8946 14.7348 16 15 16ZM5 12C5.19778 12 5.39112 11.9414 5.55557 11.8315C5.72002 11.7216 5.84819 11.5654 5.92388 11.3827C5.99957 11.2 6.01937 10.9989 5.98079 10.8049C5.9422 10.6109 5.84696 10.4327 5.70711 10.2929C5.56725 10.153 5.38907 10.0578 5.19509 10.0192C5.00111 9.98063 4.80004 10.0004 4.61732 10.0761C4.43459 10.1518 4.27841 10.28 4.16853 10.4444C4.05865 10.6089 4 10.8022 4 11C4 11.2652 4.10536 11.5196 4.29289 11.7071C4.48043 11.8946 4.73478 12 5 12ZM17 2H16V1C16 0.734784 15.8946 0.48043 15.7071 0.292893C15.5196 0.105357 15.2652 0 15 0C14.7348 0 14.4804 0.105357 14.2929 0.292893C14.1054 0.48043 14 0.734784 14 1V2H6V1C6 0.734784 5.89464 0.48043 5.70711 0.292893C5.51957 0.105357 5.26522 0 5 0C4.73478 0 4.48043 0.105357 4.29289 0.292893C4.10536 0.48043 4 0.734784 4 1V2H3C2.20435 2 1.44129 2.31607 0.87868 2.87868C0.316071 3.44129 0 4.20435 0 5V17C0 17.7956 0.316071 18.5587 0.87868 19.1213C1.44129 19.6839 2.20435 20 3 20H17C17.7956 20 18.5587 19.6839 19.1213 19.1213C19.6839 18.5587 20 17.7956 20 17V5C20 4.20435 19.6839 3.44129 19.1213 2.87868C18.5587 2.31607 17.7956 2 17 2ZM18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18H3C2.73478 18 2.48043 17.8946 2.29289 17.7071C2.10536 17.5196 2 17.2652 2 17V8H18V17ZM18 6H2V5C2 4.73478 2.10536 4.48043 2.29289 4.29289C2.48043 4.10536 2.73478 4 3 4H17C17.2652 4 17.5196 4.10536 17.7071 4.29289C17.8946 4.48043 18 4.73478 18 5V6ZM5 16C5.19778 16 5.39112 15.9414 5.55557 15.8315C5.72002 15.7216 5.84819 15.5654 5.92388 15.3827C5.99957 15.2 6.01937 14.9989 5.98079 14.8049C5.9422 14.6109 5.84696 14.4327 5.70711 14.2929C5.56725 14.153 5.38907 14.0578 5.19509 14.0192C5.00111 13.9806 4.80004 14.0004 4.61732 14.0761C4.43459 14.1518 4.27841 14.28 4.16853 14.4444C4.05865 14.6089 4 14.8022 4 15C4 15.2652 4.10536 15.5196 4.29289 15.7071C4.48043 15.8946 4.73478 16 5 16Z" fill="#484848"/>   </svg>  </div>  </div> </div> <div class="col-md-5">  <input type="text" class="form-control" name="occasion_name[]" placeholder="occasion" value=""  required=""></div> <div class="col-md-1 text-center"> <button type="button" style="padding-top:21px;" onclick="removeSavedHoliday(`local`,this);" class="btn-close" aria-label="Close"></button></div> </div>');      

     
    $('.add_date_btn').remove();
    $('.create_date').append(el);

    } 

function removeSavedImage(id) {
      var image_id = id; 
      var delete_list = [];
      
      if (!delete_list.includes(image_id)) {    
      delete_list.push(image_id);

      var delete_list_string = $('input[name=delete_list]').val();
      
      $('input[name=delete_list]').val(delete_list_string + ',' + image_id);
      }
      $('#image_'+image_id).parent().remove(); 
             
    } 

function removeSavedHoliday(el_type,e) {
       
      var image_id = e.id; 
      var delete_list = [];
    
      if (image_id != '') {

      if (!delete_list.includes(image_id)) {    
      delete_list.push(image_id);

      var delete_list_string = $('input[name=delete_holiday_list]').val();
      
      $('input[name=delete_holiday_list]').val(delete_list_string + ',' + image_id);
      } 
      }

      $(e).parent().parent().remove();  
             
    } 

function getCity(countryId,cityId=0){
        jQuery.ajax({
            url : "{{ url('dropdown/getCity/') }}/"+countryId,
            type : "GET",
            dataType : "json",
            success:function(data)
            { 
                jQuery('select[name="city_id"]').empty();
                $('select[name="city_id"]').append('<option value="">City</option>');
                jQuery.each(data, function(key,value){
                    if(cityId==key)                  
                    $('select[name="city_id"]').append('<option selected value="'+ key +'">'+ value +'</option>');
                    else
                    $('select[name="city_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                });
            }
        });
    }

function preview_image(event) {
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);}

function previews_image(event) {
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('outputs_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);}

function previewss_image(event) {
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('outputss_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);}

function profile_preview_image(event) {
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('chef_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);}
 
</script>

<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script>
CKEDITOR.replace('editor1');
CKEDITOR.replace('editor2');
</script>

@endsection