	@extends('layouts.default')  
@section('content')
<div class="container-fluid">
    <div class="fix-width">
    @include('layouts.floor_management_left_menu')
        <!-- main -->
         <main role="main" class="main-box w-100 border-main-box report-chart">
               <!-- main header -->
               <div class="dis-header">
                  <div class="row align-items-center">
                    
					
					<div class="col-xl-6 col-md-6 pr-0">
                        @if(Auth::user()->type != 1)
                         <b style="font-size: 20px;">Bookings</b>
                        @endif
                     </div>
			
					 
<div class="col-xl-6 col-md-6 pr-0">
<div class="floor-list-block">
<button id="left-button">
<svg class="svg-inline--fa fa-angle-left fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M31.7 239l136-136c9.4-9.4 24.6-9.4 33.9 0l22.6 22.6c9.4 9.4 9.4 24.6 0 33.9L127.9 256l96.4 96.4c9.4 9.4 9.4 24.6 0 33.9L201.7 409c-9.4 9.4-24.6 9.4-33.9 0l-136-136c-9.5-9.4-9.5-24.6-.1-34z"></path></svg>
</button>
<ul class="floors--list" id="floors--scroll">

@foreach($restaurantFloorList as $restaurantFloor)
<li>
<a href="{{ url('changerestaurantfloor',$restaurantFloor->id) }}" class=" @php if($id_floor == $restaurantFloor->id) { echo 'active'; } @endphp default-floor floor_type ">{{$restaurantFloor->name}}</a>
</li>
@endforeach
							  			 
</ul>
<button id="right-button">
<svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg>
</button>
</div>
</div>
					  
					  
					  
					 
                  </div>
                </div>
                <!-- end  main header -->
                <!-- container-main -->
                <div class="container-main">
                    <div class="restaurants-table rev-list-view">
                        <div class="all-list-container">
                            <div class="lists-block">
							    
								@if(count($bookings_all) > 0)
                                @foreach($bookings_all as $key =>$booking)
                                <!-- Start rev-list-item -->
                                <div class="rev-list-item">
                                    <div class="rev-booking-time">
                                        <div class="rev-booking-time-content">
                                            <div class="time--slot">
											{{ date('h:i', strtotime($booking['for_time'])) }}
											</div>
                                            <span>{{ date('A', strtotime($booking['for_time'])) }}</span>
                                        </div>
                                    </div>
                                    <div class="rev-booking-main">
                                        <div class="rev-booking-main-content">
                                            <h4>{{$booking['Uname']}}</h4>
                                            <div class="res-mini-info">
                                                <div class="res-mini-info-guest-nuumber">
                                                    <img src="{{url('admin/imgs/guests.svg')}}" alt=""> {{$booking['no_of_person']}}
                                                </div>
                                                <div class="res-mini-info-table-nuumber">
                                                    <img src="{{url('admin/imgs/table.svg')}}" alt=""> Table: {{$booking['table_no']}}
                                                </div>
                                            </div>
                                        </div>
                                        
										
						<!--<div class="rev-booking--category">
                                            <svg width="24" height="24" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect width="18" height="18" rx="4" fill="#57A78A"></rect>
                                                <g clip-path="url(#clip0)">
                                                    <path d="M14.1771 8.44141H3.82289C3.64457 8.44141 3.5 8.58597 3.5 8.76429C3.5 9.97702 4.08128 11.1128 5.13679 11.9623C6.17178 12.7954 7.54377 13.2541 9 13.2541C10.4562 13.2541 11.8282 12.7953 12.8632 11.9623C13.9187 11.1128 14.5 9.97705 14.5 8.76429C14.5 8.58597 14.3554 8.44141 14.1771 8.44141Z" fill="white"></path>

                                                    <path d="M14.3871 4.82306C14.2518 4.7069 14.048 4.72234 13.9318 4.85759L12.6339 6.3685C12.7282 6.50658 12.8057 6.65474 12.8648 6.81056C12.9227 6.83538 12.9794 6.86288 13.035 6.8927L14.4216 5.2784C14.5378 5.14314 14.5224 4.93927 14.3871 4.82306Z" fill="white"></path>

                                                    <path d="M12.3367 7.31756C12.2365 6.72098 11.7775 6.24446 11.1901 6.11824C11.0967 5.39263 10.4749 4.83008 9.72435 4.83008C9.09574 4.83008 8.55755 5.22455 8.34438 5.77898C8.13102 5.66374 7.88988 5.60068 7.64238 5.60068C6.82752 5.60068 6.16458 6.26362 6.16458 7.07848C6.16458 7.08366 6.1646 7.08886 6.16467 7.09406C5.70011 7.1612 5.29816 7.42386 5.04456 7.79548H13.149C12.941 7.55653 12.6579 7.38466 12.3367 7.31756Z" fill="white">
                                                    </path>
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0">
                                                        <rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"></rect>
                                                    </clipPath>
                                                </defs>
                                            </svg>
                                        </div>-->
						<div class="icon {{$booking['Cname']}}">
						@switch($booking['Cname'])
                        @case("Breakfast")                                  
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @case("Lunch") 
                              <img src="{{url('admin/imgs/Lunch-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @case("Dinner")
                              <img src="{{url('admin/imgs/Dinner-icon.png')}}" alt="" width="22px">                                    
                        @break
                        @case("New_category")                                   
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                    
                        @break
                        @case("Brunch")                                   
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @default                                    
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                                                    
                        @endswitch
					    </div>
					 
                                    </div>
                                    <div class="rev-booking-note">
                                        <ul>
                                            <li>Allergy: {{ $booking['allergies'] }}</li>
                                            <li>Food Intolereance: {{$booking['intolerances']}}</li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End rev-list-item -->
                                @endforeach
                                @else
								<div style="text-align:center;">No Data Found</div>
								@endif 
								
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end container-main -->
            </main>
            <!-- end main -->

         </div>
      </div>
      <!-- end of footer -->



<script>
   const rightBtn = document.querySelector('#right-button');
   const leftBtn = document.querySelector('#left-button');

   rightBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft += 300;
     event.preventDefault();
   });

   leftBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft -= 300;
     event.preventDefault();
   });
</script>

@endsection

   