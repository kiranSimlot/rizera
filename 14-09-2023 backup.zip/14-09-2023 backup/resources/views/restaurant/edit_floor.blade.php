@extends('layouts.defaulteditf')
   
@section('content')

<div class="container-fluid">
   <div class="fix-width">
      @include('layouts.floor_management_left_menu')
      <!-- main -->
      <main role="main" class="main-box">
         <!-- main header -->
         <div class="dis-header">
            <div class="row" id="viewable-btn">
               <div class="col-xl-4 col-lg-12 pr-0">
                  <ul class="list-unstyled">
                     <li>
                        <i class="fa fa-times"></i>
                        <a href="{{url('restaurant-owner/restaurant/floorManagement')}}"  onclick="hideShowViewSection()">{{ __('owner.Close') }}</a>
                     </li>
                     <li>
                        <i class="fa fa-plus"></i> <a href="javascript:void(0);" onclick="createNewFloor()">{{ __('owner.Add Floor') }}</a>
                     </li>
                     
                     <li>
                        <i class="fa fa-trash-alt"></i> <a href="javascript:void(0);" onclick="deleteFloor()">{{ __('owner.Delete') }}</a>
                     </li>
                  </ul>
               </div>
               <div class="col-xl-8 col-lg-12 tabing-right d-flex">
                  <div class="floor-list-block">
                     <button id="left-button">
                        <i class="fas fa-angle-left"></i>
                     </button>
                     <ul class="floors--list" id="floors--scroll">
                              @foreach($restaurant_list as $restaurant)
                                    @if( $restaurant->type==1 )
                                       <li>
                                          <a href="javascript:void(0);" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)"  id="floor_type_{{$restaurant->id}}" class=" active default-floor floor_type ">{{$restaurant->name}}</a>
                                       </li>
                                    @else
                                       <li>
                                          <a href="javascript:void(0);" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class="floor_type ">{{$restaurant->name}}</a>
                                       </li>
                                    @endif
                              @endforeach       
                     </ul>
                     <button id="right-button">
                        <i class="fas fa-angle-right"></i>
                     </button>
                  </div>
                  <!-- Start 26-11-2021 -->
                     <!-- <ul class="list-nav-header 
                     @php if(count($restaurant_list) > 3) 
                          echo 'slider_tabing_top';
                     @endphp
                      list-unstyled">
                        <li>
                           @foreach($restaurant_list as $restaurant)
                                 @if( $restaurant->type==1 )
                                   <a href="javascript:void(0);" style="min-width: 80px;" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class=" active default-floor floor_type btn " >{{$restaurant->name}}</a>
                                 @else
                                   <a href="javascript:void(0);" style="min-width: 80px;" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class="floor_type btn btn-sm btn-secondary " >{{$restaurant->name}}</a>
                                 @endif
                           @endforeach
                        </li>
                     </ul> -->
                  <!-- Start 26-11-2021 -->

                  <!-- <ul class="list-nav-header list-unstyled">
                     <li id="floor-btn">
                           @foreach($restaurant_list as $restaurant)
                              @if( $restaurant->type==1 )
                                 <a href="javascript:void(0);" data-floor-name='{{$restaurant->name}}' data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class=" active default-floor floor_type btn ">{{$restaurant->name}}</a>
                              @else
                                 <a href="javascript:void(0);" data-floor-name='{{$restaurant->name}}' data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class="floor_type btn btn-sm btn-secondary ">{{$restaurant->name}}</a>
                              @endif
                           @endforeach
                     </li>
                  </ul> -->
                  <ul class="list-unstyled">
                     <li>
                        <a href="javascript:void(0);" class="text-success" onclick="saveDb()"> <i class="fa fa-check"></i>{{ __('owner.Save Floor') }}</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
         <!-- end  main header -->
         <!-- container-main -->
         <div class="container-main">
            <div style="text-align: center;">
               <canvas  id="graphCanvas" ondrop="drop(event)" ondragover="allowDrop(event)" width="550" height="600"></canvas>
            </div>
         </div>
         <!-- end container-main -->
      </main>
      <!-- end main -->
      @include('layouts.edit_floor_right_sidebar')
   </div>
</div>
<style type="text/css">
   #graphCanvas{
      border: 2px dotted #ff0000 !important;
   }
   @media screen and (max-width: 991px) {
      #graphCanvas {
         width: 100%;
         height: 100%;
      }
   }
</style>

<script type="text/javascript">
   var isDragValue = true;
   var restaurantIdValue = {{$restaurant_id}};
</script>

<!-- Start Floor-list-block -->
<script>
   const rightBtn = document.querySelector('#right-button');
   const leftBtn = document.querySelector('#left-button');

   rightBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft += 300;
     event.preventDefault();
   });

   leftBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft -= 300;
     event.preventDefault();
   });
</script>
<!-- End Floor-list-block -->
@endsection