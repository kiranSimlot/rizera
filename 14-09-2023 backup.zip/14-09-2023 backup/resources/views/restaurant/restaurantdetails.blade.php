@extends('layouts.admin')
@section('content')

<style type="text/css">
  .ad-store-det tr th:first-child {
    border-right: 1px solid rgba(0, 0, 0, 0.1);
    width: 30%;
  }
  .ad-store-det tbody {
    border: 1px solid rgba(0, 0, 0, 0.1);
  }
</style>

<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>

<div class="container-fluid">
<div class="row">
  <div class="col-12">
    <a href="{{Route('admin.restaurant.list')}}" class="btn btn-primary mb-2">Back</a>
  </div>
  <div class="col-12 ad-store-det">  
  <table class="table col-md-8">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant Information</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Restaurant Id</th>
      <td>{{$restaurant->id}}</td>
    </tr>
    <tr>
      <th scope="row">Restaurant Name</th>
      <td>{{$restaurant->name}}</td>
    </tr>
    <tr>
      <th scope="row">Owner Name</th>
      <td>{{$restaurant->getOwner->name}}</td>  
    </tr>
    <tr>
      <th scope="row">Mobile No</th>
      <td>{{$restaurant->mobile}}</td>
    </tr>
    <tr>
      <th scope="row">Email</th>
      <td>{{$restaurant->email}}</td>
    </tr>
    <tr>
      <th scope="row">Website </th>
      <td>{{$restaurant->website}}</td>
    </tr>  
  </tbody>
</table>
<table class="table col-md-8 mt-4">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant Address</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Permanent Address</th>
      <td>{{$restaurant->address}}</td>
    </tr>
    <tr>
      <th scope="row">City</th>
      <td>{{$restaurant->getCity->city_name}}</td>
    </tr>
    <tr>
      <th scope="row">Country</th>
      <td>{{$restaurant->getCountry->country_name}}</td>  
    </tr>
    <tr>
      <th scope="row">Notification Mobile No</th>
      <td>{{$restaurant->notification_mobiles}}</td>
    </tr>
    <tr>
      <th scope="row">Notification Email</th>
      <td>{{$restaurant->notification_emails}}</td>
    </tr> 
     <tr>
      <th scope="row">Open/Close</th>
      <td>
          @if(!empty($restaurant->getHour))
            @if( isset($restaurant->getHour->mon_to) )
              @if((($restaurant->getHour->mon_to >= date("H:i:s")) 
                    && ($restaurant->getHour->mon_from <= date("H:i:s")) 
                    && ('Monday' == date("l"))
                  )
                  || (($restaurant->getHour->tue_to >= date("H:i:s")) 
                    && ($restaurant->getHour->tue_from <= date("H:i:s")) 
                    && ('Tuesday' == date("l"))
                  ) 
                  || (($restaurant->getHour->wed_to >= date("H:i:s")) 
                    && ($restaurant->getHour->wed_from <= date("H:i:s"))
                    && ('Wednesday' == date("l"))
                  )
                  || (($restaurant->getHour->thu_to >= date("H:i:s"))
                    && ($restaurant->getHour->thu_from <= date("H:i:s"))
                    && ('Thursday' == date("l"))
                  )
                  || (($restaurant->getHour->fri_to >= date("H:i:s"))
                    && ($restaurant->getHour->fri_from <= date("H:i:s"))
                    && ('Friday' == date("l"))
                  )
                  || (($restaurant->getHour->sat_to >= date("H:i:s"))
                    && ($restaurant->getHour->sat_from <= date("H:i:s"))
                    && ('Saturday' == date("l"))
                  )
                  || (($restaurant->getHour->sun_to >= date("H:i:s"))
                    && ($restaurant->getHour->sun_from <= date("H:i:s"))
                    && ('Saturday' == date("l"))
                  )
              )
                Open 
              @else
                Close
              @endif
            @endif
          @else
                close
          @endif


      </td>
    </tr> 
  </tbody>
</table>
<table class="table col-md-8 mt-4">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant services</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Home Delivery</th>
      <td>
          @if($restaurant->home_delivery == 1)
            Yes
          @elseif($restaurant->home_delivery == 0)
            No
          @endif
      </td>
    </tr>
    <tr>
      <th scope="row">TakeOut</th>
      <td>@if($restaurant->takeout == 1)
            Yes
          @elseif($restaurant->takeout == 0)
            No
          @endif
      </td>
    </tr>
    <tr>
      <th scope="row">Facilities</th>
      <td>
          @foreach($restaurant->getFacilities as $facility)
            {{$name=$facility->facilities['name']}},
          @endforeach
      </td>  
    </tr>
    <tr>
      <th scope="row">Cuisine</th>
      <td>
          @foreach($restaurant->getCuisine as $cuisine)
            {{$cuisine->Cuisine['name']}}, 
          @endforeach
      </td>
    </tr>
    <tr>
      <th scope="row">Expensiveness</th>
      <td>{{$restaurant->expensiveness}}</td>
    </tr> 
  </tbody>
</table>

<table class="table col-md-8 mt-4">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant Details</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Restaurant Rating</th>
      <td>{{$restaurant->rating}}</td>
    </tr>
    <tr>
      <th scope="row">Verification</th>
      <td>@if($restaurant->verified == 1)
              Verified
          @elseif($restaurant->verified == 0)
              Not verified
          @endif
      </td>
    </tr>
  </tbody>
</table>

<table class="table col-md-8 mt-4">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant Details</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Notes</th>
      <td>@php echo htmlspecialchars_decode($restaurant->notes) @endphp</td>
    </tr>
    <tr>
      <th scope="row">About</th>      
      <td>@php echo htmlspecialchars_decode($restaurant->description) @endphp</td>
    </tr>
    <tr>
      <th scope="row">Online Booking Terms & Conditions</th>      
      <td>{{$restaurant->online_book_tnc}}</td>
    </tr>
    <tr>
      <th scope="row">Minimum Payment Required for Booking</th>      
      <td>{{$restaurant->min_payment}}</td>
    </tr>
    <tr>
      <th scope="row">Opening Hours</th>      
      <td>
          @php
          
          echo '<strong>Monday</strong> - ';
		  if($openingHours['mon_from'] != '')
		  {
          if(isset($openingHours['mon_from'])) { echo $openingHours['mon_from']; }
          echo ' to ';
          if(isset($openingHours['mon_to'])) { echo $openingHours['mon_to']; }
		  }
echo "<br />";
          echo '<strong>Tuesday</strong> - ';
		  if($openingHours['tue_from'] != '')
		  {
          if(isset($openingHours['tue_from'])) { echo $openingHours['tue_from']; }
          echo ' to ';
          if(isset($openingHours['tue_to'])) { echo $openingHours['tue_to']; }
		  }
echo "<br />";
          echo '<strong>Wednesday</strong> - ';
		  if($openingHours['wed_from'] != '')
		  {
          if(isset($openingHours['wed_from'])) { echo $openingHours['wed_from']; }
          echo ' to ';
          if(isset($openingHours['wed_to'])) { echo $openingHours['wed_to']; }
		  }
echo "<br />";
          echo '<strong>Thursday</strong> - ';
		  if($openingHours['thu_from'] != '')
		  {
          if(isset($openingHours['thu_from'])) { echo $openingHours['thu_from']; }
          echo ' to ';
          if(isset($openingHours['thu_to'])) { echo $openingHours['thu_to']; }
		  }
echo "<br />";
          echo '<strong>Friday</strong> - ';
		  if($openingHours['fri_from'] != '')
		  {
          if(isset($openingHours['fri_from'])) { echo $openingHours['fri_from']; }
          echo ' to ';
          if(isset($openingHours['fri_to'])) { echo $openingHours['fri_to']; }
		  }
echo "<br />";
          echo '<strong>Saturday</strong> - ';
		  if($openingHours['sat_from'] != '')
		  {
          if(isset($openingHours['sat_from'])) { echo $openingHours['sat_from']; }
          echo ' to ';
          if(isset($openingHours['sat_to'])) { echo $openingHours['sat_to']; }
		  }
echo "<br />";
          echo '<strong>Sunday</strong> - ';
		  if($openingHours['sun_from'] != '')
		  {
          if(isset($openingHours['sun_from'])) { echo $openingHours['sun_from']; }
          echo ' to ';
          if(isset($openingHours['sun_to'])) { echo $openingHours['sun_to']; }
          }
		  
          @endphp
      </td>
    </tr>
  </tbody>
</table>

<table class="table col-md-8 mt-4">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant Images</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Image</th>
      <td>
          @foreach($restaurant->getImages as $images)
            @if($images->doc_type == 1)
             <img src="{{URL::asset('storage').'/'.$images->image}}" alt="" width="100px" height="100px">
            @endif
          @endforeach
      </td>
    </tr>
    <tr>
      <th scope="row">Menu</th>      
      <td>
        @if(isset($menu_files)) 
                                    @if($menu_files->doc_type == 2)
                                    <object data="{{URL::asset('storage').'/'.$menu_files->image}}" type="application/pdf" width="100%" height="100%">
                                    {{URL::asset('storage').'/'.$menu_files->image}}
                                    </object> 
                                    @elseif($menu_files->doc_type == 1)  
                                    <img class="img-fluid" src="{{ asset('storage').'/'.$menu_files->image}}">  
                                    @endif
                           @endif
      </td>
    </tr>
  </tbody>
</table>

<table class="table col-md-8 mt-4">
  <thead class="thead-dark">
    <tr>
      <th scope="col" colspan="2">Restaurant Chef Details</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Chef Name</th>
      <td>@php if(isset($restaurantChef->chef_name) && $restaurantChef->chef_name != '') { echo $restaurantChef->chef_name; }  @endphp</td>
    </tr>
    <tr>
      <th scope="row">Chef Mobile</th>      
      <td>@php if(isset($restaurantChef->chef_mobile) && $restaurantChef->chef_mobile != '') { echo $restaurantChef->chef_mobile; }  @endphp</td>
    </tr>
    <tr>
      <th scope="row">Chef Facebook Link</th>      
      <td>@php if(isset($restaurantChef->chef_fb_link) && $restaurantChef->chef_fb_link != '') { echo $restaurantChef->chef_fb_link; }  @endphp</td>
    </tr>
    <tr>
      <th scope="row">Chef Instagram Link</th>      
      <td>@php if(isset($restaurantChef->chef_insta_link) && $restaurantChef->chef_insta_link != '') { echo $restaurantChef->chef_insta_link; }  @endphp</td>
    </tr>
    <tr>
      <th scope="row">Chef Profile Photo</th>      
      <td>
        @php 
        if(isset($restaurantChef->chef_image) && $restaurantChef->chef_image != '') 
         {  
          @endphp
            <img src="{{ asset('storage').'/'.$restaurantChef->chef_image}}" height="100px;">
          @php
         }  
        @endphp
      </td>
    </tr>
  </tbody>
</table>


  </div>
</div>
</div>
@endsection