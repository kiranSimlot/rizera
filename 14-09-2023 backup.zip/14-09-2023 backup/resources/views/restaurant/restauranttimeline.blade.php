@extends('layouts.default')  
@section('content')
<div class="container-fluid">
    <div class="fix-width">
    @include('layouts.floor_management_left_menu')
        <!-- main -->
         <main role="main" class="main-box w-100 border-main-box report-chart">
               <!-- main header -->
               <div class="dis-header">
                  <div class="row align-items-center">
                    <div class=" col-lg-6 text-left">

                        @if(Auth::user()->type != 1)
                         <b style="font-size: 20px;">Bookings Timeline</b>
                        @endif
                     </div>
                  </div>
                </div>
                <!-- end  main header -->
                
                        
						
@if(count($timelines_all) > 0 && isset($timelines_all[0]['name']) && $timelines_all[0]['name'] != '')
@foreach($timelines_all as $key =>$timeline)
<!-- container-main -->
<div class="container-main">
<div class="restaurants-table rev-list-view">
 <div class="time-booking-block">
  <div class="time-booking-heading">
   <h4>{{$timeline['name']}} <span class="small">({{$timeline['total_tables']}} Tables)</span></h4>
  </div>
  <div class="time-booking-tables-list-block">
   <div class="time-booking-table-name">
@if(count($timeline['floor_table_view_arr']) > 0)
    @php
	$len = 0;
	@endphp
@foreach($timeline['floor_table_view_arr'] as $key =>$floor_table_view)
    <div class="tn-block" style="top:@php echo $len.'px;'; @endphp">
     <span class="time-booking-table-order">{{$floor_table_view['table_no']}}</span>
     <span class="time-booking-table-capacity">{{$floor_table_view['capacity']}}</span>
    </div>
	@php
	$len = $len+44;
	@endphp
@endforeach
@else
   <!--<div style="text-align:center;">No Data Found</div>-->
@endif
   </div>
   <div class="time-booking-tables-list">
    <div class="times-heading-block">


@php
if(count($timeframes) > 0)
{
$tot = count($timeframes);
for($x = 0; $x < $tot; $x++) 
{
@endphp
      <ul class="times-hr-col">
        <li>
          <p class="hr-count">@php echo $timeframes[$x] @endphp</p>
        </li>
        <li>
          <p class="dot-sm"></p>
        </li>
        <li>
          <p class="dot-lg"></p>
        </li>
        <li>
          <p class="dot-sm"></p>
        </li>
      </ul>
@php
}
}
@endphp
      
      
    </div>


@if(count($timeline['floor_table_view_arr']) > 0)
@foreach($timeline['floor_table_view_arr'] as $key =>$floor_table_view)
    <div class="time-booking-table-timeline">
@if(count($floor_table_view['bookings']) > 0)
@php
//$len_another = 89;
@endphp
@foreach($floor_table_view['bookings'] as $key =>$booking)	

@php
$timestamp = strtotime($booking['for_time']);
$for_time = date('H:i', $timestamp); 
$start_date = date('Y-m-d '.$start_time.'');
$end_date = date('Y-m-d '.$for_time.'');
$hourdiff = (int)round((strtotime($end_date) - strtotime($start_date))/3600, 1);  
$len_another = 89;  
if($hourdiff != 0)
$len_another = ($len_another+(44*4*$hourdiff))    
@endphp
		
    <div class="time-booking-reservation-container" style="left:@php echo $len_another.'px;'; @endphp">
    <div class="time-booking-reservation-col">
<div class="reservation-cell">
	<div class="rev-booking-main-content">
		<h4>{{ $booking['Uname'] }}</h4>
		<div class="res-mini-info">
			<div class="res-mini-info-guest-nuumber">
				<img src="https://dev.rglabs.net/rizera-web-dev/admin/imgs/guests.svg" alt=""> {{ $booking['no_of_person'] }}
			</div>
			<div class="res-mini-info-table-nuumber">
				<img src="https://dev.rglabs.net/rizera-web-dev/admin/imgs/table.svg" alt=""> Table: {{ $floor_table_view['table_no'] }}
			</div>
		</div>
	</div>
	
	<!--<div class="rev-booking--category">
		<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
			<rect width="18" height="18" rx="4" fill="#57A78A"></rect>
			<g clip-path="url(#clip0)">
				<path d="M14.1771 8.44141H3.82289C3.64457 8.44141 3.5 8.58597 3.5 8.76429C3.5 9.97702 4.08128 11.1128 5.13679 11.9623C6.17178 12.7954 7.54377 13.2541 9 13.2541C10.4562 13.2541 11.8282 12.7953 12.8632 11.9623C13.9187 11.1128 14.5 9.97705 14.5 8.76429C14.5 8.58597 14.3554 8.44141 14.1771 8.44141Z" fill="white"></path>

				<path d="M14.3871 4.82306C14.2518 4.7069 14.048 4.72234 13.9318 4.85759L12.6339 6.3685C12.7282 6.50658 12.8057 6.65474 12.8648 6.81056C12.9227 6.83538 12.9794 6.86288 13.035 6.8927L14.4216 5.2784C14.5378 5.14314 14.5224 4.93927 14.3871 4.82306Z" fill="white"></path>

				<path d="M12.3367 7.31756C12.2365 6.72098 11.7775 6.24446 11.1901 6.11824C11.0967 5.39263 10.4749 4.83008 9.72435 4.83008C9.09574 4.83008 8.55755 5.22455 8.34438 5.77898C8.13102 5.66374 7.88988 5.60068 7.64238 5.60068C6.82752 5.60068 6.16458 6.26362 6.16458 7.07848C6.16458 7.08366 6.1646 7.08886 6.16467 7.09406C5.70011 7.1612 5.29816 7.42386 5.04456 7.79548H13.149C12.941 7.55653 12.6579 7.38466 12.3367 7.31756Z" fill="white">
				</path>
			</g>
			<defs>
				<clipPath id="clip0">
					<rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"></rect>
				</clipPath>
			</defs>
		</svg>
	</div>-->
	<!--<div class="icon {{$booking['Cname']}}" style="height: 25px; margin-top: 4px;">-->
	<div class="icon Breakfast" style="height: 25px; margin-top: 4px;">
						@switch($booking['Cname'])
                        @case("Breakfast")                                  
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @case("Lunch") 
                              <img src="{{url('admin/imgs/Lunch-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @case("Dinner")
                              <img src="{{url('admin/imgs/Dinner-icon.png')}}" alt="" width="22px">                                    
                        @break
                        @case("New_category")                                   
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                    
                        @break
                        @case("Brunch")                                   
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                     
                        @break
                        @default                                    
                              <img src="{{url('admin/imgs/Breakfast-icon.png')}}" alt="" width="22px">                                                                    
                        @endswitch
					    </div>
	
</div>
</div>
    </div>
@php
	//$len_another = ($len_another+(44*4));
	@endphp
@endforeach
@else
   <!--<div style="text-align:center;">No Data Found</div>-->
@endif 

	
    </div>
	
@endforeach
@else
   <!--<div style="text-align:center;">No Data Found</div>-->
@endif   


</div>
  </div>
 </div>
</div>
</div>
<!-- end container-main --> 
@endforeach
@else
<div style="text-align:center;">No Data Found</div>
@endif
						
						
                    
            </main>
            <!-- end main -->

         </div>
      </div>
      <!-- end of footer -->





@endsection

   