@extends('layouts.default')

    
@section('content')

<style>
    #mobile-box{
        display: none;
    }

        .disable:after {
          
            position: absolute;
            width: 100%;
            height: 100%;
            content: "";
            top: 0px;
            left: 0px;
            background-color: #dee2e654;

        }
         
    </style>
    <!-- Modal -->
<div class="modal fade" id="Add-New-Guest" tabindex="-1" role="dialog" aria-labelledby="Add-New-GuestLabel" aria-hidden="true">
  <div class="modal-dialog booking-modal" role="document">
    <div class="modal-content ">
      <div class="modal-header">
        <h5 class="modal-title" id="Add-New-GuestLabel">{{ __('owner.Add New Guest') }}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">        
         <form method="POST" action="{{ route('owner.restaurant.addgustuser') }}" style="margin: 20px;" >
            @csrf
            <div class="row">                             
               <div class="form-group col-md-12">
                  <label>{{ __('owner.Name') }}<span class="spanColor">*</span></label>
                  <input class="form-control" type="text" id="first_name" name="first_name"  onKeyPress="return ValidateAlpha(event);">
                     @error('first_name')
                    <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
               </div>
                 
          
             <div class="form-group col-md-12">
                  <label>{{ __('owner.Email') }}<span class="spanColor">*</span></label>
                  <input class="form-control" type="email" id="email" name="email" >
                     @error('email')
                    <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
               </div>
                 
               <div class="form-group col-md-12">
                  <label>{{ __('owner.Mobile') }}<span class="spanColor">*</span></label>
                  <input class="form-control" type="number" id="mobile" name="mobile"  onkeypress="return isNumberKey(event)">
                      @error('mobile')
                    <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
               </div>
               
                  <div class="form-group col-md-12 mb-0">
                  <button class="btn  btn-black w-100">{{ __('owner.Save_Details') }}</button>
               </div>
            </div>
         </form>
      </div>      
    </div>
  </div>
</div>

    <div class="container-fluid">
        <div class="fix-width">
            @include('layouts.floor_management_left_menu')     
            <main role="main" class="main-box w-100 border-main-box">      
                <!------------------------------------------------------------------------------------->
                <!-- container-main -->
                <div class="container-main p-0">
                   <div class="Search_here_Guests-Profile row">
                      <div class="left_Search_here_Guests col-md-8 col-lg-8" onclick="testPreeti()">
                         <div class="header-guest-booking">
                             <div class="left">
                                <h3>{{ __('owner.Guest Booking') }}</h3>
                             </div>
                             <div class="right">
                               <a href="#"  data-toggle="modal" data-target="#Add-New-Guest" class="btn btn-add-guest">{{ __('owner.Add New Guest') }}</a>
                           </div>
                         </div>
                             @if(Session::has('success'))
                                <div class="alert alert-success " role="alert" style="margin:1rem;">
                                    {{Session::get('success')}}
                                </div>
                                @elseif(Session::has('error'))
                                <div class="alert alert-danger " role="alert" style="margin:1rem;">
                                    {{Session::get('error')}}
                                </div>
                                @endif
                        <div class="search_here mw-100">
                           <div class="form-group">
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                               <path d="M13.5325 12.4675L10.9825 9.925C11.8052 8.87684 12.2517 7.58249 12.25 6.25C12.25 5.06331 11.8981 3.90328 11.2388 2.91658C10.5795 1.92989 9.64246 1.16085 8.5461 0.706725C7.44975 0.2526 6.24335 0.13378 5.07946 0.365291C3.91558 0.596802 2.84648 1.16825 2.00736 2.00736C1.16825 2.84648 0.596802 3.91558 0.365291 5.07946C0.13378 6.24335 0.2526 7.44975 0.706725 8.5461C1.16085 9.64246 1.92989 10.5795 2.91658 11.2388C3.90328 11.8981 5.06331 12.25 6.25 12.25C7.58249 12.2517 8.87684 11.8052 9.925 10.9825L12.4675 13.5325C12.5372 13.6028 12.6202 13.6586 12.7116 13.6967C12.803 13.7347 12.901 13.7544 13 13.7544C13.099 13.7544 13.197 13.7347 13.2884 13.6967C13.3798 13.6586 13.4628 13.6028 13.5325 13.5325C13.6028 13.4628 13.6586 13.3798 13.6967 13.2884C13.7347 13.197 13.7544 13.099 13.7544 13C13.7544 12.901 13.7347 12.803 13.6967 12.7116C13.6586 12.6202 13.6028 12.5372 13.5325 12.4675ZM1.75 6.25C1.75 5.35999 2.01392 4.48996 2.50839 3.74994C3.00286 3.00992 3.70566 2.43314 4.52793 2.09254C5.35019 1.75195 6.25499 1.66284 7.12791 1.83647C8.00082 2.0101 8.80265 2.43869 9.43198 3.06802C10.0613 3.69736 10.4899 4.49918 10.6635 5.3721C10.8372 6.24501 10.7481 7.14981 10.4075 7.97208C10.0669 8.79435 9.49009 9.49715 8.75007 9.99162C8.01005 10.4861 7.14002 10.75 6.25 10.75C5.05653 10.75 3.91194 10.2759 3.06802 9.43198C2.22411 8.58807 1.75 7.44348 1.75 6.25Z" fill="#939393"/>
                               </svg>
                               
                              <input type="text" id="user_search" class="" placeholder="{{ __('owner.Search_by_name_email_or_phone') }}" />
                           </div>
                        </div>
                        <div class="left_Search_here_Guests_list">
                           <div class="guest_booking-block ">

                              @foreach($userlist as $key => $value)

                                <div class="guest_booking-card hover-overlay {{old('user_id') == $value['user_id']?'active':''}} " id="box_no-{{$value['user_id']}}"  data-user-id="{{$value['user_id']}}">
                                    <div class="left">
                                        <div class="guest_booking-card_left">
                                            <div class="guest_booking-card_img">
                                            <!-- <img src="imgs/lg.svg" alt="" /> -->
                                            @if(!empty($value['image']) && file_exists('storage/'.$value['image']))
                                
                                             <img src="{{ asset('storage').'/'.$value['image']}}" alt="" />
                                            @else
                                           <img src="{{ asset('front/imgs/placeholder.png') }}" >
                                            @endif
                                           
                                            </div>
                                            <div class="guest_booking-card_left_body">
                                                <h4 id="guest_booking-card_user_name">{{$value['name']}}</h4>
                                                <p id="guest_booking-card_user_mobile">{{$value['mobile']}}</p>
                                                <p id="guest_booking-card_user_email">{{$value['email']}}</p>
                                                <p id="guest_booking-card_user_foodintolerance" style="display:none;">{{$value['userFoodIntolerance']}}</p>
                                                <p id="guest_booking-card_user_foodallergy" style="display:none;">{{$value['userAllergy']}}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right">
                                        <h5>{{ __('owner.Total_Bookings') }}:<b>{{$value['total_record']}}</b></h5>
                                        <h6> <span>{{ __('owner.Visit') }}: <b>{{$value['visit']}}</b></span>   <span> {{ __('owner.Cancelled') }}:<b> {{$value['cancel']}}</b></span> </h6>
                                    </div>
                                </div>                              
                              @endforeach                                                            
                              </div>
                        </div>
                      </div>
                      <div class="col-md-4 col-lg-4">
                        <div class="guest_booking-right-form disable">
                           <div class="title d-flex justify-content-between">
                            <h4 id="select_user_name"></h4>
                            <span id="select_user_mobile" class="nub-link"><span>
                           </div>
                           <form method="POST" action="{{ route('owner.restaurant.bookadduser') }}">
                           @csrf
                              <div class="row">
                              <div class="form-group col-md-12">
                                 <label>{{ __('owner.Booking Time') }}<span class="spanColor">*</span></label>
                                  @if(old('for_time'))
                                 <input class="form-control" type="time" name="for_time" id="for-time" value="{{old('for_time')}}">
                                   @else
                                    <input class="form-control" type="time" name="for_time" id="for-time" >
                                   @endif
                                  @error('for_time')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                              </div>
                              <div class="form-group col-md-12">
                                
                                 <label>{{ __('owner.Booking Date') }}<span class="spanColor">*</span></label>
                             
                                    @if(old('for_time'))
                                 <input class="form-control" type="date" name="for_date" id="for-date" value="{{old('for_date')}}" >
                                     @else
                                      <input class="form-control" type="date" name="for_date" id="for-date"  >
                                  @endif
                                  @error('for_date')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-12">
                               <label>{{ __('owner.No of Person') }}</label>
                               <div class="quantity-block">
                                  <span class="quantity-arrow-minus"  id="decrease" onclick="decreaseValue()">
                                    <svg width="12" height="2" viewBox="0 0 12 2" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M10.6667 1.66683H1.33341C1.1566 1.66683 0.987035 1.59659 0.86201 1.47157C0.736986 1.34654 0.666748 1.17697 0.666748 1.00016C0.666748 0.823352 0.736986 0.653783 0.86201 0.528758C0.987035 0.403734 1.1566 0.333496 1.33341 0.333496H10.6667C10.8436 0.333496 11.0131 0.403734 11.1382 0.528758C11.2632 0.653783 11.3334 0.823352 11.3334 1.00016C11.3334 1.17697 11.2632 1.34654 11.1382 1.47157C11.0131 1.59659 10.8436 1.66683 10.6667 1.66683Z" fill="black"/>
                                    </svg>
                                  </span>

                                @if(old('no_of_person'))
                                 <input name="no_of_person" id="no-of-person" class="quantity-num" type="number" value="{{old('no_of_person')}}" />
                                        @else
                                          <input name="no_of_person" id="no-of-person" class="quantity-num" type="number" value="1" />
                                        @endif
                                 <span class="quantity-arrow-plus" id="increase" onclick="increaseValue()"> 
                                   <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.21875 8.96875H7.03125V14.7812C7.03125 15.3155 7.46573 15.75 8 15.75C8.53427 15.75 8.96875 15.3155 8.96875 14.7812V8.96875H14.7812C15.3155 8.96875 15.75 8.53427 15.75 8C15.75 7.46573 15.3155 7.03125 14.7812 7.03125H8.96875V1.21875C8.96875 0.68448 8.53427 0.25 8 0.25C7.46573 0.25 7.03125 0.68448 7.03125 1.21875V7.03125H1.21875C0.68448 7.03125 0.25 7.46573 0.25 8C0.25 8.53427 0.68448 8.96875 1.21875 8.96875Z" fill="#484848"/>
                                    </svg>
                                  </span>
                               </div>
                                    @error('no_of_person')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-12">
                              <label>{{ __('owner.Booking Status') }}<span class="spanColor">*</span></label>
                              <select class="form-control" name="booking_status" id="booking-status">
                                  <option value="">{{ __('owner.Select status') }}</option>
                                  <option value="0" @if (old('booking_status') == '0') selected="selected" @endif  >{{ __('owner.Pending') }}</option>
                                  <option value="1" @if (old('booking_status') == '1') selected="selected" @endif  >{{ __('owner.Confirm') }}</option>                                      
                              </select>
                                    @error('booking_status')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                           <div class="form-group col-md-12">
                              <label>{{ __('owner.Category') }}<span class="spanColor">*</span></label>
                              <select class="form-control" name="category_id" id="category-id">
                                    <option value="" >{{ __('owner.Select Category') }}</option>                                    
                                    @foreach  ($categories as $key => $value)
                                      
                                            @if (old('category_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach 
                                </select>
                                    @error('category_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                           <div class="form-group col-md-12 allergy" >
                                <p style="color:#ff0000;" class="mb-0">Allergy:</p> 
                                <span id="select_user_allergy" class="nub-link"><span></div>
                            <div class="form-group col-md-12 intolerance" >
                                <p style="color:#ff0000;" class="mb-0">Food Intolereance:</p>
                                <span id="select_user_intolerance" class="nub-link"><span></div>
                            <div class="form-group col-md-12">
                              <label>{{ __('owner.Event') }}</label>
                              <select class="form-control" name="tag_id" id="tag-id">
                                    <option value="">{{ __('owner.Select tag') }}</option>                                    
                                    @foreach  ($tags as $key => $value)
                                       
                                            @if (old('tag_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}" >{{$value}}</option>
                                        @endif
                                    @endforeach 
                                </select>
                                 
                           </div>
                           <div class="form-group col-md-12">
                              <label>{{ __('owner.Select Floor') }}<span class="spanColor">*</span></label>
                              <select class="form-control" name="floor_id" id="floor-id">
                                    <option value="">{{ __('owner.Select Floor') }}</option>
                                    @foreach  ($floors as $key => $value)
                                         @if (old('floor_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach                                   
                                </select>
                                   @error('floor_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                           <div class="form-group col-md-12" id='table_box'>
                              <label>{{ __('owner.Choose Table Number') }}</label>
                              <select class="form-control" id='table-no' name='table_no'>
                                <option value=''>-- {{ __('owner.Select Table') }} --</option>
                                </select>
                                 @error('table_no')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>

                            
                             <div class="form-group col-md-12">
                               <input class="form-control" type="hidden" id="user_id" name="user_id" value="{{old('user_id')}}">
                              <input class="form-control" type="hidden" id="res_id" name="res_id" value="{{$restaurant_id}}">
                              <button class="btn  btn-black w-100" type="submit">{{ __('owner.Create Reservation') }}</button>
                           </div>
                           </div>
                           </form>
                        </div>
                     </div>
                   </div>
                
      
                </div>
               <!-- end container-main -->
                
                <!------------------------------------------------------------------------------------->
            </main>
        </div>
    </div>



<script>
$(document).ready(function(){

            

    $(document).on("change", "#floor-id", function () {
        var floor_id = this.value;
        console.log(floor_id);

        let = modalHtml = "";
        let  optionValue = "";
        let tableDropDown = "";

       if(floor_id > 0){
            $.ajax({
                url: "{{url('/restaurant-owner/restaurant/tablelistbyfloorid')}}",
                type: "POST",
                data: {
                    floor_id: floor_id,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {                          
                    $("#table_id").html('');                       
                    let tableList = JSON.parse(result.table_list.floor_table_view);
                    selectedDropDownFloorTableDetail = tableList;
                    console.log(tableList);                    
                    let tableno = 0;
                    if (tableList != null) {
                        optionValue = "<option value='0'>-- Select table --</option>";            
                                
                            for (var num = 0; tableList.length > num; num++) {      
                                optionValue +=
                                    "<option data-table-no='" +
                                    tableList[num].table_no +
                                  
                                    "'value='"+
                                    tableList[num].table_id +
                                    "'>" +
                                    tableList[num].table_no +
                                    " Capacity : " +
                                    tableList[num].capacity +
                                    " min : " +
                                    tableList[num].min_capacity +
                                    " max : " +
                                    tableList[num].max_capacity +
                                    "</option>";
                                tableno = tableList[num].table_no;
                                tableId = tableList[num].table_id;

                            }  

                        
                        // console.log(dd);
                            
                            tableDropDown = "<select class='form-control'  id='table_id' name='table_id'>" +
                            optionValue +
                            "</select><input type='hidden' name='table_no'  id='table_no'><input type='hidden' name='table_detail'  id='table_detail'>";                           
                            modalHtml = "<label>Choose Table Number</label>" + tableDropDown ;
                            $("#table_box").html(modalHtml);
                        } 
                }
            });

       }else{
                optionValue = "<option value='0'>-- Select table --</option>";
                let tableDropDown = "<select class='form-control'  id='table_id' name='table_id'>" +
                            optionValue +
                            "</select>";                           
                            modalHtml = "<label>Choose Table Number</label>" + tableDropDown ;
                            $("#table_box").html(modalHtml);
       }      
    });

    $(document).on("change", "#table_id", function () {
        var data_table_no = $('option:selected', this).attr('data-table-no');
        var tableId = $('option:selected', this).attr('value');
        let table_detail = createTableObjArr(tableId);
        let dd=JSON.stringify(table_detail);
        console.log(dd);
        $('#table_no').val(data_table_no);
        $('#table_detail').val(dd);
    });


    function createTableObjArr(tableId){
        selectedTableObjArr=[];
            for(let tempNum=0; selectedDropDownFloorTableDetail.length>tempNum; tempNum++){
                let objImg = selectedDropDownFloorTableDetail[tempNum];
                if( parseInt(tableId) == parseInt(objImg.table_id) ){
                    selectedTableObjArr.push({
                            table_id:objImg.table_id,
                            table_no:objImg.table_no,
                            max_capacity:objImg.max_capacity,
                            min_capacity:objImg.min_capacity,
                        });               
                }
            }
        return selectedTableObjArr;
    }


    var result = $('.guest_booking-card');
    $(document).on("click", ".guest_booking-card", function () {
        selectUser($(this));
    });
    <?php if( old('user_id')!==null && old('user_id')>0){ ?>
        var selectedUserId = <?php echo old('user_id') ?>;
        $(document).ready(function(){
            document.getElementById("box_no-"+selectedUserId).click();
        });   
    <?php } ?>

    function selectUser(obj){
        var select_user_id = obj.attr("data-user-id");       
        var user_id = $("#user_id").val(select_user_id);
        // $("#box_no-"+select_user_id).toggleClass("active");
        $(".guest_booking-card").removeClass("active");
        obj.addClass("active");  

        //  $(".guest_booking-right-form").toggleClass("disable");
        $(".guest_booking-right-form").removeClass("disable");
        // $(".guest_booking-right-form").addClass("disable");  
        var select_user_name = obj.find('#guest_booking-card_user_name').text();
        var select_user_mobile = obj.find('#guest_booking-card_user_mobile').text();
        var select_user_email = obj.find('#guest_booking-card_user_email').text();
        var select_user_intolerance = obj.find('#guest_booking-card_user_foodintolerance').text();
        var select_user_allergy = obj.find('#guest_booking-card_user_foodallergy').text();



        if ($("#box_no-"+select_user_id).hasClass("active")){
            $("#select_user_name").text(select_user_name);
            $("#select_user_mobile").text(select_user_mobile);
            $("#select_user_allergy").text(select_user_allergy);
            $("#select_user_intolerance").text(select_user_intolerance);
             $(".allergy, .intolerance").css("display", "block");
        }else{ 
            $("#select_user_name").text('');
            $("#select_user_mobile").text('');  
            $("#select_user_allergy").text('');  
            $("#select_user_intolerance").text('');  
        }
    }
     

   
    $(document).on('keypress',"#user_search",function(e) {
        if(e.which == 13) {
          var serchdata = $(this).val();
          
          $.ajax({
            url: "{{url('/restaurant-owner/restaurant/bookingby')}}",
                type: "POST",
                data: {
                  serchdata: serchdata,
                    _token: '{{csrf_token()}}'
                },           
                success: function (result) {     
                    //hideMessageBox();
                    if (result.status) {                          
                        let userinfo = JSON.stringify(result.data)
                        let user = JSON.parse(userinfo);     
                         $("#user_id").val(user.id);
                         $("#select_user_name").text(user.name);
                         $("#select_user_mobile").text(user.mobile);

                    }else{
                        $('#Add-New-Guest').modal('show'); 
                    }
                   

                }

          });
        }
    });

    $(document).on('keyup',"#user_search", function() {
    var search = $(this).val().toLowerCase();
    //Go through each list item and hide if not match search

    $(".guest_booking-card").each(function() {
	
        if ($(this).html().toLowerCase().indexOf(search) != -1) {
            $(this).show();
        }
        else {
            $(this).hide();  
        } 
    });
	
    $(".guest_booking-card:visible").each(function(index) {
				
         if(index == 0){
             $(this).css("border-top-left-radius", "10px");
             $(this).css("border-top-right-radius", "10px");

			//  $(".title_lable").each(function() {
			// 	$(".title_lable").show();
			// });

         }
         if(index == $(".list-group-item:visible").length - 1){
             $(this).css("border-bottom-left-radius", "10px");
             $(this).css("border-bottom-right-radius", "10px");

			//  $(".title_lable").each(function() {
			// 	$(".title_lable").hide();
			// });	
         }
     });
    
    });


});

    function increaseValue() {
         $('#no-of-person').click( function() {
            var counter = $('#no-of-person').val();
            counter++ ;
            $('#no-of-person').val(counter);
           
    });
      
    }
    function decreaseValue() {
    $('#no-of-person').click( function() {
            var counter = $('#no-of-person').val();
            counter-- ;
            $('#no-of-person').val(counter);
    });
    }
  
function testPreeti()
{
    // alert('testPreeti');
    $(".guest_booking-card").removeClass('active');
    $("#select_user_name").text('');
    $("#select_user_mobile").text('');
    $(".guest_booking-right-form").addClass('disable');
}

</script>


<script type="text/javascript">
   
   function isNumberKey(evt){  
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }
         
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }

</script>

<script type="text/javascript">
    $('#submit').click(function() {
    $.ajax({
        url: 'send_email.php',
        type: 'POST',
        data: {
            email: 'email@example.com',
            message: 'hello world!'
        },
        success: function(msg) {
            alert('Email Sent');
        }               
    });
});

    $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);

    //alert(maxDate);
    $('#for-date').attr('min', maxDate);
});

      // $(function(){
      //   var dtTime = new Date();
      //   var time = dtTime.getHours();
      //     console.log(time)
      //     //var year = 2016;

      //       $('#for-time').filter(function() {
      //           return $(this).val() < time;
      //       });
         
      //   });
</script>



@endsection


