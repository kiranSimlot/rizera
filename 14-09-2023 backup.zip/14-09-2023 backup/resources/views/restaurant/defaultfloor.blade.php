@extends('layouts.default')

    
@section('content')

<div class="container-fluid">
    <div class="fix-width">
    @include('layouts.floor_management_left_menu')
        <!-- main -->
        <main role="main" class="main-box">
            <div class="container">

                <form method="POST" action="{{ route('owner.restaurant.defaultfloor') }}" style="margin: 20px;" >
                @csrf
                    <div class="container-main">
                        <div class="add-restaurant-form">                       
                            <div class="d-inline">
                                <a href="{{route('owner.restaurant.list')}}" class="btn btn-black">{{ __('owner.Back') }}</a>  
                            </div>
                            <div class="d-inline">
                                <h2>{{ __('owner.Default Floor') }}</h2>                 
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <h4>{{ __('owner.Floor') }}</h4>
                                </div>
                                <div class="card-body"> 
                
                                    @foreach($restaurant_list as $restaurant)
                                   
                                    <div class="row">                            
                                            <div class="form-group col-md-3">                                
                                                <label style=" text-transform: capitalize;" for="{{$restaurant->name}}">{{$restaurant->name}}</label>
                                            </div>
                                            <div class="form-group col-md-3"> 
                                                @if( $restaurant->type==1 )
                                                    <input type="radio" value="{{$restaurant->id}}" id="email" name="defaultfloor" checked>
                                                @else
                                                    <input type="radio" value="{{$restaurant->id}}" id="email" name="defaultfloor">
                                                @endif                                                              
                                            </div>                            
                                        </div>
                        
                                        
                                    @endforeach    
                                                            
                                </div> 
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="hidden" id="res_id" name="res_id" value="{{$res_id}}">
                                <button class="btn  btn-primary">{{ __('owner.Save') }}</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </main>    
    </div>
</div>


@endsection