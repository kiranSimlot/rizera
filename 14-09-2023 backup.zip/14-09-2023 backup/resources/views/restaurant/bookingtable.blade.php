@extends('layouts.default')

    
@section('content')

<style>
    #mobile-box{
        display: none;
    }
</style>

    <div class="container-fluid">
        <div class="fix-width">
            @include('layouts.floor_management_left_menu')
            <!------------------------------------------------------------------------------------->
            <div class="container">
                <div class="booking-modal pt-5">
                    <div class="col-md-12"><h1>{{ __('owner.Add Booking') }}</h1> </div>
                    <div class="nub-top">
                        <h3>{{$userdata->name}}</h3>
                        @if($userdata->mobile)
                            <a href="" class="nub-link">{{$userdata->mobile}}</a>
                        @else
                            <a href="" class="nub-link">{{$userdata->email}}</a>
                        @endif
                    </div>
                    <form method="POST" action="{{ route('owner.restaurant.bookadduser') }}" style="margin: 20px;" >
                        @csrf
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Booking Time') }}</label>
                                <input class="form-control" type="time" name="for_time" id="for-time" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Booking Date') }}</label>
                                <input class="form-control" type="date" name="for_date" id="for-date"  required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.No of Person') }}</label>
                                <select class="form-control" name="no_of_person" id="no-of-person" required>
                                    <option value="">{{ __('owner.Select Person') }}</option>
                                    @for ($i = 1; $i < 21; $i++)
                                    <option value="{{$i}}">{{$i}}</option>
                                    @endfor
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Booking Status') }}</label>
                                <select class="form-control" name="booking_status" id="booking-status">
                                    <option value="0">{{ __('owner.Pending') }}</option>
                                    <option value="1">{{ __('owner.Confirm') }}</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Category') }}</label>
                                <select class="form-control" name="category_id" id="category-id">
                                    <option value="">{{ __('owner.Select Category') }}</option>                                    
                                    @foreach  ($categories as $key => $value)
                                        <option value="{{$key}}">{{$value}}</option>
                                    @endforeach 
                                </select>
                            </div>
                            
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Event') }}</label>
                                <select class="form-control" name="tag_id" id="tag-id">
                                    <option value="">{{ __('owner.Select tag') }}</option>                                    
                                    @foreach  ($tags as $key => $value)
                                        <option value="{{$key}}">{{$value}}</option>
                                    @endforeach 
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Floor') }}</label>
                                <select class="form-control" name="floor_id" id="floor-id">
                                    <option value="0">{{ __('owner.Select Floor') }}</option>
                                    @foreach  ($floors as $key => $value)
                                        <option value="{{$key}}">{{$value}}</option>
                                    @endforeach                                   
                                </select>
                            </div>
                            <div class="form-group col-md-6" id='table_box'>
                                <label>{{ __('owner.Table No') }}</label>
                                <select class="form-control" id='table_no' name='table_no'>
                                    <option value='0'>-- {{ __('owner.Select Table') }} --</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">                         
                             <div class="form-group col-md-12">
                             <input class="form-control" type="hidden" id="user_id" name="user_id" value="{{$userdata->id}}">
                             <input class="form-control" type="hidden" id="res_id" name="res_id" value="{{$resid}}">
                              <button class="btn  btn-black w-100">{{ __('owner.Save') }}</button>
                           </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- dd({{$userdata}}) -->
        
            
            <!------------------------------------------------------------------------------------->
        </div>
    </div>


<script>
$(document).ready(function(){

    $(document).on("change", "#floor-id", function () {
        var floor_id = this.value;
        console.log(floor_id);

        let = modalHtml = "";
        let  optionValue = "";
        let tableDropDown = "";

       if(floor_id > 0){
            $.ajax({
                url: "{{url('/restaurant-owner/restaurant/tablelistbyfloorid')}}",
                type: "POST",
                data: {
                    floor_id: floor_id,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {                          
                    $("#table_id").html('');                       
                    let tableList = JSON.parse(result.table_list.floor_table_view);
                    console.log(tableList);                    
                    let tableno = 0;
                    if (tableList != null) {
                        optionValue = "<option value='0'>-- Select table --</option>";            
                                
                            for (var num = 0; tableList.length > num; num++) {      
                                optionValue +=
                                    "<option data-table-no='" +
                                    tableList[num].table_no +
                                    "' value='"+
                                    tableList[num].table_id +
                                    "'>" +
                                    tableList[num].table_no +
                                    " Capacity : " +
                                    tableList[num].capacity +
                                    " min : " +
                                    tableList[num].min_capacity +
                                    " max : " +
                                    tableList[num].max_capacity +
                                    "</option>";
                                tableno = tableList[num].table_no;

                            }   

                            tableDropDown = "<select class='form-control'  id='table_id' name='table_id'>" +
                            optionValue +
                            "</select><input type='hidden' name='table_no'  id='table_no'>";                           
                            modalHtml = "<label>Table No</label>" + tableDropDown ;
                            $("#table_box").html(modalHtml);
                        } 
                }
            });

       }else{
                optionValue = "<option value='0'>-- Select table --</option>";
                let tableDropDown = "<select class='form-control'  id='table_id' name='table_id'>" +
                            optionValue +
                            "</select>";                           
                            modalHtml = "<label>Table No</label>" + tableDropDown ;
                            $("#table_box").html(modalHtml);
       }      
    });

    $(document).on("change", "#table_id", function () {
        var data_table_no = $('option:selected', this).attr('data-table-no');
        $('#table_no').val(data_table_no);
    });

    
 
});



</script>
<!-- method="POST" action="{{ route('register') }}">  @csrf -->

@endsection


