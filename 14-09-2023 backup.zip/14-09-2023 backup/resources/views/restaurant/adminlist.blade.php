@extends('layouts.admin')
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
<div class="col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 ">

                <!-- <div class="row">

                  <div class="input-group mb-3 datedesign">
                    <input type="month" id="month" name="month" max="{{date('Y-m')}}" min="1970-01" class="form-control" >
                    <div class="input-group-append">
                      <button class="btn btn-outline-secondary" type="button" id="search">search</button>
                    </div>
                  </div>
                </div> -->
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Restaurant List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        <div class="col-sm-12">
                          
                          @if(session()->has('success'))
<div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                           <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">×</span>
                           </button>
                           <strong>Success!</strong> {{ \Session::get('success') }}.
                        </div>
@endif

                            <div class="card-box table-responsive">
                            <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                              <thead>
                                <tr>
								    <th data-searchable=false>S. No.</th>
                                    <!--<th>Id</th>-->
                                    <th>Restaurant Name</th>
                                    <th>Owner Account Name</th>
									<th>Country</th>
                                    <th>Cuisine</th>
                                    <th>Rating</th>
                                    <th data-searchable=false>Verification</th>
                                    <th data-searchable=false>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                              </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalContactForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold">Rejection Reason</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="{{route('admin.storereason')}}" enctype="multipart/form-data" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf
      <div class="modal-body mx-3">
        <div class="md-form">
          
          <textarea type="text" id="form8" class="md-textarea form-control" rows="4" name="rejection_reason" required></textarea>
		            @error('rejection_reason')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
          <input type="hidden" value="" name="hidden_id" class="hidden_id">
		  <input type="hidden" value="restaurant" name="url_change_to">
          <label data-error="wrong" data-success="right" for="form8">Your message</label>
        </div>

      </div>
      <div class="modal-footer d-flex justify-content-center">
         <button type="submit" class="btn btn-success" value="submit">Submit</button>
      </div>
    </form>
    </div>
  </div>
</div>


<script type="text/javascript">
$(document).ready(function() {
data();
    $("#search").click(function() {
      data();
    });

    function data (){
      $('#datatable').DataTable().clear().destroy();
      var month = $('#month').val();
      console.log(month);
      $('#datatable').DataTable({
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.restaurantdata') !!}',
             data : {"_token": "{{ csrf_token() }}",month:month}
           },
		   'columnDefs': [
                 { "targets": 5, "className": "text-center" },
                 { "targets": 6, "className": "text-center" }
              ],
           "columns": [
		      { "data": 'DT_RowIndex', orderable: false, searchable: false },
              /*{data:'Rid', name:'Rid'},*/
              {data:'Rname', name:'Rname'},
              {data:'Uname', name:'Uname'},
              {data:'COname', name:'COname'},
              {data:'Cname', name:'Cname'},
              {data:'Rating', name:'Rating'},
              {data:'verify', name:'verify'},
              {data:'actions', name:'actions'},
           ]
       });
    }
});
</script>
<script type="text/javascript">
  
  $('#datatable').on('click','.status',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.restaurant-status-update") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  });
  
  $('#datatable').on('click','.unreject',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.restaurant-reject-update") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  });

  $('#datatable').on('click','.verify',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.restaurant-verity-update") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  }); 

  $(document).on("click", ".reject", function () {
     var ids = $(this).attr('data-id');

    //alert(ids);
     $(".hidden_id").val( ids );
    });
  
</script>


@endsection

