@extends('layouts.default')

    
@section('content')

<div class="container-fluid">
    <div class="fix-width">
        @include('layouts.floor_management_left_menu')
        <!-- main -->

 <!-- main -->
 <main role="main" class="main-box w-100 border-main-box">
            <!-- main header -->
            <div class="dis-header">
               <div class="row">
                  <div class="col-xl-6 col-md-6 pr-0">
                   
                  </div>
            
                       <div class="col-xl-6 col-md-6 text-right">
                        <div class="floor-list-block">
                           <button id="left-button">
                              <i class="fas fa-angle-left"></i>
                           </button>
                           <ul class="floors--list" id="floors--scroll">
                                 <input type="hidden" name="floor_hidden_id" id="floor_hidden_id" value={{$default_floor}}>
                             @foreach($floorList as $key => $floor)
                              
                            
                                    @if( $floor->type==1 )
                                       <li  class="" id="{{$floor->id}}">
                                           <a href="{{ url('restaurant-owner/restaurant/restaurantsTimeSlot',[$floor->id,0]) }}" data-floor='{{$floor->id}}'  id="floor_type_{{$floor->id}}" class=" floor_type ">{{$floor->name}}</a>
                                          
                                       </li>
                                    @else
                                       <li  class="" id="{{$floor->id}}">
                                        <a href="{{ url('restaurant-owner/restaurant/restaurantsTimeSlot',[$floor->id,0]) }}" data-floor='{{$floor->id}}' id="floor_type_{{$floor->id}}" class="floor_type ">{{$floor->name}}</a>
                                       </li>
                                    @endif
                              @endforeach       
                           </ul>
                           <button id="right-button">
                              <i class="fas fa-angle-right"></i>
                           </button>
                        </div>
                     
                    </div> 

               </div>
            </div>
            <!-- end  main header -->
            <!-- container-main -->
            <div class="container-main p-0">
               <div class="Grid-View_header " id="main">

                  <ul class="nav nav-tabs" id="myTab" role="tablist">
             
             
                     <input type="hidden" name="category_hidden_id" id="category_hidden_id" value={{$category_id}}>
                     <li class="nav-item" role="presentation"  id="0">
                       <a class="nav-link" id="category_tab"  href="{{ url('restaurant-owner/restaurant/restaurantsTimeSlot',[$default_floor,0])}}" >all</a>
                     </li>
                 

                     @foreach($category as $key => $value)
                  
                     <li class="nav-item" role="{{$value->name}}" id="{{$value->id}}">
                      <a class="nav-link " href="{{ url('restaurant-owner/restaurant/restaurantsTimeSlot',[$default_floor,$value->id])}}" >{{$value->name}}</a>
                     </li>

                     @endforeach

                  </ul>
                  
                  <h4>Total Bookings: <span>{{$totalBookings}}</span></h4>
                  
               </div>

                         <!-- container-main -->
            <div class="container-main p-0">
            
             
               <div class="tab-content" id="myTabContent">
               <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
               <div class="Grid-View_body">
                  <!--  item -->
             
                  @foreach($rts as $value)
                     <div class="item">
                     <div class="time">
                       {{$value['start']}}
                     </div>
                       @foreach($value['minuteslots'] as $values)
                        <div class="item_card">

                        <div class="time_slote">
                           <div class="left">
                              <p> {{$values['start']}}</p>
                           </div>
                           <div class="right">
                           @if (!empty($values['bookings']))
                           @foreach($values['bookings']  as $bookings)
                         
                              <div class="card_sl_list">
                                 <h4>{{$bookings->user_name}}</h4>
                                 <div class="bt-abd">
                                    <h5><span>
                                          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                             <g clip-path="url(#clip0)">
                                                <path
                                                   d="M13.2041 9.15767C12.0039 8.40042 10.6297 7.98494 9.20959 7.90723C9.53793 8.06092 9.86292 8.22323 10.1711 8.41769C10.9137 8.88552 11.3751 9.73276 11.3751 10.6283V13.1251H14.0001V10.6283C14.0001 10.031 13.6951 9.46743 13.2041 9.15767Z"
                                                   fill="#939393" />
                                                <path
                                                   d="M9.70406 9.1571C7.04402 7.47888 3.45557 7.47888 0.796379 9.1571C0.305061 9.46642 0 10.03 0 10.6277V13.1245H10.5V10.6277C10.5 10.03 10.1949 9.46642 9.70406 9.1571Z"
                                                   fill="#939393" />
                                                <path
                                                   d="M7.87012 6.85508C8.15297 6.9407 8.44486 7.00004 8.75019 7.00004C10.4387 7.00004 11.8127 5.62601 11.8127 3.93753C11.8127 2.24905 10.4387 0.875 8.75019 0.875C8.44486 0.875 8.15297 0.934334 7.87012 1.01995C8.67263 1.74125 9.18769 2.77594 9.18769 3.93751C9.18769 5.09907 8.67266 6.13376 7.87012 6.85508Z"
                                                   fill="#939393" />
                                                <path
                                                   d="M7.41553 1.77199C8.61152 2.96798 8.61152 4.90702 7.41553 6.10301C6.21953 7.29901 4.28049 7.29901 3.0845 6.10301C1.8885 4.90702 1.8885 2.96798 3.0845 1.77199C4.28049 0.575991 6.21953 0.576019 7.41553 1.77199Z"
                                                   fill="#939393" />
                                             </g>
                                             <defs>
                                                <clipPath id="clip0">
                                                   <rect width="14" height="14" fill="white" />
                                                </clipPath>
                                             </defs>
                                          </svg>
                                          {{$bookings->no_of_person}}
                                       </span> <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                             <path
                                                d="M11.0229 7.00017C11.0229 9.34904 9.21388 11.2533 6.98246 11.2533C4.75103 11.2533 2.94202 9.34904 2.94202 7.00017C2.94202 4.6513 4.75103 2.74707 6.98246 2.74707C9.21388 2.74707 11.0229 4.6513 11.0229 7.00017Z"
                                                fill="#939393" />
                                             <path
                                                d="M7 0C3.13388 0 0 3.13388 0 7C0 10.8661 3.13388 14 7 14C10.8661 14 14 10.8661 14 7C13.9959 3.13572 10.8643 0.00414474 7 0ZM7 13.0246C3.6727 13.0246 0.975395 10.3273 0.975395 7C0.975395 3.6727 3.6727 0.975395 7 0.975395C10.3273 0.975395 13.0246 3.6727 13.0246 7C13.0209 10.3259 10.3259 13.0209 7 13.0246Z"
                                                fill="#939393" />
                                          </svg>
                                          Table: {{$bookings->table_updated}}
                                       </span></h5>
                                    <span>

                                       @switch($bookings->category_id)
                                             @case("Breakfast")                                  
                                                  
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect width="18" height="18" rx="4" fill="#57A78A"/>
                                                <g clip-path="url(#clip0_2383_2576)">
                                                <path d="M14.1771 8.44165H3.82289C3.64457 8.44165 3.5 8.58622 3.5 8.76454C3.5 9.97727 4.08128 11.113 5.13679 11.9626C6.17178 12.7956 7.54377 13.2544 9 13.2544C10.4562 13.2544 11.8282 12.7956 12.8632 11.9626C13.9187 11.113 14.5 9.97729 14.5 8.76454C14.5 8.58622 14.3554 8.44165 14.1771 8.44165Z" fill="white"/>
                                                <path d="M14.387 4.82355C14.2517 4.70739 14.0479 4.72283 13.9317 4.85808L12.6338 6.36899C12.7281 6.50707 12.8056 6.65522 12.8646 6.81105C12.9226 6.83586 12.9793 6.86336 13.0349 6.89318L14.4215 5.27889C14.5377 5.14363 14.5223 4.93976 14.387 4.82355Z" fill="white"/>
                                                <path d="M12.3371 7.31805C12.2369 6.72147 11.7779 6.24495 11.1904 6.11873C11.097 5.39311 10.4753 4.83057 9.72471 4.83057C9.0961 4.83057 8.55792 5.22504 8.34475 5.77947C8.13139 5.66422 7.89025 5.60117 7.64275 5.60117C6.82789 5.60117 6.16495 6.26411 6.16495 7.07897C6.16495 7.08415 6.16497 7.08935 6.16503 7.09455C5.70047 7.16169 5.29852 7.42435 5.04492 7.79597H13.1493C12.9414 7.55702 12.6583 7.38514 12.3371 7.31805Z" fill="white"/>
                                                </g>
                                                <defs>
                                                <clipPath id="clip0_2383_2576">
                                                <rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"/>
                                                </clipPath>
                                                </defs>
                                                </svg>
                                                                                
                                             @break
                                             @case("Lunch") 
                                                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                      <rect width="18" height="18" rx="4" fill="#D9A465"/>
                                                      <g clip-path="url(#clip0_2383_2744)">
                                                      <path d="M14.2139 12.8527L9.90057 8.53937L4.86119 3.5H4.46737L4.38695 3.70434C4.1747 4.24368 4.08402 4.79531 4.12473 5.29953C4.17114 5.87428 4.38948 6.37188 4.7562 6.7386L8.6902 10.6726L9.20909 10.1537L12.8461 14.2206C13.2079 14.5823 13.8306 14.6038 14.2139 14.2206C14.591 13.8434 14.591 13.2298 14.2139 12.8527Z" fill="white"/>
                                                      <path d="M6.86684 9.76147L3.78575 12.8426C3.40866 13.2197 3.40866 13.8333 3.78575 14.2104C4.14398 14.5686 4.7637 14.6002 5.15355 14.2104L8.23467 11.1293L6.86684 9.76147Z" fill="white"/>
                                                      <path d="M14.033 5.33158L12.2852 7.07933L11.8292 6.62339L13.577 4.87562L13.1211 4.41967L11.3733 6.16743L10.9174 5.71149L12.6652 3.96373L12.2092 3.50781L9.92954 5.78752C9.65065 6.06641 9.48412 6.43671 9.46057 6.83026C9.45462 6.92997 9.43202 7.02805 9.39453 7.12133L10.8754 8.60223C10.9687 8.5647 11.0668 8.54212 11.1665 8.53617C11.56 8.51268 11.9304 8.34612 12.2092 8.06723L14.4889 5.78754L14.033 5.33158Z" fill="white"/>
                                                      </g>
                                                      <defs>
                                                      <clipPath id="clip0_2383_2744">
                                                      <rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"/>
                                                      </clipPath>
                                                      </defs>
                                                      </svg>                                     
                                             @break
                                             @case("Dinner")
                                                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="18" height="18" rx="4" fill="#DD87D4"/>
                                    <g clip-path="url(#clip0_2383_2768)">
                                    <path d="M12.4308 9.44168C11.5142 8.52508 10.2956 8.02026 8.9993 8.02026C7.70302 8.02026 6.48433 8.52506 5.56773 9.44166C4.72785 10.2816 4.23401 11.3752 4.15723 12.5497H13.8414C13.7646 11.3752 13.2707 10.2816 12.4308 9.44168Z" fill="white"/>
                                    <path d="M12.816 6.77778C12.8534 6.79275 12.8694 6.82215 12.8755 6.83832C12.8816 6.85452 12.8893 6.88707 12.8712 6.92317L12.5249 7.68092L13.1135 7.94973L13.4529 7.20667C13.5441 7.02021 13.5541 6.80256 13.4803 6.60838C13.4057 6.41219 13.2512 6.25496 13.0563 6.17701C13.0078 6.15762 12.9812 6.10583 12.9924 6.05588L13.1791 5.63999L12.5888 5.375L12.3866 5.82548L12.3814 5.8409C12.2556 6.21844 12.4465 6.62997 12.816 6.77778Z" fill="white"/>
                                    <path d="M10.4439 4.91204C10.4814 4.92703 10.4973 4.9564 10.5034 4.9726C10.5096 4.98878 10.5172 5.02132 10.4992 5.05743L10.1528 5.8152L10.7414 6.08401L11.0808 5.34099C11.172 5.15453 11.1821 4.93684 11.1082 4.74266C11.0336 4.54645 10.8791 4.38923 10.6842 4.31129C10.6357 4.29189 10.6091 4.24013 10.6203 4.1902L10.807 3.77425L10.2167 3.50928L10.0145 3.95974L10.0094 3.97512C9.88352 4.35268 10.0744 4.7642 10.4439 4.91204Z" fill="white"/>
                                    <path d="M7.31596 4.91206C7.35341 4.92703 7.36935 4.95642 7.37549 4.97262C7.38164 4.9888 7.38928 5.02135 7.37125 5.05741L7.02492 5.8152L7.6135 6.08401L7.95286 5.34095C8.04406 5.15449 8.05411 4.93684 7.98028 4.74268C7.90569 4.54647 7.75115 4.38926 7.55628 4.31129C7.50777 4.29189 7.48122 4.24013 7.49237 4.1902L7.67905 3.77427L7.08876 3.50928L6.88656 3.95976L6.88144 3.97516C6.75559 4.3527 6.94643 4.76423 7.31596 4.91206Z" fill="white"/>
                                    <path d="M4.94389 6.65913C4.98133 6.67412 4.99727 6.70349 5.00342 6.71969C5.00957 6.73589 5.01722 6.76842 4.99917 6.80452L4.65286 7.56227L5.24143 7.83108L5.58079 7.08804C5.67198 6.90158 5.68206 6.68391 5.60823 6.48975C5.53364 6.29354 5.37908 6.1363 5.18421 6.05836C5.1357 6.03897 5.10913 5.9872 5.1203 5.93727L5.307 5.52134L4.71671 5.25635L4.5145 5.70683L4.50937 5.72223C4.38352 6.09977 4.5744 6.5113 4.94389 6.65913Z" fill="white"/>
                                    <path d="M9.64763 7.41086V7.37313C9.64763 7.01578 9.35792 6.72607 9.00058 6.72607C8.64323 6.72607 8.35352 7.01578 8.35352 7.37313V7.41086C8.56674 7.38605 8.78265 7.37313 9.00058 7.37313C9.21848 7.37313 9.43441 7.38605 9.64763 7.41086Z" fill="white"/>
                                    <path d="M3.5 13.1965H14.5V14.4907H3.5V13.1965Z" fill="white"/>
                                    </g>
                                    <defs>
                                    <clipPath id="clip0_2383_2768">
                                    <rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"/>
                                    </clipPath>
                                    </defs>
                                    </svg>                                    
                                             @break
                                          
                                             @case("Brunch")                                   
                                                 <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                      <rect width="18" height="18" rx="4" fill="#D9A465"/>
                                                      <g clip-path="url(#clip0_2383_2744)">
                                                      <path d="M14.2139 12.8527L9.90057 8.53937L4.86119 3.5H4.46737L4.38695 3.70434C4.1747 4.24368 4.08402 4.79531 4.12473 5.29953C4.17114 5.87428 4.38948 6.37188 4.7562 6.7386L8.6902 10.6726L9.20909 10.1537L12.8461 14.2206C13.2079 14.5823 13.8306 14.6038 14.2139 14.2206C14.591 13.8434 14.591 13.2298 14.2139 12.8527Z" fill="white"/>
                                                      <path d="M6.86684 9.76147L3.78575 12.8426C3.40866 13.2197 3.40866 13.8333 3.78575 14.2104C4.14398 14.5686 4.7637 14.6002 5.15355 14.2104L8.23467 11.1293L6.86684 9.76147Z" fill="white"/>
                                                      <path d="M14.033 5.33158L12.2852 7.07933L11.8292 6.62339L13.577 4.87562L13.1211 4.41967L11.3733 6.16743L10.9174 5.71149L12.6652 3.96373L12.2092 3.50781L9.92954 5.78752C9.65065 6.06641 9.48412 6.43671 9.46057 6.83026C9.45462 6.92997 9.43202 7.02805 9.39453 7.12133L10.8754 8.60223C10.9687 8.5647 11.0668 8.54212 11.1665 8.53617C11.56 8.51268 11.9304 8.34612 12.2092 8.06723L14.4889 5.78754L14.033 5.33158Z" fill="white"/>
                                                      </g>
                                                      <defs>
                                                      <clipPath id="clip0_2383_2744">
                                                      <rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"/>
                                                      </clipPath>
                                                      </defs>
                                                      </svg>                                 
                                             @break
                                             @default                                    
                                                  
                                                   <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                   <rect width="18" height="18" rx="4" fill="#57A78A"/>
                                                   <g clip-path="url(#clip0_2383_2576)">
                                                   <path d="M14.1771 8.44165H3.82289C3.64457 8.44165 3.5 8.58622 3.5 8.76454C3.5 9.97727 4.08128 11.113 5.13679 11.9626C6.17178 12.7956 7.54377 13.2544 9 13.2544C10.4562 13.2544 11.8282 12.7956 12.8632 11.9626C13.9187 11.113 14.5 9.97729 14.5 8.76454C14.5 8.58622 14.3554 8.44165 14.1771 8.44165Z" fill="white"/>
                                                   <path d="M14.387 4.82355C14.2517 4.70739 14.0479 4.72283 13.9317 4.85808L12.6338 6.36899C12.7281 6.50707 12.8056 6.65522 12.8646 6.81105C12.9226 6.83586 12.9793 6.86336 13.0349 6.89318L14.4215 5.27889C14.5377 5.14363 14.5223 4.93976 14.387 4.82355Z" fill="white"/>
                                                   <path d="M12.3371 7.31805C12.2369 6.72147 11.7779 6.24495 11.1904 6.11873C11.097 5.39311 10.4753 4.83057 9.72471 4.83057C9.0961 4.83057 8.55792 5.22504 8.34475 5.77947C8.13139 5.66422 7.89025 5.60117 7.64275 5.60117C6.82789 5.60117 6.16495 6.26411 6.16495 7.07897C6.16495 7.08415 6.16497 7.08935 6.16503 7.09455C5.70047 7.16169 5.29852 7.42435 5.04492 7.79597H13.1493C12.9414 7.55702 12.6583 7.38514 12.3371 7.31805Z" fill="white"/>
                                                   </g>
                                                   <defs>
                                                   <clipPath id="clip0_2383_2576">
                                                   <rect width="11" height="11" fill="white" transform="translate(3.5 3.5)"/>
                                                   </clipPath>
                                                   </defs>
                                                   </svg>
                                                                    
                                             @endswitch
                                    
                                      <!--  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                          xmlns="http://www.w3.org/2000/svg">
                                          <rect width="18" height="18" rx="4" fill="#57A78A" />
                                          <g clip-path="url(#clip0)">
                                             <path
                                                d="M14.1771 8.44141H3.82289C3.64457 8.44141 3.5 8.58597 3.5 8.76429C3.5 9.97702 4.08128 11.1128 5.13679 11.9623C6.17178 12.7954 7.54377 13.2541 9 13.2541C10.4562 13.2541 11.8282 12.7953 12.8632 11.9623C13.9187 11.1128 14.5 9.97705 14.5 8.76429C14.5 8.58597 14.3554 8.44141 14.1771 8.44141Z"
                                                fill="white" />
                                             <path
                                                d="M14.3871 4.82306C14.2518 4.7069 14.048 4.72234 13.9318 4.85759L12.6339 6.3685C12.7282 6.50658 12.8057 6.65474 12.8648 6.81056C12.9227 6.83538 12.9794 6.86288 13.035 6.8927L14.4216 5.2784C14.5378 5.14314 14.5224 4.93927 14.3871 4.82306Z"
                                                fill="white" />
                                             <path
                                                d="M12.3367 7.31756C12.2365 6.72098 11.7775 6.24446 11.1901 6.11824C11.0967 5.39263 10.4749 4.83008 9.72435 4.83008C9.09574 4.83008 8.55755 5.22455 8.34438 5.77898C8.13102 5.66374 7.88988 5.60068 7.64238 5.60068C6.82752 5.60068 6.16458 6.26362 6.16458 7.07848C6.16458 7.08366 6.1646 7.08886 6.16467 7.09406C5.70011 7.1612 5.29816 7.42386 5.04456 7.79548H13.149C12.941 7.55653 12.6579 7.38466 12.3367 7.31756Z"
                                                fill="white" />
                                          </g>
                                          <defs>
                                             <clipPath id="clip0">
                                                <rect width="11" height="11" fill="white"
                                                   transform="translate(3.5 3.5)" />
                                             </clipPath>
                                          </defs>
                                       </svg> -->

                                    </span>
                                 </div>
                              </div>
                              
                             
                              @endforeach
                              @else
                                  <p>No Bookings</p>
                              @endif  
                              
                           </div>
                        
                        </div>
                        <div class="Reserve_slote">
                           <div class="left">
                              <!-- <p>11:00
                                    AM</p> -->
                           </div>
                           <div class="right">
                              <a href="{{ url('/restaurant-owner/restaurant/booking')}}"><button class="btn btn-Reserve">Reserve</button></a>
                           </div>
                        </div>
                       
                     </div>
               
                   @endforeach    
                      </div>              
                  @endforeach    
                 
             
                  <!-- end item -->
                  </div>
                  </div>
              
                  </div>
                 
               </div>
             
           
               </div>
                
            </div>
            <!-- end container-main -->
         </main>
         <!-- end main -->

    </div>
</div>
<script>
   const rightBtn = document.querySelector('#right-button');
   const leftBtn = document.querySelector('#left-button');

   rightBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft += 300;
     event.preventDefault();
   });

   leftBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft -= 300;
     event.preventDefault();
   });

</script>


 <script type="text/javascript">
   var indexValue =$('#category_hidden_id').val();
 //  alert(indexValue)
   if(indexValue == ""){
   $('#' + '0').addClass("active-tabs");
   }
   else if(indexValue >= 0){
   $('#' +indexValue).addClass("active-tabs");
   }
  

</script>
 <script type="text/javascript">
   var Value =$('#floor_hidden_id').val();
 //  alert(Value)
   $('#' + Value).addClass("active-floor ");

</script>
<script type="text/javascript">
   
</script>

@endsection
 