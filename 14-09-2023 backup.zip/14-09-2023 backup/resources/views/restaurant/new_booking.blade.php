

@extends('layouts.default')

    
@section('content')

<style>
    #mobile-box{
        display: none;
    }

        .disable:after {
          
            position: absolute;
            width: 100%;
            height: 100%;
            content: "";
            top: 0px;
            left: 0px;
            background-color: #dee2e654;

        }
         
    </style>


    <div class="container-fluid">
        <div class="fix-width">
            @include('layouts.floor_management_left_menu')     
            <main role="main" class="main-box w-100 border-main-box">      
                <!------------------------------------------------------------------------------------->
                <!-- container-main -->
                <div class="container-main p-0">
                   <div class="Search_here_Guests-Profile row">
                      <div class="left_Search_here_Guests col-md-8 col-lg-8" onclick="testPreeti()">
                         <div class="header-guest-booking">
                             <div class="left">
                                <h3>{{ __('owner.Guest New Booking') }}</h3>
                             </div>
                             <div class="right">
                               <a href="{{ url('/restaurant-owner/restaurant/booking') }}" class="btn btn-add-guest">{{ __('owner.Back to Booking List') }}</a>
                           </div>
                         </div>
            @if(Session::has('success'))
            <div class="alert alert-success " role="alert" style="margin:1rem;">
                {{Session::get('success')}}
            </div>
            @elseif(Session::has('error'))
            <div class="alert alert-danger " role="alert" style="margin:1rem;">
                {{Session::get('error')}}
            </div>
            @endif
                        <div class="left_Search_here_Guests_list">
                           <div class="guest_booking-block ">
                                           
                                <div class="guest_booking-card hover-overlay active" id="box_no-{{$user_detail->id}}"  data-user-id="{{$user_detail->id}}">
                                    <div class="left">
                                        <div class="guest_booking-card_left">
                                            <div class="guest_booking-card_img">
                                            <!-- <img src="imgs/lg.svg" alt="" /> -->                                      
                                                <!-- <img src="imgs/lg.svg" alt="" /> -->
                                            @if(!empty($user_detail->image) && file_exists('storage/'.$user_detail->image))
                                            <img src="{{ asset('storage').'/'.$user_detail->image}}" alt="" />
                                            @else
                                            <img src="{{ asset('front/imgs/placeholder.png') }}" >
                                            @endif
                                           
                                            </div>
                                            <div class="guest_booking-card_left_body">
                                                <h4 id="guest_booking-card_user_name">{{$user_detail->name}}</h4>
                                                <p id="guest_booking-card_user_mobile">{{$user_detail->mobile}}</p>
                                                <p id="guest_booking-card_user_email">{{$user_detail->email}}</p>
                                                <p id="guest_booking-card_user_foodintolerance" style="display:none;">
                                                @if(isset($user_detail->userFoodIntolerance)){{$user_detail->userFoodIntolerance}}
                                                @endif</p>
                                                <p id="guest_booking-card_user_foodallergy" style="display:none;">@if(isset($user_detail->userAllergy)){{$user_detail->userAllergy}}
                                                @endif</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right">
                                        <h5>{{ __('owner.Total_Bookings') }}:<b>0</b></h5>
                                        <h6> <span>{{ __('owner.Visit') }}: <b>0</b></span>   <span> {{ __('owner.Cancelled') }}:<b> 0</b></span> </h6>
                                    </div>
                                </div>                              
                                                                                
                              </div>
                        </div>
                      </div>
                      <div class="col-md-4 col-lg-4">
                        <div class="guest_booking-right-form ">
                           <div class="title d-flex justify-content-between">
                            <h4 id="select_user_name">{{$user_detail->name}}</h4>
                            <span id="select_user_mobile" class="nub-link">{{$user_detail->mobile}}<span>
                           </div>
                           <form method="POST" action="{{ route('owner.restaurant.bookadduser') }}" >
                           @csrf
                              <div class="row">
                              <div class="form-group col-md-12">
                                 <label>{{ __('owner.Booking Time') }}</label>
                                 @if(old('for_time'))
                                 <input class="form-control" type="time" name="for_time" id="for-time" value="{{old('for_time')}}">
                                   @else
                                    <input class="form-control" type="time" name="for_time" id="for-time" >
                                   @endif
                                    @error('for_time')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                              </div>
                              <div class="form-group col-md-12">
                                 <label>{{ __('owner.Booking Date') }}</label>
                                  @if(old('for_time'))
                                 <input class="form-control" type="date" name="for_date" id="for-date" value="{{old('for_date')}}" >
                                     @else
                                      <input class="form-control" type="date" name="for_date" id="for-date"  >
                                  @endif
                                  @error('for_date')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-12">
                               <label>{{ __('owner.No of Person') }}</label>
                               <div class="quantity-block">
                                  <span class="quantity-arrow-minus"  id="decrease" onclick="decreaseValue()">
                                    <svg width="12" height="2" viewBox="0 0 12 2" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M10.6667 1.66683H1.33341C1.1566 1.66683 0.987035 1.59659 0.86201 1.47157C0.736986 1.34654 0.666748 1.17697 0.666748 1.00016C0.666748 0.823352 0.736986 0.653783 0.86201 0.528758C0.987035 0.403734 1.1566 0.333496 1.33341 0.333496H10.6667C10.8436 0.333496 11.0131 0.403734 11.1382 0.528758C11.2632 0.653783 11.3334 0.823352 11.3334 1.00016C11.3334 1.17697 11.2632 1.34654 11.1382 1.47157C11.0131 1.59659 10.8436 1.66683 10.6667 1.66683Z" fill="black"/>
                                    </svg>
                                  </span>
                                  @if(old('no_of_person'))
                                 <input name="no_of_person" id="no-of-person" class="quantity-num" type="number" value="{{old('no_of_person')}}" />
                                        @else
                                          <input name="no_of_person" id="no-of-person" class="quantity-num" type="number" value="1" />
                                        @endif

                                 <span class="quantity-arrow-plus" id="increase" onclick="increaseValue()"> 
                                   <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.21875 8.96875H7.03125V14.7812C7.03125 15.3155 7.46573 15.75 8 15.75C8.53427 15.75 8.96875 15.3155 8.96875 14.7812V8.96875H14.7812C15.3155 8.96875 15.75 8.53427 15.75 8C15.75 7.46573 15.3155 7.03125 14.7812 7.03125H8.96875V1.21875C8.96875 0.68448 8.53427 0.25 8 0.25C7.46573 0.25 7.03125 0.68448 7.03125 1.21875V7.03125H1.21875C0.68448 7.03125 0.25 7.46573 0.25 8C0.25 8.53427 0.68448 8.96875 1.21875 8.96875Z" fill="#484848"/>
                                    </svg>
                                  </span>
                               </div>
                                 @error('no_of_person')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-12">
                              <label>{{ __('owner.Booking Status') }}</label>
                              <select class="form-control" name="booking_status" id="booking-status">
                                  <option value="">{{ __('owner.Select status') }}</option>
                                   <option value="0" @if (old('booking_status') == '0') selected="selected" @endif  >{{ __('owner.Pending') }}</option>
                                  <option value="1" @if (old('booking_status') == '1') selected="selected" @endif  >{{ __('owner.Confirm') }}</option>                                      
                              </select>
                                    @error('booking_status')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                           <div class="form-group col-md-12">
                              <label>{{ __('owner.Category') }}</label>
                              <select class="form-control" name="category_id" id="category-id">
                                    <option value="" >{{ __('owner.Select Category') }}</option>                                    
                                    @foreach  ($categories as $key => $value)
                                      
                                            @if (old('category_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach 
                                </select>
                                    @error('category_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                             <div class="form-group col-md-12 allergyy" >
                                <p style="color:#ff0000;" class="mb-0">Allergy:</p> 
                                <span id="select_user_allergy" class="nub-link"><span></div>
                            <div class="form-group col-md-12 intolerancee">
                                <p style="color:#ff0000;" class="mb-0">Food Intolereance:</p>
                                <span id="select_user_intolerance" class="nub-link"><span></div>
                            <div class="form-group col-md-12">
                              <label>{{ __('owner.Event') }}</label>
                             <select class="form-control" name="tag_id" id="tag-id">
                                    <option value="">{{ __('owner.Select tag') }}</option>                                    
                                    @foreach  ($tags as $key => $value)
                                        <option value="{{$key}}" >{{$value}}</option>
                                            @if (old('tag_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}" >{{$value}}</option>
                                        @endif
                                    @endforeach 
                                </select>
                           </div>
                           <div class="form-group col-md-12">
                              <label>{{ __('owner.Select Floor') }}<span class="spanColor">*</span></label>
                              <select class="form-control" name="floor_id" id="floor-id">
                                    <option value="">{{ __('owner.Select Floor') }}</option>
                                    @foreach  ($floors as $key => $value)
                                         @if (old('floor_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach                                   
                                </select>
                                   @error('floor_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                           <div class="form-group col-md-12" id='table_box'>
                              <label>{{ __('owner.Choose Table Number') }}</label>
                              <select class="form-control" id='table-no' name='table_no'>
                                <option value=''>-- {{ __('owner.Select Table') }} --</option>
                                </select>
                                 @error('table_no')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                           </div>
                             <div class="form-group col-md-12">
                               <input class="form-control" type="hidden" id="user_id" name="user_id" value="{{$user_detail->id}}">
                              <input class="form-control" type="hidden" id="res_id" name="res_id" value="{{$restaurant_id}}">
                              <button class="btn  btn-black w-100">{{ __('owner.Create Reservation') }}</button>
                           </div>
                           </div>
                           </form>
                        </div>
                     </div>
                   </div>
                
      
                </div>
               <!-- end container-main -->
                
                <!------------------------------------------------------------------------------------->
            </main>
        </div>
    </div>



<script>
$(document).ready(function(){

            

    $(document).on("change", "#floor-id", function () {
        var floor_id = this.value;
        console.log(floor_id);

        let = modalHtml = "";
        let  optionValue = "";
        let tableDropDown = "";

       if(floor_id > 0){
            $.ajax({
                url: "{{url('/restaurant-owner/restaurant/tablelistbyfloorid')}}",
                type: "POST",
                data: {
                    floor_id: floor_id,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {                          
                    $("#table_id").html('');                       
                    let tableList = JSON.parse(result.table_list.floor_table_view);
                    selectedDropDownFloorTableDetail = tableList;
                    console.log(tableList);                    
                    let tableno = 0;
                    if (tableList != null) {
                        optionValue = "<option value='0'>-- Select table --</option>";            
                                
                            for (var num = 0; tableList.length > num; num++) {      
                                optionValue +=
                                    "<option data-table-no='" +
                                    tableList[num].table_no +
                                  
                                    "'value='"+
                                    tableList[num].table_id +
                                    "'>" +
                                    tableList[num].table_no +
                                    " Capacity : " +
                                    tableList[num].capacity +
                                    " min : " +
                                    tableList[num].min_capacity +
                                    " max : " +
                                    tableList[num].max_capacity +
                                    "</option>";
                                tableno = tableList[num].table_no;
                                tableId = tableList[num].table_id;

                            }  

                        
                        // console.log(dd);
                            
                            tableDropDown = "<select class='form-control'  id='table_id' name='table_id'>" +
                            optionValue +
                            "</select><input type='hidden' name='table_no'  id='table_no'><input type='hidden' name='table_detail'  id='table_detail'>";                           
                            modalHtml = "<label>Choose Table Number</label>" + tableDropDown ;
                            $("#table_box").html(modalHtml);
                        } 
                }
            });

       }else{
                optionValue = "<option value='0'>-- Select table --</option>";
                let tableDropDown = "<select class='form-control'  id='table_id' name='table_id'>" +
                            optionValue +
                            "</select>";                           
                            modalHtml = "<label>Choose Table Number</label>" + tableDropDown ;
                            $("#table_box").html(modalHtml);
       }      
    });

$(document).on("change", "#table_id", function () {
        var data_table_no = $('option:selected', this).attr('data-table-no');
        var tableId = $('option:selected', this).attr('value');
        let table_detail = createTableObjArr(tableId);
        let dd=JSON.stringify(table_detail);
        console.log(dd);
        $('#table_no').val(data_table_no);
        $('#table_detail').val(dd);
    });


    function createTableObjArr(tableId){
        selectedTableObjArr=[];
            for(let tempNum=0; selectedDropDownFloorTableDetail.length>tempNum; tempNum++){
                let objImg = selectedDropDownFloorTableDetail[tempNum];
                if( parseInt(tableId) == parseInt(objImg.table_id) ){
                    selectedTableObjArr.push({
                            table_id:objImg.table_id,
                            table_no:objImg.table_no,
                            max_capacity:objImg.max_capacity,
                            min_capacity:objImg.min_capacity,
                        });               
                }
            }
        return selectedTableObjArr;
    }
     

   
    $(document).on('keypress',"#user_search",function(e) {
        if(e.which == 13) {
          var serchdata = $(this).val();
          
          $.ajax({
            url: "{{url('/restaurant-owner/restaurant/bookingby')}}",
                type: "POST",
                data: {
                  serchdata: serchdata,
                    _token: '{{csrf_token()}}'
                },           
                success: function (result) {     
                    //hideMessageBox();
                    if (result.status) {                          
                        let userinfo = JSON.stringify(result.data)
                        let user = JSON.parse(userinfo);     
                         $("#user_id").val(user.id);
                         $("#select_user_name").text(user.name);
                         $("#select_user_mobile").text(user.mobile);

                    }else{
                        $('#Add-New-Guest').modal('show'); 
                    }
                   

                }

          });
        }
    });
      var result = $('.guest_booking-card');
    $(document).on("click", ".guest_booking-card", function () {
        selectUser($(this));
    });
     function selectUser(obj){
        var select_user_id = obj.attr("data-user-id");       
        var user_id = $("#user_id").val(select_user_id);
        // $("#box_no-"+select_user_id).toggleClass("active");
        $(".guest_booking-card").removeClass("active");
        obj.addClass("active");  

        //  $(".guest_booking-right-form").toggleClass("disable");
        $(".guest_booking-right-form").removeClass("disable");
        // $(".guest_booking-right-form").addClass("disable");  
        var select_user_name = obj.find('#guest_booking-card_user_name').text();
        var select_user_mobile = obj.find('#guest_booking-card_user_mobile').text();
        var select_user_email = obj.find('#guest_booking-card_user_email').text();
        var select_user_intolerance = obj.find('#guest_booking-card_user_foodintolerance').text();
        var select_user_allergy = obj.find('#guest_booking-card_user_foodallergy').text();


      if ($("#box_no-"+select_user_id).hasClass("active")){
            $("#select_user_name").text(select_user_name);
            $("#select_user_mobile").text(select_user_mobile);
            $("#select_user_allergy").text(select_user_allergy);
            $("#select_user_intolerance").text(select_user_intolerance);
             $(".allergy, .intolerance").css("display", "block");
        }else{ 
            $("#select_user_name").text('');
            $("#select_user_mobile").text('');  
            $("#select_user_allergy").text('');  
            $("#select_user_intolerance").text('');  
        }
    }
     

    $(document).on('keyup',"#user_search", function() {
    var search = $(this).val().toLowerCase();
    //Go through each list item and hide if not match search

    $(".guest_booking-card").each(function() {
	
        if ($(this).html().toLowerCase().indexOf(search) != -1) {
            $(this).show();
        }
        else {
            $(this).hide();  
        } 
    });
	
    $(".guest_booking-card:visible").each(function(index) {
				
         if(index == 0){
             $(this).css("border-top-left-radius", "10px");
             $(this).css("border-top-right-radius", "10px");

			//  $(".title_lable").each(function() {
			// 	$(".title_lable").show();
			// });

         }
         if(index == $(".list-group-item:visible").length - 1){
             $(this).css("border-bottom-left-radius", "10px");
             $(this).css("border-bottom-right-radius", "10px");

			//  $(".title_lable").each(function() {
			// 	$(".title_lable").hide();
			// });	
         }
     });
    
    });


});

        function increaseValue() {
         $('#no-of-person').click( function() {
            var counter = $('#no-of-person').val();
            counter++ ;
            $('#no-of-person').val(counter);
           
    });
      
    }
    function decreaseValue() {
    $('#no-of-person').click( function() {
            var counter = $('#no-of-person').val();
            counter-- ;
            $('#no-of-person').val(counter);
    });
    }
  
function testPreeti()
{
    // alert('testPreeti');
    $(".guest_booking-card").removeClass('active');
    $("#select_user_name").text('');
    $("#select_user_mobile").text('');
    $(".guest_booking-right-form").addClass('disable');
}

    $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);

   // alert(maxDate);
    $('#for-date').attr('min', maxDate);
});

</script>


@endsection


