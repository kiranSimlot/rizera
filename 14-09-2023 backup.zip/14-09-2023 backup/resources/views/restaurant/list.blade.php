@extends('layouts.default')  
@section('content')
<div class="container-fluid">
    <div class="fix-width">
    @include('layouts.floor_management_left_menu')
        <!-- main -->
         <main role="main" class="main-box w-100 border-main-box report-chart">
               <!-- main header -->
               <div class="dis-header">
                  <div class="row align-items-center">
                    <div class=" col-md-6 text-left">

                        @if(Auth::user()->type != 1)
                         <b style="font-size: 20px;">{{ __('owner.All Restaurant List') }}</b>
                        @endif
                     </div>
                     <div class="col-md-6 text-right">
                        @if(Auth::user()->type != 1)
                        <a href="{{route('owner.restaurant.add')}}" class="btn advanced-report">{{ __('owner.Add Restaurant') }}</a>
                        @endif
                     </div>
                  </div>
               </div>
               <!-- end  main header -->
               <!-- container-main -->
               <div class="container-main">
                
                <div class="table-responsive report_table restaurants-table">
  <table class="table">
    <thead>
    <tr>
      <th scope="col" class="restaurant-id">#</th>
      <th scope="col" class="restaurant-th">{{ __('owner.Restaurant') }}</th>
      @if(Auth::user()->type == 1)
      <th scope="col">{{ __('owner.Name') }}</th>
      @endif
      <th scope="col" class="restaurant-rating">{{ __('owner.Cuisine Type') }}</th>
      <th scope="col" class="restaurant-rating">{{ __('owner.Overall Rating') }}</th>
      <th scope="col" class="restaurant-rating">{{ __('owner.Status') }}</th>
      <th scope="col" class="restaurant-floor">{{ __('owner.Default Floor') }}</th>
      <th scope="col" class="action-th">{{ __('owner.Action') }}</th>

        @if( Auth::user()->type == 1  )
         <th class="action-th" scope="col"><span class="nobr">{{ __('owner.Action') }}</span></th>

        @endif
      <th scope="col" class="restaurant-rating">{{ __('owner.Make Primary') }}</th>
    </tr>
  </thead>

  <tbody>
      @if($restaurants->count() > 0)
    @foreach($restaurants as $key =>$restaurant)
        <tr>
            <td>{{++$key}}</td>
            <td>{{$restaurant->name}}</td>
            @if(Auth::user()->type == 1)
                    <td>{{$restaurant->getOwner->name}}</td>
            @endif
            <td>
                @foreach($restaurant->getCuisine as $cuisine)
                    {{$cuisine->Cuisine['name']}}
                @endforeach
            </td>
            <td class="table-rating">{{$restaurant->rating}}</td>
            <td>
                @if($restaurant->verified == 1)
                    Verified
                @elseif($restaurant->verified == 0)
                    Not Verified
                @endif
            </td>
            @if($restaurant->default_floor_name == null)
            
                <td> <a href="" class="change_floor"  data-id="{{$restaurant->id}}" data-toggle="modal" data-target="#choosefloorModal"><img src="{{ asset('admin/imgs/edit_icon.svg') }}" style="height: 15px;" data-toggle="tooltip" data-placement="top" title="Change Default Floor"></a>   0</td>
            @else
            <td> 
                <a href="" class="default--floor" data-id="{{$restaurant->id}}" data-toggle="modal" data-target="#choosefloorModal" >
                    <img src="{{ asset('admin/imgs/edit_icon.svg') }}"> {{$restaurant->default_floor_name->name}}
                </a> 
            </td>
            @endif
            @if( Auth::user()->type != 1  )
            <td>

                <a href="{{ Route('owner.restaurant.edit',$restaurant->id)}}" class="btn report-edit mr-2"><img src="{{ asset('admin/imgs/edit_icon.svg') }}" style="height: 15px;" data-toggle="tooltip" data-placement="top" title="Edit"></a>
                <a href="#" class="btn report-trash mr-2" onclick="event.preventDefault(); if(confirm('Are you delete it.')){ document.getElementById('delete-form-{{$restaurant->id}}').submit();  } " ><img src="{{ asset('admin/imgs/trash.svg') }}" style="height: 15px;" data-toggle="tooltip" data-placement="top" title="Delete">
                    <form id="delete-form-{{$restaurant->id}}" action="{{Route('owner.restaurant.delete',$restaurant->id)}}" method="post" style="display:none;">
                        @csrf
                        @method("DELETE")
                    </form>
                </a>
                <a href="{{route('owner.restaurant.floorManagement',$restaurant->id)}}" class="btn report-icon "><img src="{{ asset('admin/imgs/icon1.svg') }}" style="height: 15px;" data-toggle="tooltip" data-placement="top" title="Floor Management"></a>
                @if($restaurant->status == 3)
                    <button class="btn btn-sm btn-danger review--update"  data-toggle="tooltip" data-placement="top" title="{{$restaurant->admin_comment}}">
                    {{ __('owner.Rejected By Admin') }}<!-- <span class="tooltiptext">{{$restaurant->admin_comment}}</span> -->
                </button>
                @endif
            </td>
            <td>
                <div class="form-check" >
                @if($restaurant->make_primary == 1)
                    <input class="form-check-input" type="radio" id="gridCheck1" name="primary" value="{{$restaurant->id}}" style="margin-left:20px;" checked>
                @else
                    <input class="form-check-input" type="radio" id="gridCheck1" name="primary" value="{{$restaurant->id}}" style="margin-left:20px;">
                @endif
                <label class="form-check-label" for="gridCheck1">&nbsp</label>
                </div>
            </td>
            @endif
        </tr>
    @endforeach

@else

<tr>
    <td></td>
    <td><h5>No Restaurant Found!</h5></td>
</tr>
@endif 

</tbody>
 




   

  </table>
</div>

<div class="table_footer">
   <div class="row align-items-center">

   <div class="col-md-12 text-right">

<div class="table-pagination pt-2">
  <ul class="pagination justify-content-end mb-0">
    {!! $restaurants->links() !!}
  </ul>
</div>
   </div>
</div>
</div>



               </div>
               <!-- end container-main -->
            </main>
            <!-- end main -->

         </div>
      </div>
      <!-- end of footer -->



<!-- Modal -->
<div class="modal fade" id="choosefloorModal" tabindex="-1" role="dialog" aria-labelledby="choosefloorModal" aria-hidden="true">
  <div class="modal-dialog booking-modal" role="document">
    <div class="modal-content ">
      <div class="modal-header">
        <h5 class="modal-title" id="choosefloorModal">Default Floor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" >

         <form method="GET" action="{{ route('owner.restaurant.defaultfloor') }}" id="userModal" >
         @csrf
             
        </form>
      </div>
      
    </div>
  </div>
</div>
<script type="text/javascript">
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
        $(document).ready(function(){
        $('.change_floor').on('click', function(e) {
        e.preventDefault();
        var restaurantId = $(this).attr('data-id');
         $('input[name="floor_restaurant"]').val(restaurantId);
       // alert(restaurantId);
        $.ajax({
            url: "{{route('owner.restaurant.getdata')}}",
            type: 'GET',
            dataType: 'html',
            data: {
                         "_token": "{{ csrf_token() }}",
                         "restaurantId":restaurantId
                      },
            success: function (data) {
              // console.log(data)
                var len = 0;
                $('#userModal').empty(); 
                   if(data != null){
                    len = data.length;
                    console.log(data)
                }

            if(len > 2){
             data = JSON.parse(data);
               data.forEach(function(element) {
                 var id = element.id;
                 var name = element.name;
                 var type = element.type;
               if(type ==1){
                var tr_str = " <div class='row' style='margin-left:10px;'><div class='col-md-12 pb-4'>" +
                   " <input  type='hidden' id='floor_id' name='floor_id' value='"+id+"'>" 
                 +"<div class='form-check mb-2'>"+
                   " <input class='form-check-input' type='radio' id='floor' checked  name='florr'  value='"+id+"'>" 
                   + " <label class='form-check-label' for='gridCheck1'>" 
                    + name + '</label>' +"</div> " + "</div>" ;
               }
               else{
                 var tr_str = " <div class='row' style='margin-left:10px;'><div class='col-md-12 pb-4'>" +
                   " <input  type='hidden' id='floor_id' name='floor_id' value='"+id+"'>" 
                 +"<div class='form-check mb-2'>"+
                   " <input class='form-check-input' type='radio' id='floor' name='florr'  value='"+id+"'>" 
                   + " <label class='form-check-label' for='gridCheck1'>" 
                    + name + '</label>' +"</div> " + "</div>" ;
               }

                 
                   
                 
                 $("#userModal").append(tr_str);
              });
               var footer= "<div class='form-group col-md-12'><div class='row'>"+
                               " <div class='col-12'>"+ "<input class='form-control' type='hidden' id='name_restaurant' name='name_restaurant' value='"+restaurantId+"'> "+
                                  "<button class='btn  btn-black w-100'>Save</button>"+
                                "</div>"
                             " </div></div></div>";

                            $("#userModal").append(footer);
              }
              else{
              var tr_str = 
                  "<div>No Floor found.</div>";

              $("#userModal").append(tr_str);
           }

            }
        });

     //   console.log('one'+"{{route('owner.restaurant.getdata')}}"); 
        });
    });
      </script> 

       <script>  
 $(document).ready(function(){  
      $('input[type="radio"]').click(function(){  
           var primary = $(this).val();  
          // alert(primary);
           $.ajax({  
               url: "{{route('owner.restaurant.primaryUpdate')}}",
                method:"post",  
                  data: {
                         "_token": "{{ csrf_token() }}",
                         "primary":primary
                      },
                success:function(data){  
                  //  alert('hii');
                }  
           });  
      });  
 });  
 </script> 
@endsection

   