@extends('layouts.default')


@section('content')

    <style type="text/css">
        .openinghours {
    font-family:Lucida Console;
    border-radius:4px;
    margin:10px;
    box-shadow: 0 0 10px black;
    padding:0 10px 0 10px;
    overflow: hidden;
    display: inline-block;
}
.openinghourscontent {
    float:left;
}
.openinghourscontent h2 {
    display:block;
    text-align:center;
    margin-top:.33em;
}
.openinghourscontent button {
    color:white;
    font-family:Courier New;
    font-size:large;
    font-weight:bolder;
    background-color:#4679BD;
    border-radius:4px;
    width:100%;
    margin-bottom:10px;
}
.today {
    color: #8AC007;
}
.opening-hours-table tr td:first-child {
    font-weight:bold;
}
#open-status {
    display:block;
    margin-top:-1em;
    text-align:center;
    border:dotted lightgrey 3px;
}
.openorclosed:after {
    content:" open during these hours:";
}
.open {
    color:green;
}
.open:after {
    content:" Open";
    color: #6C0;
}
.closed:after {
    content:" Closed";
    color: red;
}
.opening-hours-table tr td {
    padding:5px;
}
.copy_btn{
      background: no-repeat;
    border: 0px;
    font-size: 14px;
    font-weight: 600;
    color: #FF5C01;
    float: right;
}

    </style>
      <div class="container-fluid">
         <div class="fix-width">
            @include('layouts.floor_management_left_menu')
            <!-- main -->
            <main role="main" class="main-box m-auto w-100">

               <!-- end  main header -->
               <!-- container-main -->
               <form action="{{ ( (isset($restaurant->id)&&$restaurant->id>0)? route('owner.restaurant.update',$restaurant->id) :route('owner.restaurant.create') ) }}" method="post" enctype="multipart/form-data">
               <div class="container-main">
                  <!-- Your Restaurant Details -->
                    <div class="add-restaurant-form">
                       <h2>
                       @if(isset($restaurant->id) && $restaurant->id>0)
                       {{ __('owner.Your Restaurant Details') }}
                       @else
                       {{ __('owner.Add Your Restaurant Details') }}
                       @endif
                       </h2>
                       <!-- <div style="float:right;">
                            <a href="{{url('restaurants')}}" class="btn btn-primary">Back</a>
                       </div> -->
                       <div class="card">
                          <div class="card-header">
                             <h4>{{ __('owner.General') }}</h4>
                          </div>
                          <div class="card-body">
                                <div class="form-group">
                                @csrf
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Name') }}<span class="spanColor">*</span></label>
                                @if(isset($restaurant->id))
                                <input type="hidden" name="id" value="{{$restaurant->id}}">
                                <input type="hidden" name="delete_list" value="">
                                <input type="hidden" name="delete_holiday_list" value="">
                                <input type="hidden" name="restaurant_cuisine_types_saved" value="{{$restaurantCuisineTypes}}">
                                <input type="hidden" name="restaurant_facilities_saved" value="{{implode(',',$restaurantFacilities)}}">
                                <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Name') }}" value="{{old('name')??$restaurant->name}}" onKeyPress="return ValidateAlpha(event);">
                                @else
                                <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Name') }}" value="{{old('name')}}" onKeyPress="return ValidateAlpha(event);">
                                @endif
                                @error('name')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                                </div>

                                <div class="form-group">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Arabic Name') }}<span class="spanColor">*</span></label>
                                @if(isset($restaurant->id))
                                <input type="text" name="ar_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Arabic Name') }}" value="{{old('ar_name')??$restaurant->ar_name}}" >
                                @else
                                <input type="text" name="ar_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Arabic Name') }}" value="{{old('ar_name')}}" >
                                @endif
                                @error('ar_name')
                                <div class="error-box">{{$message}}</div>
                                @enderror
                                </div>

                                <div class="form-group">
                                    <label for="exampleFormControlInput1" class="">{{ __('owner.French Name') }}<span class="spanColor">*</span></label>
                                    @if(isset($restaurant->id))
                                        <input type="text" name="fr_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant French Name') }}" value="{{old('fr_name')??$restaurant->ar_name}}" >
                                    @else
                                        <input type="text" name="fr_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant French Name') }}" value="{{old('fr_name')}}" >
                                    @endif
                                    @error('fr_name')
                                        <div class="error-box">{{$message}}</div>
                                    @enderror
                                </div>


                                <div class="form-group">
                                    <label for="exampleFormControlInput1" class="">{{ __('owner.Description') }}<span class="spanColor">*</span></label>
                                    @if(isset($restaurant->id))
                                        <textarea name="description" id="editor2" >
                                            {{old('description')??$restaurant->description}}
                                        </textarea>
                                    @else
                                        <textarea name="description" id="editor2" >
                                            {{old('description')}}
                                        </textarea>
                                    @endif
                                    @error('description')
                                        <div class="error-box">{{$message}}</div>
                                    @enderror
                                </div>



                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="">{{ __('owner.Online Booking Terms & Conditions') }}<span class="spanColor">*</span></label>
                    @if(isset($restaurant->id))
                    <input type="text" name="online_book_tnc"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Online Booking Terms & Conditions') }}" value="{{old('online_book_tnc')??$restaurant->online_book_tnc}}">
                    @else
                    <input type="text" name="online_book_tnc"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Online Booking Terms & Conditions') }}" value="{{old('online_book_tnc')}}">
                    @endif
                    @error('online_book_tnc')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="">{{ __('owner.Notification Emails') }}</label>
                    @if(isset($restaurant->id))
                    <input type="text" name="notification_emails"  class="form-control" id="exampleFormControlInput1" placeholder="e.g. example@example.com" value="{{old('notification_emails')??$restaurant->notification_emails}}">
                    @else
                    <input type="text" name="notification_emails"  class="form-control" id="exampleFormControlInput1" placeholder="e.g. example@example.com" value="{{old('notification_emails')}}">
                    @endif
                    @error('notification_emails')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="">{{ __('owner.Notification Mobiles') }}</label>
                    @if(isset($restaurant->id))
                    <input type="text" name="notification_mobiles"  class="form-control" id="exampleFormControlInput1" placeholder="e.g. 9999999999" value="{{old('notification_mobiles')??$restaurant->notification_mobiles}}" onkeypress="return isNumberKey(event)">
                    @else
                    <input type="text" name="notification_mobiles"  class="form-control" id="exampleFormControlInput1" placeholder="e.g. 9999999999" value="{{old('notification_mobiles')}}" onkeypress="return isNumberKey(event)">
                    @endif
                    @error('notification_mobiles')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="form-group mb-3">
                    <label for="exampleFormControlTextarea1" class="">{{ __('owner.Country') }}<span class="spanColor">*</span></label>
                        <select name="country_id" id="country_id" class="form-control" aria-label="Default select example">
                            <option value="">{{ __('owner.Country') }}</option>
                            @foreach($countries as $key=>$country)
                                @if(isset($restaurant->country_id) && $restaurant->country_id == $key)
                                    <option selected value="{{$key}}">{{$country}}</option>
                                @elseif(old('country_id')== $key)
                                    <option selected value="{{$key}}">{{$country}}</option>
                                @else
                                    <option value="{{$key}}">{{$country}}</option>
                                @endif
                            @endforeach
                        </select>
                    @error('country_id')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>


                 <div class="form-group mb-0">
                    <label for="exampleFormControlTextarea1" class="">{{ __('owner.City') }}<span class="spanColor">*</span></label>
                        <select name="city_id" id="city_id" class="form-control" aria-label="Default select example" >
                            <option value="">{{ __('owner.City') }}</option>
                        </select>
                    @error('city_id')
                        <div class="error-box" >{{$message}}</div>
                    @enderror
                </div>

                          </div>
                       </div>



                       <div class="card">
                        <div class="card-header">
                           <h4>{{ __('owner.Contact Information') }}</h4>
                        </div>
                        <div class="card-body">
                              <div class="row">
                              <div class="form-group col-md-6">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Email') }}<span class="spanColor">*</span></label>
                                @if(isset($restaurant->id))
                                <input type="text" name="email"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Email') }}" value="{{old('email')??$restaurant->email}}">
                                @else
                                <input type="text" name="email"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Email') }}" value="{{old('email')}}">
                                @endif
                                @error('email')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>
                            <div class="form-group col-md-6">
                            <label for="exampleFormControlInput1" class="">{{ __('owner.Mobile') }}<span class="spanColor">*</span></label>
                            @if(isset($restaurant->id))
                            <input type="text" name="mobile"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Mobile') }}" value="{{old('mobile')??$restaurant->mobile}}" onkeypress="return isNumberKey(event)">
                            @else
                            <input type="text" name="mobile"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Mobile') }}" value="{{old('mobile')}}" onkeypress="return isNumberKey(event)">
                            @endif
                            @error('mobile')
                                <div class="error-box">{{$message}}</div>
                            @enderror
                            </div>
                            <div class="form-group col-md-6 mb-0">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Website') }}</label>
                                @if(isset($restaurant->id))
                                <input type="text" name="website"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Website') }}" value="{{old('website')??$restaurant->website}}">
                                @else
                                <input type="text" name="website"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Website') }}" value="{{old('website')}}">
                                @endif
                                @error('website')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                            </div>
                           </div>
                        </div>
                     </div>


                     <div class="card">
                        <div class="card-header">
                           <h4>{{ __('owner.Social Media Links') }}</h4>
                        </div>
                        <div class="card-body">
                              <div class="row">
                              <div class="form-group col-md-6">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Facebook Link') }}</label>
                                @if(isset($restaurant->id))
                                <input type="text" name="facebook_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Facebook Link') }}" value="{{old('facebook_link')??$restaurant->facebook_link}}">
                                @else
                                <input type="text" name="facebook_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Facebook Link') }}" value="{{old('facebook_link')}}">
                                @endif
                                @error('facebook_link')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>
                              <div class="form-group col-md-6">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Twitter Link') }}</label>
                                @if(isset($restaurant->id))
                                <input type="text" name="twitter_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Twitter Link') }}" value="{{old('twitter_link')??$restaurant->twitter_link}}">
                                @else
                                <input type="text" name="twitter_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Twitter Link') }}" value="{{old('twitter_link')}}">
                                @endif
                                @error('twitter_link')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>
                               <div class="form-group col-md-6">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Instagram Link') }}</label>
                                @if(isset($restaurant->id))
                                <input type="text" name="instagram_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Instagram Link') }}" value="{{old('instagram_link')??$restaurant->instagram_link}}">
                                @else
                                <input type="text" name="instagram_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Instagram Link') }}" value="{{old('instagram_link')}}">
                                @endif
                                @error('instagram_link')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="card op-hr">
                        <div class="card-header">
                           <h4>{{ __('owner.Opening Hours') }}</h4>
                        </div>
                        <div class="card-body">
                              <div class="row">
                              <div class="form-group col-md-12">

                                <div class="cp-all">
                                <label>{{ __('owner.Monday') }}</label>
                                <button type="button" class="copy_btn">{{ __('owner.Copy to All') }}</button>
                                <div class="float-right">

                                </div>
                                </div>

                                <div class="row">
                                <div class="col-md-6">
                                <input type="time" name="monday_open_time" class="form-control open_time" value="{{ (old('monday_open_time') != '') ? old('monday_open_time')
                                : (isset($openingHours['mon_from']) ? $openingHours['mon_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="monday_close_time" class="form-control close_time" value="{{ (old('monday_close_time') != '') ? old('monday_close_time')
                                : (isset($openingHours['mon_to']) ? $openingHours['mon_to'] : '')  }}">

                                </div>
                                </div>

                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('owner.Tuesday') }}</label>
                                <div class="row">
                                <div class="col-md-6">

                                <input type="time" name="tuesday_open_time" class="form-control open_time" value="{{ (old('tuesday_open_time') != '') ? old('tuesday_open_time')
                                : (isset($openingHours['tue_from']) ? $openingHours['tue_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="tuesday_close_time" class="form-control close_time" value="{{ (old('tuesday_close_time') != '') ? old('tuesday_close_time')
                                : (isset($openingHours['tue_to']) ? $openingHours['tue_to'] : '')  }}">

                                </div>
                                </div>
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('owner.Wednesday') }}</label>
                                <div class="row">
                                <div class="col-md-6">

                                <input type="time" name="wednesday_open_time" class="form-control open_time" value="{{ (old('wednesday_open_time') != '') ? old('wednesday_open_time')
                                : (isset($openingHours['wed_from']) ? $openingHours['wed_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="wednesday_close_time" class="form-control close_time" value="{{ (old('wednesday_close_time') != '') ? old('wednesday_close_time')
                                : (isset($openingHours['wed_to']) ? $openingHours['wed_to'] : '')  }}">

                                </div>
                                </div>
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('owner.Thursday') }}</label>
                                <div class="row">
                                <div class="col-md-6">

                                <input type="time" name="thursday_open_time" class="form-control open_time" value="{{ (old('thursday_open_time') != '') ? old('thursday_open_time')
                                : (isset($openingHours['thu_from']) ? $openingHours['thu_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="thursday_close_time" class="form-control close_time" value="{{ (old('thursday_close_time') != '') ? old('thursday_close_time')
                                : (isset($openingHours['thu_to']) ? $openingHours['thu_to'] : '')  }}">

                                </div>
                                </div>
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('owner.Friday') }}</label>
                                <div class="row">
                                <div class="col-md-6">

                                <input type="time" name="friday_open_time" class="form-control open_time" value="{{ (old('friday_open_time') != '') ? old('friday_open_time')
                                : (isset($openingHours['fri_from']) ? $openingHours['fri_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="friday_close_time" class="form-control close_time" value="{{ (old('friday_close_time') != '') ? old('friday_close_time')
                                : (isset($openingHours['fri_to']) ? $openingHours['fri_to'] : '')  }}">

                                </div>
                                </div>
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('owner.Saturday') }}</label>
                                <div class="row">
                                <div class="col-md-6">

                                <input type="time" name="saturday_open_time" class="form-control open_time" value="{{ (old('saturday_open_time') != '') ? old('saturday_open_time')
                                : (isset($openingHours['sat_from']) ? $openingHours['sat_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="saturday_close_time" class="form-control close_time" value="{{ (old('saturday_close_time') != '') ? old('saturday_close_time')
                                : (isset($openingHours['sat_to']) ? $openingHours['sat_to'] : '')  }}">

                                </div>
                                </div>
                              </div>
                              <div class="form-group col-md-12">
                                <label>{{ __('owner.Sunday') }}</label>
                                <div class="row">
                                <div class="col-md-6">

                                <input type="time" name="sunday_open_time" class="form-control open_time" value="{{ (old('sunday_open_time') != '') ? old('sunday_open_time')
                                : (isset($openingHours['sun_from']) ? $openingHours['sun_from'] : '')  }}">

                                </div>
                                <div class="col-md-6">

                                <input type="time" name="sunday_close_time" class="form-control close_time" value="{{ (old('sunday_close_time') != '') ? old('sunday_close_time')
                                : (isset($openingHours['sun_to']) ? $openingHours['sun_to'] : '')  }}">

                                </div>
                                </div>
                              </div>
                              <div class="form-group col-md-12 create_date">
                                <div class="date_div">
                                 <label>{{ __('owner.Restaurant Holiday Management') }}</label>
                                 @if(isset($restaurantHolidays) && count($restaurantHolidays) > 0)
                                 @foreach($restaurantHolidays as $key => $holiday)
                                 <div class="row mb-2 holiday_block">
                                    <div class="col-md-6">
                                       <div class="input-group date" data-provide="datepicker">
                                          <input type="hidden" class="form-control" name="saved_occasion_id[]" value="{{$holiday['id']}}">
                                          <input type="text" min="{{date('Y-m-d')}}" name="saved_occasion_date[]" class="form-control" value="{{$holiday['date']}}">
                                          <div class="input-group-addon">
                                          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10 12C10.1978 12 10.3911 11.9414 10.5556 11.8315C10.72 11.7216 10.8482 11.5654 10.9239 11.3827C10.9996 11.2 11.0194 10.9989 10.9808 10.8049C10.9422 10.6109 10.847 10.4327 10.7071 10.2929C10.5673 10.153 10.3891 10.0578 10.1951 10.0192C10.0011 9.98063 9.80004 10.0004 9.61732 10.0761C9.43459 10.1518 9.27841 10.28 9.16853 10.4444C9.05865 10.6089 9 10.8022 9 11C9 11.2652 9.10536 11.5196 9.29289 11.7071C9.48043 11.8946 9.73478 12 10 12ZM15 12C15.1978 12 15.3911 11.9414 15.5556 11.8315C15.72 11.7216 15.8482 11.5654 15.9239 11.3827C15.9996 11.2 16.0194 10.9989 15.9808 10.8049C15.9422 10.6109 15.847 10.4327 15.7071 10.2929C15.5673 10.153 15.3891 10.0578 15.1951 10.0192C15.0011 9.98063 14.8 10.0004 14.6173 10.0761C14.4346 10.1518 14.2784 10.28 14.1685 10.4444C14.0586 10.6089 14 10.8022 14 11C14 11.2652 14.1054 11.5196 14.2929 11.7071C14.4804 11.8946 14.7348 12 15 12ZM10 16C10.1978 16 10.3911 15.9414 10.5556 15.8315C10.72 15.7216 10.8482 15.5654 10.9239 15.3827C10.9996 15.2 11.0194 14.9989 10.9808 14.8049C10.9422 14.6109 10.847 14.4327 10.7071 14.2929C10.5673 14.153 10.3891 14.0578 10.1951 14.0192C10.0011 13.9806 9.80004 14.0004 9.61732 14.0761C9.43459 14.1518 9.27841 14.28 9.16853 14.4444C9.05865 14.6089 9 14.8022 9 15C9 15.2652 9.10536 15.5196 9.29289 15.7071C9.48043 15.8946 9.73478 16 10 16ZM15 16C15.1978 16 15.3911 15.9414 15.5556 15.8315C15.72 15.7216 15.8482 15.5654 15.9239 15.3827C15.9996 15.2 16.0194 14.9989 15.9808 14.8049C15.9422 14.6109 15.847 14.4327 15.7071 14.2929C15.5673 14.153 15.3891 14.0578 15.1951 14.0192C15.0011 13.9806 14.8 14.0004 14.6173 14.0761C14.4346 14.1518 14.2784 14.28 14.1685 14.4444C14.0586 14.6089 14 14.8022 14 15C14 15.2652 14.1054 15.5196 14.2929 15.7071C14.4804 15.8946 14.7348 16 15 16ZM5 12C5.19778 12 5.39112 11.9414 5.55557 11.8315C5.72002 11.7216 5.84819 11.5654 5.92388 11.3827C5.99957 11.2 6.01937 10.9989 5.98079 10.8049C5.9422 10.6109 5.84696 10.4327 5.70711 10.2929C5.56725 10.153 5.38907 10.0578 5.19509 10.0192C5.00111 9.98063 4.80004 10.0004 4.61732 10.0761C4.43459 10.1518 4.27841 10.28 4.16853 10.4444C4.05865 10.6089 4 10.8022 4 11C4 11.2652 4.10536 11.5196 4.29289 11.7071C4.48043 11.8946 4.73478 12 5 12ZM17 2H16V1C16 0.734784 15.8946 0.48043 15.7071 0.292893C15.5196 0.105357 15.2652 0 15 0C14.7348 0 14.4804 0.105357 14.2929 0.292893C14.1054 0.48043 14 0.734784 14 1V2H6V1C6 0.734784 5.89464 0.48043 5.70711 0.292893C5.51957 0.105357 5.26522 0 5 0C4.73478 0 4.48043 0.105357 4.29289 0.292893C4.10536 0.48043 4 0.734784 4 1V2H3C2.20435 2 1.44129 2.31607 0.87868 2.87868C0.316071 3.44129 0 4.20435 0 5V17C0 17.7956 0.316071 18.5587 0.87868 19.1213C1.44129 19.6839 2.20435 20 3 20H17C17.7956 20 18.5587 19.6839 19.1213 19.1213C19.6839 18.5587 20 17.7956 20 17V5C20 4.20435 19.6839 3.44129 19.1213 2.87868C18.5587 2.31607 17.7956 2 17 2ZM18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18H3C2.73478 18 2.48043 17.8946 2.29289 17.7071C2.10536 17.5196 2 17.2652 2 17V8H18V17ZM18 6H2V5C2 4.73478 2.10536 4.48043 2.29289 4.29289C2.48043 4.10536 2.73478 4 3 4H17C17.2652 4 17.5196 4.10536 17.7071 4.29289C17.8946 4.48043 18 4.73478 18 5V6ZM5 16C5.19778 16 5.39112 15.9414 5.55557 15.8315C5.72002 15.7216 5.84819 15.5654 5.92388 15.3827C5.99957 15.2 6.01937 14.9989 5.98079 14.8049C5.9422 14.6109 5.84696 14.4327 5.70711 14.2929C5.56725 14.153 5.38907 14.0578 5.19509 14.0192C5.00111 13.9806 4.80004 14.0004 4.61732 14.0761C4.43459 14.1518 4.27841 14.28 4.16853 14.4444C4.05865 14.6089 4 14.8022 4 15C4 15.2652 4.10536 15.5196 4.29289 15.7071C4.48043 15.8946 4.73478 16 5 16Z" fill="#484848"/>
                                                </svg>
                                          </div>
                                      </div>
                                    </div>
                                    <div class="col-md-5">
                                    <input type="text" class="form-control" name="occasion_name[]" placeholder="occasion" value="{{$holiday['occasion']}}"  >
                                    </div>
                                    <div class="col-md-1 text-center">
                                       <!--  <button type="button" style="padding-top:21px;" id="{{$holiday['id']}}" onclick="removeSavedHoliday('saved',this);" class="btn-close" aria-label="Close"></button> -->
                                    </div>
                                 </div>
                                 @endforeach
                                 @else
                                 <!-- <div class="row mb-2 holiday_block">
                                    <div class="col-md-6">
                                       <div class="input-group date" data-provide="datepicker">
                                          <input type="text" min="{{date('Y-m-d')}}" name="occasion_date[]" class="form-control" value="">
                                          <div class="input-group-addon">
                                             <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10 12C10.1978 12 10.3911 11.9414 10.5556 11.8315C10.72 11.7216 10.8482 11.5654 10.9239 11.3827C10.9996 11.2 11.0194 10.9989 10.9808 10.8049C10.9422 10.6109 10.847 10.4327 10.7071 10.2929C10.5673 10.153 10.3891 10.0578 10.1951 10.0192C10.0011 9.98063 9.80004 10.0004 9.61732 10.0761C9.43459 10.1518 9.27841 10.28 9.16853 10.4444C9.05865 10.6089 9 10.8022 9 11C9 11.2652 9.10536 11.5196 9.29289 11.7071C9.48043 11.8946 9.73478 12 10 12ZM15 12C15.1978 12 15.3911 11.9414 15.5556 11.8315C15.72 11.7216 15.8482 11.5654 15.9239 11.3827C15.9996 11.2 16.0194 10.9989 15.9808 10.8049C15.9422 10.6109 15.847 10.4327 15.7071 10.2929C15.5673 10.153 15.3891 10.0578 15.1951 10.0192C15.0011 9.98063 14.8 10.0004 14.6173 10.0761C14.4346 10.1518 14.2784 10.28 14.1685 10.4444C14.0586 10.6089 14 10.8022 14 11C14 11.2652 14.1054 11.5196 14.2929 11.7071C14.4804 11.8946 14.7348 12 15 12ZM10 16C10.1978 16 10.3911 15.9414 10.5556 15.8315C10.72 15.7216 10.8482 15.5654 10.9239 15.3827C10.9996 15.2 11.0194 14.9989 10.9808 14.8049C10.9422 14.6109 10.847 14.4327 10.7071 14.2929C10.5673 14.153 10.3891 14.0578 10.1951 14.0192C10.0011 13.9806 9.80004 14.0004 9.61732 14.0761C9.43459 14.1518 9.27841 14.28 9.16853 14.4444C9.05865 14.6089 9 14.8022 9 15C9 15.2652 9.10536 15.5196 9.29289 15.7071C9.48043 15.8946 9.73478 16 10 16ZM15 16C15.1978 16 15.3911 15.9414 15.5556 15.8315C15.72 15.7216 15.8482 15.5654 15.9239 15.3827C15.9996 15.2 16.0194 14.9989 15.9808 14.8049C15.9422 14.6109 15.847 14.4327 15.7071 14.2929C15.5673 14.153 15.3891 14.0578 15.1951 14.0192C15.0011 13.9806 14.8 14.0004 14.6173 14.0761C14.4346 14.1518 14.2784 14.28 14.1685 14.4444C14.0586 14.6089 14 14.8022 14 15C14 15.2652 14.1054 15.5196 14.2929 15.7071C14.4804 15.8946 14.7348 16 15 16ZM5 12C5.19778 12 5.39112 11.9414 5.55557 11.8315C5.72002 11.7216 5.84819 11.5654 5.92388 11.3827C5.99957 11.2 6.01937 10.9989 5.98079 10.8049C5.9422 10.6109 5.84696 10.4327 5.70711 10.2929C5.56725 10.153 5.38907 10.0578 5.19509 10.0192C5.00111 9.98063 4.80004 10.0004 4.61732 10.0761C4.43459 10.1518 4.27841 10.28 4.16853 10.4444C4.05865 10.6089 4 10.8022 4 11C4 11.2652 4.10536 11.5196 4.29289 11.7071C4.48043 11.8946 4.73478 12 5 12ZM17 2H16V1C16 0.734784 15.8946 0.48043 15.7071 0.292893C15.5196 0.105357 15.2652 0 15 0C14.7348 0 14.4804 0.105357 14.2929 0.292893C14.1054 0.48043 14 0.734784 14 1V2H6V1C6 0.734784 5.89464 0.48043 5.70711 0.292893C5.51957 0.105357 5.26522 0 5 0C4.73478 0 4.48043 0.105357 4.29289 0.292893C4.10536 0.48043 4 0.734784 4 1V2H3C2.20435 2 1.44129 2.31607 0.87868 2.87868C0.316071 3.44129 0 4.20435 0 5V17C0 17.7956 0.316071 18.5587 0.87868 19.1213C1.44129 19.6839 2.20435 20 3 20H17C17.7956 20 18.5587 19.6839 19.1213 19.1213C19.6839 18.5587 20 17.7956 20 17V5C20 4.20435 19.6839 3.44129 19.1213 2.87868C18.5587 2.31607 17.7956 2 17 2ZM18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18H3C2.73478 18 2.48043 17.8946 2.29289 17.7071C2.10536 17.5196 2 17.2652 2 17V8H18V17ZM18 6H2V5C2 4.73478 2.10536 4.48043 2.29289 4.29289C2.48043 4.10536 2.73478 4 3 4H17C17.2652 4 17.5196 4.10536 17.7071 4.29289C17.8946 4.48043 18 4.73478 18 5V6ZM5 16C5.19778 16 5.39112 15.9414 5.55557 15.8315C5.72002 15.7216 5.84819 15.5654 5.92388 15.3827C5.99957 15.2 6.01937 14.9989 5.98079 14.8049C5.9422 14.6109 5.84696 14.4327 5.70711 14.2929C5.56725 14.153 5.38907 14.0578 5.19509 14.0192C5.00111 13.9806 4.80004 14.0004 4.61732 14.0761C4.43459 14.1518 4.27841 14.28 4.16853 14.4444C4.05865 14.6089 4 14.8022 4 15C4 15.2652 4.10536 15.5196 4.29289 15.7071C4.48043 15.8946 4.73478 16 5 16Z" fill="#484848"/>
                                                </svg>
                                          </div>
                                      </div>
                                    </div>
                                    <div class="col-md-5">
                                    <input type="text" class="form-control" name="occasion_name[]" placeholder="occasion" value=""  required="">
                                    </div>
                                    <div class="col-md-1 text-center">
                                        <button type="button" style="padding-top:21px;" onclick="removeSavedHoliday('local',this);" class="btn-close" aria-label="Close"></button>
                                    </div>
                                 </div> -->
                                 @endif
                              </div>

                           </div>
                                 <div class="form-group col-md-6 mb-0">
                            <button class="btn p-0" type="button" href="javascript:" onclick="createDate()">{{ __('owner.Plusadd') }}
                            @if(isset($restaurantHolidays) && count($restaurantHolidays) > 0)
                            {{ __('owner.More') }}
                            @else
                            {{ __('owner.Holiday') }}
                            @endif
                            </button>
                           </div>
                           </div>
                        </div>
                     </div>
                     <div class="card">
                        <!-- <select name="facility_id[]" id="facility_id" class="form-select form-control chosen-select" aria-label="Default select example" multiple>
                        </select> -->
                        <div class="card-header">
                           <h4>{{ __('owner.Restaurant Info') }}</h4>
                        </div>
                        <div class="card-body">
                            <form>

                           <div class="row">
                            @foreach($facilities as $key=>$cuisineType)
                                @if(in_array($key,$restaurantFacilities))
                                <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" name="facility_id[]" value="{{$key}}" type="checkbox" id="gridCheck1" checked>
                                    <label class="form-check-label" for="gridCheck1">
                                       {{$cuisineType}}
                                    </label>
                                </div>
                                </div>
                                @elseif(is_array(old('facility_id'))== $key)
                                <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" name="facility_id[]" value="{{$key}}" type="checkbox" id="gridCheck1" checked>
                                    <label class="form-check-label" for="gridCheck1">
                                       {{$cuisineType}}
                                    </label>
                                </div>
                                </div>
                                @else
                                <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" name="facility_id[]" value="{{$key}}" type="checkbox" id="gridCheck1">
                                    <label class="form-check-label" for="gridCheck1">
                                       {{$cuisineType}}
                                    </label>
                                </div>
                                </div>
                                @endif
                            @endforeach
                           </div>
                            </form>
                        </div>
                        @error('facility_id')
                        <div class="error-box">{{$message}}</div>
                        @enderror
                     </div>
                     <div class="card">
                        <div class="card-header">
                           <h4>{{ __('owner.Location') }}<span class="spanColor">*</span></h4>
                        </div>
                        <div class="card-body">
                              <div class="input-group date">
                    @if(isset($restaurant->id))

                    <input type="text" id="address" name="address" class="form-control map-input" id="searchInputSec" value="{{old('address')??$restaurant->address}}">
                    @else
                  <input type="text" id="address" name="address" class="form-control map-input" id="searchInputSec" value="{{old('address')}}">
                    @endif

                                 <div class="input-group-addon">
                                    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M10.0021 13.0026C11.6592 13.0026 13.0026 11.6592 13.0026 10.0021C13.0026 8.34487 11.6592 7.00146 10.0021 7.00146C8.34487 7.00146 7.00146 8.34487 7.00146 10.0021C7.00146 11.6592 8.34487 13.0026 10.0021 13.0026Z" fill="#484848"/>
                                       <path d="M20.0039 9.00176H17.9345C17.7103 7.24152 16.9078 5.60559 15.653 4.35086C14.3983 3.09612 12.7624 2.29364 11.0021 2.0694V0H9.00176V2.0694C7.24158 2.2938 5.60575 3.09634 4.35105 4.35105C3.09634 5.60575 2.2938 7.24158 2.0694 9.00176H0V11.0021H2.0694C2.2938 12.7623 3.09634 14.3982 4.35105 15.6529C5.60575 16.9076 7.24158 17.7101 9.00176 17.9345V20.0039H11.0021V17.9345C12.7623 17.7101 14.3982 16.9076 15.6529 15.6529C16.9076 14.3982 17.7101 12.7623 17.9345 11.0021H20.0039V9.00176ZM10.002 16.0031C6.69231 16.0031 4.00078 13.3106 4.00078 10.002C4.00078 6.69331 6.69231 4.00078 10.002 4.00078C13.3116 4.00078 16.0031 6.69331 16.0031 10.002C16.0031 13.3106 13.3116 16.0031 10.002 16.0031Z" fill="#484848"/>
                                       </svg>
                                </div>
                             </div>


                        @if(isset($restaurant->id))
                          <input type="hidden" class="form-control" name="latitude" id="lat" value="{{old('latitude')??$restaurant->latitude}}">
                          <input type="hidden" class="form-control" name="longitude" id="lon" value="{{old('longitude')??$restaurant->longitude}}">
                          <!-- <input type="hidden" class="form-control" name="{{old('address')??$restaurant->address}}" id="address" value=""> -->
                          @else
                           <input type="hidden" class="form-control" name="latitude" id="lat" value="{{old('latitude')}}">
                          <input type="hidden" class="form-control" name="longitude" id="lon" value="{{old('longitude')}}">
                         <!--  <input type="hidden" class="form-control" name="{{old('address')}}" id="address" value=""> -->
                          @endif


        <div class="location_map" style="width:100%;height:400px; ">
        <div id="mapsec" style="width: 100%; height: 100%" >

        </div>
    </div>


                        </div>
                     </div>

                     <div class="card">
                        <div class="card-header">
                           <h4>{{ __('owner.Image') }}</h4>
                        </div>
                        <div class="card-body">
                           <h4 class="h6">{{ __('owner.Gallery Photos') }}<span class="spanColor">*</span></h4>
                           <div class="row mb-4">
                              <div class="col-md-4">
                                 <div class="input-upload-img-input ">
                                    <input type="file" class="file" id="all_images" accept="image/*" name="images[]" multiple onchange="preview_image(event)">
                                    @error('images')
                                    <div class="error-box">{{$message}}</div>
                                    @enderror<br/>
                                    <svg width="94" height="40" viewBox="0 0 94 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M47.007 3.993L47.031 11H48.938L48.986 3.986L51.5 6.5L53 5L48 0L43 5L44.5 6.5L47.007 3.993Z" fill="#939393"/>
                                       <path d="M54 10V13H42V10H40V16H56V10H54Z" fill="#939393"/>
                                       <path d="M5.73702 37.168C7.61302 37.168 8.77502 36.174 9.48902 35.054L8.08902 34.354C7.64102 35.124 6.73102 35.712 5.73702 35.712C3.88902 35.712 2.51702 34.284 2.51702 32.338C2.51702 30.364 3.88902 28.964 5.73702 28.964C6.73102 28.964 7.64102 29.538 8.08902 30.322L9.47502 29.594C8.78902 28.474 7.61302 27.508 5.73702 27.508C2.97902 27.508 0.837023 29.454 0.837023 32.338C0.837023 35.208 2.97902 37.168 5.73702 37.168ZM12.214 37V27.662H10.744V37H12.214ZM14.8629 29.412C15.3669 29.412 15.7729 29.006 15.7729 28.502C15.7729 27.998 15.3669 27.592 14.8629 27.592C14.3589 27.592 13.9529 27.998 13.9529 28.502C13.9529 29.006 14.3589 29.412 14.8629 29.412ZM15.5909 37V30.238H14.1209V37H15.5909ZM20.5779 37.168C21.9079 37.168 22.6919 36.594 23.1679 35.964L22.2019 35.054C21.8239 35.586 21.3059 35.866 20.6479 35.866C19.4299 35.866 18.6039 34.928 18.6039 33.612C18.6039 32.296 19.4299 31.372 20.6479 31.372C21.3059 31.372 21.8239 31.624 22.2019 32.156L23.1679 31.274C22.6919 30.63 21.9079 30.07 20.5779 30.07C18.5339 30.07 17.0919 31.568 17.0919 33.612C17.0919 35.656 18.5339 37.168 20.5779 37.168ZM30.7986 37L27.9426 33.304L30.7426 30.238H28.9226L25.9406 33.5V27.662H24.4706V37H25.9406V35.18L26.8926 34.2L28.9506 37H30.7986ZM37.5067 37.168C38.1787 37.168 38.6127 36.972 38.8787 36.734L38.5287 35.614C38.4167 35.74 38.1647 35.866 37.8847 35.866C37.4647 35.866 37.2407 35.516 37.2407 35.054V31.512H38.6127V30.238H37.2407V28.39H35.7707V30.238H34.6507V31.512H35.7707V35.418C35.7707 36.552 36.3587 37.168 37.5067 37.168ZM42.9994 37.168C45.1554 37.168 46.4714 35.544 46.4714 33.612C46.4714 31.666 45.1554 30.07 42.9994 30.07C40.8434 30.07 39.5274 31.666 39.5274 33.612C39.5274 35.544 40.8434 37.168 42.9994 37.168ZM42.9994 35.866C41.7534 35.866 41.0534 34.816 41.0534 33.612C41.0534 32.422 41.7534 31.372 42.9994 31.372C44.2594 31.372 44.9454 32.422 44.9454 33.612C44.9454 34.816 44.2594 35.866 42.9994 35.866ZM57.6159 37V30.238H56.1459V34.984C55.8099 35.432 55.1659 35.866 54.4239 35.866C53.5839 35.866 53.0519 35.53 53.0519 34.48V30.238H51.5819V35.026C51.5819 36.398 52.3099 37.168 53.7659 37.168C54.8299 37.168 55.6699 36.636 56.1459 36.104V37H57.6159ZM63.1652 37.168C64.9152 37.168 66.1612 35.838 66.1612 33.612C66.1612 31.386 64.9152 30.07 63.1652 30.07C62.2832 30.07 61.4992 30.49 60.9952 31.162V30.238H59.5252V39.576H60.9952V36.062C61.5552 36.776 62.3112 37.168 63.1652 37.168ZM62.7312 35.866C62.0452 35.866 61.3172 35.446 60.9952 34.942V32.268C61.3312 31.764 62.0452 31.372 62.7312 31.372C63.8932 31.372 64.6492 32.296 64.6492 33.612C64.6492 34.928 63.8932 35.866 62.7312 35.866ZM69.1027 37V27.662H67.6327V37H69.1027ZM74.0756 37.168C76.2316 37.168 77.5476 35.544 77.5476 33.612C77.5476 31.666 76.2316 30.07 74.0756 30.07C71.9196 30.07 70.6036 31.666 70.6036 33.612C70.6036 35.544 71.9196 37.168 74.0756 37.168ZM74.0756 35.866C72.8296 35.866 72.1296 34.816 72.1296 33.612C72.1296 32.422 72.8296 31.372 74.0756 31.372C75.3356 31.372 76.0216 32.422 76.0216 33.612C76.0216 34.816 75.3356 35.866 74.0756 35.866ZM84.6627 37V32.506C84.6627 30.7 83.3467 30.07 81.8347 30.07C80.7567 30.07 79.7767 30.406 78.9927 31.162L79.6087 32.184C80.1827 31.596 80.8547 31.316 81.6107 31.316C82.5347 31.316 83.1927 31.792 83.1927 32.576V33.584C82.6887 33.01 81.9187 32.716 80.9947 32.716C79.8887 32.716 78.6567 33.36 78.6567 34.928C78.6567 36.412 79.9027 37.168 80.9947 37.168C81.8907 37.168 82.6887 36.846 83.1927 36.258V37H84.6627ZM81.5827 36.16C80.7567 36.16 80.1267 35.684 80.1267 34.942C80.1267 34.214 80.7567 33.724 81.5827 33.724C82.2127 33.724 82.8427 33.962 83.1927 34.424V35.46C82.8427 35.922 82.2127 36.16 81.5827 36.16ZM92.7982 37V27.662H91.3282V31.176C90.7962 30.448 90.0122 30.07 89.1582 30.07C87.4222 30.07 86.1622 31.428 86.1622 33.612C86.1622 35.852 87.4362 37.168 89.1582 37.168C90.0402 37.168 90.8102 36.748 91.3282 36.076V37H92.7982ZM89.5922 35.866C88.4162 35.866 87.6742 34.928 87.6742 33.612C87.6742 32.31 88.4162 31.372 89.5922 31.372C90.2782 31.372 91.0062 31.778 91.3282 32.282V34.956C91.0062 35.46 90.2782 35.866 89.5922 35.866Z" fill="#939393"/>
                                       </svg>

                                 </div>
                                 <small></small>
                              </div>

                              @if(isset($images))
                              @foreach($images as $key=>$val)
                              <div class="col-md-4">
                                 <div class="input-upload-img img-wrap">

                                    <span id="{{$val->id}}" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>
                                    <img class="img-fluid" id="image_{{$val->id}}" src="{{ asset('storage').'/'.$val->image}}">

                                 </div>
                              </div>
                              @endforeach


                              @endif

                              <div class="row img_all" >

                              </div>

                           </div>

                           <h4 class="h6">{{ __('owner.Upload 360') }}<span>&#176;</span>{{ __('owner.Photos') }}</h4>
                           <div class="row mb-4">
                              <div class="col-md-4">
                                 <div class="input-upload-img-input">
                                    <input type="file" class="file" id="files" name="images_360[]" accept="image/*" multiple onchange="previews_image(event)">
                                    @error('images_360')
                                    <div class="error-box">{{$message}}</div>
                                    @enderror<br/>
                                    <svg width="94" height="40" viewBox="0 0 94 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M47.007 3.993L47.031 11H48.938L48.986 3.986L51.5 6.5L53 5L48 0L43 5L44.5 6.5L47.007 3.993Z" fill="#939393"/>
                                       <path d="M54 10V13H42V10H40V16H56V10H54Z" fill="#939393"/>
                                       <path d="M5.73702 37.168C7.61302 37.168 8.77502 36.174 9.48902 35.054L8.08902 34.354C7.64102 35.124 6.73102 35.712 5.73702 35.712C3.88902 35.712 2.51702 34.284 2.51702 32.338C2.51702 30.364 3.88902 28.964 5.73702 28.964C6.73102 28.964 7.64102 29.538 8.08902 30.322L9.47502 29.594C8.78902 28.474 7.61302 27.508 5.73702 27.508C2.97902 27.508 0.837023 29.454 0.837023 32.338C0.837023 35.208 2.97902 37.168 5.73702 37.168ZM12.214 37V27.662H10.744V37H12.214ZM14.8629 29.412C15.3669 29.412 15.7729 29.006 15.7729 28.502C15.7729 27.998 15.3669 27.592 14.8629 27.592C14.3589 27.592 13.9529 27.998 13.9529 28.502C13.9529 29.006 14.3589 29.412 14.8629 29.412ZM15.5909 37V30.238H14.1209V37H15.5909ZM20.5779 37.168C21.9079 37.168 22.6919 36.594 23.1679 35.964L22.2019 35.054C21.8239 35.586 21.3059 35.866 20.6479 35.866C19.4299 35.866 18.6039 34.928 18.6039 33.612C18.6039 32.296 19.4299 31.372 20.6479 31.372C21.3059 31.372 21.8239 31.624 22.2019 32.156L23.1679 31.274C22.6919 30.63 21.9079 30.07 20.5779 30.07C18.5339 30.07 17.0919 31.568 17.0919 33.612C17.0919 35.656 18.5339 37.168 20.5779 37.168ZM30.7986 37L27.9426 33.304L30.7426 30.238H28.9226L25.9406 33.5V27.662H24.4706V37H25.9406V35.18L26.8926 34.2L28.9506 37H30.7986ZM37.5067 37.168C38.1787 37.168 38.6127 36.972 38.8787 36.734L38.5287 35.614C38.4167 35.74 38.1647 35.866 37.8847 35.866C37.4647 35.866 37.2407 35.516 37.2407 35.054V31.512H38.6127V30.238H37.2407V28.39H35.7707V30.238H34.6507V31.512H35.7707V35.418C35.7707 36.552 36.3587 37.168 37.5067 37.168ZM42.9994 37.168C45.1554 37.168 46.4714 35.544 46.4714 33.612C46.4714 31.666 45.1554 30.07 42.9994 30.07C40.8434 30.07 39.5274 31.666 39.5274 33.612C39.5274 35.544 40.8434 37.168 42.9994 37.168ZM42.9994 35.866C41.7534 35.866 41.0534 34.816 41.0534 33.612C41.0534 32.422 41.7534 31.372 42.9994 31.372C44.2594 31.372 44.9454 32.422 44.9454 33.612C44.9454 34.816 44.2594 35.866 42.9994 35.866ZM57.6159 37V30.238H56.1459V34.984C55.8099 35.432 55.1659 35.866 54.4239 35.866C53.5839 35.866 53.0519 35.53 53.0519 34.48V30.238H51.5819V35.026C51.5819 36.398 52.3099 37.168 53.7659 37.168C54.8299 37.168 55.6699 36.636 56.1459 36.104V37H57.6159ZM63.1652 37.168C64.9152 37.168 66.1612 35.838 66.1612 33.612C66.1612 31.386 64.9152 30.07 63.1652 30.07C62.2832 30.07 61.4992 30.49 60.9952 31.162V30.238H59.5252V39.576H60.9952V36.062C61.5552 36.776 62.3112 37.168 63.1652 37.168ZM62.7312 35.866C62.0452 35.866 61.3172 35.446 60.9952 34.942V32.268C61.3312 31.764 62.0452 31.372 62.7312 31.372C63.8932 31.372 64.6492 32.296 64.6492 33.612C64.6492 34.928 63.8932 35.866 62.7312 35.866ZM69.1027 37V27.662H67.6327V37H69.1027ZM74.0756 37.168C76.2316 37.168 77.5476 35.544 77.5476 33.612C77.5476 31.666 76.2316 30.07 74.0756 30.07C71.9196 30.07 70.6036 31.666 70.6036 33.612C70.6036 35.544 71.9196 37.168 74.0756 37.168ZM74.0756 35.866C72.8296 35.866 72.1296 34.816 72.1296 33.612C72.1296 32.422 72.8296 31.372 74.0756 31.372C75.3356 31.372 76.0216 32.422 76.0216 33.612C76.0216 34.816 75.3356 35.866 74.0756 35.866ZM84.6627 37V32.506C84.6627 30.7 83.3467 30.07 81.8347 30.07C80.7567 30.07 79.7767 30.406 78.9927 31.162L79.6087 32.184C80.1827 31.596 80.8547 31.316 81.6107 31.316C82.5347 31.316 83.1927 31.792 83.1927 32.576V33.584C82.6887 33.01 81.9187 32.716 80.9947 32.716C79.8887 32.716 78.6567 33.36 78.6567 34.928C78.6567 36.412 79.9027 37.168 80.9947 37.168C81.8907 37.168 82.6887 36.846 83.1927 36.258V37H84.6627ZM81.5827 36.16C80.7567 36.16 80.1267 35.684 80.1267 34.942C80.1267 34.214 80.7567 33.724 81.5827 33.724C82.2127 33.724 82.8427 33.962 83.1927 34.424V35.46C82.8427 35.922 82.2127 36.16 81.5827 36.16ZM92.7982 37V27.662H91.3282V31.176C90.7962 30.448 90.0122 30.07 89.1582 30.07C87.4222 30.07 86.1622 31.428 86.1622 33.612C86.1622 35.852 87.4362 37.168 89.1582 37.168C90.0402 37.168 90.8102 36.748 91.3282 36.076V37H92.7982ZM89.5922 35.866C88.4162 35.866 87.6742 34.928 87.6742 33.612C87.6742 32.31 88.4162 31.372 89.5922 31.372C90.2782 31.372 91.0062 31.778 91.3282 32.282V34.956C91.0062 35.46 90.2782 35.866 89.5922 35.866Z" fill="#939393"/>
                                       </svg>

                                 </div>
                                 <small></small>
                              </div>
                              @if(isset($images_360))
                              @foreach($images_360 as $key=>$val)
                              <div class="col-md-4">
                                 <div class="input-upload-img img-wrap">

                                    <span id="{{$val->id}}" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>
                                    <img class="img-fluid" id="image_{{$val->id}}" src="{{ asset('storage').'/'.$val->image}}">

                                 </div>
                              </div>
                              @endforeach
                                @endif

                              <div class="col-md-4" >
                                 <div class="input-upload-img img-wrap" >


                                    <img class="img-fluid" id="outputs_image" src="" >

                                 </div>
                              </div>


                           </div>



                        <h4 class="h6">{{ __('owner.Upload Cover Image') }}<span class="spanColor">*</span></h4>
                           <div class="row mb-4">
                              <div class="col-md-4">
                                 <div class="input-upload-img-input">
                                    <input type="file" class="file" id="files" name="cover_image" accept="image/*" multiple onchange="previewss_image(event)">
                                    @error('cover_image')
                                    <div class="error-box">{{$message}}</div>
                                    @enderror<br/>
                                    <svg width="94" height="40" viewBox="0 0 94 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M47.007 3.993L47.031 11H48.938L48.986 3.986L51.5 6.5L53 5L48 0L43 5L44.5 6.5L47.007 3.993Z" fill="#939393"/>
                                       <path d="M54 10V13H42V10H40V16H56V10H54Z" fill="#939393"/>
                                       <path d="M5.73702 37.168C7.61302 37.168 8.77502 36.174 9.48902 35.054L8.08902 34.354C7.64102 35.124 6.73102 35.712 5.73702 35.712C3.88902 35.712 2.51702 34.284 2.51702 32.338C2.51702 30.364 3.88902 28.964 5.73702 28.964C6.73102 28.964 7.64102 29.538 8.08902 30.322L9.47502 29.594C8.78902 28.474 7.61302 27.508 5.73702 27.508C2.97902 27.508 0.837023 29.454 0.837023 32.338C0.837023 35.208 2.97902 37.168 5.73702 37.168ZM12.214 37V27.662H10.744V37H12.214ZM14.8629 29.412C15.3669 29.412 15.7729 29.006 15.7729 28.502C15.7729 27.998 15.3669 27.592 14.8629 27.592C14.3589 27.592 13.9529 27.998 13.9529 28.502C13.9529 29.006 14.3589 29.412 14.8629 29.412ZM15.5909 37V30.238H14.1209V37H15.5909ZM20.5779 37.168C21.9079 37.168 22.6919 36.594 23.1679 35.964L22.2019 35.054C21.8239 35.586 21.3059 35.866 20.6479 35.866C19.4299 35.866 18.6039 34.928 18.6039 33.612C18.6039 32.296 19.4299 31.372 20.6479 31.372C21.3059 31.372 21.8239 31.624 22.2019 32.156L23.1679 31.274C22.6919 30.63 21.9079 30.07 20.5779 30.07C18.5339 30.07 17.0919 31.568 17.0919 33.612C17.0919 35.656 18.5339 37.168 20.5779 37.168ZM30.7986 37L27.9426 33.304L30.7426 30.238H28.9226L25.9406 33.5V27.662H24.4706V37H25.9406V35.18L26.8926 34.2L28.9506 37H30.7986ZM37.5067 37.168C38.1787 37.168 38.6127 36.972 38.8787 36.734L38.5287 35.614C38.4167 35.74 38.1647 35.866 37.8847 35.866C37.4647 35.866 37.2407 35.516 37.2407 35.054V31.512H38.6127V30.238H37.2407V28.39H35.7707V30.238H34.6507V31.512H35.7707V35.418C35.7707 36.552 36.3587 37.168 37.5067 37.168ZM42.9994 37.168C45.1554 37.168 46.4714 35.544 46.4714 33.612C46.4714 31.666 45.1554 30.07 42.9994 30.07C40.8434 30.07 39.5274 31.666 39.5274 33.612C39.5274 35.544 40.8434 37.168 42.9994 37.168ZM42.9994 35.866C41.7534 35.866 41.0534 34.816 41.0534 33.612C41.0534 32.422 41.7534 31.372 42.9994 31.372C44.2594 31.372 44.9454 32.422 44.9454 33.612C44.9454 34.816 44.2594 35.866 42.9994 35.866ZM57.6159 37V30.238H56.1459V34.984C55.8099 35.432 55.1659 35.866 54.4239 35.866C53.5839 35.866 53.0519 35.53 53.0519 34.48V30.238H51.5819V35.026C51.5819 36.398 52.3099 37.168 53.7659 37.168C54.8299 37.168 55.6699 36.636 56.1459 36.104V37H57.6159ZM63.1652 37.168C64.9152 37.168 66.1612 35.838 66.1612 33.612C66.1612 31.386 64.9152 30.07 63.1652 30.07C62.2832 30.07 61.4992 30.49 60.9952 31.162V30.238H59.5252V39.576H60.9952V36.062C61.5552 36.776 62.3112 37.168 63.1652 37.168ZM62.7312 35.866C62.0452 35.866 61.3172 35.446 60.9952 34.942V32.268C61.3312 31.764 62.0452 31.372 62.7312 31.372C63.8932 31.372 64.6492 32.296 64.6492 33.612C64.6492 34.928 63.8932 35.866 62.7312 35.866ZM69.1027 37V27.662H67.6327V37H69.1027ZM74.0756 37.168C76.2316 37.168 77.5476 35.544 77.5476 33.612C77.5476 31.666 76.2316 30.07 74.0756 30.07C71.9196 30.07 70.6036 31.666 70.6036 33.612C70.6036 35.544 71.9196 37.168 74.0756 37.168ZM74.0756 35.866C72.8296 35.866 72.1296 34.816 72.1296 33.612C72.1296 32.422 72.8296 31.372 74.0756 31.372C75.3356 31.372 76.0216 32.422 76.0216 33.612C76.0216 34.816 75.3356 35.866 74.0756 35.866ZM84.6627 37V32.506C84.6627 30.7 83.3467 30.07 81.8347 30.07C80.7567 30.07 79.7767 30.406 78.9927 31.162L79.6087 32.184C80.1827 31.596 80.8547 31.316 81.6107 31.316C82.5347 31.316 83.1927 31.792 83.1927 32.576V33.584C82.6887 33.01 81.9187 32.716 80.9947 32.716C79.8887 32.716 78.6567 33.36 78.6567 34.928C78.6567 36.412 79.9027 37.168 80.9947 37.168C81.8907 37.168 82.6887 36.846 83.1927 36.258V37H84.6627ZM81.5827 36.16C80.7567 36.16 80.1267 35.684 80.1267 34.942C80.1267 34.214 80.7567 33.724 81.5827 33.724C82.2127 33.724 82.8427 33.962 83.1927 34.424V35.46C82.8427 35.922 82.2127 36.16 81.5827 36.16ZM92.7982 37V27.662H91.3282V31.176C90.7962 30.448 90.0122 30.07 89.1582 30.07C87.4222 30.07 86.1622 31.428 86.1622 33.612C86.1622 35.852 87.4362 37.168 89.1582 37.168C90.0402 37.168 90.8102 36.748 91.3282 36.076V37H92.7982ZM89.5922 35.866C88.4162 35.866 87.6742 34.928 87.6742 33.612C87.6742 32.31 88.4162 31.372 89.5922 31.372C90.2782 31.372 91.0062 31.778 91.3282 32.282V34.956C91.0062 35.46 90.2782 35.866 89.5922 35.866Z" fill="#939393"/>
                                       </svg>

                                 </div>
                                 <small>{{ __('owner.Size > 1900x500') }}</small>
                              </div>
                              @if(isset($cover_image))

                              <div class="col-md-4">
                                 <div class="input-upload-img img-wrap">

                                    <span id="{{$cover_image->id}}" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>
                                    <img class="img-fluid" id="image_{{$cover_image->id}}" src="{{ asset('storage').'/'.$cover_image->image}}">

                                 </div>
                              </div>

                                @endif
                              <div class="col-md-4" >
                                 <div class="input-upload-img img-wrap" >


                                    <img class="img-fluid" id="outputss_image" src="" >

                                 </div>
                              </div>


                           </div>

                           <h4 class="h6">{{ __('owner.Upload Menu') }}<span class="spanColor">*</span></h4>
                           <div class="row">
                              <div class="col-md-4">
                                 <div class="input-upload-img-input">
                                    <input type="file" class="file" id="myPdf" name="menu_files" accept="application/pdf" multiple onchange="previewsss_image(event)">
                                    @error('menu_files')
                                    <div class="error-box">{{$message}}</div>
                                    @enderror<br/>
                                    <svg width="94" height="40" viewBox="0 0 94 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M47.007 3.993L47.031 11H48.938L48.986 3.986L51.5 6.5L53 5L48 0L43 5L44.5 6.5L47.007 3.993Z" fill="#939393"/>
                                       <path d="M54 10V13H42V10H40V16H56V10H54Z" fill="#939393"/>
                                       <path d="M5.73702 37.168C7.61302 37.168 8.77502 36.174 9.48902 35.054L8.08902 34.354C7.64102 35.124 6.73102 35.712 5.73702 35.712C3.88902 35.712 2.51702 34.284 2.51702 32.338C2.51702 30.364 3.88902 28.964 5.73702 28.964C6.73102 28.964 7.64102 29.538 8.08902 30.322L9.47502 29.594C8.78902 28.474 7.61302 27.508 5.73702 27.508C2.97902 27.508 0.837023 29.454 0.837023 32.338C0.837023 35.208 2.97902 37.168 5.73702 37.168ZM12.214 37V27.662H10.744V37H12.214ZM14.8629 29.412C15.3669 29.412 15.7729 29.006 15.7729 28.502C15.7729 27.998 15.3669 27.592 14.8629 27.592C14.3589 27.592 13.9529 27.998 13.9529 28.502C13.9529 29.006 14.3589 29.412 14.8629 29.412ZM15.5909 37V30.238H14.1209V37H15.5909ZM20.5779 37.168C21.9079 37.168 22.6919 36.594 23.1679 35.964L22.2019 35.054C21.8239 35.586 21.3059 35.866 20.6479 35.866C19.4299 35.866 18.6039 34.928 18.6039 33.612C18.6039 32.296 19.4299 31.372 20.6479 31.372C21.3059 31.372 21.8239 31.624 22.2019 32.156L23.1679 31.274C22.6919 30.63 21.9079 30.07 20.5779 30.07C18.5339 30.07 17.0919 31.568 17.0919 33.612C17.0919 35.656 18.5339 37.168 20.5779 37.168ZM30.7986 37L27.9426 33.304L30.7426 30.238H28.9226L25.9406 33.5V27.662H24.4706V37H25.9406V35.18L26.8926 34.2L28.9506 37H30.7986ZM37.5067 37.168C38.1787 37.168 38.6127 36.972 38.8787 36.734L38.5287 35.614C38.4167 35.74 38.1647 35.866 37.8847 35.866C37.4647 35.866 37.2407 35.516 37.2407 35.054V31.512H38.6127V30.238H37.2407V28.39H35.7707V30.238H34.6507V31.512H35.7707V35.418C35.7707 36.552 36.3587 37.168 37.5067 37.168ZM42.9994 37.168C45.1554 37.168 46.4714 35.544 46.4714 33.612C46.4714 31.666 45.1554 30.07 42.9994 30.07C40.8434 30.07 39.5274 31.666 39.5274 33.612C39.5274 35.544 40.8434 37.168 42.9994 37.168ZM42.9994 35.866C41.7534 35.866 41.0534 34.816 41.0534 33.612C41.0534 32.422 41.7534 31.372 42.9994 31.372C44.2594 31.372 44.9454 32.422 44.9454 33.612C44.9454 34.816 44.2594 35.866 42.9994 35.866ZM57.6159 37V30.238H56.1459V34.984C55.8099 35.432 55.1659 35.866 54.4239 35.866C53.5839 35.866 53.0519 35.53 53.0519 34.48V30.238H51.5819V35.026C51.5819 36.398 52.3099 37.168 53.7659 37.168C54.8299 37.168 55.6699 36.636 56.1459 36.104V37H57.6159ZM63.1652 37.168C64.9152 37.168 66.1612 35.838 66.1612 33.612C66.1612 31.386 64.9152 30.07 63.1652 30.07C62.2832 30.07 61.4992 30.49 60.9952 31.162V30.238H59.5252V39.576H60.9952V36.062C61.5552 36.776 62.3112 37.168 63.1652 37.168ZM62.7312 35.866C62.0452 35.866 61.3172 35.446 60.9952 34.942V32.268C61.3312 31.764 62.0452 31.372 62.7312 31.372C63.8932 31.372 64.6492 32.296 64.6492 33.612C64.6492 34.928 63.8932 35.866 62.7312 35.866ZM69.1027 37V27.662H67.6327V37H69.1027ZM74.0756 37.168C76.2316 37.168 77.5476 35.544 77.5476 33.612C77.5476 31.666 76.2316 30.07 74.0756 30.07C71.9196 30.07 70.6036 31.666 70.6036 33.612C70.6036 35.544 71.9196 37.168 74.0756 37.168ZM74.0756 35.866C72.8296 35.866 72.1296 34.816 72.1296 33.612C72.1296 32.422 72.8296 31.372 74.0756 31.372C75.3356 31.372 76.0216 32.422 76.0216 33.612C76.0216 34.816 75.3356 35.866 74.0756 35.866ZM84.6627 37V32.506C84.6627 30.7 83.3467 30.07 81.8347 30.07C80.7567 30.07 79.7767 30.406 78.9927 31.162L79.6087 32.184C80.1827 31.596 80.8547 31.316 81.6107 31.316C82.5347 31.316 83.1927 31.792 83.1927 32.576V33.584C82.6887 33.01 81.9187 32.716 80.9947 32.716C79.8887 32.716 78.6567 33.36 78.6567 34.928C78.6567 36.412 79.9027 37.168 80.9947 37.168C81.8907 37.168 82.6887 36.846 83.1927 36.258V37H84.6627ZM81.5827 36.16C80.7567 36.16 80.1267 35.684 80.1267 34.942C80.1267 34.214 80.7567 33.724 81.5827 33.724C82.2127 33.724 82.8427 33.962 83.1927 34.424V35.46C82.8427 35.922 82.2127 36.16 81.5827 36.16ZM92.7982 37V27.662H91.3282V31.176C90.7962 30.448 90.0122 30.07 89.1582 30.07C87.4222 30.07 86.1622 31.428 86.1622 33.612C86.1622 35.852 87.4362 37.168 89.1582 37.168C90.0402 37.168 90.8102 36.748 91.3282 36.076V37H92.7982ZM89.5922 35.866C88.4162 35.866 87.6742 34.928 87.6742 33.612C87.6742 32.31 88.4162 31.372 89.5922 31.372C90.2782 31.372 91.0062 31.778 91.3282 32.282V34.956C91.0062 35.46 90.2782 35.866 89.5922 35.866Z" fill="#939393"/>
                                       </svg>

                                 </div>
                                 <small>{{ __('owner.Only pdf is allowed') }}</small>
                              </div>



                              @if(isset($menu_files))

                              <div class="col-md-4">
                                 <div class="input-upload-img img-wrap">
                                    @if($menu_files->doc_type == 2)
                                    <span id="{{$menu_files->id}}" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>
                                    <object  id="image_{{$menu_files->id}}" data="{{URL::asset('storage').'/'.$menu_files->image}}" type="application/pdf" width="100%" height="100%">
                                    {{URL::asset('storage').'/'.$val->image}}
                                    </object>
                                    @elseif($val->doc_type == 1)
                                    <span id="{{$menu_files->id}}" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>
                                    <img class="img-fluid" id="image_{{$menu_files->id}}" src="{{ asset('storage').'/'.$menu_files->image}}">
                                    @endif
                                 </div>
                              </div>

                                   @endif


                              <div class="col-md-4" >
                                 <div class="input-upload-img img-wrap" >
                                     <canvas class="hide" id="pdfViewer" style="height: 165px;"  class="img-fluid" src="" ></canvas>

                                    <img class="img-fluid hide" id="outputsss_image" src=""  >

                                 </div>
                              </div>


                           </div>

                        </div>
                     </div>
                     <div class="card">
                        <div class="card-header">
                           <h4>{{ __('owner.Other') }}</h4>
                        </div>
                        <div class="card-body">
                        <div class="form-group">
                        <label for="exampleFormControlTextarea1" class="">{{ __('owner.Home Delivery available') }}<span class="spanColor">*</span></label>
                               <select name="home_delivery" id="home_delivery" class="form-control" aria-label="Default select example">
                                     <option selected value="">Select</option>
                                @foreach($homeDeliveryArray as $key=>$homeDelivery)

                                    @if(isset($restaurant->home_delivery) && $key == $restaurant->home_delivery)
                                        <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                    @elseif(old('home_delivery')== $key)
                                        <option  value="{{$key}}">{{$homeDelivery}}</option>
                                    @else
                                        <option value="{{$key}}">{{$homeDelivery}}</option>
                                    @endif
                                @endforeach
                            </select>
                        @error('home_delivery')
                            <div class="error-box">{{$message}}</div>
                        @enderror
                        </div>

                        <div class="form-group">
                        <label for="exampleFormControlTextarea1" class="">Minimum Payment Required for Booking<span class="spanColor">*</span></label>
                        <input type="text" name="min_payment"  class="form-control" id="exampleFormControlInput1" placeholder="" value="{{old('min_payment')??($restaurant->min_payment??'')}}">
                        @error('min_payment')
                            <div class="error-box">{{$message}}</div>
                        @enderror
                        </div>


                        <div class="form-group">
                            <label for="exampleFormControlTextarea1" class="">{{ __('owner.Take-out facility available') }} </label>
                                   <select name="takeout" id="takeout" class="form-control" aria-label="Default select example">
                                       <option selected value="">Select</option>
                                    @foreach($homeDeliveryArray as $key=>$homeDelivery)
                                        @if(isset($restaurant->takeout) && $key == $restaurant->takeout)
                                            <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                        @elseif(old('takeout')== $key)
                                            <option  value="{{$key}}">{{$homeDelivery}}</option>
                                        @else
                                            <option value="{{$key}}">{{$homeDelivery}}</option>
                                        @endif
                                    @endforeach
                                </select>
                            @error('takeout')
                                <div class="error-box">{{$message}}</div>
                            @enderror
                        </div>



                              <div class="form-group">
                                 <div class="">
                                 <label>{{ __('owner.Our most popular cuisine type') }}<span class="spanColor">*</span></label>
                                </div>
                                <div id="container">


                                </div>
                                @error('cuisine_type_id')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>

                              <div class="form-group">
                                 <div class="">
                                 <label>{{ __('owner.Expensiveness') }}<span class="spanColor">*</span></label>
                                </div>

                             @if(isset($restaurant->id))
                                <div class="form-check expensive">
                                    <input class="form-check-input" name="expensive" value="$" type="radio" id="expensive-1" required <?php if($restaurant->expensiveness == "$") { echo "checked"; }?> >
                                    <label class="form-check-label" for="expensive-1">
                                      $
                                    </label>
                                </div>

                                <div class="form-check expensive">
                                    <input class="form-check-input" name="expensive" value="$$" type="radio" id="expensive-2" required <?php if($restaurant->expensiveness == "$$") { echo "checked"; }?>>
                                    <label class="form-check-label" for="expensive-2">
                                      $$
                                    </label>
                                </div>

                                <div class="form-check expensive">
                                    <input class="form-check-input" name="expensive" value="$$$" type="radio" id="expensive-3" required <?php if($restaurant->expensiveness == "$$$") { echo "checked"; }?>>
                                    <label class="form-check-label" for="expensive-3">
                                       $$$
                                    </label>
                                </div>


                               @else
                                <div class="form-check expensive">
                                    <input class="form-check-input" name="expensive" value="$" {{ old("expensive") == '$' ? 'checked' : '' }} type="radio" id="expensive-1"   >
                                    <label class="form-check-label" for="expensive-1">
                                      $
                                    </label>
                                </div>

                                <div class="form-check expensive">
                                    <input class="form-check-input" name="expensive" value="$$" {{ old("expensive") == '$$' ? 'checked' : '' }} type="radio" id="expensive-2"  >
                                    <label class="form-check-label" for="expensive-2">
                                      $$
                                    </label>
                                </div>

                                <div class="form-check expensive">
                                    <input class="form-check-input" name="expensive" value="$$$" {{ old("expensive") == '$$$' ? 'checked' : '' }} type="radio" id="expensive-3" >
                                    <label class="form-check-label" for="expensive-3">
                                       $$$
                                    </label>
                                </div>
                               @endif




                                @error('expensiveness')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>


                              <div class="form-group mb-0">
                               <label>{{ __('owner.Notes') }} <small>({{ __('owner.for customers') }})</small></label>
                               @if(isset($restaurant->id))
                               <textarea name="notes" class="editor2" >
                                  {{old('notes')??$restaurant->notes}}
                               </textarea>
                               @else
                               <textarea name="notes" class="editor2" >
                                  {{old('notes')}}
                               </textarea>
                               @endif
                                @error('notes')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                            </div>
                        </div>
                     </div>

               <div class="card">
                        <div class="card-header">
                           <h4>{{ __('owner.Chef Details') }}</h4>
                        </div>
                        <div class="card-body">

                              <div class="row">

                              <div class="form-group col-md-6">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Chef Name') }}</label>
                                @if(isset($restaurant->id) && isset($restaurantChef))
                                <input type="text" name="chef_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Chef') }}" value="{{old('chef_name')??$restaurantChef->chef_name}}" onKeyPress="return ValidateAlpha(event);">
                                @else
                                <input type="text" name="chef_name"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Restaurant Chef') }}" value="{{old('chef_name')}}" onKeyPress="return ValidateAlpha(event);">
                                @endif
                                @error('chef_name')
                                    <div class="error-box">{{$message}}</div>
                                @enderror
                              </div>
                            <div class="form-group col-md-6">
                            <label for="exampleFormControlInput1" class="">{{ __('owner.Chef Mobile') }}</label>
                            @if(isset($restaurant->id) && isset($restaurantChef))
                            <input type="text" name="chef_mobile"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Chef Mobile') }}" value="{{old('chef_mobile')??$restaurantChef->chef_mobile}}" onkeypress="return isNumberKey(event)">
                            @else
                            <input type="text" name="chef_mobile"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Chef Mobile') }}" value="{{old('chef_mobile')}}" onkeypress="return isNumberKey(event)">
                            @endif
                            @error('chef_mobile')
                                <div class="error-box">{{$message}}</div>
                            @enderror
                            </div>
                            <div class="form-group col-md-6">
                                <label for="exampleFormControlInput1" class="">{{ __('owner.Chef Facebook Link') }}</label>
                    @if(isset($restaurant->id)&& isset($restaurantChef))
                    <input type="text" name="chef_fb_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Chef Facebook Link') }}" value="{{old('chef_fb_link')??$restaurantChef->chef_fb_link}}">
                    @else
                    <input type="text" name="chef_fb_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Chef Facebook Link') }}" value="{{old('chef_fb_link')}}">
                    @endif
                    @error('chef_fb_link')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                            </div>
                            <div class="form-group col-md-6">
                                  <label for="exampleFormControlInput1" class="">{{ __('owner.Chef Instagram Link') }}</label>
                    @if(isset($restaurant->id)&& isset($restaurantChef))
                    <input type="text" name="chef_insta_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Chef Instagram Link') }}" value="{{old('chef_insta_link')??$restaurantChef->chef_insta_link}}">
                    @else
                    <input type="text" name="chef_insta_link"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Chef Instagram Link') }}" value="{{old('chef_insta_link')}}">
                    @endif
                    @error('chef_insta_link')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                           </div>
                           </div>
                            <label for="exampleFormControlInput1" class="">{{ __('owner.Chef Profile Photos') }}</label>

                           <div class="row">
                              <div class="col-md-4">
                                 <div class="input-upload-img-input">

                                     <input type="file" name="chef_image" id="image" class="file" onchange="profile_preview_image(event)">
                                    @error('chef_image')
                                    <div class="error-box">{{$message}}</div>
                                    @enderror<br/>
                                    <svg width="94" height="40" viewBox="0 0 94 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M47.007 3.993L47.031 11H48.938L48.986 3.986L51.5 6.5L53 5L48 0L43 5L44.5 6.5L47.007 3.993Z" fill="#939393"/>
                                       <path d="M54 10V13H42V10H40V16H56V10H54Z" fill="#939393"/>
                                       <path d="M5.73702 37.168C7.61302 37.168 8.77502 36.174 9.48902 35.054L8.08902 34.354C7.64102 35.124 6.73102 35.712 5.73702 35.712C3.88902 35.712 2.51702 34.284 2.51702 32.338C2.51702 30.364 3.88902 28.964 5.73702 28.964C6.73102 28.964 7.64102 29.538 8.08902 30.322L9.47502 29.594C8.78902 28.474 7.61302 27.508 5.73702 27.508C2.97902 27.508 0.837023 29.454 0.837023 32.338C0.837023 35.208 2.97902 37.168 5.73702 37.168ZM12.214 37V27.662H10.744V37H12.214ZM14.8629 29.412C15.3669 29.412 15.7729 29.006 15.7729 28.502C15.7729 27.998 15.3669 27.592 14.8629 27.592C14.3589 27.592 13.9529 27.998 13.9529 28.502C13.9529 29.006 14.3589 29.412 14.8629 29.412ZM15.5909 37V30.238H14.1209V37H15.5909ZM20.5779 37.168C21.9079 37.168 22.6919 36.594 23.1679 35.964L22.2019 35.054C21.8239 35.586 21.3059 35.866 20.6479 35.866C19.4299 35.866 18.6039 34.928 18.6039 33.612C18.6039 32.296 19.4299 31.372 20.6479 31.372C21.3059 31.372 21.8239 31.624 22.2019 32.156L23.1679 31.274C22.6919 30.63 21.9079 30.07 20.5779 30.07C18.5339 30.07 17.0919 31.568 17.0919 33.612C17.0919 35.656 18.5339 37.168 20.5779 37.168ZM30.7986 37L27.9426 33.304L30.7426 30.238H28.9226L25.9406 33.5V27.662H24.4706V37H25.9406V35.18L26.8926 34.2L28.9506 37H30.7986ZM37.5067 37.168C38.1787 37.168 38.6127 36.972 38.8787 36.734L38.5287 35.614C38.4167 35.74 38.1647 35.866 37.8847 35.866C37.4647 35.866 37.2407 35.516 37.2407 35.054V31.512H38.6127V30.238H37.2407V28.39H35.7707V30.238H34.6507V31.512H35.7707V35.418C35.7707 36.552 36.3587 37.168 37.5067 37.168ZM42.9994 37.168C45.1554 37.168 46.4714 35.544 46.4714 33.612C46.4714 31.666 45.1554 30.07 42.9994 30.07C40.8434 30.07 39.5274 31.666 39.5274 33.612C39.5274 35.544 40.8434 37.168 42.9994 37.168ZM42.9994 35.866C41.7534 35.866 41.0534 34.816 41.0534 33.612C41.0534 32.422 41.7534 31.372 42.9994 31.372C44.2594 31.372 44.9454 32.422 44.9454 33.612C44.9454 34.816 44.2594 35.866 42.9994 35.866ZM57.6159 37V30.238H56.1459V34.984C55.8099 35.432 55.1659 35.866 54.4239 35.866C53.5839 35.866 53.0519 35.53 53.0519 34.48V30.238H51.5819V35.026C51.5819 36.398 52.3099 37.168 53.7659 37.168C54.8299 37.168 55.6699 36.636 56.1459 36.104V37H57.6159ZM63.1652 37.168C64.9152 37.168 66.1612 35.838 66.1612 33.612C66.1612 31.386 64.9152 30.07 63.1652 30.07C62.2832 30.07 61.4992 30.49 60.9952 31.162V30.238H59.5252V39.576H60.9952V36.062C61.5552 36.776 62.3112 37.168 63.1652 37.168ZM62.7312 35.866C62.0452 35.866 61.3172 35.446 60.9952 34.942V32.268C61.3312 31.764 62.0452 31.372 62.7312 31.372C63.8932 31.372 64.6492 32.296 64.6492 33.612C64.6492 34.928 63.8932 35.866 62.7312 35.866ZM69.1027 37V27.662H67.6327V37H69.1027ZM74.0756 37.168C76.2316 37.168 77.5476 35.544 77.5476 33.612C77.5476 31.666 76.2316 30.07 74.0756 30.07C71.9196 30.07 70.6036 31.666 70.6036 33.612C70.6036 35.544 71.9196 37.168 74.0756 37.168ZM74.0756 35.866C72.8296 35.866 72.1296 34.816 72.1296 33.612C72.1296 32.422 72.8296 31.372 74.0756 31.372C75.3356 31.372 76.0216 32.422 76.0216 33.612C76.0216 34.816 75.3356 35.866 74.0756 35.866ZM84.6627 37V32.506C84.6627 30.7 83.3467 30.07 81.8347 30.07C80.7567 30.07 79.7767 30.406 78.9927 31.162L79.6087 32.184C80.1827 31.596 80.8547 31.316 81.6107 31.316C82.5347 31.316 83.1927 31.792 83.1927 32.576V33.584C82.6887 33.01 81.9187 32.716 80.9947 32.716C79.8887 32.716 78.6567 33.36 78.6567 34.928C78.6567 36.412 79.9027 37.168 80.9947 37.168C81.8907 37.168 82.6887 36.846 83.1927 36.258V37H84.6627ZM81.5827 36.16C80.7567 36.16 80.1267 35.684 80.1267 34.942C80.1267 34.214 80.7567 33.724 81.5827 33.724C82.2127 33.724 82.8427 33.962 83.1927 34.424V35.46C82.8427 35.922 82.2127 36.16 81.5827 36.16ZM92.7982 37V27.662H91.3282V31.176C90.7962 30.448 90.0122 30.07 89.1582 30.07C87.4222 30.07 86.1622 31.428 86.1622 33.612C86.1622 35.852 87.4362 37.168 89.1582 37.168C90.0402 37.168 90.8102 36.748 91.3282 36.076V37H92.7982ZM89.5922 35.866C88.4162 35.866 87.6742 34.928 87.6742 33.612C87.6742 32.31 88.4162 31.372 89.5922 31.372C90.2782 31.372 91.0062 31.778 91.3282 32.282V34.956C91.0062 35.46 90.2782 35.866 89.5922 35.866Z" fill="#939393"/>
                                       </svg>

                                 </div>
                                 <small></small>
                              </div>

                              @if(isset($restaurantChef))

                              <div class="col-md-4">
                                 <div class="input-upload-img img-wrap">

                                    <img class="img-fluid" id="chef_image" src="{{ asset('storage').'/'.$restaurantChef->chef_image}}">

                                 </div>
                              </div>


                              @else

                              <div class="col-md-4" >
                                 <div class="input-upload-img img-wrap" >


                                    <img class="img-fluid" id="chef_image" src="" >

                                 </div>
                              </div>

                              @endif
                           </div>

                        </div>
                     </div>


                     <button class="btn btn-black w-100 py-3" type="submit">
                        @if(isset($restaurant->id) && $restaurant->id>0)
                            {{ __('owner.Update') }}
                        @else
                            {{ __('owner.Submit for Review') }}
                        @endif
                     </button>
                    </div>
                  <!-- end Your Restaurant Details -->
               </div>
               <!-- end container-main -->
           </form>
            </main>
            <!-- end main -->

         </div>
      </div>
<!-- {{ old('country_id')}}
{{ old('cuisine_type_id.0')}}
<h1>one</h1> -->

     <style type="text/css">
         .show{
display: block;
         }

         .hide{
            display: none;
         }

     </style>



<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>

<script>
    (function(e, t, n, r) {
        if (e) return;
        t._appt = true;
        var i = n.createElement(r),
            s = n.getElementsByTagName(r)[0];
        i.async = true;
        i.src = '//dje0x8zlxc38k.cloudfront.net/loaders/s-min.js';
        s.parentNode.insertBefore(i, s)
    })(window._appt, window, document, "script")
</script>
<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDTOBlMNBbD-xmkzYkjbK5VoTCcbN5G6Bk&libraries=places&callback=initialize" async defer></script>


<script type="text/javascript">
 let map;


    function createDate() {
    var el = $('<div class="date_div"></div>');
    el.html('<div class="row mb-2 holiday_block"> <div class="col-md-6"><div class="input-group date" data-provide="datepicker">    <input type="text" min="{{date(`Y-m-d`)}}" name="occasion_date[]" class="form-control" value=""> <div class="input-group-addon">    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M10 12C10.1978 12 10.3911 11.9414 10.5556 11.8315C10.72 11.7216 10.8482 11.5654 10.9239 11.3827C10.9996 11.2 11.0194 10.9989 10.9808 10.8049C10.9422 10.6109 10.847 10.4327 10.7071 10.2929C10.5673 10.153 10.3891 10.0578 10.1951 10.0192C10.0011 9.98063 9.80004 10.0004 9.61732 10.0761C9.43459 10.1518 9.27841 10.28 9.16853 10.4444C9.05865 10.6089 9 10.8022 9 11C9 11.2652 9.10536 11.5196 9.29289 11.7071C9.48043 11.8946 9.73478 12 10 12ZM15 12C15.1978 12 15.3911 11.9414 15.5556 11.8315C15.72 11.7216 15.8482 11.5654 15.9239 11.3827C15.9996 11.2 16.0194 10.9989 15.9808 10.8049C15.9422 10.6109 15.847 10.4327 15.7071 10.2929C15.5673 10.153 15.3891 10.0578 15.1951 10.0192C15.0011 9.98063 14.8 10.0004 14.6173 10.0761C14.4346 10.1518 14.2784 10.28 14.1685 10.4444C14.0586 10.6089 14 10.8022 14 11C14 11.2652 14.1054 11.5196 14.2929 11.7071C14.4804 11.8946 14.7348 12 15 12ZM10 16C10.1978 16 10.3911 15.9414 10.5556 15.8315C10.72 15.7216 10.8482 15.5654 10.9239 15.3827C10.9996 15.2 11.0194 14.9989 10.9808 14.8049C10.9422 14.6109 10.847 14.4327 10.7071 14.2929C10.5673 14.153 10.3891 14.0578 10.1951 14.0192C10.0011 13.9806 9.80004 14.0004 9.61732 14.0761C9.43459 14.1518 9.27841 14.28 9.16853 14.4444C9.05865 14.6089 9 14.8022 9 15C9 15.2652 9.10536 15.5196 9.29289 15.7071C9.48043 15.8946 9.73478 16 10 16ZM15 16C15.1978 16 15.3911 15.9414 15.5556 15.8315C15.72 15.7216 15.8482 15.5654 15.9239 15.3827C15.9996 15.2 16.0194 14.9989 15.9808 14.8049C15.9422 14.6109 15.847 14.4327 15.7071 14.2929C15.5673 14.153 15.3891 14.0578 15.1951 14.0192C15.0011 13.9806 14.8 14.0004 14.6173 14.0761C14.4346 14.1518 14.2784 14.28 14.1685 14.4444C14.0586 14.6089 14 14.8022 14 15C14 15.2652 14.1054 15.5196 14.2929 15.7071C14.4804 15.8946 14.7348 16 15 16ZM5 12C5.19778 12 5.39112 11.9414 5.55557 11.8315C5.72002 11.7216 5.84819 11.5654 5.92388 11.3827C5.99957 11.2 6.01937 10.9989 5.98079 10.8049C5.9422 10.6109 5.84696 10.4327 5.70711 10.2929C5.56725 10.153 5.38907 10.0578 5.19509 10.0192C5.00111 9.98063 4.80004 10.0004 4.61732 10.0761C4.43459 10.1518 4.27841 10.28 4.16853 10.4444C4.05865 10.6089 4 10.8022 4 11C4 11.2652 4.10536 11.5196 4.29289 11.7071C4.48043 11.8946 4.73478 12 5 12ZM17 2H16V1C16 0.734784 15.8946 0.48043 15.7071 0.292893C15.5196 0.105357 15.2652 0 15 0C14.7348 0 14.4804 0.105357 14.2929 0.292893C14.1054 0.48043 14 0.734784 14 1V2H6V1C6 0.734784 5.89464 0.48043 5.70711 0.292893C5.51957 0.105357 5.26522 0 5 0C4.73478 0 4.48043 0.105357 4.29289 0.292893C4.10536 0.48043 4 0.734784 4 1V2H3C2.20435 2 1.44129 2.31607 0.87868 2.87868C0.316071 3.44129 0 4.20435 0 5V17C0 17.7956 0.316071 18.5587 0.87868 19.1213C1.44129 19.6839 2.20435 20 3 20H17C17.7956 20 18.5587 19.6839 19.1213 19.1213C19.6839 18.5587 20 17.7956 20 17V5C20 4.20435 19.6839 3.44129 19.1213 2.87868C18.5587 2.31607 17.7956 2 17 2ZM18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18H3C2.73478 18 2.48043 17.8946 2.29289 17.7071C2.10536 17.5196 2 17.2652 2 17V8H18V17ZM18 6H2V5C2 4.73478 2.10536 4.48043 2.29289 4.29289C2.48043 4.10536 2.73478 4 3 4H17C17.2652 4 17.5196 4.10536 17.7071 4.29289C17.8946 4.48043 18 4.73478 18 5V6ZM5 16C5.19778 16 5.39112 15.9414 5.55557 15.8315C5.72002 15.7216 5.84819 15.5654 5.92388 15.3827C5.99957 15.2 6.01937 14.9989 5.98079 14.8049C5.9422 14.6109 5.84696 14.4327 5.70711 14.2929C5.56725 14.153 5.38907 14.0578 5.19509 14.0192C5.00111 13.9806 4.80004 14.0004 4.61732 14.0761C4.43459 14.1518 4.27841 14.28 4.16853 14.4444C4.05865 14.6089 4 14.8022 4 15C4 15.2652 4.10536 15.5196 4.29289 15.7071C4.48043 15.8946 4.73478 16 5 16Z" fill="#484848"/>   </svg>  </div>  </div> </div> <div class="col-md-5">  <input type="text" class="form-control" name="occasion_name[]" placeholder="Add note here " value=""  required=""></div> <div class="col-md-1 text-center"> <a type="button" style="line-height:46px;" onclick="removeSavedHoliday(`local`,this);" class="btn-close" aria-label="Close"><i class="fas fa-times"></i></a></div> </div>');



    $('.add_date_btn').remove();
    $('.create_date').append(el);

    }


    $(".chosen-select").chosen({
    no_results_text: "Oops, nothing found!"
    });



    function removeSavedImage(id) {
      var image_id = id;
      var delete_list = [];

      if (!delete_list.includes(image_id)) {
      delete_list.push(image_id);

      var delete_list_string = $('input[name=delete_list]').val();

      $('input[name=delete_list]').val(delete_list_string + ',' + image_id);
      }
      $('#image_'+image_id).parent().remove();

    }

    function removeSavedHoliday(el_type,e) {

      var image_id = e.id;
      var delete_list = [];

      if (image_id != '') {

      if (!delete_list.includes(image_id)) {
      delete_list.push(image_id);

      var delete_list_string = $('input[name=delete_holiday_list]').val();

      $('input[name=delete_holiday_list]').val(delete_list_string + ',' + image_id);
      }
      }

      $(e).parent().parent().remove();

    }


    $(document).ready(function ()
    {
        var dates = ["29/06/2021"];

        function DisableDates(date) {
        var string = jQuery.datepicker.formatDate('dd-mm-yy', date);
        return [dates.indexOf(string) == -1];
        }

        $(function() {
        $("input[type=date]").datepicker({
        beforeShowDay: DisableDates
        });
        });


        $('.copy_btn').on('click', function() {
            var monday_open_time = $('input[name=monday_open_time').val();
            var monday_close_time = $('input[name=monday_close_time').val();

            $('.open_time').each(function (){
                $(this).val(monday_open_time);
            });

            $('.close_time').each(function (){
                $(this).val(monday_close_time);
            });
        });

        $('select[name="country_id"]').on('change',function(){
            var countryId = jQuery(this).val();
            if(countryId)
            {
                getCity(countryId);
                getCuisine(countryId);
            }
            else
            {
               $('select[name="city_id"]').empty();
            }
        });
    });
    @if( isset($restaurant->id) && $restaurant->id>0)
        getCity({{$restaurant->country_id}},{{$restaurant->city_id}});
        getCuisine({{$restaurant->country_id}},{{$restaurantCuisineTypes->cuisine_type_id}});
    @endif
    <?php if( old('city_id')!==null && old('city_id')>0){ ?>
        var selectedCityId = <?php echo old('city_id') ?>;
        var selectedCountryId = <?php echo old('country_id') ?>;
        getCityOld(selectedCountryId,selectedCityId);
      //  alert(selectedCityId);
    <?php } ?>
      <?php if( old('country_id')!==null && old('country_id')>0){ ?>

        var selectedCountryId = <?php echo old('country_id') ?>;
        var selectedCuisineId = <?php echo old('cuisine_type_id.0') ?>;
        getCuisineOld(selectedCountryId,selectedCuisineId);
      //  alert(selectedCityId);
    <?php } ?>

    function getCity(countryId,cityId=0){
        jQuery.ajax({
            url : "{{ url('dropdown/getCity/') }}/"+countryId,
            type : "GET",
            dataType : "json",
            success:function(data)
            {
                jQuery('select[name="city_id"]').empty();
                $('select[name="city_id"]').append('<option value="">City</option>');
                jQuery.each(data, function(key,value){
                    if(cityId==key)
                    $('select[name="city_id"]').append('<option selected value="'+ key +'">'+ value +'</option>');

                    else
                    $('select[name="city_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                });
            }
        });
    }

        function getCuisine(countryId,cuisine_type_id=0){
          //console.log(countryId);
            jQuery.ajax({
            url : "{{ url('dropdown/getCuisine/') }}/"+countryId,
            type : "GET",
            dataType : "json",
            success:function(data)
            {
                 jQuery.each(data.cuisine, function(k,v){
                    let key = v.id;
                    let value= v.name;
                    if(cuisine_type_id==key)  {

                     var tr_str = " <div class='form-check cuisine'>" +
                        "<input class='form-check-input' name='cuisine_type_id[]' value='"+key+"' type='radio' checked id='"+key+"' >" +"<label class='form-check-label' for='"+key+"'>" + value +"</label></div>"
                     }

                     else
                     {
                      var tr_str = " <div class='form-check cuisine'>" +
                         "<input class='form-check-input' name='cuisine_type_id[]' value='"+key+"' type='radio' id='"+key+"' >" +"<label class='form-check-label' for='"+key+"'>" + value +"</label></div>"
                     }

                    $('#container').append(tr_str);

                });
            }
        });
    }

      function getCuisineOld(countryId,cuisine_type_id){
        //  console.log(countryId);
          //console.log(cuisine_type_id);
            jQuery.ajax({
            url : "{{ url('dropdown/getCuisine/') }}/"+countryId,
            type : "GET",
            dataType : "json",
            success:function(data)
            {
               // console.log(data)
                 jQuery.each(data.cuisine, function(k,v){
                    let key = v.id;
                    let value= v.name;
                   if(cuisine_type_id==key)  {

                     var tr_str = " <div class='form-check cuisine'>" +
                        "<input class='form-check-input' name='cuisine_type_id[]' value='"+key+"' type='radio' checked id='"+key+"' >" +"<label class='form-check-label' for='"+key+"'>" + value +"</label></div>"
                     }

                     else
                     {
                      var tr_str = " <div class='form-check cuisine'>" +
                         "<input class='form-check-input' name='cuisine_type_id[]' value='"+key+"' type='radio' id='"+key+"' >" +"<label class='form-check-label' for='"+key+"'>" + value +"</label></div>"
                     }
                      $('#container').append(tr_str);

                });
            }
        });
    }


    function getCityOld(country_id,city_id=0){
        jQuery.ajax({
            url : "{{ url('dropdown/getCity/') }}/"+country_id,
            type : "GET",
            dataType : "json",
            success:function(data)
            {
                jQuery('select[name="city_id"]').empty();
                $('select[name="city_id"]').append('<option value="">City</option>');
                jQuery.each(data, function(key,value){
                    if(city_id==key)
                    $('select[name="city_id"]').append('<option selected value="'+ key +'">'+ value +'</option>');

                    else
                    $('select[name="city_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                });
            }
        });
    }






</script>
<script type='text/javascript'>
function preview_image(event)
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}

function previews_image(event)
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('outputs_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}

function previewss_image(event)
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('outputss_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}


function profile_preview_image(event)
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('chef_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
  $(function() {
    // Multiple images preview with JavaScript
    var multiImgPreview = function(input, imgPreviewPlaceholder) {
        if (input.files) {
            var filesAmount = input.files.length;
            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
                reader.onload = function(event) {
                  $( $.parseHTML('<div class="col-md-4" style="margin-top: 20px;"><div class="input-upload-img img-wrap"> <img class="img-fluid" src="'+event.target.result+'"> </div></div> '))
                    // $('<div class="col-md-4"><div class="input-upload-img img-wrap"><div class="preview-image"> <span id=""  class="close close-icon">&times;</span>  '+$.parseHTML('<img class="img-fluid">')).attr('src', event.target.result)+'<img class="img-fluid"> </div></div></div>'
                    .appendTo(imgPreviewPlaceholder);
                }
                reader.readAsDataURL(input.files[i]);
            }
        }
    };
    $('#all_images').on('change', function() {
        multiImgPreview(this, 'div.img_all');
    });
  });




</script>
<script type="text/javascript">
       function initialize() {
   let map;
   let marker;
   let geocoder;
let longitud = 36.805127;
let latitud = -1.264714;

let saved=0;



   $(document).ready(function() {
   $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
   });
   });

   initMapsec();


   var options = {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0
   };

   function success(pos) {

   if(saved == 1){
   pos = { coords: {
     latitude: latitud,
     longitude: longitud,

   }, timestamp: Date.now() };
   }

   if(pos==0)
   {

   }
   else
   {
     var crd = pos.coords;
     latitud = crd.latitude;
     longitud = crd.longitude;
   }



    map = new google.maps.Map(document.getElementById("mapsec"), {
        center: {lat: latitud, lng: longitud},
        zoom: 14,
    });
   console.log(latitud + ' - ' + longitud);
   var myLatLong = { lat: latitud, lng: longitud };
     marker = new google.maps.Marker({
        animation: google.maps.Animation.DROP,
        map: map,
        position: myLatLong,

        draggable: true,
        title: "hello W"
    });

        marker.setIcon(({
            //url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));

    var input = document.getElementById('searchInputSec');
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);

    var infowindow = new google.maps.InfoWindow();




    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        marker.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }

        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }
        marker.setIcon(({
            //url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);


        document.getElementById('lat').value = place.geometry.location.lat();
        document.getElementById('lon').value = place.geometry.location.lng();
        document.getElementById('address').value =  place.formatted_address;

        // Location details
        for (var i = 0; i < place.address_components.length; i++) {
            if(place.address_components[i].types[0] == 'postal_code'){

            }
            if(place.address_components[i].types[0] == 'country'){

            }
        }console.log(place.formatted_address);

    });


   geocoder = new google.maps.Geocoder();
     google.maps.event.addListener(marker, 'dragend', function(evt) {

        var newLat = evt.latLng.lat().toFixed(8);
        var newLng = evt.latLng.lng().toFixed(8);console.log(newLat + ' , ' + newLng);

        document.getElementById('lat').value = newLat;
        document.getElementById('lon').value = newLng;


    geocodePosition(marker.getPosition());
     map.setCenter(marker.getPosition());
   marker.setMap(map);
        marker.setIcon(({
            //url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));
   });

   };

   function error(err) {
    var ts = Date.now();
    var GP =  Object.create(null);
    GP.coords =  Object.create(null);
    GP.coords.latitude = latitud;
    GP.coords.longitude = longitud;
    GP.timestamp = ts;
    success({ coords: {
     latitude: latitud,
     longitude: longitud,

   }, timestamp: Date.now() });

   };

   function initMapsec(){
    navigator.geolocation.getCurrentPosition(success, error);

   }

   function geocodePosition(pos) {
   geocoder.geocode({
    latLng: pos
   }, function(responses) {
    if (responses && responses.length > 0) {
        //$("#searchInputSec").val(responses[0].formatted_address);
      updateMarkerAddress(responses[0].formatted_address);
      document.getElementById('address').value =  responses[0].formatted_address;

    } else {

    }
   });
   }


   function updateMarkerAddress(res)
   {
   $("#searchInputSec").val(res);
   }

   function initMapsecdd() {


      map = new google.maps.Map($("#mapsec"), {
      center: {lat: -1.2920659, lng: 36.8219462},
      zoom: 13
    });
    var input = document.getElementById('searchInputSec');
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);

    var infowindow = new google.maps.InfoWindow();
    var marker = new google.maps.Marker({
        map: map,
        anchorPoint: new google.maps.Point(0, -29)
    });

    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        marker.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }

        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }
        marker.setIcon(({
            url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);
        initMapsec
        var address = '';
        if (place.address_components) {
            address = [
              (place.address_components[0] && place.address_components[0].short_name || ''),
              (place.address_components[1] && place.address_components[1].short_name || ''),
              (place.address_components[2] && place.address_components[2].short_name || '')
            ].join(' ');
        }

        infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
        infowindow.open(map, marker);

        // Location details
        for (var i = 0; i < place.address_components.length; i++) {
            if(place.address_components[i].types[0] == 'postal_code'){
                document.getElementById('postal_code').innerHTML = place.address_components[i].long_name;
            }
            if(place.address_components[i].types[0] == 'country'){
                document.getElementById('country').innerHTML = place.address_components[i].long_name;
            }
        }conosole.log(place.formatted_address);
        document.getElementById('location').innerHTML = place.formatted_address;
        document.getElementById('lat').innerHTML = place.geometry.location.lat();
        document.getElementById('lon').innerHTML = place.geometry.location.lng();
    });
   }


   var mapstore;
   var markerstore;
   var geocoderstore;
   var longitudstore = 36.80512;
   var latitudstore = -1.264714;

   var ordersaved=0;

   initMapsecorder();

   function storesuccess(pos) {

      if(ordersaved == 1){
   pos = { coords: {
      latitude: latitudstore,
      longitude: longitudstore,

   }, timestamp: Date.now() };
   }

   if(pos==0)
   {
     // latitud = crd.latitude;
     // longitud = crd.longitude;
   }
   else
   {
     var crd = pos.coords;
     latitudstore = crd.latitude;
     longitudstore = crd.longitude;
   }

    mapstore = new google.maps.Map(document.getElementById("storemapsec"), {
        center: {lat: latitudstore, lng: longitudstore},
        zoom: 14,
    });
   //console.log(latitudstore + ' - ' + longitudstore);
   var myLatLong = { lat: latitudstore, lng: longitudstore };
   markerstore = new google.maps.Marker({
        animation: google.maps.Animation.DROP,
        map: mapstore,
        position: myLatLong,
        //anchorPoint: new google.maps.Point(latitud , longitud),
        draggable: true,
        title: "hello W"
    });

    markerstore.setIcon(({
            //url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));

    var input = document.getElementById('storeAddress');
    mapstore.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', mapstore);

    var infowindow = new google.maps.InfoWindow();




    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        markerstore.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }

        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
         mapstore.fitBounds(place.geometry.viewport);
        } else {
         mapstore.setCenter(place.geometry.location);
         mapstore.setZoom(17);
        }
        markerstore.setIcon(({
            //url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));
        markerstore.setPosition(place.geometry.location);
        markerstore.setVisible(true);


        document.getElementById('order_latitude').value = place.geometry.location.lat();
        document.getElementById('order_longitude').value = place.geometry.location.lng();
        document.getElementById('store_address').value =  place.formatted_address;

        for (var i = 0; i < place.address_components.length; i++) {
            if(place.address_components[i].types[0] == 'postal_code'){
            }
            if(place.address_components[i].types[0] == 'country'){
            }
        }console.log(place.formatted_address);

    });


    geocoderstore = new google.maps.Geocoder();
     google.maps.event.addListener(markerstore, 'dragend', function(evt) {

        var newLat = evt.latLng.lat().toFixed(8);
        var newLng = evt.latLng.lng().toFixed(8);console.log(newLat + ' , ' + newLng);

        document.getElementById('order_latitude').value = newLat;
        document.getElementById('order_longitude').value = newLng;

    //updateMarkerStatus('Drag ended');
    geocodePositionStore(markerstore.getPosition());
    mapstore.setCenter(markerstore.getPosition());
    markerstore.setMap(mapstore);
    markerstore.setIcon(({
            //url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));


   });

   };

   function storeerror(err) {

    storesuccess({ coords: {
     latitude: latitud,
     longitude: longitud,

   }, timestamp: Date.now() });


   }

   function initMapsecorder(){
    navigator.geolocation.getCurrentPosition(storesuccess, storeerror);

   }

   function geocodePositionStore(pos) {
   geocoder.geocode({
    latLng: pos
   }, function(responses) {
    if (responses && responses.length > 0) {
      updateMarkerStoreAddress(responses[0].formatted_address);
      document.getElementById('store_address').value =  responses[0].formatted_address;

    } else {
      //updateMarkerStoreAddress('Cannot determine address at this location.');
    }
   });
   }


   function updateMarkerStoreAddress(res)
   {
   $("#storeAddress").val(res);
   }


   };




</script>

<script type="text/javascript">

   function isNumberKey(evt){
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }

    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)

        return false;
            return true;
    }

</script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.5.207/pdf.min.js"></script>

<script type="text/javascript">

    // Loaded via <script> tag, create shortcut to access PDF.js exports.
var pdfjsLib = window['pdfjs-dist/build/pdf'];
// The workerSrc property shall be specified.
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.5.207/pdf.worker.min.js';

$("#myPdf").on("change", function(e){
    var file = e.target.files[0]
    if(file.type == "application/pdf"){

        var fileReader = new FileReader();
        fileReader.onload = function() {
            var pdfData = new Uint8Array(this.result);
            // Using DocumentInitParameters object to load binary data.
            var loadingTask = pdfjsLib.getDocument({data: pdfData});
            loadingTask.promise.then(function(pdf) {
              console.log('PDF loaded');

              // Fetch the first page
              var pageNumber = 1;
              pdf.getPage(pageNumber).then(function(page) {
                console.log('Page loaded');

                var scale = 1.5;
                var viewport = page.getViewport({scale: scale});

                // Prepare canvas using PDF page dimensions
                var canvas = $("#pdfViewer")[0];
                var context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;

                // Render PDF page into canvas context
                var renderContext = {
                  canvasContext: context,
                  viewport: viewport
                };
                var renderTask = page.render(renderContext);
                renderTask.promise.then(function () {
                  console.log('Page rendered');

                });
              });
            }, function (reason) {
              // PDF loading error
              console.error(reason);
            });
        };
        fileReader.readAsArrayBuffer(file);
    document.getElementById("pdfViewer").classList.add('show');
    document.getElementById("pdfViewer").classList.remove('hide');
    }
    else{

         var reader = new FileReader();
         reader.onload = function()
         {
          var output = document.getElementById('outputsss_image');
          output.src = reader.result;
         }
         reader.readAsDataURL(event.target.files[0]);
            document.getElementById("outputsss_image").classList.add('show');

        document.getElementById("outputsss_image").classList.remove('hide');
    }
});
</script>

@endsection
