
@extends('layouts.default')  
@section('content')

      <!-- <img id="scream" width="220" height="277" src="img_the_scream.jpg" alt="The Scream"> -->

      <div class="container-fluid fixed-height">
         <div class="fix-width">
            @include('layouts.floor_management_left_menu')
            <!-- main -->
            <main role="main" class="main-box">

                <!-- main header -->
                <div class="dis-header">
                  <div class="row">
                    <div class="col-xl-5 col-lg-12 pr-0">
                        <ul class="list-unstyled">
                           <li class="times-dropdown">
                              <button type="button" class="dropdown-toggle" data-toggle="dropdown">
                                 <i class="fa fa-clock"></i> Times
                              </button type="button">
                              <div class="dropdown-menu">
                                 @foreach($minutes_Slots as $minutes)
                                 <a class="dropdown-item" href="#">{{$minutes['start']}}</a>
                                 @endforeach
                                
                              </div>
                           </li>
                           <li>
                              <i class="fa fa-chair"></i> {{ __('owner.Table Capacity') }}  
                           </li>
                        </ul>
                    </div>
                    <div class="col-xl-7 col-lg-12 tabing-right">
                        <div class="floor-list-block">
                           <button id="left-button">
                              <i class="fas fa-angle-left"></i>
                           </button>
                           <ul class="floors--list" id="floors--scroll">
                              @foreach($restaurant_list as $restaurant)
                                    @if( $restaurant->type==1 )
                                       <li>
                                          <a href="javascript:void(0);" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)"  id="floor_type_{{$restaurant->id}}" class=" active default-floor floor_type ">{{$restaurant->name}}</a>
                                       </li>
                                    @else
                                       <li>
                                          <a href="javascript:void(0);" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class="floor_type ">{{$restaurant->name}}</a>
                                       </li>
                                    @endif
                              @endforeach       
                           </ul>
                           <button id="right-button">
                              <i class="fas fa-angle-right"></i>
                           </button>
                        </div>
                        <!-- Start 26-11-2021 -->
                        <!-- <ul class="list-nav-header 
                          @php if(count($restaurant_list) > 3) 
                               echo 'slider_tabing_top';
                          @endphp
                           list-unstyled">
                           <li>
                              @foreach($restaurant_list as $restaurant)
                                    @if( $restaurant->type==1 )
                                      <a href="javascript:void(0);" style="min-width: 80px;" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class=" active default-floor floor_type btn " >{{$restaurant->name}}</a>
                                    @else
                                      <a href="javascript:void(0);" style="min-width: 80px;" data-floor='{{$restaurant->id}}' onclick="clickOnFloor(this)" id="floor_type_{{$restaurant->id}}" class="floor_type btn btn-sm btn-secondary " >{{$restaurant->name}}</a>
                                    @endif
                              @endforeach                              
                           </li>
                        </ul> -->
                        @if(Auth::user()->type != 3)
                        <ul class="list-unstyled">
                           <li>
                              <a href="{{url('restaurant-owner/restaurant/editFloor')}}"> <i class="fa fa-cog"></i>{{ __('owner.Edit Floor') }}</a>
                           </li>
                        </ul>
                        @endif
                    </div> 
                  </div>
                </div>
                  <x-auth-session-status class="mb-4" :status="session('status')" />

                        <!-- Validation Errors -->
                        <x-auth-validation-errors class="mb-4" :errors="$errors" />

                        @if (session('error'))
                            <div class="alert alert-danger">
                                {{ session('error') }}
                            </div>
                        @endif
               <!-- end  main header -->
             
               <!-- container-main -->
               <div class="container-main">

               <div class="sitting_summary" id="floor-info">
                     <h4>{{ __('owner.Sitting Summary') }}</h4>
                     <ul>
                        <li id="totaltables" data-toggle="tooltip" data-placement="bottom" title="Total no of ables"></li>
                        <li id="totalcapacity" data-toggle="tooltip" data-placement="bottom" title="Total no of Seats"></li>
                        <li id="singlesitting" data-toggle="tooltip" data-placement="bottom" title="Single Seater table"></li>
                        <li id="doublesitting" data-toggle="tooltip" data-placement="bottom" title="Double Seater table"></li>
                        <li id="foursitting" data-toggle="tooltip" data-placement="bottom" title="Four Seater table"></li>
                        <li id="sixsitting" data-toggle="tooltip" data-placement="bottom" title="Six Seater table"></li>
                        <li id="eigntsitting" data-toggle="tooltip" data-placement="bottom" title="Eight Seater table"></li>
                     </ul>
                   </div>
                     <div style="text-align: center;">
                       <canvas style="border: 1px solid #ffffff;background: #ffffff; border:1px dotted #ff0000;"  class="" id="graphCanvas" ondrop="drop(event)" ondragover="allowDrop(event)"  height="600px" width="550px">
                        </canvas>
                     </div>

                            
                    </canvas>
               </div>
               <!-- end container-main -->
            </main>
            <!-- end main -->
            @include('layouts.floor_management_right_menu')
         </div>
      </div>
     
      <!-- Canvas: Don't remove this record, it's belong to canvas -->
      <input type="hidden" name="max_capacity" id="max_capacity">
      <input type="hidden" name="min_capacity" id="min_capacity">
      <input type="hidden" name="capacity" id="capacity" >
      <input type="hidden" name="table_no" id="table_no">
      <input type="hidden" id="floor_no" value="">

      <input type="hidden" name="table_id" id="table_id"></div>

      <div class="" style="display: none;">
       <img  id="1-person-round-table-t" src="{{asset('admin/imgs/tt-1.svg')}}">
       <img  id="2-person-round-table-t" src="{{asset('admin/imgs/tt-2.svg')}}">
       <img id="t-4-person-round-table-t" src="{{asset('admin/imgs/ttt-4.svg')}}" >
       <img id="4-person-round-table-t" src="{{url('admin/imgs/tt-s-4.svg')}}" >
       <img id="6-person-round-table-t" src="{{asset('admin/imgs/tt-6.svg')}}">
       <img  id="8-person-round-table-t" src="{{asset('admin/imgs/tt8.svg')}}"> 
      </div>
      <!-- Canvas: Don't remove this record, it's belong to canvas -->

      <script type="text/javascript">
         var isDragValue = false;
         var restaurantIdValue = {{$restaurant_id}};
      </script>
      <!-- Start Floor-list-block -->
<script>
   const rightBtn = document.querySelector('#right-button');
   const leftBtn = document.querySelector('#left-button');

   rightBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft += 300;
     event.preventDefault();
   });

   leftBtn.addEventListener("click", function(event) {
     const conent = document.querySelector('#floors--scroll');
     conent.scrollLeft -= 300;
     event.preventDefault();
   });
</script>
<!-- End Floor-list-block -->
@endsection

