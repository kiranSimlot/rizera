
@extends('layouts.historyreservation')

    
@section('content')

<div class="container-fluid">
    <div class="fix-width">
        @include('layouts.floor_management_left_menu')
        <!-- main -->
        <main role="main" class="main-box" >
            <!-- main header -->
     <!--        <div class="dis-header">
                <div class="row">
                    <div class="col-md-12">
                        <div class="search_here">
                            <div class="form-group">
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5325 12.4675L10.9825 9.925C11.8052 8.87684 12.2517 7.58249 12.25 6.25C12.25 5.06331 11.8981 3.90328 11.2388 2.91658C10.5795 1.92989 9.64246 1.16085 8.5461 0.706725C7.44975 0.2526 6.24335 0.13378 5.07946 0.365291C3.91558 0.596802 2.84648 1.16825 2.00736 2.00736C1.16825 2.84648 0.596802 3.91558 0.365291 5.07946C0.13378 6.24335 0.2526 7.44975 0.706725 8.5461C1.16085 9.64246 1.92989 10.5795 2.91658 11.2388C3.90328 11.8981 5.06331 12.25 6.25 12.25C7.58249 12.2517 8.87684 11.8052 9.925 10.9825L12.4675 13.5325C12.5372 13.6028 12.6202 13.6586 12.7116 13.6967C12.803 13.7347 12.901 13.7544 13 13.7544C13.099 13.7544 13.197 13.7347 13.2884 13.6967C13.3798 13.6586 13.4628 13.6028 13.5325 13.5325C13.6028 13.4628 13.6586 13.3798 13.6967 13.2884C13.7347 13.197 13.7544 13.099 13.7544 13C13.7544 12.901 13.7347 12.803 13.6967 12.7116C13.6586 12.6202 13.6028 12.5372 13.5325 12.4675ZM1.75 6.25C1.75 5.35999 2.01392 4.48996 2.50839 3.74994C3.00286 3.00992 3.70566 2.43314 4.52793 2.09254C5.35019 1.75195 6.25499 1.66284 7.12791 1.83647C8.00082 2.0101 8.80265 2.43869 9.43198 3.06802C10.0613 3.69736 10.4899 4.49918 10.6635 5.3721C10.8372 6.24501 10.7481 7.14981 10.4075 7.97208C10.0669 8.79435 9.49009 9.49715 8.75007 9.99162C8.01005 10.4861 7.14002 10.75 6.25 10.75C5.05653 10.75 3.91194 10.2759 3.06802 9.43198C2.22411 8.58807 1.75 7.44348 1.75 6.25Z" fill="#939393"/>
                                </svg>                              
                                <input id="globalSearch" name="globalSearch" type="text" class="" placeholder="{{ __('owner.Search here') }}" />
                            </div>
                        </div>
                    </div>                    
                </div>
            </div> -->
            <!-- end  main header -->

            <!-- container-main -->
             @if(Session::has('success'))
            <div class="alert alert-success " role="alert" style="margin:1rem;">
                {{Session::get('success')}}
            </div>
            @elseif(Session::has('error'))
            <div class="alert alert-danger " role="alert" style="margin:1rem;">
                {{Session::get('error')}}
            </div>
            @endif
            <div class="container-main p-0">
					<div class="Search_here_Guests-Profile row">
						<div class="left_Search_here_Guests col-md-4 col-lg-3">
                     <div class="search_here">
                        <div class="form-group">
                         <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.5325 12.4675L10.9825 9.925C11.8052 8.87684 12.2517 7.58249 12.25 6.25C12.25 5.06331 11.8981 3.90328 11.2388 2.91658C10.5795 1.92989 9.64246 1.16085 8.5461 0.706725C7.44975 0.2526 6.24335 0.13378 5.07946 0.365291C3.91558 0.596802 2.84648 1.16825 2.00736 2.00736C1.16825 2.84648 0.596802 3.91558 0.365291 5.07946C0.13378 6.24335 0.2526 7.44975 0.706725 8.5461C1.16085 9.64246 1.92989 10.5795 2.91658 11.2388C3.90328 11.8981 5.06331 12.25 6.25 12.25C7.58249 12.2517 8.87684 11.8052 9.925 10.9825L12.4675 13.5325C12.5372 13.6028 12.6202 13.6586 12.7116 13.6967C12.803 13.7347 12.901 13.7544 13 13.7544C13.099 13.7544 13.197 13.7347 13.2884 13.6967C13.3798 13.6586 13.4628 13.6028 13.5325 13.5325C13.6028 13.4628 13.6586 13.3798 13.6967 13.2884C13.7347 13.197 13.7544 13.099 13.7544 13C13.7544 12.901 13.7347 12.803 13.6967 12.7116C13.6586 12.6202 13.6028 12.5372 13.5325 12.4675ZM1.75 6.25C1.75 5.35999 2.01392 4.48996 2.50839 3.74994C3.00286 3.00992 3.70566 2.43314 4.52793 2.09254C5.35019 1.75195 6.25499 1.66284 7.12791 1.83647C8.00082 2.0101 8.80265 2.43869 9.43198 3.06802C10.0613 3.69736 10.4899 4.49918 10.6635 5.3721C10.8372 6.24501 10.7481 7.14981 10.4075 7.97208C10.0669 8.79435 9.49009 9.49715 8.75007 9.99162C8.01005 10.4861 7.14002 10.75 6.25 10.75C5.05653 10.75 3.91194 10.2759 3.06802 9.43198C2.22411 8.58807 1.75 7.44348 1.75 6.25Z" fill="#939393"/>
                            </svg>                            
                           <input id="userSearch" name="userSearch" type="text" value="{{$selectuser->name}}" class="" placeholder="{{ __('owner.Search here') }}" />
                        </div>

                     </div>
                     <div class="left_Search_here_Guests_list">
                        <ul>
                           <li>
                           @foreach($users as $key => $user)
                              <div class="title_lable">
                              {{$key}}
                              </div>
                              <ul class="list-group" id="demonames">
                                @foreach($user as $k => $v)   
                                <!-- <li class="list-group-item">{{$v->id}} : {{$v->name}}</li>  -->
                                <li class="list-group-item">                                  
                                    <a href="{{url('restaurant-owner/restaurant/guestuser', $v->id)}}" class="demoname">
                                    {{ $v->name }}
                                    </a>                                     										
								</li>   
                                @endforeach
                              </ul>
                            @endforeach
                           </li>                        
                        </ul>
                     </div>
                   </div>
						<div class="left_Search_here_Guests col-md-8 col-lg-9">
							 <div class="albert_flores">
								<div class="left">
								   <h3>{{$selectuser->name}}</h3>
								</div>
									<!-- @if(isset($id_restaurant) && $id_restaurant != "")
								<div class="right">
									<a href="#"  data-toggle="modal" data-target="#create-reservation" class="btn-Create-Reservation">
									{{ __('owner.Create Reservation') }}  
									</a>
								</div>
									@endif -->
							 </div>
							 <div class="profile_reservation_history">
								<div class="left">
								   <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
									  <li class="nav-item">
										<a class="nav-link active" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="true">{{ __('owner.Profile') }}</a>
									  </li>
									  
									  <li class="nav-item">
										<a class="nav-link" id="pills-eservation_history-tab" data-toggle="pill" href="#pills-eservation_history" role="tab" aria-controls="pills-eservation_history" aria-selected="false">{{ __('owner.Reservation_history') }}</a>
									  </li>
									</ul>
								</div>
								<div class="right">
								   <ul>
										<li class="text-success">{{$visitcount}} {{ __('owner.Total_visits') }}</li>
										<li class="text-danger">{{$cancelcount}} {{ __('owner.Cancellations') }}</li>
										<li class="text-dark">{{$count}} {{ __('owner.Total_Bookings') }}</li>										
								   </ul>
								   </div>
							 </div>
							 <div class="profile_reservation_history_body" >
								<div class="tab-content" id="pills-tabContent">
								   <div class="tab-pane fade show active" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
								   		<form method="POST" action="{{ route('owner.restaurant.vipgust') }}" enctype="multipart/form-data" >
                        					@csrf
											<div class="upload">
											<div class="upload_img">
												
							 				@if(!empty($selectuser->image) && file_exists('storage/'.$selectuser->image))
							               <img src="{{ asset('storage').'/'.$selectuser->image}}" alt="" />
							               	<input type="hidden"  name="image_old" id="image_old" value="{{$selectuser->image}}" >
							                @else
							                        
							                <img src="{{ asset('front/imgs/placeholder.png') }}" class="w-100 h-100">

							                @endif
               
													
												</div>											
												<!-- <span><svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
												<circle cx="19" cy="19" r="19" fill="#484848"/>
												<path d="M19 14.7402C16.536 14.7402 14.5312 16.745 14.5312 19.209C14.5312 21.673 16.536 23.6777 19 23.6777C21.464 23.6777 23.4688 21.673 23.4688 19.209C23.4688 16.745 21.464 14.7402 19 14.7402ZM19 21.6152C17.6733 21.6152 16.5938 20.5356 16.5938 19.209C16.5938 17.8823 17.6733 16.8027 19 16.8027C20.3267 16.8027 21.4062 17.8823 21.4062 19.209C21.4062 20.5356 20.3267 21.6152 19 21.6152Z" fill="white"/>
												<path d="M27.25 11.6469H24.2529C24.1455 11.6469 24.0431 11.5958 23.9787 11.5106L23.9783 11.5099L22.9827 10.1879C22.5312 9.58704 21.8124 9.22852 21.0601 9.22852H16.9398C16.1876 9.22852 15.4688 9.58703 15.0177 10.1873L14.0213 11.5106C13.9569 11.5958 13.8545 11.6469 13.7471 11.6469H10.75C9.42334 11.6469 8.34375 12.7264 8.34375 14.0531V24.3656C8.34375 25.6923 9.42334 26.7719 10.75 26.7719H27.25C28.5767 26.7719 29.6562 25.6923 29.6562 24.3656V14.0531C29.6562 12.7264 28.5767 11.6469 27.25 11.6469ZM27.5938 24.3656C27.5938 24.5549 27.4397 24.7094 27.25 24.7094H10.75C10.5603 24.7094 10.4062 24.5549 10.4062 24.3656V14.0531C10.4062 13.8638 10.5603 13.7094 10.75 13.7094H13.7471C14.4994 13.7094 15.2181 13.3508 15.6693 12.7506L16.6656 11.4273C16.73 11.342 16.8324 11.291 16.9399 11.291H21.0602C21.1676 11.291 21.27 11.342 21.3348 11.428L22.3308 12.7506C22.7826 13.3508 23.501 13.7094 24.2529 13.7094H27.25C27.4397 13.7094 27.5938 13.8638 27.5938 14.0531V24.3656Z" fill="white"/>
												</svg> <input type="file"  name="image" placeholder="Choose image" id="image" accept="image/x-png,image/gif,image/jpeg" >
														
												</span> -->

											</div>
											<h4>{{ __('owner.Personal_Details') }}</h4>
											<div class="row">
												<div class="col-lg-8">
													<div class="form_profile">
													<div class="row">
														<div class="form-group col-md-6">
															<label>{{ __('owner.First_Name') }}</label>
															<input type="text" name="first_name" id="first_name" value="{{$selectuser->first_name}}" placeholder="{{ __('owner.First_Name') }}" class="form-control" readonly>
														</div>
														<div class="form-group col-md-6">
															<label>{{ __('owner.Last_Name') }}</label>
															<input type="text" name="last_name"  id="last_name" value="{{$selectuser->last_name}}" placeholder="{{ __('owner.Last_Name') }}" class="form-control" readonly>
														</div>
														<div class="form-group col-md-6">
															<label>{{ __('owner.Phone_Number') }}</label>
															<input type="mobile" name="phone" id="phone"  value="{{$selectuser->mobile}}" placeholder="{{ __('owner.Phone_Number') }}"  minlength="10" maxlength="10" class="form-control" readonly>
														</div>
														<div class="form-group col-md-6">
															<label>{{ __('owner.Email_Address') }}</label>
															<input type="email" name="email" id="email"  value="{{$selectuser->email}}" placeholder="{{ __('owner.Email') }}" class="form-control" readonly>
														</div>
														<div class="form-group col-md-12">
															<label>{{ __('owner.Guest_Tags') }}</label>
															<select class="form-control" name="vip_tag"  id="vip_tag">
																<option> {{ __('owner.Select_Guest_type') }} </option>
																@if(isset($vip->vip_tag_id))
																	@foreach  ($vips as $key => $value)
																		@if($vip->vip_tag_id == $key)
																			<option selected value="{{$key}}">{{$value}}</option>
																		@else
																			<option value="{{$key}}">{{$value}}</option>
																		@endif																		
																	@endforeach  
																@else
																	@foreach  ($vips as $key => $value)																		
																		<option value="{{$key}}">{{$value}}</option>																																					
																	@endforeach 
																@endif 
															</select>
														</div>
														<div class="form-group col-md-12">
															<label>{{ __('owner.Guest_Notes') }}</label>
															<textarea class="form-control" name="vip_note"  id="vip_note">
															@if(isset($vip->vip_tag_id))
																{{$vip->vip_note}} 										
															@endif
															</textarea>
															</div>
															<div class="form-group col-md-12">
																<input type="hidden"  name="user_id" id="user_id" value="{{$selectuser->id}}" >
																<input type="hidden"  name="id_restaurant" id="id_restaurant" value="{{ session()->get('id_restaurant') }}" >
																<input type="hidden"  name="updated_by" id="updated_by" value="{{ Auth::user()->id }}" >																
																<button class="btn btn-black w-100 py-3">{{ __('owner.Save_Changes') }}</button>
														</div>
													</div>
												</div>
											</div>								  
										</form>
									</div>
								</div>


									<div class="tab-pane fade" id="pills-eservation_history" role="tabpanel" aria-labelledby="pills-eservation_history-tab">
										<div class="reservation-history-data">
											<!-- item -->
											@if(isset($bookings))
											@foreach($bookings as $key => $value)
												<div class="row">
													<div class="col-md-3">
														<label>{{ __('owner.Date_and_Time') }}</label>
														<h5>{{$value->date}}&nbsp;&nbsp;&nbsp;{{Carbon\Carbon::parse($value->for_time)->format('g:i A' ) }}</h5>
														@if($value->booking_by ==1)
														<span class="small" style="color:#008a00;">(Online booking)</span>
														@else
														<span class="small" style="color:#ffc83d;">(Offline booking)</span>
														@endif
													</div>
													<div class="col-md-2">
														<label>{{ __('owner.No_of_Guests') }}</label>
														<h5><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0)">
															<path d="M13.204 9.15767C12.0038 8.40042 10.6296 7.98494 9.20947 7.90723C9.53781 8.06092 9.8628 8.22323 10.171 8.41769C10.9135 8.88552 11.375 9.73276 11.375 10.6283V13.1251H14V10.6283C14 10.031 13.6949 9.46743 13.204 9.15767Z" fill="#484848"/>
															<path d="M9.70406 9.15759C7.04402 7.47937 3.45557 7.47937 0.796379 9.15759C0.305061 9.46691 0 10.0305 0 10.6282V13.125H10.5V10.6282C10.5 10.0305 10.1949 9.46691 9.70406 9.15759Z" fill="#484848"/>
															<path d="M7.87012 6.85508C8.15297 6.9407 8.44486 7.00004 8.75019 7.00004C10.4387 7.00004 11.8127 5.62601 11.8127 3.93753C11.8127 2.24905 10.4387 0.875 8.75019 0.875C8.44486 0.875 8.15297 0.934334 7.87012 1.01995C8.67263 1.74125 9.18769 2.77594 9.18769 3.93751C9.18769 5.09907 8.67266 6.13376 7.87012 6.85508Z" fill="#484848"/>
															<path d="M7.41553 1.77199C8.61152 2.96798 8.61152 4.90702 7.41553 6.10301C6.21953 7.29901 4.28049 7.29901 3.0845 6.10301C1.8885 4.90702 1.8885 2.96798 3.0845 1.77199C4.28049 0.575991 6.21953 0.576019 7.41553 1.77199Z" fill="#484848"/>
															</g>
															<defs>
															<clipPath id="clip0">
															<rect width="14" height="14" fill="white"/>
															</clipPath>
															</defs>
															</svg>
															{{$value->no_of_person}}
														</h5>
													</div>
													<div class="col-md-3 tb-fl">
														<label>{{ __('owner.Floor_and_Table_No') }}</label>
														<h5>{{$value->floor_name}} {{ __('owner.Floor') }}&nbsp;<span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
															<path d="M11.0228 6.99968C11.0228 9.34855 9.21376 11.2528 6.98234 11.2528C4.75091 11.2528 2.94189 9.34855 2.94189 6.99968C2.94189 4.65081 4.75091 2.74658 6.98234 2.74658C9.21376 2.74658 11.0228 4.65081 11.0228 6.99968Z" fill="#484848"/>
															<path d="M7 0C3.13388 0 0 3.13388 0 7C0 10.8661 3.13388 14 7 14C10.8661 14 14 10.8661 14 7C13.9959 3.13572 10.8643 0.00414474 7 0ZM7 13.0246C3.6727 13.0246 0.975395 10.3273 0.975395 7C0.975395 3.6727 3.6727 0.975395 7 0.975395C10.3273 0.975395 13.0246 3.6727 13.0246 7C13.0209 10.3259 10.3259 13.0209 7 13.0246Z" fill="#484848"/>
															</svg>{{ __('owner.Table') }}: {{$value->table_updated}}
															</span>
														</h5>
													</div>
													<div class="col-md-2">
														<label>{{ __('owner.Category') }}</label>

														<h5>
															@if($value->categories_name =='Breakfast')
																<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
																<circle cx="11" cy="11" r="8" fill="#57A78A"/>
																<circle cx="11" cy="11" r="10.5" stroke="#57A78A"/>
																<g clip-path="url(#clip0)">
																<path d="M15.7065 10.4924H6.29354C6.13143 10.4924 6 10.6239 6 10.786C6 11.8884 6.52844 12.9209 7.48799 13.6933C8.42889 14.4506 9.67615 14.8676 11 14.8676C12.3238 14.8676 13.5711 14.4506 14.512 13.6933C15.4716 12.921 16 11.8885 16 10.786C16 10.6239 15.8686 10.4924 15.7065 10.4924Z" fill="white"/>
																<path d="M15.8978 7.20318C15.7748 7.09758 15.5895 7.11162 15.4838 7.23457L14.304 8.60813C14.3897 8.73365 14.4601 8.86834 14.5138 9.01C14.5665 9.03256 14.6181 9.05756 14.6686 9.08467L15.9292 7.61713C16.0348 7.49416 16.0208 7.30883 15.8978 7.20318Z" fill="white"/>
																<path d="M14.0331 9.47082C13.9421 8.92848 13.5248 8.49527 12.9907 8.38053C12.9059 7.72088 12.3406 7.20947 11.6583 7.20947C11.0868 7.20947 10.5976 7.56809 10.4038 8.07211C10.2098 7.96734 9.99059 7.91002 9.76559 7.91002C9.02481 7.91002 8.42213 8.51269 8.42213 9.25348C8.42213 9.25818 8.42215 9.26291 8.42221 9.26764C7.99989 9.32867 7.63448 9.56746 7.40393 9.90529H14.7716C14.5825 9.68807 14.3252 9.53182 14.0331 9.47082Z" fill="white"/>
																</g>
																<defs>
																<clipPath id="clip0">
																<rect width="10" height="10" fill="white" transform="translate(6 6)"/>
																</clipPath>
																</defs>
																</svg>
															@elseif($value->categories_name =='Lunch')
																<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
																<circle cx="11" cy="11" r="8" fill="#D9A465"/>
																<g clip-path="url(#clip0)">
																<path d="M15.7399 14.5025L11.8187 10.5813L7.23747 6H6.87944L6.80634 6.18576C6.61339 6.67607 6.53095 7.17756 6.56796 7.63594C6.61015 8.15844 6.80864 8.6108 7.14202 8.94418L10.7184 12.5205L11.1901 12.0488L14.4965 15.746C14.8254 16.0749 15.3915 16.0944 15.7399 15.746C16.0828 15.4031 16.0828 14.8453 15.7399 14.5025Z" fill="white"/>
																<path d="M9.06103 11.6921L6.26004 14.4931C5.91723 14.8359 5.91723 15.3938 6.26004 15.7366C6.5857 16.0623 7.14908 16.091 7.5035 15.7366L10.3045 12.9356L9.06103 11.6921Z" fill="white"/>
																<path d="M15.5753 7.6648L13.9864 9.25367L13.5719 8.83918L15.1608 7.25029L14.7463 6.8358L13.1574 8.42467L12.7429 8.01018L14.3318 6.42131L13.9173 6.00684L11.8449 8.0793C11.5914 8.33283 11.44 8.66947 11.4186 9.02725C11.4131 9.11789 11.3926 9.20705 11.3585 9.29186L12.7048 10.6381C12.7896 10.604 12.8788 10.5835 12.9694 10.5781C13.3272 10.5567 13.6638 10.4053 13.9173 10.1518L15.9898 8.07932L15.5753 7.6648Z" fill="white"/>
																</g>
																<circle cx="11" cy="11" r="10.5" stroke="#D9A465"/>
																<defs>
																<clipPath id="clip0">
																<rect width="10" height="10" fill="white" transform="translate(6 6)"/>
																</clipPath>
																</defs>
																</svg>
															@elseif($value->categories_name =='Dinner')
																<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
																<circle cx="11" cy="11" r="8" fill="#DD87D4"/>
																<g clip-path="url(#clip0)">
																<path d="M14.1195 11.4011C13.2862 10.5678 12.1783 10.1089 10.9999 10.1089C9.82147 10.1089 8.71357 10.5678 7.8803 11.4011C7.11677 12.1646 6.66783 13.1588 6.59802 14.2265H15.4018C15.332 13.1588 14.883 12.1646 14.1195 11.4011Z" fill="white"/>
																<path d="M14.4689 8.97984C14.5029 8.99345 14.5174 9.02018 14.523 9.03488C14.5286 9.04961 14.5355 9.0792 14.5191 9.11202L14.2043 9.80088L14.7394 10.0453L15.0479 9.36975C15.1308 9.20024 15.1399 9.00237 15.0728 8.82584C15.005 8.64749 14.8645 8.50455 14.6873 8.43369C14.6432 8.41606 14.6191 8.36898 14.6292 8.32357L14.799 7.94549L14.2623 7.70459L14.0785 8.11412L14.0738 8.12814C13.9594 8.47135 14.133 8.84547 14.4689 8.97984Z" fill="white"/>
																<path d="M12.3125 7.28354C12.3466 7.29716 12.361 7.32387 12.3666 7.33859C12.3722 7.3533 12.3792 7.38289 12.3628 7.41571L12.0479 8.10459L12.583 8.34897L12.8915 7.6735C12.9744 7.50399 12.9836 7.30609 12.9164 7.12956C12.8486 6.95118 12.7081 6.80826 12.531 6.7374C12.4869 6.71977 12.4627 6.67271 12.4729 6.62732L12.6426 6.24918L12.1059 6.0083L11.9221 6.41781L11.9175 6.43179C11.8031 6.77503 11.9766 7.14914 12.3125 7.28354Z" fill="white"/>
																<path d="M9.46887 7.28356C9.50291 7.29716 9.5174 7.32389 9.52299 7.33861C9.52858 7.35332 9.53552 7.38291 9.51913 7.41569L9.20428 8.10459L9.73936 8.34897L10.0479 7.67346C10.1308 7.50395 10.1399 7.30608 10.0728 7.12958C10.005 6.9512 9.8645 6.80828 9.68734 6.7374C9.64324 6.71977 9.61911 6.67271 9.62924 6.62732L9.79895 6.2492L9.26232 6.0083L9.0785 6.41783L9.07385 6.43183C8.95944 6.77505 9.13293 7.14916 9.46887 7.28356Z" fill="white"/>
																<path d="M7.31249 8.87193C7.34653 8.88556 7.36102 8.91227 7.36661 8.92699C7.3722 8.94172 7.37916 8.97129 7.36275 9.00411L7.04793 9.69297L7.58298 9.93735L7.89149 9.26186C7.9744 9.09235 7.98355 8.89446 7.91644 8.71795C7.84863 8.53958 7.70812 8.39664 7.53097 8.32578C7.48687 8.30815 7.46271 8.26109 7.47287 8.2157L7.64259 7.83758L7.10596 7.59668L6.92214 8.00621L6.91747 8.02021C6.80306 8.36342 6.97659 8.73754 7.31249 8.87193Z" fill="white"/>
																<path d="M11.5882 9.55515V9.52085C11.5882 9.19599 11.3248 8.93262 11 8.93262C10.6751 8.93262 10.4117 9.19599 10.4117 9.52085V9.55515C10.6056 9.5326 10.8019 9.52085 11 9.52085C11.1981 9.52085 11.3944 9.5326 11.5882 9.55515Z" fill="white"/>
																<path d="M6 14.8149H16V15.9914H6V14.8149Z" fill="white"/>
																</g>
																<circle cx="11" cy="11" r="10.5" stroke="#DD87D4"/>
																<defs>
																<clipPath id="clip0">
																<rect width="10" height="10" fill="white" transform="translate(6 6)"/>
																</clipPath>
																</defs>
																</svg>
															@elseif($value->categories_name =='Brunch')
																<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<circle cx="11" cy="11" r="8" fill="#57A78A"/>
																	<circle cx="11" cy="11" r="10.5" stroke="#57A78A"/>
																	<g clip-path="url(#clip0)">
																		<path d="M15.7065 10.4924H6.29354C6.13143 10.4924 6 10.6239 6 10.786C6 11.8884 6.52844 12.9209 7.48799 13.6933C8.42889 14.4506 9.67615 14.8676 11 14.8676C12.3238 14.8676 13.5711 14.4506 14.512 13.6933C15.4716 12.921 16 11.8885 16 10.786C16 10.6239 15.8686 10.4924 15.7065 10.4924Z" fill="white"/>
																		<path d="M15.8978 7.20318C15.7748 7.09758 15.5895 7.11162 15.4838 7.23457L14.304 8.60813C14.3897 8.73365 14.4601 8.86834 14.5138 9.01C14.5665 9.03256 14.6181 9.05756 14.6686 9.08467L15.9292 7.61713C16.0348 7.49416 16.0208 7.30883 15.8978 7.20318Z" fill="white"/>
																		<path d="M14.0331 9.47082C13.9421 8.92848 13.5248 8.49527 12.9907 8.38053C12.9059 7.72088 12.3406 7.20947 11.6583 7.20947C11.0868 7.20947 10.5976 7.56809 10.4038 8.07211C10.2098 7.96734 9.99059 7.91002 9.76559 7.91002C9.02481 7.91002 8.42213 8.51269 8.42213 9.25348C8.42213 9.25818 8.42215 9.26291 8.42221 9.26764C7.99989 9.32867 7.63448 9.56746 7.40393 9.90529H14.7716C14.5825 9.68807 14.3252 9.53182 14.0331 9.47082Z" fill="white"/>
																	</g>
																	<defs>
																		<clipPath id="clip0">
																			<rect width="10" height="10" fill="white" transform="translate(6 6)"/>
																		</clipPath>
																	</defs>
																</svg>
																@else
															@endif													
															{{$value->categories_name}}
														</h5>
													</div>
													<div class="col-md-2">
														<label>{{ __('owner.Status') }}</label>
														<h5>
															@if(($value->status==2))
																<span class="text-danger" style="margin-left:1px;" >{{ __('owner.Cancelled') }}</span>
															
															@elseif(($value->status==1)) 
																<span class="text-success" style="margin-left:1px;">{{ __('owner.Confirmed') }}</span>
													
														    @elseif(($value->status==0)) 
																<span class="text-warning" style="margin-left:1px;">{{ __('owner.Pending') }}</span>
													
														    @elseif(($value->status==3)) 
																<span class="text-info" style="margin-left:1px;">{{ __('owner.Waiting') }}</span>
														    @else
														    	<span class="text-primary" style="margin-left:1px;">{{ __('owner.Visited') }}</span>
															@endif
														</h5>
													</div>


												</div>
											@endforeach
											@else
											<h4>No Reservation History Found</h4>
											@endif
											
											<!-- end item -->
											
											
											
											
											</div>
									</div>
								</div>
							 </div>
						  </div>
					</div>
               </div>
               <!-- end container-main -->
        </main>
    </div>
</div>


 <!-- Start Modal: This modal are using in canvas -->
 	<div class="modal fade" id="create-reservation" tabindex="-1" role="dialog" aria-labelledby="Add-New-GuestLabel" aria-hidden="true">
		
	 	<div class="modal-dialog booking-modal" role="document">
			<div class="modal-content ">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">{{ __('owner.Reservation') }}</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="nub-top">
						<h3>{{$selectuser->name}}</h3>
						<a href="" class="nub-link">{{$selectuser->mobile}}</a>
					</div>
					<form method="POST" action="{{ route('owner.restaurant.newreservation') }}" style="margin: 20px;" >
                        @csrf
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Booking Time') }}<span class="spanColor">*</span></label>
                                   @if(old('for_time'))
                                 <input class="form-control" type="time" name="for_time" id="for-time" value="{{old('for_time')}}">
                                   @else
                                    <input class="form-control" type="time" name="for_time" id="for-time" >
                                   @endif
                                 @error('for_time')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Booking Date') }}<span class="spanColor">*</span></label>
                                
                                  @if(old('for_date'))
                                 <input class="form-control" type="date" name="for_date" id="for-date" value="{{old('for_date')}}">
                                   @else
                                <input class="form-control" type="date" name="for_date" id="for-date"  >
                                   @endif
                                 @error('for_date')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.No of Person') }} <span class="spanColor">*</span></label>
                                <select class="form-control" name="no_of_person" id="no-of-person" >
                                    <option value="">{{ __('owner.Select Person') }}<span class="spanColor">*</span></option>
                                    @for ($i = 1; $i < 21; $i++)
                                  
                                       <option value="{{$i}}" @if (old('no_of_person') == '{{$i}}') selected="selected" @endif >{{$i}}</option>
                                 
                                    @endfor
                                </select>
                                  @error('no_of_person')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Booking Status') }}<span class="spanColor">*</span></label>
                                <select class="form-control" name="booking_status" id="booking-status">
                                	   <option value="">{{ __('owner.Select status') }}<span class="spanColor">*</span></option>
                                    <option value="0" @if (old('booking_status') == '0') selected="selected" @endif >{{ __('owner.Pending') }}</option>
                                    <option value="1" @if (old('booking_status') == '1') selected="selected" @endif >{{ __('owner.Confirm') }}</option>
                                </select>
                                 @error('booking_status')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Category') }}<span class="spanColor">*</span></label>
                                <select class="form-control" name="category_id" id="category-id">
                                    <option value="">{{ __('owner.Select Category') }}<span class="spanColor">*</span></option>                                    
                                    @foreach  ($categories as $key => $value)
                                        @if (old('category_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach 
                                </select>
                                 @error('category_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Event') }}</label>
                                <select class="form-control" name="tag_id" id="tag-id">
                                    <option value="">{{ __('owner.Select tag') }}</option>                                    
                                    @foreach  ($tags as $key => $value)
                                       @if (old('tag_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach 
                                </select>
                                 @error('tag_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>{{ __('owner.Floor') }}<span class="spanColor">*</span></label>
                                <select class="form-control" name="floor_id" id="floor-id">
                                    <option value="">{{ __('owner.Select Floor') }}<span class="spanColor">*</span></option>
                                    @foreach  ($floors as $key => $value)
                                        @if (old('floor_id') == $key)
                                            <option value="{{$key}}"  selected>{{$value}}</option>
                                        @else
                                            <option value="{{$key}}"  >{{$value}}</option>
                                        @endif
                                    @endforeach                                   
                                </select>
                                 @error('floor_id')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                            <div class="form-group col-md-6" id='table_box'>
                                <label>{{ __('owner.Table No') }}</label>
                                <select class="form-control" id='table_no' name='table_no' >
                                    <option value=''>-- {{ __('owner.Select Table') }} --</option>
                                </select>
                                 @error('table_no')
                                    <div class="error-box" style="color: red">{{$message}}</div>
                                    @enderror
                            </div>
                        </div>
                        <div class="row">                         
                             <div class="form-group col-md-12">
                             <input class="form-control" type="hidden" id="user_id" name="user_id" value="{{$selectuser->id}}">
                             <input class="form-control" type="hidden" id="res_id" name="res_id" value="{{$id_restaurant}}">
                              <button type="submit" class="btn  btn-black w-100">{{ __('owner.Save') }}</button>
                           </div>
                        </div>
                    </form>			
									
				</div>
			
			</div>
		</div>

    </div>
<!-- End Modal: This modal are using in canvas -->



<script>
$(document).ready(function(){

	$(document).on("change", "#floor-id", function () {
		var floor_id = this.value;
		console.log(floor_id);

		let modalHtml = "";
		let  optionValue = "";
		let tableDropDown = "";

		if(floor_id > 0){
				$.ajax({
					url: "{{url('/restaurant-owner/restaurant/tablelistbyfloorid')}}",
					type: "POST",
					data: {
						floor_id: floor_id,
						_token: '{{csrf_token()}}'
					},
					dataType: 'json',
					success: function (result) {                          
						$("#table_id").html('');                       
						let tableList = JSON.parse(result.table_list.floor_table_view);
						console.log(tableList);                    
						let tableno = 0;
						if (tableList != null) {
							optionValue = "<option value='0'>-- Select table --</option>";            
									
								for (var num = 0; tableList.length > num; num++) {      
									optionValue +=
										"<option data-table-no='" +
										tableList[num].table_no +
										"' value='"+
										tableList[num].table_id +
										"'>" +
										tableList[num].table_no +
										" Capacity : " +
										tableList[num].capacity +
										" min : " +
										tableList[num].min_capacity +
										" max : " +
										tableList[num].max_capacity +
										"</option>";
									tableno = tableList[num].table_no;

								}   

								tableDropDown = "<select class='form-control'  id='table_id' name='table_id' required>" +
								optionValue +
								"</select><input type='hidden' name='table_no'  id='table_no'>";                           
								modalHtml = "<label>Table no</label>" + tableDropDown ;
								$("#table_box").html(modalHtml);
							} 
					}
				});

		}else{
					optionValue = "<option value='0'>-- Select table --</option>";
					let tableDropDown = "<select class='form-control'  id='table_id' name='table_id' required>" +
								optionValue +
								"</select>";                           
								modalHtml = "<label>Table no</label>" + tableDropDown ;
								$("#table_box").html(modalHtml);
		}      
	});

	$(document).on("change", "#table_id", function () {
        var data_table_no = $('option:selected', this).attr('data-table-no');
        $('#table_no').val(data_table_no);
    });

	$('textarea').each(function(){
            $(this).val($(this).val().trim());
        }
    );
	
});

// $("#userSearch").on('keyup', function() {
//     var search = $(this).val().toLowerCase();
//     //Go through each list item and hide if not match search

//     $(".list-group-item").each(function() {
	
//         if ($(this).html().toLowerCase().indexOf(search) != -1) {
//             $(this).show();
//         }
//         else {
//             $(this).hide();  
//         } 
//     });
	

	var btsearch = {
    init: function(search_field, searchable_elements, searchable_text_class) {
        $(search_field).keyup(function(e){
            e.preventDefault();
            var query = $(this).val().toLowerCase();
            if(query){
                // loop through all elements to find match
                $.each($(searchable_elements), function(){
                    var title = $(this).find(searchable_text_class).text().toLowerCase();
                    if(title.indexOf(query) == -1){
                        $(this).hide();
                    } else {
                        $(this).show();
                    }
                });
            } else {
                // empty query so show everything
                $(searchable_elements).show();
            }
        });
    }
}

$(function(){
  // USAGE: btsearch.init(('search field element', 'searchable children elements', 'searchable text class');
  btsearch.init('#search_field', '#demonames li', '.demoname');
});
	
    $(".list-group-item:visible").each(function(index) {
				
         if(index == 0){
             $(this).css("border-top-left-radius", "10px");
             $(this).css("border-top-right-radius", "10px");

			//  $(".title_lable").each(function() {
			// 	$(".title_lable").show();
			// });

         }
         if(index == $(".list-group-item:visible").length - 1){
             $(this).css("border-bottom-left-radius", "10px");
             $(this).css("border-bottom-right-radius", "10px");

			//  $(".title_lable").each(function() {
			// 	$(".title_lable").hide();
			// });	
         }
     });
    

</script>
@endsection
 
    