@extends('layouts.admin')
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">
    <div class="bg-white" style="padding:1rem; border-radius:5px;">
        <b style="font-size: 20px;"> Food Intolerance </b>
        <div style="float:right;">
            {{-- @if(Auth::user()->type == 1) --}}
            <a href="{{ route('admin.foodintolerance.addfoodintolerance') }}" class="btn btn-primary btn-sm">Add New Food Intolerance</a>
            {{-- @endif --}}
        </div>
    </div>
</div>



<div class="col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>All Food Intolerance</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">

                                @if(session()->has('success'))
<div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                           <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">×</span>
                           </button>
                           <strong>Success!</strong> {{ \Session::get('success') }}.
                        </div>
@endif

                                <div class="card-box table-responsive">
                                    <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                        <thead>
                                            <tr> 
                                                <th data-searchable=false>S. No.</th>  
                                                <th>Country Name</th>
                                                <th>Food Intolerance Name</th> 
                                                <th data-searchable=false>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
data();

    function data (){
      $('#datatable').DataTable().clear().destroy();

      $('#datatable').DataTable({
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.foodintolerance.foodintolerance-list') !!}',
             data : {"_token": "{{ csrf_token() }}"}
           },
           'columnDefs': [
                 { "targets": 2, "className": "text-center" }
              ],
           "columns": [ 
              { "data": 'DT_RowIndex', orderable: false, searchable: false }, 
              {data:'country_name', name:'country_name'},
              {data:'foodintolerance_name', name:'foodintolerance_name'}, 
              {data:'action', name:'action'},
           ]
       });
    }
});
</script>

<script type="text/javascript">
  $('#datatable').on('click','.status',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.foodintolerance.statusupdatefoodintolerance") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  });
</script>
<script>
  function DelFun() {
      if(!confirm("Are You Sure to delete this?"))
      event.preventDefault();
  }
</script>
@endsection

