@extends('layouts.admin')    
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <a href="{{Route('admin.template.template')}}" class="btn btn-primary">Back</a>
        <div class="x_panel">
            <div class="x_title">
                <h2>Edit Template</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <br />
            <form method="post" action="{{ route('admin.template.updatetemplate',$template->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
            @csrf
            <div class="item form-group">
                <label class="col-form-label col-md-3 col-sm-3 label-align" for="type">New Type <span class="required spanColor">*</span></label>
                <div class="col-md-6 col-sm-6 ">
                    <input type="text" name="type" value="{{old('type', $template->type)}}" id="name" readonly="readonly" class="form-control ">
                    @error('type')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                </div>
            </div>
            <div class="item form-group">
                <label class="col-form-label col-md-3 col-sm-3 label-align" for="title">New Title <span class="required spanColor">*</span></label>
                <div class="col-md-6 col-sm-6 ">
                    <input type="text" name="title" value="{{old('title', $template->title)}}" id="name" class="form-control ">
                    @error('title')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                </div>
            </div>
            <div class="item form-group">
                <label class="col-form-label col-md-3 col-sm-3 label-align" for="subject">New Subject <span class="required spanColor">*</span></label>
                <div class="col-md-6 col-sm-6 ">
                    <input type="text" name="subject" value="{{old('subject', $template->subject)}}" id="name" class="form-control ">
                    @error('subject')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                </div>
            </div>
            <div class="item form-group">
                <label class="col-form-label col-md-3 col-sm-3 label-align" for="message">New Message <span class="required spanColor">*</span></label>
                <div class="col-md-9 col-sm-9 ">
                    <textarea class="resizable_textarea form-control" id="message" name="message">{{old('message', $template->message)}}</textarea>
                    @error('message')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                </div>
            </div>
            <div class="ln_solid"></div>
            <div class="item form-group">
                <div class="col-md-6 col-sm-6 offset-md-3">
                    <button type="submit" class="btn btn-success" value="submit">Update</button>
                </div>
            </div>
            </form>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script>
CKEDITOR.replace('message');
</script>
@endsection