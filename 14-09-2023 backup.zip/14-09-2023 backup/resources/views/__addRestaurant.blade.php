@extends('layouts.default')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
            You're logged in!
        </div>
    </div>
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem;">
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">EEEmail address</label>
                <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Example textarea</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
        </div>
    </div>
@endsection

