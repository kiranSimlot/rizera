@extends('layouts.admin')
@section('content')

<link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>

<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>


        <div class="col" role="main">
          <div class="">
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                
                <!-- <div class="row">
                  <div class="input-group mb-3 datedesign">
                    <input type="month" id="month" name="month" max="{{date('Y-m')}}" min="1970-01" class="form-control" >
                    <div class="input-group-append">
                      <button class="btn btn-outline-secondary" type="button" id="search">search</button>
                    </div>
                  </div>
                </div> -->

                <div class="row">
                  <div class="input-group mb-3 datedesign">
                    <input type="text" id="month" name="month" max="{{date('Y-m')}}" min="1970-01" class="form-control monthPicker" >
                    <div class="input-group-append">
                      <button class="btn btn-outline-secondary" type="button" id="search">search</button>
                    </div>
                  </div>
                </div>

                <div class="x_panel">
                  <div class="x_title">
                    <h2>Monthly Booking Report</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        <div class="col-sm-12">
		                    <div class="card-box table-responsive bookings-list">
		                    <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
		                      <thead>
		                        <tr> 
								              <th data-searchable=false>S. No.</th> 
		                          <th>User</th> 
		                          <th>Restaurant</th>
                              <th>Booking Date</th>  
                              <th>Status</th>
		                        </tr>
		                      </thead>
		                      <tbody>
		                      </tbody>
		                    </table>
                  			</div>
                  		</div>
              		</div>
            		</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <style type="text/css">
.bookings-list .dt-buttons.btn-group {
    float: left;
}
.bookings-list div#datatable_length {
    float: right;
}
.bookings-list div#datatable_filter {
    float: right;
    margin-right: 20px;
}
.bookings-list a.btn.btn-default {
    font-size: 12px;
    font-weight: 500;
    border: 1px solid #dee2e6;
    background: rgba(0,0,0,.05);
}
</style>

<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {

$(".monthPicker").datepicker({
        //dateFormat: 'MM yy',
        dateFormat: 'yy-mm',
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,
        //minDate: new Date(new Date().getFullYear() - 1, new Date().getMonth(), 1),
        minDate: new Date('2021'),
        maxDate: new Date((new Date().getFullYear() + 0), new Date().getMonth(), 1),

        onClose: function(dateText, inst) {
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).val($.datepicker.formatDate('yy-mm', new Date(year, month, 1)));
        }
    });

    $(".monthPicker").focus(function () {
        $(".ui-datepicker-calendar").hide();
        $("#ui-datepicker-div").position({
            my: "left top",
            at: "left bottom",
            of: $(this)
        });
    });
  
data();
    $("#search").click(function() {
      data();
    });

    function data (){
      $('#datatable').DataTable().clear().destroy();
      var month = $('#month').val();
      $('#datatable').DataTable({
        "dom": 'Blfrtip',
            // "pageLength": 5,
            "buttons": ['csv','print', 'excel', 'pdf'],
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.report.datareport') !!}',
             data : {"_token": "{{ csrf_token() }}",month:month}
           },

           "columns": [ 
		      { "data": 'DT_RowIndex', orderable: false, searchable: false },   
              {data:'Uname', name:'Uname'}, 
              {data:'Rname', name:'Rname'},
              {data:'month', name:'month'},
              {data:'status', name:'status'},
           ]
       });
    }
});

</script>
@endsection