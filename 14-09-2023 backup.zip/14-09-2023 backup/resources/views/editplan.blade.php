@extends('layouts.admin')    
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
<div class="row">
	<div class="col-md-12 col-sm-12 ">
		<a href="{{Route('admin.plan.plan')}}" class="btn btn-primary">Back</a>
		<div class="x_panel">
			<div class="x_title">
				<h2> Edit Subcription Plan</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
			<br />
			<form method="post" action="{{ route('admin.plan.updateplan',$plans->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
				@csrf
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="plan name">Plan Name 
					  <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="plan name" name="name" value="{{old('name', $plans->name)}}" class="form-control ">
					    @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="mark">Mark <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="mark" name="mark" value="{{old('mark', $plans->mark)}}" class="form-control ">
					    @error('mark')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
				<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="amount">Monthly Amount <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="amount" name="amount" value="{{old('amount', $plans->monthly_amount)}}" class="form-control ">
					    @error('amount')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
					<div class="item form-group">
					<label class="col-form-label col-md-3 col-sm-3 label-align" for="yearly_amount">Yearly Amount <span class="required spanColor">*</span>
					</label>
					<div class="col-md-6 col-sm-6 ">
					<input type="text" id="yearly_amount" name="yearly_amount" value="{{old('yearly_amount', $plans->yearly_amount)}}" class="form-control ">
					    @error('yearly_amount')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
					</div>
				</div>
				<div class="item form-group">
                	<label class="col-form-label col-md-3 col-sm-3 label-align" for="description">Description<span class="required spanColor">*</span></label>
                	<div class="col-md-9 col-sm-9 ">
                    <textarea class="resizable_textarea form-control" name="description" id="message">{{old('description', $plans->description)}}</textarea>
                        @error('description')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                	</div>
            	</div>	
				<div class="ln_solid"></div>
				<div class="item form-group">
					<div class="col-md-6 col-sm-6 offset-md-3">
						<button type="submit" class="btn btn-success" value="submit">Submit</button>
					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
</div>
<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script>
CKEDITOR.replace('message');
</script>
@endsection