@extends('layouts.admin')  
@section('content')
<h1>Dashboard</h1>
<div class="row">
    <div class="col-md-6" id="users-div"></div>
    <div class="col-md-6" id="booking-div"></div>
</div>
<div class="row">
    <div class="col-md-6" id="subscriptions-div"></div>
    <div class="col-md-6" id=""></div>
</div>
<div class="row mt-5">
    <div class="col-md-12 col-sm-12 ">
        <div class="x_panel">
            <div class="x_title">
                <h2>Restaurant Approval Requests</h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                            <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                <thead>
                                    <tr>
									 <th data-searchable=false>S. No.</th>
                                        <!--<th>Id</th>-->
                                        <th>Restaurant Name</th>
                                        <th>Address</th>
                                        <th data-searchable=false>Verification</th>
                                        <th data-searchable=false>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalContactForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold">Rejection Reason</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="{{route('admin.storereason')}}" enctype="multipart/form-data" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf
      <div class="modal-body mx-3">
        <div class="md-form">
          
          <textarea type="text" id="form8" class="md-textarea form-control" rows="4" name="rejection_reason"></textarea>
		  @error('rejection_reason')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
          <input type="hidden" value="" name="hidden_id" class="hidden_id">
		  <input type="hidden" value="dashboard" name="url_change_to">
          <label data-error="wrong" data-success="right" for="form8">Your message</label>
        </div>

      </div>
      <div class="modal-footer d-flex justify-content-center">
         <button type="submit" class="btn btn-success" value="submit">Submit</button>
      </div>
    </form>
    </div>
  </div>
</div>

<script type="text/javascript">
  
  $('#datatable').on('click','.status',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.restaurant-status-update") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  });

  $('#datatable').on('click','.verify',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.restaurant-verity-update") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  }); 

  $(document).on("click", ".reject", function () {
     var ids = $(this).attr('data-id');

    //alert(ids);
     $(".hidden_id").val( ids );
    });
  
</script>

<script type="text/javascript">

    var users =  <?php echo $users; ?>;
    Highcharts.stockChart('users-div', {
        title: { 
            text: 'Graph of Daily Registration'
        },
        yAxis: {
            title: {
                text: 'Number of Registration'
            }
        },
        chart: {
            alignTicks: false
        },
		
        rangeSelector: {
            selected: 1
			//enabled: false
			/*allButtonsEnabled: true,
            buttons: [{
                type: 'month',
                count: 3,
                text: 'Day',
                dataGrouping: {
                    forced: true,
                    units: [['day', [1]]]
                }
            }, {
                type: 'year',
                count: 1,
                text: 'Week',
                dataGrouping: {
                    forced: true,
                    units: [['week', [1]]]
                }
            }, {
                type: 'all',
                text: 'Month',
                dataGrouping: {
                    forced: true,
                    units: [['month', [1]]]
                }
            }	]*/
        },
        series: [{
            type: 'column',
            name: 'graph of daily registration',
            data: users
        }]
    });
</script>

<script>
    $(function() {
		var data =  <?php echo $booking; ?>;
    Highcharts.stockChart('booking-div', {
        title: {
            text: 'Graph of Daily Booking'
        },
        yAxis: {
            title: {
                text: 'Number of Booking'
            }
        },
        chart: {
            alignTicks: false
        },
        rangeSelector: {
            selected: 1
        },
        series: [{
            type: 'column',
            name: 'Daily booking',
            data: data
      
        }]
    });
});
</script>

<script type="text/javascript">
    var subscriptions =  <?php echo $subscriptions; ?>;
    Highcharts.stockChart('subscriptions-div', {
        title: {
            text: 'Graph of Daily Subscription'
        },
        yAxis: {
            title: {
                text: 'Number of Subscription'
            }
        },
        chart: {
            alignTicks: false
        },
        rangeSelector: {
            selected: 1
        },
        series: [{
            type: 'column',
            name: 'graph of daily subscription',
            data: subscriptions
        }]
    });
</script>

<script type="text/javascript">
$(document).ready(function() {
data();

    function data (){
      $('#datatable').DataTable().clear().destroy();
      $('#datatable').DataTable({
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.restaurantApprove') !!}',
             data : {"_token": "{{ csrf_token() }}"}
           },
		   'columnDefs': [
			  {
				  "targets": 3,
				  "className": "text-center"
			 },
			 {
				  "targets": 4,
				  "className": "text-center",
			 }],
           "columns": [
		      { "data": 'DT_RowIndex', orderable: false, searchable: false },
              /*{data:'Rid', name:'Rid'},*/
              {data:'Rname', name:'Rname'},
              {data:'Address', name:'Address'},
			  {data:'verify', name:'verify'},
              {data:'actions', name:'actions'},
           ]
       });
    }
});
</script>

@endsection