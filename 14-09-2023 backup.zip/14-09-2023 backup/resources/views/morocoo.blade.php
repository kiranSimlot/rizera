{{-- @extends('layouts.admin') --}}
{{-- @section('content') --}}
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Rizera</title>
  </head>
  <body>
  	
{{-- nav bar --}}
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Rizera</a>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
  	</ul>
    <a href="#" class="btn btn-outline-primary">Login</a>
  </div>
	</nav>
{{-- /nav bar --}}

<div class="container">
{{-- search bar --}}
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <form action="{{route('search-m')}}" method="post">
                    @csrf
                    <div class="input-group mb-3 col-md-6 text-center">
                        <input type="text" name="search" class="form-control" placeholder="Name, Location, Cuisine" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-outline-primary" type="submit" value="submit">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
{{-- /search bar --}}
                <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" scope="col">#</th>
                            <th class="column-title" scope="col">Restaurant</th>
                            <th class="column-title" scope="col">Country</th>
                            <th class="column-title" scope="col">City</th>
                          </tr>
                        </thead>
                        <tbody>
                        @foreach($restaurants as $key =>$restaurant)
                            <tr class="even pointer">
                            <td scope="row">{{++$key}}</td>
                            <td>{{$restaurant->name}}</td>
                            <td>{{$restaurant->country_name}}</td>
                            <td>{{$restaurant->city_name}}</td>
                            </tr>
                        @endforeach 
                        </tbody>
                      </table>
                        <div class="d-felx justify-content-center">
                            {{$restaurants->links()}}
                        </div>
                    </div>  
                </div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
{{-- @endsection --}}

