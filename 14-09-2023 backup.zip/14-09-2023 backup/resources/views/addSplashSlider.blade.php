@extends('layouts.admin') 
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
    <div class="row">
        <div class="col-md-12 col-sm-12 ">
            <a href="{{Route('admin.splashSlider.list')}}" class="btn btn-primary">Back</a>
            <div class="x_panel">
                <div class="x_title">
                    <h2>Add New Splash Banner</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.splashSlider.storeSplashSlider') }}" enctype="multipart/form-data" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf 
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Image <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="file" name="image" id="image" class="form-control " onchange="previewss_image(event)">
                           <div class="col-md-4" >
                                 <div class="input-upload-img img-wrap" >
                                    
                                    <img class="img-fluid" id="outputss_image" src="" > 

                                 </div> 
                              </div>
                        @error('image')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                    </div>
                </div>
                <p style="margin-left: 255px;"> Resolution &gt; 700*500</p>
                <div class="ln_solid"></div>
                <div class="item form-group">
                    <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" class="btn btn-success" value="submit">Submit</button>
                    </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>
@endsection


<script type="text/javascript">
    function previewss_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('outputss_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}

</script>