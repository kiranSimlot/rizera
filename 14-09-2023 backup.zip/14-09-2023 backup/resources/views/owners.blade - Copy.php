@extends('layouts.admin')    
@section('content')
        <div class="col" role="main">
          <div class="">
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="row">
                  <div class="input-group mb-3 datedesign">
                    <input type="month" id="month" name="month" max="{{date('Y-m')}}" min="1970-01" class="form-control" >
                    <div class="input-group-append">
                      <button class="btn btn-outline-secondary" type="button" id="search">search</button>
                    </div>
                  </div>
                </div>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Owners List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                            <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                              <thead>
                                <tr>
								    <th data-searchable=false>S. No.</th>
                                    <!--<th>Id</th>-->
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th data-searchable=false>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<script type="text/javascript">
$(document).ready(function() {
data();
    $("#search").click(function() {
      data();
    });

    function data (){
      $('#datatable').DataTable().clear().destroy();
      var month = $('#month').val();
      var table = $('#datatable').DataTable({
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.ownersData') !!}',
             data : {"_token": "{{ csrf_token() }}",month:month}
           },
		   'columnDefs': [
                 { "targets": 3, "className": "text-center" }
              ],
           "columns": [
		      { "data": 'DT_RowIndex', orderable: false, searchable: false },
              /*{data:'id', name:'id'},*/
              {data:'name', name:'name'},
              {data:'email', name:'email'},
              {data:'actions', name:'actions'},
           ]
       });


$('input[type="search"]').on( 'keyup', function () {
            //table.columns([1]).search($(this).val()).draw();
            //table.column(1).search(this.value).column(2).search(this.value).draw();
            // table.columns([1,2]).search($(this).val()).draw();

            //table.columns(1).search($(this).val()).draw();
            //table.columns(2).search($(this).val()).draw();
            //table.columns([1,2]).search($(this).val()).draw();
} );




     



    }
});
</script>
<script type="text/javascript">
  $('#datatable').on('click','.status',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    $.ajax({
      url:'{!! route("admin.supdate") !!}',
      type:'PUT',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  });
</script>
<script type="text/javascript">
  $('#datatable').on('click','.del',function(e){
    event.preventDefault();
    var id = e.target.dataset.id;
    console.log(id);
    if(confirm('Are you sure to delete')){
    $.ajax({
      url:'{!! route("admin.sdelete") !!}',
      type:'post',
      data:{
            "_token":"{{ csrf_token() }}",
            id:id
      },
      success: function(data){
        window.location.reload();
      }
    });
  }
  });
</script>
@endsection