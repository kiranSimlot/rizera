@extends('layouts.default') 
@section('content') 

<div class="container-fluid">
    <div class="fix-width">
        @include('layouts.floor_management_left_menu')
        <!-- main -->
        <main role="main" class="main-box">
            <div class="container">
                @if(count($staffList) == 0)
                    <div class="alert alert-warning " role="alert" style="margin:1rem;">
                        No Record found
                    </div> 
                @endif

                <div style="padding-top:1rem; padding-bottom:1rem;">
                    <div class="bg-white" style="padding:1rem; border-radius:5px;">
                            <b> {{ __('owner.Staff') }}</b>
                            <div style="float:right;">
                                <a href="{{route('owner.staff.add')}}" class="btn btn-black">{{ __('owner.Add Staff') }}</a>
                            </div>
                    </div>
                </div>


                <div style="padding-top:1rem; padding-bottom:1rem;">
                    <div class="bg-white" style="padding:1.5rem; border-radius:5px;">

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">{{ __('owner.Username') }}</th>
                                    <th scope="col">{{ __('owner.Email') }}</th>
                                    <th scope="col">{{ __('owner.Action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                                @foreach($staffList as $key =>$staff)
                                <tr>
                                    <th scope="row">{{++$key}}</th>
                                    <td>{{$staff['name']}}</td>
                                    <td>{{$staff['email']}}</td>
                                    <td>
                                        <a href="{{route('owner.staff.edit',$staff['id'])}}" class="btn-sm btn-black py-3" >{{ __('owner.Edit') }}</a>
                                        <button class="btn btn-sm btn-danger" onclick="event.preventDefault(); if(confirm('Are you delete it.')){ document.getElementById('delete-form-{{$staff->id}}').submit();  } " >{{ __('owner.Delete') }}</button>
                                        <form id="delete-form-{{$staff->id}}" action="{{route('owner.staff.destroy',$staff['id'])}}" method="post" style="display:none;">
                                            @csrf
                                            @method("DELETE")
                                        </form>
                                    </td>
                                </tr>
                                @endforeach 

                            </tbody>
                        </table>
                        <div class="d-felx justify-content-center"></div>
                    </div>
                </div>


            </div>
        </main>
    </div>
</div>

@endsection