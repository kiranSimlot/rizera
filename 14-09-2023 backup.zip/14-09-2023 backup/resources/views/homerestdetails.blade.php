<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Rizera</title>
  </head>
  <body>
  	
{{-- nav bar --}}
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Rizera</a>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
  	</ul>
  </div>
	</nav>
{{-- /nav bar --}}

{{-- main --}}
{{-- @foreach($restaurants as $key =>$restaurant) --}}
<div class="card mb-3">
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="{{ asset('admin_theme/production/images/rest.jpg') }}" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="{{ asset('admin_theme/production/images/rest1.jpg') }}" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="{{ asset('admin_theme/production/images/rest2.jpg') }}" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
  <div class="card-body">
    <h1 class="card-title">{{$restaurant->name}}
          @if(isset($restaurant->getHour))
          @if(isset($restaurant->getHour->mon_to))
          @if(
              (($restaurant->getHour->mon_to <= date("H:i:s")) 
                AND ($restaurant->getHour->mon_from >= date("H:i:s")) 
                AND ('Monday' == date("l"))
              )
          OR (($restaurant->getHour->tue_to <= date("H:i:s")) 
                AND ($restaurant->getHour->tue_from >= date("H:i:s")) 
                AND ('Tuesday' == date("l"))
              ) 
          OR (($restaurant->getHour->wed_to <= date("H:i:s")) 
                AND ($restaurant->getHour->wed_from >= date("H:i:s"))
                AND ('Wednesday' == date("l"))
              )
          OR (($restaurant->getHour->thu_to <= date("H:i:s"))
                AND ($restaurant->getHour->thu_from >= date("H:i:s"))
                AND ('Thursday' == date("l"))
              )
          OR (($restaurant->getHour->fri_to <= date("H:i:s"))
                AND ($restaurant->getHour->fri_from >= date("H:i:s"))
                AND ('Friday' == date("l"))
              )
          OR (($restaurant->getHour->sat_to <= date("H:i:s"))
                AND ($restaurant->getHour->sat_from >= date("H:i:s"))
                AND ('Saturday' == date("l"))
              )
          OR (($restaurant->getHour->sun_to <= date("H:i:s"))
                AND ($restaurant->getHour->sun_from >= date("H:i:s"))
                AND ('Saturday' == date("l"))
              )
            )
          <span class="badge badge-pill badge-success"> Open </span>
          @else
          <span class="badge badge-pill badge-danger"> Close </span>
          @endif
        @endif
        @endif
    </h1>
    {{-- <p>Date:{{date("h:i:s")}}</p> --}}
    <h3 class="card-text">{{$restaurant->getOwner->name}}</h3>
    <p class="card-text"><b>Address:</b> {{$restaurant->address}}</p>
    <p class="card-text"><b>City:</b> {{$restaurant->getCity->city_name}}</p>
    <p class="card-text"><b>Country:</b> {{$restaurant->getCountry->country_name}}</p>
    <p class="card-text"><b>Contact No.:</b> {{$restaurant->mobile}}</p>
    <p class="card-text"><b>Contact Email:</b> {{$restaurant->email}}</p>
    <p class="card-text"><b>Visit Website:</b> {{$restaurant->website}}</p>
    {{-- <p class="card-text"><b>Cuisine Type:</b> {{$restaurant->cname}}</p> --}}
    <p class="card-text"><b>Cuisine Type:</b></p>
    @foreach($restaurant->getCuisine as $cuisine)
      {{$cuisine->Cuisine['name']}}
      <br>
    @endforeach
    <p class="card-text"><b>Restaurant Facilities:</b></p>
    @foreach($restaurant->getFacilities as $facility)
      {{$facility->facilities['name']}}
      <br>
    @endforeach
    <p class="card-text">{{$restaurant->notes}}</p>
    <div class="col-md-6 m-3">
      <h6><b>About Restaurant:</b></h6>
    <p class="card-text">{{$restaurant->description}}</p>
    </div>
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Timing
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{$restaurant->name}} Timing</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-striped">
   		 <thead class="thead-dark">
   	    	<tr>
			    <th scope="col">Day</th>
			    <th scope="col">Open</th>
			    <th scope="col">Close</th>
		    </tr>
		  </thead>
    		{{-- <tr><td>Monday</td><td>{{$restaurant->getHour->mon_to}}:AM</td><td>{{$restaurant->getHour->mon_from}}:PM</td></tr>
    		<tr><td>Tuesday</td><td>{{$restaurant->getHour->tue_to}}:AM</td><td>{{$restaurant->getHour->tue_from}}:PM</td></tr>
    		<tr><td>Wednesday</td><td>{{$restaurant->wed_to}}:AM</td><td>{{$restaurant->wed_from}}:PM</td></tr>
    		<tr><td>Thursday</td><td>{{$restaurant->thu_to}}:AM</td><td>{{$restaurant->thu_from}}:PM</td></tr>
    		<tr><td>Friday</td><td>{{$restaurant->fri_to}}:AM</td><td>{{$restaurant->fri_from}}:PM</td></tr>
    		<tr><td>Saturday</td><td>{{$restaurant->sat_to}}:AM</td><td>{{$restaurant->sat_from}}:PM</td></tr>
    		<tr><td>Sunday</td><td>{{$restaurant->sun_to}}:AM</td><td>{{$restaurant->sun_from}}:PM</td></tr> --}}

        <tr><td>Monday</td>
          @if($restaurant->getHour)
          @if(($restaurant->getHour->mon_to == Null) && ($restaurant->getHour->mon_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td>{{$restaurant->getHour->mon_to}}:AM</td><td>{{$restaurant->getHour->mon_from}}:PM</td>
          @endif
        </tr>
        <tr><td>Tuesday</td>
          @if(($restaurant->getHour->tue_to == Null) && ($restaurant->getHour->tue_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td>{{$restaurant->getHour->tue_to}}:AM</td><td>{{$restaurant->getHour->tue_from}}:PM</td>
          @endif
        </tr>
        <tr><td>Wednesday</td>
          @if(($restaurant->getHour->wed_to == Null) && ($restaurant->getHour->wed_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td>{{$restaurant->getHour->wed_to}}:AM</td><td>{{$restaurant->getHour->wed_from}}:PM</td>
          @endif
        </tr>
        <tr><td>Thursday</td>
          @if(($restaurant->getHour->thu_to == Null) && ($restaurant->getHour->thu_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td>{{$restaurant->getHour->thu_to}}:AM</td><td>{{$restaurant->getHour->thu_from}}:PM</td>
          @endif
        </tr>
        <tr><td>Friday</td>
          @if(($restaurant->getHour->fri_to == Null) && ($restaurant->getHour->fri_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td>{{$restaurant->getHour->fri_to}}:AM</td><td>{{$restaurant->getHour->fri_from}}:PM</td>
          @endif
        </tr>
        <tr><td>Saturday</td>
          @if(($restaurant->getHour->sat_to == Null) && ($restaurant->getHour->sat_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td>{{$restaurant->getHour->sat_to}}:AM</td><td>{{$restaurant->getHour->sat_from}}:PM</td>
          @endif
        </tr>
        <tr><td>Sunday</td>
          @if(($restaurant->getHour->sun_to == Null) && ($restaurant->getHour->sun_from == Null))
          <td colspan="2" class="text-center"><b>Close</b></td>
          @else
          <td colspan="2" class="text-center"><b>Open</b></td>
          @endif
          @endif
        </tr>
    	</table>
      </div>
    </div>
  </div>
</div>

 
    <p class="card-text">{{$restaurant->online_book_tnc}}</p>
    <p class="card-text"><b>Notification Contact Email:</b> {{$restaurant->notification_emails}}</p>
    <p class="card-text"><b>Notification Contact Mobile No.:</b> {{$restaurant->notification_mobiles}}</p>
    <h6><b>Delivery Services: </b></h6>
    @if($restaurant->home_delivery == 1)
    <p class="card-text">Yes, We can provide you Home Delivery services.</p>
    @elseif($restaurant->home_delivery == 0)
    <p class="card-text">Sorry, We can not provide you Home Delivery services.</p>
    @endif
    @if($restaurant->takeout == 1)
    <p class="card-text"><b>Takeout: </b>Yes</p>
    @elseif($restaurant->takeout == 0)
    <p class="card-text"><b>Takeout: </b>No</p>
    @endif
    <p class="card-text"><b>Restaurant Rating: </b> {{$restaurant->rating}}</p>
    @if($restaurant->verified == 1)
    <p class="card-text"><b>Restaurant Varified: </b>Varified</p>
    @elseif($restaurant->verified == 0)
    <p class="card-text"><b>Restaurant Varified: </b>Not Varified</p>
    @endif
    
    {{-- <p class="card-text">{{$restaurant->verified}}</p> --}}
    <p class="card-text">{{$restaurant->expensiveness}}</p>
    <p class="card-text">{{$restaurant->created_at}}</p>
  </div>
</div>
{{-- @endforeach --}}
{{-- /main --}}
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>

