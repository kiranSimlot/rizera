@extends('layouts.admin')
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
     <div class="row">
        <div class="col-md-12 col-sm-12 ">
            <a href="{{Route('admin.allergy.allergy')}}" class="btn btn-primary">Back</a>
            <div class="x_panel">
                <div class="x_title">
                    <h2>Add New Allergy</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.allergy.storeallergy') }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf
                      <div class="item form-group">
                        <label for="country" class="col-form-label col-md-3 col-sm-3 label-align">Country <span class="required spanColor">*</span></label>
                        <div class="col-md-6 col-sm-6 ">

                            <select name="country_name" class="form-control" id="country_name">
                                <option value="">Select Country</option>
                                <?php
                       
                                foreach($country as $list)
                                 {
                                  $chk_id = $list->id;  
                                  $checked_ser = '';
                                  if(old('country_name'))
                                   {
                                    if($chk_id == old('country_name'))
                                     {
                                      $checked_ser = 'selected="selected"'; 
                                     }
                                    else
                                     {
                                      $checked_ser = ''; 
                                     }
                                   }
                                echo $checked_ser;
                                ?>
                                <option value="<?php echo $list->id; ?>" <?php echo $checked_ser; ?>><?php echo $list->country_name; ?></option>
                                <?php } ?>
                                </select>
                            
                        @error('country_name')
                        <div class="error-box" style="color: #ff0000;">{{$message}}</div>
                        @enderror
                        </div>
                </div>
                
                
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">New Allergy(En) <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name" value="{{old('name')}}" id="name" class="form-control ">
                    @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                    </div>
                </div>
                
                
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">New Allergy(Ar) <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name_ar" value="{{old('name_ar')}}" id="name_ar" class="form-control ">
                    @error('name_ar')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                    </div>
                </div>
                
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">New Allergy(Fr) <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name_fr" value="{{old('name_fr')}}" id="name_fr" class="form-control ">
                    @error('name_fr')
                        <div class="error-box" style="color: red">{{$message}}</div>
                    @enderror
                    </div>
                </div>
                
                
                
                
                <div class="ln_solid"></div>
                <div class="item form-group">
                    <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" class="btn btn-success" value="submit">Submit</button>
                    </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>
@endsection