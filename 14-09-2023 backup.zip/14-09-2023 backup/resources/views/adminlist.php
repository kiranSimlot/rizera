@extends('layouts.admin')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b style="font-size: 20px;"> Restaurants </b>
                <div style="float:right;">
                    @if(Auth::user()->type != 1)
                    <a href="{{url('#')}}" class="btn btn-primary btn-sm">Add Restaurant</a>
                    @endif
                </div>
        </div>
    </div>
{{-- search bar --}}
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <form action="{{route('restaurant.search')}}" method="post">
                    @csrf
                    <div class="input-group mb-3 col-md-6 text-center">
                        <input type="text" name="search" class="form-control" placeholder="Search for restaurant or location" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-outline-primary" type="submit" value="submit">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
{{-- /search bar --}}
                <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" scope="col">#</th>
                            <th class="column-title" scope="col">Restaurant</th>
                            @if(Auth::user()->type == 1)
                            <th class="column-title" scope="col">Name</th>
                            @endif
                            <th class="column-title" scope="col">Cuisine Type</th>
                            <th class="column-title" scope="col">Rating</th>
                            <th class="column-title" scope="col">Verification</th>
                            @if( Auth::user()->type == 1  )
                            <th class="column-title no-link last" scope="col"><span class="nobr">Action</span></th>
                            @endif
                          </tr>
                        </thead>
                        <tbody>
                        @foreach($restaurants as $key =>$restaurant)
                            <tr class="even pointer">
                            <td scope="row">{{++$key}}</td>
                            <td>{{$restaurant->name}}</td>
                            @if(Auth::user()->type == 1)
                                <td>{{$restaurant->getOwner->name}}</td>
                            @endif
                            {{-- <td>{{$restaurant->cname}}</td> --}}
                            <td>@foreach($restaurant->getCuisine as $cuisine)
                                {{$cuisine->Cuisine['name']}}
                                @endforeach
                            </td>
                            <td>{{$restaurant->rating}}</td>
                            {{-- <td>{{$restaurant->verified}}</td> --}}
                            @if($restaurant->verified == 1)
                            <td>Varified</td>
                            @elseif($restaurant->verified == 0)
                            <td>Not Varified</td>
                            @endif
                            @if( Auth::user()->type != 1  )
                            <td>
                            <a href="{{url('restaurant/edit',$restaurant['restaurant.id'])}}" class=" btn btn-sm btn-primary" >Edit</a>
                            <button class="btn btn-sm btn-danger" onclick="event.preventDefault(); if(confirm('Are you delete it.')){ document.getElementById('delete-form-{{$restaurant->restaurant.id}}').submit();  } " >
                                Delete
                            </button>
                            <form id="delete-form-{{$restaurant->id}}" action="{{url('restaurant/delete',$restaurant->id)}}" method="post" style="display:none;">
                                @csrf
                                @method("DELETE")
                            </form>
                            </td>
                            @elseif(Auth::user()->type == 1 )
                            <td>
                            <a href="{{route('admin.details',$restaurant->id)}}" class=" btn btn-sm btn-info" >View</a>
                            </td>
                            @endif
                            </tr>
                        @endforeach 
                        </tbody>
                      </table>
                        <div class="d-felx justify-content-center">
                            {{$restaurants->links()}}
                        </div>
                    </div>  
                </div>
@endsection

