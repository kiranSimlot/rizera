<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="{{ asset('front/assets/bootstrap/css/bootstrap.min.css') }}" >
      <!-- Custom CSS -->
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" >
      <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/slick/slick.css') }}"/>
      @if(app()->getLocale() == 'ara')
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css">
        
        @endif
      <link rel="stylesheet" href="{{ asset('front/css/style.css') }}" >
      @if(app()->getLocale() == 'ara')
        
        <link rel="stylesheet" href="{{ asset('front/css/style-rtl.css') }}" >
        @endif
      <link rel="stylesheet" href="{{ asset('front/css/responsive.css') }}" >
      <title>Rizera</title>
   </head>
   <body>
      <!-- header -->
      <div class="header">
         <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
               <div class="container-fluid">
                  <a class="navbar-brand" href="#"><img src="{{ asset('front/imgs/logo.png') }}" alt=""></a>
                  <div class="dropdown lang">
                     <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <g filter="url(#filter0_d)">
                              <circle cx="21" cy="21" r="11" fill="#D80027"/>
                              <circle cx="21" cy="21" r="10.5" stroke="white"/>
                           </g>
                           <path d="M26.28 19.5853H22.2465L21 15.72L19.7535 19.5855H15.72L18.9832 21.9745L17.7367 25.84L21 23.4508L24.2632 25.8398L23.0168 21.9743L26.28 19.5853ZM19.8965 21.6753L20.318 20.3682H21.682L22.1035 21.6753V21.6754L21 22.4832L19.8965 21.6753ZM21.4295 19.5853H20.5705L21 18.2532L21.4295 19.5853ZM22.7643 21.1915L22.4988 20.3682H23.8889L22.7643 21.1915ZM19.5011 20.3682L19.2356 21.1915L18.1111 20.3682H19.5011ZM19.2145 23.7903L19.6441 22.4582L20.3391 22.967L19.2145 23.7903ZM21.6609 22.967L22.3558 22.4582L22.7854 23.7903L21.6609 22.967Z" fill="#FFDA44"/>
                           <defs>
                              <filter id="filter0_d" x="0" y="0" width="42" height="42" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                 <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                 <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"/>
                                 <feOffset/>
                                 <feGaussianBlur stdDeviation="5"/>
                                 <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"/>
                                 <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow"/>
                                 <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow" result="shape"/>
                              </filter>
                           </defs>
                        </svg>
                        Choose Country 
                        <svg class="arrow" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5.5914 4.06061C5.7252 4.15395 5.8746 4.21728 6.0306 4.24595C6.18241 4.24328 6.32821 4.17728 6.43801 4.06061L9.87725 0.382564C10.1116 0.137964 10.4207 0.00124584 10.7422 8.47257e-06C11.0637 -0.00122889 11.3736 0.133106 11.6095 0.375897L11.6275 0.394564C11.7446 0.516318 11.8381 0.663431 11.9022 0.826844C11.9663 0.990258 11.9995 1.16651 12 1.34476C12.0004 1.523 11.9681 1.69946 11.9048 1.86327C11.8416 2.02708 11.7488 2.17478 11.6323 2.29726L6.46441 7.80866C6.34622 7.9301 6.19158 7.99831 6.0306 8C5.86582 7.97067 5.70783 7.90566 5.5656 7.80866L0.366533 2.29726C0.250139 2.17459 0.157575 2.02676 0.0945406 1.86285C0.0315063 1.69894 -0.000664114 1.52243 1.03909e-05 1.34418C0.000684896 1.16594 0.03419 0.989732 0.0984627 0.826418C0.162735 0.663103 0.256415 0.516135 0.373733 0.394564L0.395333 0.375897C0.632717 0.1331 0.943877 -0.00111428 1.26652 0.00012191C1.58917 0.0013581 1.89948 0.137954 2.13536 0.382564L5.5914 4.06061Z" fill="#484848"/>
                     </svg>
                     </button>
                     <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li>
                           <a class="dropdown-item" href="/1">
                              <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <g filter="url(#filter0_d)">
                                    <circle cx="21" cy="21" r="11" fill="#D80027"/>
                                    <circle cx="21" cy="21" r="10.5" stroke="white"/>
                                 </g>
                                 <path d="M26.28 19.5853H22.2465L21 15.72L19.7535 19.5855H15.72L18.9832 21.9745L17.7367 25.84L21 23.4508L24.2632 25.8398L23.0168 21.9743L26.28 19.5853ZM19.8965 21.6753L20.318 20.3682H21.682L22.1035 21.6753V21.6754L21 22.4832L19.8965 21.6753ZM21.4295 19.5853H20.5705L21 18.2532L21.4295 19.5853ZM22.7643 21.1915L22.4988 20.3682H23.8889L22.7643 21.1915ZM19.5011 20.3682L19.2356 21.1915L18.1111 20.3682H19.5011ZM19.2145 23.7903L19.6441 22.4582L20.3391 22.967L19.2145 23.7903ZM21.6609 22.967L22.3558 22.4582L22.7854 23.7903L21.6609 22.967Z" fill="#FFDA44"/>
                                 <defs>
                                    <filter id="filter0_d" x="0" y="0" width="42" height="42" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                       <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                       <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"/>
                                       <feOffset/>
                                       <feGaussianBlur stdDeviation="5"/>
                                       <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"/>
                                       <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow"/>
                                       <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow" result="shape"/>
                                    </filter>
                                 </defs>
                              </svg>
                              Kuwait
                           </a>
                        </li>
                        <li>
                           <a class="dropdown-item" href="/2">
                              <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <g filter="url(#filter0_d)">
                                    <circle cx="21" cy="21" r="11" fill="#D80027"/>
                                    <circle cx="21" cy="21" r="10.5" stroke="white"/>
                                 </g>
                                 <path d="M26.28 19.5853H22.2465L21 15.72L19.7535 19.5855H15.72L18.9832 21.9745L17.7367 25.84L21 23.4508L24.2632 25.8398L23.0168 21.9743L26.28 19.5853ZM19.8965 21.6753L20.318 20.3682H21.682L22.1035 21.6753V21.6754L21 22.4832L19.8965 21.6753ZM21.4295 19.5853H20.5705L21 18.2532L21.4295 19.5853ZM22.7643 21.1915L22.4988 20.3682H23.8889L22.7643 21.1915ZM19.5011 20.3682L19.2356 21.1915L18.1111 20.3682H19.5011ZM19.2145 23.7903L19.6441 22.4582L20.3391 22.967L19.2145 23.7903ZM21.6609 22.967L22.3558 22.4582L22.7854 23.7903L21.6609 22.967Z" fill="#FFDA44"/>
                                 <defs>
                                    <filter id="filter0_d" x="0" y="0" width="42" height="42" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                       <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                       <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"/>
                                       <feOffset/>
                                       <feGaussianBlur stdDeviation="5"/>
                                       <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"/>
                                       <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow"/>
                                       <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow" result="shape"/>
                                    </filter>
                                 </defs>
                              </svg>
                              Morocco
                           </a>
                        </li>
                     </ul>
                  </div>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNav">
                     <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                           <a class="nav-link" href="lang/fr">{{ __('message.French') }}</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="lang/ara">{{ __('message.Arabic') }}</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="lang/en">{{ __('message.English') }}</a>
                        </li>
                     </ul>
                  </div>
                  <a class="btn btn-primary ms-3 px-3" href="#" tabindex="-1" aria-disabled="true">{{ __('message.For Restaurant') }}</a>
               </div>
            </nav>
         </div>
      </div>
      <!-- end off header -->

      <!-- hiro -->
      <section class="hiro" style="background-image: url(front/imgs/hiro.jpg);">
           <div class="container">
                <h2>{{ __('message.Reserve a table at the best restaurants in your region') }}</h2>
<div class="form-hiro">
    <div class="search">
        <div class="form-g"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.7263 16.3951L13.289 11.9395C14.4299 10.6301 15.055 8.98262 15.055 7.26749C15.055 3.26026 11.6781 0 7.52752 0C3.37691 0 0 3.26026 0 7.26749C0 11.2747 3.37691 14.535 7.52752 14.535C9.08571 14.535 10.5706 14.0812 11.8401 13.2199L16.3111 17.7093C16.498 17.8967 16.7494 18 17.0187 18C17.2737 18 17.5156 17.9062 17.6992 17.7355C18.0893 17.3731 18.1017 16.7721 17.7263 16.3951ZM7.52752 1.89587C10.5955 1.89587 13.0913 4.30552 13.0913 7.26749C13.0913 10.2295 10.5955 12.6391 7.52752 12.6391C4.45956 12.6391 1.9637 10.2295 1.9637 7.26749C1.9637 4.30552 4.45956 1.89587 7.52752 1.89587Z" fill="#939393"/>
</svg>
<form action="{{route('home-kuwait')}}" method="post">
   @csrf
   <input type="text" name="search" placeholder="{{ __('message.Search for restaurant or location') }}">
   <button type="submit" value="submit" class="btn btn-black">{{ __('message.Explore') }}</button>
</form>
</div>
</div></div>
<h6><span> {{ __('message.Just looking around? Let us suggest you something hot & happening!') }} </span><span> <svg width="103" height="70" viewBox="0 0 103 70" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M28.062 0.173073C27.6053 -0.137482 26.9834 -0.0190089 26.6728 0.43769C26.3623 0.894389 26.4807 1.51637 26.9374 1.82693L28.062 0.173073ZM62.9997 41L63.6768 40.2641L62.9997 41ZM95.9997 43.4999L96.6429 44.2656L95.9997 43.4999ZM26.5 38.5L25.8705 37.723H25.8705L26.5 38.5ZM-3.8445e-05 69.5L10.0531 63.8196L0.107149 57.9535L-3.8445e-05 69.5ZM26.9374 1.82693C39.3195 10.2468 45.6042 17.8481 50.04 24.4777C52.3071 27.8663 54.0001 30.8497 55.9058 33.7984C57.7697 36.6825 59.7304 39.3511 62.3227 41.7359L63.6768 40.2641C61.2641 38.0444 59.41 35.5358 57.5855 32.7128C55.8028 29.9544 53.9338 26.7009 51.7022 23.3656C47.1404 16.5475 40.6799 8.75324 28.062 0.173073L26.9374 1.82693ZM62.3227 41.7359C68.7883 47.6843 75.9759 49.501 82.2348 49.237C88.4539 48.9747 93.7967 46.6564 96.6429 44.2656L95.3565 42.7342C92.8839 44.8112 87.9768 46.993 82.1505 47.2388C76.3641 47.4828 69.7112 45.8157 63.6768 40.2641L62.3227 41.7359ZM96.6429 44.2656C100.071 41.3863 102.274 35.4326 102.522 29.3296C102.772 23.1922 101.06 16.5484 96.2212 12.3102C91.3393 8.0343 83.5463 6.43746 72.1584 9.84669C60.7832 13.2521 45.6648 21.6871 25.8705 37.723L27.1295 39.277C46.8351 23.3129 61.7167 15.0604 72.732 11.7627C83.7347 8.46876 90.7229 10.1531 94.9035 13.8147C99.127 17.514 100.759 23.464 100.524 29.2484C100.288 35.0673 98.1788 40.3635 95.3565 42.7342L96.6429 44.2656ZM25.8705 37.723C16.321 45.4593 8.50612 54.7008 3.7652 61.1575L5.3773 62.3412C10.0516 55.9752 17.752 46.874 27.1295 39.277L25.8705 37.723Z" fill="white"/>
</svg>
</span></span></h6>

<div class="nav-btn-hiro">
     <ul class="list-unstyled">
      @foreach($cuisine as $key=>$name)
       <li><a href="#">{{$name->name}}</a></li>
      @endforeach
      </ul>

    </div>
           </div>

      </section>

      <!-- banner -->
      <!-- Popular restaurants in Morocco -->
      <section class="popular-restaurants">
         <div class="container">
            <h2 class="text-center">
               <span><span> {{ __('message.Popular restaurants in Morocco') }} </span>
               <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0)">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.2019C172.852 17.559 170.476 23.313 168.842 25.0987C166.912 18.4519 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.063C74.8429 19.7416 4.00944 32.1424 0 11.2098V7.04317V6.94397C0.148498 13.3924 9.65236 17.4598 21.6807 18.0551C38.3124 18.8487 59.8446 14.4836 70.982 12.1027C90.4352 7.93603 118.204 1.58682 141.964 0.197934C150.28 -0.298098 158.15 -0.0996849 164.833 0.991585C170.921 2.08285 173 6.54714 173 11.4083Z" fill="#FCCC00"/>
                  </g>
                  <defs>
                     <clipPath id="clip0">
                        <rect width="173" height="25" fill="white"/>
                     </clipPath>
                  </defs>
               </svg>
            </h2>
            <div class="row">
               @foreach($restaurants as $key=>$detail)
               <div class="col-lg-6 col-xl-4 col-md-6">
                  <div class="card">
                     <div class="card-img">
                        <div class="hart">
                           <img src="{{ asset('front/imgs/hart.svg') }}" alt="">
                        </div>
                        <img src="{{ asset('front/imgs/item.png') }}" alt="" class="w-100">
                        <div class="card-img-overly">
                           <div class="row">
                              <div class="col-6">
                                 <span class="American"><img src="{{ asset('front/imgs/American.png') }}" alt="">                                
                                 @foreach($detail->getCuisine as $cuisine)
                                {{$cuisine->Cuisine['name']}}
                                @endforeach</span>
                              </div>
                              <div class="col-6 text-end">
                                 @if($detail->verified == 1)
                                 <span class="Verified"><img src="{{ asset('front/imgs/Verified.png') }}" alt="">Verified</span>
                                 @elseif($detail->verified == 0)
                                 <span class="Verified"><img src="{{ asset('front/imgs/Verified.png') }}" alt="">Not Verified</span>
                                 @endif
                                 <span class="Star"><img src="{{ asset('front/imgs/Star.png') }}" alt="">{{$detail->rating}}</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-7">
                              <h3>{{$detail->name}}</h3>
                              <p>Metropolitian Hotel, Umm al Sheif</p>
                           </div>
                           <div class="col-5 text-end">
                              

                              {{-- open/close --}}

                           @if( isset($detail->getHour->mon_to) )
                              @if((($detail->getHour->mon_to <= date("H:i:s")) 
                                    && ($detail->getHour->mon_from >= date("H:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->getHour->tue_to <= date("H:i:s")) 
                                    && ($detail->getHour->tue_from >= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->getHour->wed_to <= date("H:i:s")) 
                                    && ($detail->getHour->wed_from >= date("H:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->getHour->thu_to <= date("H:i:s"))
                                    && ($detail->getHour->thu_from >= date("H:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->getHour->fri_to <= date("H:i:s"))
                                    && ($detail->getHour->fri_from >= date("H:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->getHour->sat_to <= date("H:i:s"))
                                    && ($detail->getHour->sat_from >= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->getHour->sun_to <= date("H:i:s"))
                                    && ($detail->getHour->sun_from >= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                )
                                <span class="open"> 
                                <span class="badge badge-pill badge-success"> {{ __('message.open') }}  </span>
                                </span>
                                @else
                                <span class="close">
                                <span class="badge badge-pill badge-danger"> {{ __('message.close') }} </span>
                                </span>
                              @endif
                           @endif

                              
                              <span class="doller">$$</span>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-7">
                              <h6>What we provide?</h6>
                              <ul class="list-unstyled">
                                 @if($detail->takeout == 1)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt=""> Takeout </li>
                                 @elseif($detail->takeout == 0)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt="">No Takeout </li>
                                 @endif
                                 @if($detail->home_delivery == 1)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> Delivery </li>
                                 @elseif($detail->home_delivery == 0)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> No Delivery </li>
                                 @endif
                              </ul>
                           </div>
                           <div class="col-5 text-end">
                              <a href="" class="btn btn-primary"> Reserve Now</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               @endforeach
            </div>
            <div class="btn-center text-center pt-3">
               <a href="restaurant-list/1" class="btn btn-black">
                  {{ __('message.See all restaurants') }}
                  <svg class="ms-2" width="15" height="11" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M12.6363 4.81412C11.3716 4.81412 10.1893 4.81412 9.00765 4.81412C6.32339 4.81347 3.63914 4.81154 0.954248 4.81412C0.796313 4.81412 0.632623 4.82185 0.481082 4.8618C0.165852 4.94494 -0.00742817 5.20271 0.000244141 5.53266C0.0079174 5.84327 0.186954 6.08429 0.493871 6.16162C0.63582 6.19706 0.788 6.20415 0.935704 6.20415C4.6865 6.20609 8.43601 6.20609 12.1855 6.20609C12.3109 6.20609 12.4362 6.20609 12.6312 6.20609C12.5148 6.33433 12.4432 6.41875 12.3652 6.49673C11.2961 7.5755 10.2251 8.6517 9.15919 9.7337C9.05688 9.83745 8.95778 9.96183 8.9079 10.0959C8.79664 10.3936 8.92069 10.7223 9.1739 10.8866C9.44437 11.0619 9.78006 11.0355 10.023 10.797C10.4431 10.3859 10.8543 9.96441 11.2686 9.54682C12.4061 8.40037 13.543 7.25393 14.6792 6.10684C15.1038 5.67765 15.107 5.34319 14.6882 4.92109C13.1523 3.37252 11.6133 1.82653 10.0812 0.273456C9.86446 0.0537048 9.6055 -0.0784035 9.3395 0.0511272C9.14448 0.145858 8.96097 0.359165 8.87465 0.56345C8.75892 0.836044 8.93795 1.07126 9.13617 1.27039C10.2072 2.34659 11.2763 3.42537 12.3454 4.50414C12.4247 4.58534 12.5014 4.67041 12.6363 4.81412Z" fill="white"/>
                  </svg>
               </a>
            </div>
         </div>
      </section>
      
      <!-- end of Popular restaurants in Morocco -->
      <!-- Explore by top Locations -->
      <section class="explore-location">
         <div class="container">
            <h2 class="text-center">
               <span>
                  {{ __('message.Explore by top Locations') }} 
                  <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.202C172.852 17.5591 170.476 23.3131 168.842 25.0988C166.912 18.452 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.0631C74.8429 19.7416 4.00944 32.1424 0 11.2099V7.04323V6.94403C0.148498 13.3924 9.65236 17.4599 21.6807 18.0551C38.3124 18.8488 59.8446 14.4837 70.982 12.1028C90.4352 7.93609 118.204 1.58688 141.964 0.197995C150.28 -0.298037 158.15 -0.0996239 164.833 0.991646C170.921 2.08292 173 6.5472 173 11.4083Z" fill="#FCCC00"/>
                  </svg>
               </span>
            </h2>
            <div class="row">
               @foreach($city as $key=>$cities)
               <div class="col-md-4 col-lg-3 col-xl-2">
                  <div class="card border-0">
                     <div class="icon">
                        <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">
                           <!-- <img src="{{ asset('front/imgs/Explore/Ellipse 31.png') }}" alt=""></a> -->
                           <img class="card-img-top" src="/city/{{ $cities->city_image }}" alt="Card image cap"></a>
                        <div class="hover">
                           <div class="hover-c">
                              <div>
                                 <span>{{$cities->city_name}}</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">
                     <h4>{{$cities->city_name}}</h4></a>
                  </div>
               </div>
               @endforeach
            </div>
         </div>
      </section>
      <!-- end Explore by top Locations -->
      <!-- How it Work -->
      <section class="how-it-work">
         <div class="container">
            <h2 class="text-center">
               <span>
                  {{ __('message.How it Work') }}
                  <svg width="111" height="25" viewBox="0 0 111 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M111 11.4083V12.202C110.905 17.5591 109.38 23.3131 108.332 25.0988C107.094 18.452 99.5665 16.6662 90.9914 16.4678C87.1803 16.4678 83.2738 16.6662 79.5579 17.0631C48.0206 19.7416 2.57253 32.1424 0 11.2099V7.04323V6.94403C0.095279 13.3924 6.19313 17.4599 13.9107 18.0551C24.582 18.8488 38.3974 14.4837 45.5433 12.1028C58.0249 7.93609 75.8421 1.58688 91.0867 0.197995C96.4223 -0.298037 101.472 -0.0996239 105.76 0.991646C109.666 2.08292 111 6.5472 111 11.4083Z" fill="#FCCC00"/>
                  </svg>
               </span>
            </h2>
            <div class="row">
               <div class="col-md-4">
                  <div class="card">
                     <div class="icon">
                        <img src="{{ asset('front/imgs/Search-Location.svg') }}" alt="">
                     </div>
                     <h3>Find Restaurant</h3>
                     <p>Amet minim mollit non deserunt est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit.</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="card" style="background: #2BD2FF;">
                     <div class="icon">
                        <img src="{{ asset('front/imgs/Shop.svg') }}" alt="">
                     </div>
                     <h3>Review Listings</h3>
                     <p>Amet minim mollit non deserunt est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit.</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="card"  style="background: #FCCC00;">
                     <div class="icon">
                        <img src="{{ asset('front/imgs/Calender.svg') }}" alt="">
                     </div>
                     <h3>Make a Reservation</h3>
                     <p>Amet minim mollit non deserunt est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit.</p>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end of How it Work -->
      <!-- download section -->
      <section class="download-section">
         <div class="container">
            <h6>Download the app form here...</h6>
            <ul class="list-unstyled">
               <li><a href=""><img src="{{ asset('front/imgs/google-s.png') }}" alt=""> </a></li>
               <li><a href=""><img src="{{ asset('front/imgs/app-s.png') }}" alt=""> </a></li>
            </ul>
         </div>
      </section>
      <!-- end of download  -->
      <!-- Footer -->
      <div class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-6 pe-md-5">
                  <div class="logo-footer">
                     <a href=""><img src="{{ asset('front/imgs/f-logo.png') }}" alt=""></a>
                  </div>
                  <p class="mb-4 pe-md-5">Amet minim mollit non deserunt ullamco est aliqua sit dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.</p>
                  <h5>Connect and Share</h5>
                  <ul class="list-unstyled socal">
                     <li>
                        <a href="">
                           <svg width="8" height="17" viewBox="0 0 8 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M7.57281 8.35415H5.34053V16.3037H2.03395V8.35415H0.464355V5.55111H2.03395V3.72082C2.02572 3.63987 2.0216 3.5452 2.0216 3.44916C2.0216 1.73688 3.41009 0.348389 5.12238 0.348389C5.20882 0.348389 5.29388 0.352504 5.37895 0.359364L5.36797 0.357993H7.81566V3.16104H6.04026C6.02929 3.16104 6.01831 3.15967 6.00596 3.15967C5.63414 3.15967 5.33367 3.46014 5.33367 3.83196C5.33367 3.86489 5.33642 3.89782 5.34053 3.92937V3.92526V5.57854H7.86231L7.57281 8.35415Z" fill="#141414"/>
                           </svg>
                        </a>
                     </li>
                     <li>
                        <a href="">
                           <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M11.1666 0.265776H4.75783C4.75509 0.265776 4.75234 0.265776 4.74823 0.265776C2.32523 0.265776 0.359121 2.22503 0.348145 4.64528V11.054C0.348145 13.4893 2.32249 15.4637 4.75783 15.4637H11.1666C13.5896 15.4582 15.5515 13.4962 15.557 11.0732V4.64528C15.5461 2.2264 13.5854 0.269892 11.1666 0.264404V0.265776ZM7.96288 11.3065C6.064 11.3065 4.52459 9.76705 4.52459 7.86816C4.52459 5.96928 6.064 4.42987 7.96288 4.42987C9.86176 4.42987 11.4012 5.96928 11.4012 7.86816C11.4012 9.76705 9.86176 11.3065 7.96288 11.3065ZM11.6989 5.02944C11.183 5.02807 10.7659 4.61098 10.7659 4.0951C10.7659 3.57922 11.1844 3.16075 11.7003 3.16075C12.2162 3.16075 12.6346 3.57922 12.6346 4.0951C12.6346 4.11156 12.6346 4.12803 12.6333 4.14449V4.14174C12.6086 4.63705 12.1997 5.02944 11.7003 5.02944C11.6907 5.02944 11.6797 5.02944 11.6701 5.02944H11.6715H11.6989Z" fill="#141414"/>
                           </svg>
                        </a>
                     </li>
                     <li>
                        <a href="">
                           <svg width="11" height="15" viewBox="0 0 11 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M6.2723 10.5617C5.5657 10.4368 4.94692 10.1281 4.44613 9.68907L4.45025 9.69318C4.08529 11.5619 3.65584 13.3647 2.35791 14.2991C1.96551 11.496 2.94651 9.3488 3.40476 7.08771C2.61997 5.78017 3.49806 3.13628 5.14175 3.78113C7.16823 4.58513 3.38556 8.66691 5.92654 9.17181C8.46753 9.67672 9.66257 4.58514 8.00928 2.91264C5.63705 0.511595 1.10525 2.86599 1.66641 6.30428C1.79675 7.14533 2.67485 7.40602 2.01216 8.56538C0.498816 8.22923 0.0405602 7.03283 0.0968132 5.43579C0.305361 2.9634 2.2454 1.00415 4.69035 0.766791L4.71093 0.765418C7.51398 0.447109 10.2498 1.81227 10.6148 4.50144C11.0346 7.53773 9.32505 10.8169 6.27092 10.5823L6.2723 10.5617Z" fill="#141414"/>
                           </svg>
                        </a>
                     </li>
                     <li>
                        <a href="">
                           <svg width="19" height="13" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.1279 3.28017C18.1279 1.86698 16.9823 0.719971 15.5677 0.719971H3.53643C2.12325 0.719971 0.976234 1.86561 0.976234 3.28017V10.165C0.976234 11.5782 2.12188 12.7252 3.53643 12.7252H15.5677C16.9809 12.7252 18.1279 11.5795 18.1279 10.165V3.28017ZM7.85282 9.62304V3.18687L12.7564 6.40976L7.85282 9.62304Z" fill="#141414"/>
                           </svg>
                        </a>
                     </li>
                  </ul>
               </div>
               <div class="col-md-3">
                  <h3>Company</h3>
                  <ul class="list-unstyled">
                     <li><a href="">About us</a></li>
                     <li><a href="">Contact us </a></li>
                     <li><a href="">Privacy policy </a></li>
                     <li><a href="">Terms of service </a></li>
                     <li><a href="">Pricing </a></li>
                  </ul>
               </div>
               <div class="col-md-3">
                  <h3>Support</h3>
                  <h5>Address</h5>
                  <address>4140 Parker Rd. Allentown, New Mexico 31134</address>
                  <h5>Helpline</h5>
                  <a href="" class="call">  (205) 555-0100 </a>
                  <h5>Timing</h5>
                  <div class="timeing">
                     <p>Monday - Saturday</p>
                     <p>7AM to 10PM</p>
                  </div>
               </div>
            </div>
         </div>
         <div class="copy-right text-center">
            <p>All Right Reserved 2021 - Rezera</p>
         </div>
      </div>
      <!-- end of footer -->
      <script src="{{ asset('front/js/jquery.min.js') }}" ></script>
      <script src="{{ asset('front/assets/bootstrap/js/bootstrap.bundle.min.js') }}" ></script>
      <script type="text/javascript" src="{{ asset('front/assets/slick/slick.min.js') }}"></script>
      <script type="text/javascript" src="{{ asset('front/js/custom.js') }}"></script>
   </body>
</html>