@extends('layouts.admin')
@section('content')

<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign"></div>

<div class="col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>All Request</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                        <thead>
                                            <tr>
											<th data-searchable=false>S. No.</th>
                                                <!--<th>Id</th>-->
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Country Code</th>
                                                <th>Mobile</th>
                                                <th>Email</th>
                                                <th>Restaurant</th>
                                                <th data-searchable=false>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
data();

    function data (){
      $('#datatable').DataTable().clear().destroy();

      $('#datatable').DataTable({
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('admin.demo.requestData') !!}',
             data : {"_token": "{{ csrf_token() }}"}
           },
           "order": [[1, 'desc' ]],
		   'columnDefs': [
                 { "targets": 7, "className": "text-center" }
              ],
           "columns": [
		      { "data": 'DT_RowIndex', orderable: false, searchable: false },
              /*{data:'id', name:'id'},*/
              {data:'first_name', name:'first-name'},
              {data:'last_name', name:'last_name'},
              {data:'country_code', name:'country_code'},
              {data:'mobile_no', name:'mobile_no'},
              {data:'email', name:'email'},
              {data:'restaurant_name', name:'restaurant_name'},
              {data:'action', name:'action'},
           ]
       });
    }
});
</script>
<script type="text/javascript">
$('#datatable').on('click','.mark',function(e){
    event.preventDefault();
    var id= e.target.dataset.id;
    console.log(e);
    console.log(id);
    $.ajax({
        url:'{!! route("admin.demo.requestAprove") !!}',
        type:'PUT',
        data:{
                "_token": "{{ csrf_token() }}",
                id:id
            },
        success: function(data){
        e.target.style.visibility = 'hidden';
        window.location.reload();
        }
    });
});  

$('#datatable').on('click','.reject',function(e){
    event.preventDefault();
    var id= e.target.dataset.id;
    console.log(e);
    console.log(id);
    $.ajax({
        url:'{!! route("admin.demo.requestReject") !!}',
        type:'PUT',
        data:{
                "_token": "{{ csrf_token() }}",
                id:id
            },
        success: function(data){
        e.target.style.visibility = 'hidden';
        window.location.reload();
        }
    });
});  
</script>


@endsection

