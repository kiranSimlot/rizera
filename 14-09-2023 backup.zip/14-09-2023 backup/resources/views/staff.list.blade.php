@extends('layouts.default')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                        You're logged in!
        </div>
    </div>
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem; border-radius:5px;">

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Username</th>
                        <th scope="col">Email</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($staffList as $key =>$staff)
                    <tr>
                        <th scope="row">{{++$key}}</th>
                        <td>{{$staff['name']}}</td>
                        <td>{{$staff['email']}}</td>
                        <td>
                            <a href="{{url('destroy',$staff['id'])}}" class="btn-sm btn-danger" onclick="return confirm('Are you sure delete it');" >Delete</a>
                            <form id="delete-form-{{$staff['id']}}" action="{{url('destroy',$staff['id'])}}" method="post" style="display:none;">
                                @csrf
                                @method("DELETE")
                            </form>
                        </td>
                    </tr>
                    @endforeach 
                </tbody>
            </table>
            <div class="d-felx justify-content-center">
            {{ $staffList->links() }}
        </div>
    </div>
@endsection

