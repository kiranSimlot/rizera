@extends('layouts.default')

@section('content')
<!-- <?php

if(isset($permission_type)){
    {{-- echo "<pre>"; print_r($permission_type); die; --}}
}


 ?> -->
<div class="container-fluid">
    <div class="fix-width">
         @include('layouts.floor_management_left_menu')
        <!-- main -->
        <main role="main" class="main-box m-auto w-100">

            <form action="{{ ( (isset($staff->id)&&$staff->id>0)? route('owner.staff.update') :route('owner.staff.create') ) }}" method="post" enctype="multipart/form-data">
               <!-- end  main header -->
               <!-- container-main -->
               <div class="container-main">
                  <!-- Your Restaurant Details -->
                    <div class="add-restaurant-form">


                <div class="d-inline">
                @if(isset($staff->id) && $staff->id>0)
                    <h2>Edit Staff Details</h2>
                @else
                    <h2>Add New Staff</h2>
                @endif
                </div>

                    <div class="card">
                    <div class="card-header">
                    <h4>{{ __('owner.General Details') }}</h4>
                        @if(old('chef') && old('waiter'))
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input type="radio" id="staff" name="chef" value="3">
                                    <label for="staff">{{ __('owner.Staff') }}</label>
                                    <input type="radio" id="chef" name="chef" value="5">
                                    <label for="chef">{{ __('owner.Chef') }}</label>
                                    <input type="radio" id="waiter" name="chef" value="6">
                                    <label for="waiter">{{ __('owner.Waiter') }}</label>
                                    {{-- <input class="form-check-input" name="chef" value="{{old('chef')}}" type="checkbox" id="gridCheck1" >
                                    <label class="form-check-label" for="gridCheck1">
                                    {{ __('owner.Chef') }}
                                    </label> --}}
                                </div>
                            </div>
                        @elseif(isset($staff->type))
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input type="radio" id="staff" name="chef" value="3" {{ $staff->type == '3' ? 'checked' : '' }}>
                                    <label for="staff">{{ __('owner.Staff') }}</label>
                                    <input type="radio" id="chef" name="chef" value="5" {{ $staff->type == '5' ? 'checked' : '' }}>
                                    <label for="chef">{{ __('owner.Chef') }}</label>
                                    <input type="radio" id="waiter" name="chef" value="6" {{ $staff->type == '6' ? 'checked' : '' }}>
                                    <label for="waiter">{{ __('owner.Waiter') }}</label>
                                    {{-- <input class="form-check-input" name="chef" value="chef" type="checkbox" id="gridCheck1"
                                        <?php
                                            if ($staff->type == 5) {
                                                echo "checked";
                                            }
                                        ?>
                                    >
                                    <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Chef') }}
                                    </label> --}}
                                </div>
                            </div>
                        @else
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input type="radio" id="staff" name="chef" value="3">
                                    <label for="staff">{{ __('owner.Staff') }}</label>
                                    <input type="radio" id="chef" name="chef" value="5">
                                    <label for="chef">{{ __('owner.Chef') }}</label>
                                    <input type="radio" id="waiter" name="chef" value="6">
                                    <label for="waiter">{{ __('owner.Waiter') }}</label>
                                </div>
                            </div>
                            {{-- <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" name="chef" value="chef" type="checkbox" id="gridCheck1" >
                                    <label class="form-check-label" for="gridCheck1">
                                    {{ __('owner.Chef') }}
                                    </label>
                                </div>
                            </div> --}}
                        @endif
                    </div>
                    <div class="card-body">
                    <div class="form-group">

                    @csrf
                    <label for="exampleFormControlInput1" class="form-label">Name<span class="spanColor">*</span></label>
                    @if(isset($staff->id) && $staff->id>0)
                        <input type="hidden" name="id" value="{{$staff->id}}">
                    @endif

                    @if(old('name'))
                        <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Name" value="{{old('name')}}" onKeyPress="return ValidateAlpha(event);">
                    @elseif(isset($staff->name) )
                        <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Name" value="{{$staff->name}}" onKeyPress="return ValidateAlpha(event);">
                    @else
                        <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Name" value="" onKeyPress="return ValidateAlpha(event);">
                    @endif
                    @error('name')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="form-group">

                                    <label for="exampleFormControlTextarea1" class="form-label">{{ __('owner.Email') }}<span class="spanColor">*</span></label>
                                    @if(old('email'))
                                        <input type="email"  name="email"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Email') }}" value="{{old('email')}}">
                                    @elseif(isset($staff->email))
                                        <input type="email"  name="email"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Email') }}" value="{{$staff->email}}">
                                    @else
                                        <input type="email"  name="email"  class="form-control" id="exampleFormControlInput1" placeholder="{{ __('owner.Email') }}" value="">
                                    @endif
                                    @error('email')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>


                    <div class="form-group">
                       <label for="exampleFormControlTextarea1" class="">{{ __('owner.Restaurant') }}<span class="spanColor">*</span> </label>
                       <select name="restaurant" id="restaurant_id" class="form-control" aria-label="Default select example">
                                <option selected value="">--- Select Restaurant ---</option>
                        @foreach($restaurants as $key=>$restaurant)
                            @if(isset($staff->restaurant_id) && $key == $staff->restaurant_id)
                                <option selected value="{{$key}}">{{$restaurant}}</option>
                            @elseif(old('restaurant_id')== $key)
                                <option selected value="{{$key}}">{{$restaurant}}</option>
                            @else
                                <option value="{{$key}}">{{$restaurant}}</option>
                            @endif
                        @endforeach
                        </select>
                        @error('restaurant')
                            <div class="error-box">{{$message}}</div>
                        @enderror
                    </div>

                            </div>
                        </div>
                     <div class="card">
                        <!-- <select name="facility_id[]" id="facility_id" class="form-select form-control chosen-select" aria-label="Default select example" multiple>
                        </select> -->
                        <div class="card-header">
                           <h4>{{ __('owner.Staff Permissions') }}<span class="spanColor">*</span></h4>
                        </div>
                        <div class="card-body">
                            <form>
                                  <div class="row">

                            @if(!empty($permission_type))
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" name="permission_type[]" value="Floor Management" type="checkbox" id="gridCheck1"
                                        <?php
                                        if (in_array("floor_management", $permission_type))
                                        {
                                        echo "checked";
                                        }
                                    ?>
                                    >
                                        <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Floor Management') }}<span class="spanColor">*</span>
                                        </label>
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" name="permission_type[]" value="report" type="checkbox" id="gridCheck1"  <?php
                                            if (in_array("report",  $permission_type))
                                                {
                                                echo "checked";
                                                }
                                        ?>>
                                        <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Report') }}
                                        </label>
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" name="permission_type[]" value="Guest Booking" type="checkbox" id="gridCheck1"  <?php
                                        if (in_array("guest_booking", $permission_type))
                                        {
                                        echo "checked";
                                        }
                                    ?>
                                    >
                                        <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Guest Booking') }}
                                        </label>
                                    </div>
                                </div>








                                @else

                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" name="permission_type[]" value="floor_management" type="checkbox" id="gridCheck1" >
                                        <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Floor Management') }}
                                        </label>
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" name="permission_type[]" value="report" type="checkbox" id="gridCheck1" >
                                        <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Report') }}
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" name="permission_type[]" value="guest_booking" type="checkbox" id="gridCheck1">
                                        <label class="form-check-label" for="gridCheck1">
                                        {{ __('owner.Guest Booking') }}
                                        </label>
                                    </div>
                                </div>


                            @endif

                         </div>
                            </form>
                        </div>
                        @error('permission_type')
                        <div class="error-box">{{$message}}</div>
                        @enderror
                     </div>

                        <div class="card">
                            <div class="card-header">
                                <h4>{{ __('owner.Credentials') }}</h4>
                            </div>
                            <div class="card-body">

                            <label for="exampleFormControlTextarea1" class="form-label">{{ __('owner.Password') }}<span class="spanColor">*</span></label>
                            <div class="input-group date ">
                                <input type="password" name="password"  class="form-control" id="password" placeholder="{{ __('owner.Password') }}" value="">

                                <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash">
                                        <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye-slash" aria-hidden="true"></i></button>
                                    </span>
                                    <span class="input-group-btn" id="eyeShow" style="display: none;">
                                        <button class="btn btn-default reveal" onclick="visibility3()" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                    </span>
                                </div>
                            </div>
                               @error('password')
                                    <div class="alert alert-danger">{{$message}}</div>
                                @enderror

                              <label for="exampleFormControlTextarea1" class="form-label" style="margin-top:25px;">{{ __('owner.Confirm Password') }}<span class="spanColor">*</span></label>
                                <div class="input-group date ">

                                    <input type="password" name="password_confirmation" class="form-control" id="confirm_password" placeholder="{{ __('owner.Confirm Password') }}">

                                    <input type="hidden" name="owner_id" class="form-control" value="{{ Auth::user()->id }}">

                                 <div class="input-group-addon" data-node-uid="452" >
                                      <span class="input-group-btn" id="eyeSlash1">
                                   <button class="btn btn-default reveal" onclick="visibility4()" type="button"><i class="fa fa-eye-slash" aria-hidden="true"></i></button>
                                 </span>
                                 <span class="input-group-btn" id="eyeShow1" style="display: none;">
                                   <button class="btn btn-default reveal" onclick="visibility4()" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                 </span>
                             </div>


                            </div>
                             @error('password_confirmation')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                        </div>
                        <div class="form-group">
                             <button class="btn btn-black w-100 py-3" type="submit">
                                @if(isset($staff->id) && $staff->id>0)
                                    {{ __('owner.Update Staff') }}
                                @else
                                    {{ __('owner.Add Staff') }}
                                @endif
                            </button>


                    </div>
                </div>
            </form>
        </main>
    </div>
</div>

<script type="text/javascript">

   function isNumberKey(evt){
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }

    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)

        return false;
            return true;
    }

    function visibility3() {
  var x = document.getElementById('password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow').show();
    $('#eyeSlash').hide();
  }else {
    x.type = "password";
    $('#eyeShow').hide();
    $('#eyeSlash').show();
  }
}

 function visibility4() {
  var x = document.getElementById('confirm_password');
  if (x.type === 'password') {
    x.type = "text";
    $('#eyeShow1').show();
    $('#eyeSlash1').hide();
  }else {
    x.type = "password";
    $('#eyeShow1').hide();
    $('#eyeSlash1').show();
  }
}

</script>

@endsection
