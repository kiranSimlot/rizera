@extends('layouts.default')

@section('content')

<style type="text/css">
    .openinghours {
        font-family: Lucida Console;
        border-radius: 4px;
        margin: 10px;
        box-shadow: 0 0 10px black;
        padding: 0 10px 0 10px;
        overflow: hidden;
        display: inline-block;
    }

    .openinghourscontent {
        float: left;
    }

    .openinghourscontent h2 {
        display: block;
        text-align: center;
        margin-top: .33em;
    }

    .openinghourscontent button {
        color: white;
        font-family: Courier New;
        font-size: large;
        font-weight: bolder;
        background-color: #4679BD;
        border-radius: 4px;
        width: 100%;
        margin-bottom: 10px;
    }

    .today {
        color: #8AC007;
    }

    .opening-hours-table tr td:first-child {
        font-weight: bold;
    }

    #open-status {
        display: block;
        margin-top: -1em;
        text-align: center;
        border: dotted lightgrey 3px;
    }

    .openorclosed:after {
        content: " open during these hours:";
    }

    .open {
        color: green;
    }

    .open:after {
        content: " Open";
        color: #6C0;
    }

    .closed:after {
        content: " Closed";
        color: red;
    }

    .opening-hours-table tr td {
        padding: 5px;
    }

    .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }

    /* Style the buttons inside the tab */
    .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #ddd;
    }

    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #ccc;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }
</style>
<div class="container-fluid">
    <div class="fix-width">
        @include('layouts.floor_management_left_menu')

        <main class="main-box w-100 border-main-box report-chart" role="main">
            <div class="dis-header">
                <div class="row align-items-center">
                    <div class=" col-md-6 text-left">
                        <b style="font-size: 20px;">All Item List</b>
                    </div>
                    <div class="col-md-6 text-right">
                        <a href="{{url('/restaurant-owner/additem')}}" class="btn advanced-report"> Item List Add</a>
                    </div>
                </div>
            </div>


            <div class="container-main">
            <div class="x_content">
                                <div class="row">
                                    <div class="col-sm-12">
                                        @if(session()->has('success'))
                                        <div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                                            <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                            <strong>Success!</strong> {{ \Session::get('success') }}.
                                        </div>
                                        @endif
                                        <div class="card-box faqlisttable table-responsive">
                                            <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th data-searchable="false" width="20%">ID</th>
                                                        <th width="30%">Category Name</th>
                                                        <th width="30%">Name</th>
                                                        <th data-searchable="false" width="20%">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

            </div>
        </main>

        <!-- <div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">

            <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b style="font-size: 20px;"> Item List </b>
                <div class="text-right">
                    <a href="{{url('/restaurant-owner/additem')}}" class="btn btn-primary btn-sm">Add</a>
                </div>
            </div>
        </div>
        <div class="col" role="main">
            <div class="">

                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>All Item List</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>

                            <div class="x_content">
                                <div class="row">
                                    <div class="col-sm-12">
                                        @if(session()->has('success'))
                                        <div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                                            <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                            <strong>Success!</strong> {{ \Session::get('success') }}.
                                        </div>
                                        @endif
                                        <div class="card-box faqlisttable table-responsive">
                                            <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th data-searchable="false" width="20%">ID</th>
                                                        <th width="30%">Category Name</th>
                                                        <th width="30%">Name</th>
                                                        <th data-searchable="false" width="20%">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function () {
        data();

        function data() {
            $('#datatable').DataTable().clear().destroy();

            var mytable = $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": {
                        url: '{{url('/restaurant-owner/itemData')}}',
                        data: {
                            "_token": "{{ csrf_token() }}"
                        }
                    },
                    "bAutoWidth": false,
                    "columns": [
                        {data: 'id', name: 'id'},
                        {data: 'category', name: 'category'},
                        {data: 'name', name: 'name'},
                        {data: 'action', name: 'action', orderable: false, searchable: false},
                    ],
                    "order": [],
                    success: function(data) {
                        mytable.ajax.reload();
                    }
                });

            $(document).on('click', '.soft_item_delete', function() {
                var result = confirm('Are you sure you want to delete this item?');
                if(result){
                    var id = $(this).attr('id');
                    $.ajax({
                        type: 'GET',
                        dataType: 'json',
                        url: 'delete_item',
                        data: {
                            'id': id
                        },
                        success: function(data){
                            console.log(data);
                            mytable.ajax.reload();
                        }
                    });
                }
		    });
        }
		
    });
</script>

@endsection
