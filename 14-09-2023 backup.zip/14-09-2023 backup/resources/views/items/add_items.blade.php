@extends('layouts.default')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.6/cropper.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.6/cropper.js"></script>

<style type="text/css">
    
    img {
        display: block;
        max-width: 100%;
    }
    .preview {
        text-align: center;
        overflow: hidden;
        width: 160px; 
        height: 160px;
        margin: 10px;
        border: 1px solid red;
    }
    .modal-lg{
        max-width: 1000px !important;
    }
    .input-group {
    column-gap: 15px;
}
</style>

<div class="container-fluid">
  <div class="fix-width">
    @include('layouts.floor_management_left_menu')
    <main class="main-box w-100 border-main-box report-chart" role="main">
      <div class="add-restaurant-form">
        <div class="d-inline">
          <h2>Add Item</h2>
        </div>
        <form method="post" action="{{url('/restaurant-owner/storeitem')}}" id="itemForm"
          data-parsley-validate class="form-horizontal form-label-left row g-lg-5 g-4"
          enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="restaurant_id" value="<?php if(isset($id_restaurant)){ echo $id_restaurant; }else{ echo $resturant_id['id']; }?>">
          <div class="card w-100">
            <div class="card-body">
              <div class="form-group">
                <select class="form-control" name="category_id">
                  <option value="">Select Category</option>
                  @foreach ($categories as $category)
                  <option value="{{ $category->id }}">{{ $category->name }}</option>
                  @endforeach
                </select>
                @error('category_id')
                <div class="error-box" style="color: red">{{$message}}</div>
                @enderror
              </div>
              <div class="form-group">
                <label class="col-form-label label-align" for="question">Name<span
                    class="required spanColor">*</span>
                </label>
                <input class="form-control" type="text" name="name">
                @error('name')
                <div class="error-box" style="color: red">{{$message}}</div>
                @enderror
              </div>

              <div class="form-group">
                <label class="col-form-label label-align" for="question">Image<span
                    class="required spanColor">*</span>
                </label>
                <!-- <input class="form-control" type="file" name="image_name[]" class="myfrm form-control" multiple> -->
                <input type="file" name="image" class="image">
                <input type="hidden" name="image_session" class="image_session">
                @error('name')
                <div class="error-box" style="color: red">{{$message}}</div>
                @enderror
              </div>
			
				<div class="form-group">
                <label class="col-form-label label-align" for="question">Description<span
                    class="required spanColor">*</span>
                </label>
                <input class="form-control" type="text" name="description">
                @error('description')
                <div class="error-box" style="color: red">{{$message}}</div>
                @enderror
              </div>
			
              <div id="itemFields">
                <div class="item form-group">
                  <label class="col-form-label label-align" for="question">Price<span
                      class="required spanColor">*</span>
                  </label>
                  <input type="text" name="price[]" class="price form-control" required>
                  @error('price.*')
                  <div class="error-box" style="color: red">{{$message}}</div>
                  @enderror
                  <label class="col-form-label label-align" for="question">Variation<span
                      class="required spanColor">*</span>
                  </label>
                  <input type="text" name="quantity[]" class="quantity form-control" required>
                  @error('quantity.*')
                  <div class="error-box" style="color: red">{{$message}}</div>
                  @enderror
                </div>
              </div>
              
              <button type="button" id="addMoreBtn" class="btn btn-primary">Add More</button>

              <div class="form-group mt-4 mb-0">
                <button class="btn btn-black w-100 py-3" type="submit"> Add Item </button>
              </div>
            </div>
          </div>
            
         </form>
            </div>
          </main>
        </div>
    </div>
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Crop Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="img-container">
                        <div class="row">
                            <div class="col-md-8">
                                <img id="image" src="https://avatars0.githubusercontent.com/u/3456749">
                            </div>
                            <div class="col-md-4">
                                <div class="preview"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="crop">Crop</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        var $modal = $('#modal');
        var image = document.getElementById('image');
        var cropper;

        $("body").on("change", ".image", function(e){
            var files = e.target.files;
            var done = function (url) {
                image.src = url;
                $modal.modal('show');
            };

            var reader;
            var file;
            var url;

            if (files && files.length > 0) {
                file = files[0];

                if (URL) {
                    done(URL.createObjectURL(file));
                } else if (FileReader) {
                    reader = new FileReader();
                    reader.onload = function (e) {
                        done(reader.result);
                    };
                reader.readAsDataURL(file);
                }
            }
        });

        $modal.on('shown.bs.modal', function () {
            cropper = new Cropper(image, {
                aspectRatio: 1,
                viewMode: 3,
                preview: '.preview'
            });
        }).on('hidden.bs.modal', function () {
            cropper.destroy();
            cropper = null;
        });

        $("#crop").click(function(){
            canvas = cropper.getCroppedCanvas({
                width: 160,
                height: 160,
            });

            canvas.toBlob(function(blob) {
                url = URL.createObjectURL(blob);
                var reader = new FileReader();
                reader.readAsDataURL(blob);
                reader.onloadend = function() {
                    var base64data = reader.result; 
                    $.ajax({
                        type: "POST",
                        dataType: "json",
                        url: "{{url('/restaurant-owner/crop_image')}}",
                        data: {'_token': '{{ csrf_token() }}', 'image': base64data},
                        success: function(data){
                            console.log(data);
                            $modal.modal('hide');

                            $.ajax({
                            type: "GET",
                            url: "{{url('/restaurant-owner/get-session')}}",
                            data: { key: "imageName" },
                            success: function(response) {
                                // Handle session value retrieval success
                                console.log("Session value retrieved:", response.value.imageName);
                                $(".image_session").val(response.value.imageName);

                            }
                        });
                            //alert("Crop image successfully uploaded");
                        }
                    });
                }
            });
        });
    </script>

<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>



<script>
  $(document).ready(function() {
    // Function to add more input fields
    /*$('#addMoreBtn').click(function() {
      var newItem = '<div class="item">' +
        '<label class="col-form-label label-align" for="question">Price<span class="required spanColor">*</span></label>' +
        '<input type="text" name="price[]" class="price form-control" required>' +
        '<label class="col-form-label label-align" for="question">Quantity<span class="required spanColor">*</span></label>' +
        '<input type="text" name="quantity[]" class="quantity form-control" required>' +
        '<button type="button" class="deleteBtn btn btn-danger">Delete</button>' +
        '</div>';

      $('#itemFields').append(newItem);
    });*/

    $('#addMoreBtn').click(function() {
            var priceContainer = $('#itemFields');
            var inputGroup = $('<div class="input-group form-group"></div>');
            var priceInput = $('<input type="text" placeholder="Price" name="price[]" class="price form-control" required>');
            var quantityInput = $('<input type="text" placeholder="Quantity" name="quantity[]" class="quantity form-control" required>');
            var removeButton = $('<button type="button" class="deleteBtn btn btn-danger">Remove</button>');

            inputGroup.append(priceInput);
            inputGroup.append(quantityInput);
            inputGroup.append(removeButton);
            priceContainer.append(inputGroup);
        });

    // Function to delete a row
    $(document).on('click', '.deleteBtn', function(){
      //$(this).closest('.item').remove();
        $(this).parent('.input-group').remove();
    });
  });
</script>
@endsection
