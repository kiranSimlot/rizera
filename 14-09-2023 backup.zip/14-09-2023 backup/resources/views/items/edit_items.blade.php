@extends('layouts.default')
@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.6/cropper.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.6/cropper.js"></script>
<style type="text/css">
    
    img {
        display: block;
        max-width: 100%;
    }
    .preview {
        text-align: center;
        overflow: hidden;
        width: 160px; 
        height: 160px;
        margin: 10px;
        border: 1px solid red;
    }
    .modal-lg{
        max-width: 1000px !important;
    }

    .lightbox {
  /* Default to hidden */
  display: none;

  /* Overlay entire screen */
  position: fixed;
  z-index: 999;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  
  /* A bit of padding around image */
  padding: 1em;

  /* Translucent background */
  background: rgba(0, 0, 0, 0.8);
}

/* Unhide the lightbox when it's the target */
.lightbox:target {
    display: flex;
    justify-content: center;
    align-items: center;
}

.lightbox span {
  /* Full width and height */
  display: block;
  width: 50%;
  height: 50%;

  /* Size and position background image */
  background-position: center;
  background-repeat: no-repeat;
  background-size: auto;
}
.input-group {
    column-gap: 15px;
}
</style>
<div class="container-fluid">
	<div class="fix-width">
		@include('layouts.floor_management_left_menu')

		<main class="main-box w-100 border-main-box report-chart" role="main">

			<div class="add-restaurant-form">

				<div class="d-inline">
					<h2>Edit item List</h2>
				</div>

				<form method="post" action="{{url('/restaurant-owner/updateitem',$item->id)}}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left row g-lg-5 g-4" enctype="multipart/form-data">
					@csrf
					<div class="card w-100">
						<div class="card-body">
							<div class="form-group">
								<select class="form-control" name="category_id">
									<option value="">Select Category</option>
									@foreach ($categories as $category)
									<option value="{{$category->id}}" {{$category->id == $item->category_id?'selected':'' }} >{{$category->name}}</option>
									@endforeach
								</select>
								@error('category_id')
								<div class="error-box" style="color: red">{{$message}}</div>
								@enderror
							</div>
							<div class="form-group">
								<label class="col-form-label label-align" for="question">Name<span class="required spanColor">*</span></label>
								<input class="form-control" type="text" name="name" value="{{old('name',$item->name)}}">
								@error('name')
								<div class="error-box" style="color: red">{{$message}}</div>
									@enderror
							</div>


							<div class="form-group">
								<label class="col-form-label label-align" for="question">Image<span class="required spanColor">*</span></label>
								<!-- <input class="form-control" type="file" name="file[]" multiple> -->
								<input type="file" name="image" class="image">
								<input type="hidden" name="image_session" class="image_session">
								@error('name')
								<div class="error-box" style="color: red">{{$message}}</div>
								@enderror

								@foreach ($ItemImage as $image)
								@if(file_exists(public_path('/files/').$image->image_name))
								<a href="#img1"><img src="{{ asset('public/files/' . $image->image_name) }}" alt="Image" height="50" width="50"></a>
								<a href="#" class="lightbox" id="img1">
  <span style="background-image: url({{ asset('public/files/' . $image->image_name) }})"></span>
</a>
								@endif
								@endforeach
							</div>
							<div class="form-group">
									<label class="col-form-label label-align" for="question">Description<span
										class="required spanColor">*</span>
									</label>
									<input class="form-control" type="text" name="description" value="{{old('description',$item->description)}}">
									@error('description')
									<div class="error-box" style="color: red">{{$message}}</div>
									@enderror
								</div>
							<div class="form-group">
								<label for="prices">Prices</label>
								<div class="price-container">
									@foreach ($ItemPrice as $index => $price)
									<div class="input-group form-group">
										<input type="text" name="prices[]" value="{{ $price->price }}" class="form-control" />
										<input type="text" name="quantities[]" value="{{ $price->quantity }}" class="form-control" />
										@if ($index > 0)
										<button type="button" class="btn btn-danger remove-price" data-id="{{ $price->id}}">Remove</button>
										@endif
									</div>
									@endforeach
								</div>
								
								<button type="button" class="btn btn-primary add-price">Add More</button>
							</div>

							<div class="form-group mt-4 mb-0">
								<button class="btn btn-black w-100 py-3" type="submit">Submit</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</main>
	</div>
</div>

<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Crop Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="img-container">
                        <div class="row">
                            <div class="col-md-8">
                                <img id="image" src="https://avatars0.githubusercontent.com/u/3456749">
                            </div>
                            <div class="col-md-4">
                                <div class="preview"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="crop">Crop</button>
                </div>
            </div>
        </div>
    </div>
<script>
        var $modal = $('#modal');
        var image = document.getElementById('image');
        var cropper;

        $("body").on("change", ".image", function(e){
            var files = e.target.files;
            var done = function (url) {
                image.src = url;
                $modal.modal('show');
            };

            var reader;
            var file;
            var url;

            if (files && files.length > 0) {
                file = files[0];

                if (URL) {
                    done(URL.createObjectURL(file));
                } else if (FileReader) {
                    reader = new FileReader();
                    reader.onload = function (e) {
                        done(reader.result);
                    };
                reader.readAsDataURL(file);
                }
            }
        });

        $modal.on('shown.bs.modal', function () {
            cropper = new Cropper(image, {
                aspectRatio: 1,
                viewMode: 3,
                preview: '.preview'
            });
        }).on('hidden.bs.modal', function () {
            cropper.destroy();
            cropper = null;
        });

        $("#crop").click(function(){
            canvas = cropper.getCroppedCanvas({
                width: 160,
                height: 160,
            });

            canvas.toBlob(function(blob) {
                url = URL.createObjectURL(blob);
                var reader = new FileReader();
                reader.readAsDataURL(blob);
                reader.onloadend = function() {
                    var base64data = reader.result; 
                    $.ajax({
                        type: "POST",
                        dataType: "json",
                        url: "{{url('/restaurant-owner/crop_image')}}",
                        data: {'_token': '{{ csrf_token() }}', 'image': base64data},
                        success: function(data){
                            console.log(data);
                            $modal.modal('hide');

                            $.ajax({
                            type: "GET",
                            url: "{{url('/restaurant-owner/get-session')}}",
                            data: { key: "imageName" },
                            success: function(response) {
                                // Handle session value retrieval success
                                console.log("Session value retrieved:", response.value.imageName);
                                $(".image_session").val(response.value.imageName);

                            }
                        });
                            //alert("Crop image successfully uploaded");
                        }
                    });
                }
            });
        });
    </script>

<script src="{{ asset('admin_theme/vendors/ckeditor/ckeditor.js') }}"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
	$(document).ready(function() {
		// Add More button click event
		$('.add-price').click(function() {
			var priceContainer = $('.price-container');
			var inputGroup = $('<div class="input-group form-group"></div>');
			var priceInput = $('<input type="text" placeholder="Price" name="prices[]" class="form-control" />');
			var quantityInput = $('<input type="text" placeholder="Quantity" name="quantities[]" class="form-control" />');
			var removeButton = $('<button type="button" class="btn btn-danger remove-price">Remove</button>');

			inputGroup.append(priceInput);
			inputGroup.append(quantityInput);
			inputGroup.append(removeButton);
			priceContainer.append(inputGroup);
		});

		// Remove button click event
		$(document).on('click', '.remove-price', function() {

			
			var priceId = $(this).data('id'); 

			if (confirm("Are you sure you want to delete this price and quantity?")) {
				$(this).parent('.input-group').remove();
				$.ajax({
					url: "{{ url('/restaurant-owner/remove_price') }}",
					type: "POST",
					data: {
						
						_token: "{{ csrf_token() }}",
						price_id: priceId,
						
					},
					success: function(response) {
						
						console.log('Price and quantity removed successfully.');
					
						//$(this).parent('.input-group').remove();
					},
					error: function(xhr, status, error) {
						
						console.log('An error occurred while removing price and quantity.');
					}
				});
			}

		});
	});
</script>
@endsection
