@extends('layouts.front')
@section('content') 

<style>
    .img-wrapper {
        position: relative;
        height: 110px;
        overflow: hidden;
    }
    .img-wrapper img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .img-overlay {
        background: rgba(0, 0, 0, 0.7);
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        cursor: pointer;
    }
    .img-overlay i {
        color: #fff;
        font-size: 3em;
    }

    #overlay {
        background: rgba(0, 0, 0, 0.7);
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    #overlay img {
        margin: 0;
        width: 80%;
        height: auto;
        -o-object-fit: contain;
            object-fit: contain;
        padding: 5%;
    }
    @media screen and (min-width: 768px) {
        #overlay img {
            width: 60%;
        }
    }
    @media screen and (min-width: 1200px) {
        #overlay img {
            width: 50%;
        }
    }

    #nextButton {
        color: #fff;
        font-size: 2em;
        transition: opacity 0.8s;
    }
    #nextButton:hover {
        opacity: 0.7;
    }
    @media screen and (min-width: 768px) {
        #nextButton {
            font-size: 2em;
        }
    }

    #prevButton {
        color: #fff;
        font-size: 2em;
        transition: opacity 0.8s;
    }
    #prevButton:hover {
        opacity: 0.7;
    }
    @media screen and (min-width: 768px) {
        #prevButton {
            font-size: 2em;
        }
    }
    #exitButton {
        color: #fff;
        font-size: 2em;
        transition: opacity 0.8s;
        position: absolute;
        top: 15px;
        right: 15px;
    }
    #exitButton:hover {
        opacity: 0.7;
    }
    @media screen and (min-width: 768px) {
        #exitButton {
            font-size: 2em;
        }
    }
</style>
   <!-- Modal -->
   <div class="modal fade item-modal" id="itemmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body position-relative">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="item-box">
                <div class="item-img">
                    <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                </div>
                <div class="item-detail">
                    <p class="item-category">Starters</p>
                    <h6>Spring Rolls</h6>
                    <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                        Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                    </p>
                </div>
            </div>
            <hr>
            <h6>Quantity :</h6>
            <div class="item-price">
                <p>250 Gm</p>
                <p>₹230</p>
            </div>
            <div class="item-price">
                <p>250 Gm</p>
                <p>₹230</p>
            </div>
            <div class="item-price">
                <p>250 Gm</p>
                <p>₹230</p>
            </div>
        </div>
    </div>
    </div>
</div>
<div class="modal fade item-modal category-modal" id="itemcategory" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body position-relative">
            <div class="menu-category">
                <div class="category-item item-price mt-0">
                    <p>Starters</p>
                    <p>02</p>
                </div>
                <div class="category-item item-price">
                    <p>Starters</p>
                    <p>02</p>
                </div>
                <div class="category-item item-price">
                    <p>Starters</p>
                    <p>02</p>
                </div>
                <div class="category-item item-price">
                    <p>Starters</p>
                    <p>02</p>
                </div>
                <div class="category-item item-price">
                    <p>Starters</p>
                    <p>02</p>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<section class="detail_page_banner" style="background: url({{ asset('front/imgs/detail.png') }}) no-repeat center center; background-size: cover;">
    <div class="detail_abs">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>
                        <span class="Verified">
                            <img src="{{ asset('front/imgs/Verified.png') }}" alt="">
                        </span>
                    </h2>
                    <h6>
                        <p>Address</p>
                        <a href="http://maps.google.co.uk/maps?q=51.917168,-0.2292397" target=_blank>
                            <span class="map"><svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4.04419 8.44897L6.86053 9.85714V1.40811L4.04419 -6.10352e-05V8.44897Z" fill="#FCCC00"/>
                                <path d="M0.523926 9.8572L3.34027 8.44903V0L0.523926 1.40817V9.8572Z" fill="#FCCC00"/>
                                <path d="M7.56445 1.40811V9.85714L10.3808 8.44897V-6.10352e-05L7.56445 1.40811Z" fill="#FCCC00"/>
                                </svg>
                                Map
                            </span>
                        </a>
                    </h6>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="#" class="btn btn-primary" >
                        Reserve Now
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section_detail_page_tab">
    <div class="top_nav">
        <div class="container">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="Profile-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="button" role="tab" aria-controls="Profile" aria-selected="true">Profile</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="Profile-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="button" role="tab" aria-controls="Profile" aria-selected="true">Profile</button>
                </li>   
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="Profile-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="button" role="tab" aria-controls="Profile" aria-selected="true">Profile</button>
                </li>   
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="Profile-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="button" role="tab" aria-controls="Profile" aria-selected="true">Profile</button>
                </li>   
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="Profile-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="button" role="tab" aria-controls="Profile" aria-selected="true">Profile</button>
                </li>                        
            </ul>
        </div>
        <div class="container">
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="Profile" role="tabpanel" aria-labelledby="Profile-tab">
                 
                <div class="menu-fixed-btn" type="button" data-bs-toggle="modal" data-bs-target="#itemcategory">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none">
                        <path d="M13.1252 7.0315V5.25H10.5002C10.2681 5.25 10.0455 5.15781 9.88143 4.99372C9.71734 4.82962 9.62515 4.60706 9.62515 4.375C9.62515 4.14294 9.71734 3.92038 9.88143 3.75628C10.0455 3.59219 10.2681 3.5 10.5002 3.5H17.5002C17.7322 3.5 17.9548 3.59219 18.1189 3.75628C18.283 3.92038 18.3752 4.14294 18.3752 4.375C18.3752 4.60706 18.283 4.82962 18.1189 4.99372C17.9548 5.15781 17.7322 5.25 17.5002 5.25H14.8752V7.0315C16.5539 7.15129 18.19 7.61572 19.6813 8.39582C21.1726 9.17592 22.4871 10.255 23.5429 11.5656C24.5987 12.8763 25.3732 14.3904 25.8179 16.0136C26.2626 17.6368 26.368 19.3342 26.1277 21H1.87265C1.63228 19.3342 1.73774 17.6368 2.18244 16.0136C2.62714 14.3904 3.40156 12.8763 4.45737 11.5656C5.51318 10.255 6.82774 9.17592 8.31904 8.39582C9.81035 7.61572 11.4464 7.15129 13.1252 7.0315ZM3.50015 19.25H24.5002C24.5002 17.8711 24.2286 16.5057 23.7009 15.2318C23.1732 13.9579 22.3998 12.8004 21.4248 11.8254C20.4498 10.8504 19.2922 10.0769 18.0183 9.54926C16.7444 9.02159 15.379 8.75 14.0002 8.75C12.6213 8.75 11.2559 9.02159 9.98198 9.54926C8.70806 10.0769 7.55055 10.8504 6.57553 11.8254C5.60052 12.8004 4.82709 13.9579 4.29942 15.2318C3.77174 16.5057 3.50015 17.8711 3.50015 19.25ZM2.62515 22.75H25.3752C25.6072 22.75 25.8298 22.8422 25.9939 23.0063C26.158 23.1704 26.2502 23.3929 26.2502 23.625C26.2502 23.8571 26.158 24.0796 25.9939 24.2437C25.8298 24.4078 25.6072 24.5 25.3752 24.5H2.62515C2.39309 24.5 2.17053 24.4078 2.00643 24.2437C1.84234 24.0796 1.75015 23.8571 1.75015 23.625C1.75015 23.3929 1.84234 23.1704 2.00643 23.0063C2.17053 22.8422 2.39309 22.75 2.62515 22.75Z" fill="white"/>
                    </svg>
                    <span> menu </span>
                </div>
                    <?php /*
                <div class="menus-section">
                    @foreach($categoryItemList as $categoryItem)
                        @if( isset($categoryItem->getItems[0]->id) )
                        <h2 class="Simphony-h2">{{$categoryItem->name}}</h2>
                        <div class="menu-items">
                            @foreach($categoryItem->getItems as $item)
                                <div class="item-box">
                                    <div class="item-img">
                                        <img src="{{URL::asset('/files/').$item->itemImage[0]->image_name}}" class="item-img" alt="item-img">
                                    </div>
                                    <div class="item-detail">
                                        <p class="item-category">{{$categoryItem->name}}</p>
                                        <h6>{{$item->name}}</h6>
                                        <p>{{$item->description}}</p>
                                        <hr>
                                        <h6>{{ $item->itemPrice[0]->price??'N/A' }}</h6>
                                    </div>
                                </div>
                            @endforeach
                            @endif
                        </div>
                    @endforeach
                </div>
                <br>=================================break=============================================<br>
                    */ ?>
                @foreach($categoryItemList as  $categoryItemList)
                    @if(count($categoryItemList->getItems) > 0)
                        <div class="menus-section" >
                            <h2 class="Simphony-h2">{{$categoryItemList->name}}:</h2>
                            <div class="menu-items">
                                @foreach($categoryItemList->getItems as $getItem)   
                                    <div class="item-box" type="button" data-bs-toggle="modal" data-bs-target="#itemmodal">
                                        
                                            <div class="item-img">
                                                <img src="{{asset('/files/' . $getItem->itemImage->image_name)}}" class="item-img" alt="item-img">
                                            </div>
                                            <div class="item-detail">
                                                <p class="item-category">{{$categoryItemList->name}}</p>
                                                <h6>{{$getItem->name}}</h6>
                                                <p>{{isset($getItem->description)?$getItem->description:""}}
                                                </p>
                                                <hr>
                                                @foreach($getItem->itemPrice as $getPrice) 
                                                    <h6>₹ {{ $getPrice->price }}</h6>
                                                @endforeach
                                            </div>
                                        
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endif
                @endforeach

                <!-- <div class="menus-section">
                    <h2 class="Simphony-h2">Beverages :</h2>
                    <div class="menu-items">
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="menus-section">
                    <h2 class="Simphony-h2">Salads :</h2>
                    <div class="menu-items">
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                        <div class="item-box">
                            <div class="item-img">
                                <img src="{{URL::asset('/front/imgs/item-img.png')}}" class="item-img" alt="item-img">
                            </div>
                            <div class="item-detail">
                                <p class="item-category">Starters</p>
                                <h6>Spring Rolls</h6>
                                <p>Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                    Lorem ipsum dolor sit amet consectetur. Faucibus euismod.
                                </p>
                                <hr>
                                <h6>₹ 299</h6>
                            </div>
                        </div>
                    </div>
                </div>
                </div> -->
            </div>
        </div>
    </div>
</div>
@endsection