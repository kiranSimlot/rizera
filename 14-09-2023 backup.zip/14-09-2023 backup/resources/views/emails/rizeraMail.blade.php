<!DOCTYPE html>
<html>
<head>
    <title>Rizera</title>
</head>
<body>
    <p>{{ $details['title'] }}</p>
    <p>{{ $details['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>