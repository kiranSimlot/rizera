@extends('layouts.front')

@section('content') 
      <div class="modal fade" id="selesct-modal" tabindex="-1" role="dialog" aria-labelledby="selesct-modalLabel" aria-hidden="true" >
         <div class="modal-dialog">
           <div class="modal-content select_location">
             
             <div class="modal-body p-0">
                 <div class="alert alert-danger" role="alert" style="display: none;" id="errordiv">
                Please select any country for further process!
              </div>
             <h3>Select your location</h3>

             <ul class="list-unstyled">
                <li>
                   <div class="form-group check">
                      <input type="radio" name="country" value=1 id="countryId-1" class="countryId" />
                      <label><span><span class="icon"><img src="{{ asset('front/imgs/location2.svg') }}"></span> Kuwait</span><span class="check-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="12" fill="#FCCC00"/>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.6443 7.46429C18.1346 8.06354 18.1157 9.01303 17.602 9.58504L11.3163 16.585C10.8195 17.1383 10.0376 17.1383 9.54078 16.585L6.39796 13.085C5.88432 12.513 5.8654 11.5635 6.35569 10.9643C6.84599 10.365 7.65984 10.343 8.17348 10.915L10.4285 13.4263L15.8265 7.41497C16.3402 6.84296 17.154 6.86504 17.6443 7.46429Z" fill="#141414"/>
                        </svg>
                        </span> </label>
                   </div>
                </li>
                <li>
                  <div class="form-group check">
                     <input type="radio" name="country" value=2 id="countryId" class="countryId" />
                     <label><span><span class="icon"><img src="{{ asset('front/imgs/location1.svg') }}"></span> Morocco</span><span class="check-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <circle cx="12" cy="12" r="12" fill="#FCCC00"/>
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M17.6443 7.46429C18.1346 8.06354 18.1157 9.01303 17.602 9.58504L11.3163 16.585C10.8195 17.1383 10.0376 17.1383 9.54078 16.585L6.39796 13.085C5.88432 12.513 5.8654 11.5635 6.35569 10.9643C6.84599 10.365 7.65984 10.343 8.17348 10.915L10.4285 13.4263L15.8265 7.41497C16.3402 6.84296 17.154 6.86504 17.6443 7.46429Z" fill="#141414"/>
                       </svg>
                       </span> </label>
                  </div>
               </li>
             </ul>
               
             <button class="btn btn-black w-100 py-3" id="countrySelectButton" class="countrySelectButton">Continue</button>
             </div>
             
           </div>
         </div>
       </div>
      <!-- end modal -->



<div class="main-hero-slider">
   <div class="header-hero owl-carousel owl-theme">

      @if($countryId)
        @foreach($banners as $value)
        @if($countryId==1)
        <div class="item" style="background-image: url({{ asset('storage').'/'.$value->image }});"></div>
          
        @elseif($countryId==2)
        <div class="item" style="background-image: url({{ asset('storage').'/'.$value->image }});"></div>
         
        @endif
          
    @endforeach
    @else
        <div class="item" style="background-image: url(front/imgs/hiro.jpg);"></div>
   @endif
       
       
   </div>


   <div class="hero-scontent hiro">
      <h2>{{ __('message.Reserve a table at the best restaurants in your region') }}</h2>
   <div class="form-hiro">
      <div class="search">
         <div class="form-g">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M17.7263 16.3951L13.289 11.9395C14.4299 10.6301 15.055 8.98262 15.055 7.26749C15.055 3.26026 11.6781 0 7.52752 0C3.37691 0 0 3.26026 0 7.26749C0 11.2747 3.37691 14.535 7.52752 14.535C9.08571 14.535 10.5706 14.0812 11.8401 13.2199L16.3111 17.7093C16.498 17.8967 16.7494 18 17.0187 18C17.2737 18 17.5156 17.9062 17.6992 17.7355C18.0893 17.3731 18.1017 16.7721 17.7263 16.3951ZM7.52752 1.89587C10.5955 1.89587 13.0913 4.30552 13.0913 7.26749C13.0913 10.2295 10.5955 12.6391 7.52752 12.6391C4.45956 12.6391 1.9637 10.2295 1.9637 7.26749C1.9637 4.30552 4.45956 1.89587 7.52752 1.89587Z" fill="#939393"/>
            </svg>
            <form action="{{route('restaurant-search')}}" method="get">
               @csrf
               <input type="text" name="search" placeholder="{{ __('message.Search for restaurant or location') }}">
               <button type="submit" value="submit" class="btn btn-black">{{ __('message.Explore') }}</button>
            </form>
         </div>
      </div>
   </div>
   <h6>
      <span> {{ __('message.Just looking around? Let us suggest you something hot & happening!') }} </span>
      <span><svg width="103" height="70" viewBox="0 0 103 70" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M28.062 0.173073C27.6053 -0.137482 26.9834 -0.0190089 26.6728 0.43769C26.3623 0.894389 26.4807 1.51637 26.9374 1.82693L28.062 0.173073ZM62.9997 41L63.6768 40.2641L62.9997 41ZM95.9997 43.4999L96.6429 44.2656L95.9997 43.4999ZM26.5 38.5L25.8705 37.723H25.8705L26.5 38.5ZM-3.8445e-05 69.5L10.0531 63.8196L0.107149 57.9535L-3.8445e-05 69.5ZM26.9374 1.82693C39.3195 10.2468 45.6042 17.8481 50.04 24.4777C52.3071 27.8663 54.0001 30.8497 55.9058 33.7984C57.7697 36.6825 59.7304 39.3511 62.3227 41.7359L63.6768 40.2641C61.2641 38.0444 59.41 35.5358 57.5855 32.7128C55.8028 29.9544 53.9338 26.7009 51.7022 23.3656C47.1404 16.5475 40.6799 8.75324 28.062 0.173073L26.9374 1.82693ZM62.3227 41.7359C68.7883 47.6843 75.9759 49.501 82.2348 49.237C88.4539 48.9747 93.7967 46.6564 96.6429 44.2656L95.3565 42.7342C92.8839 44.8112 87.9768 46.993 82.1505 47.2388C76.3641 47.4828 69.7112 45.8157 63.6768 40.2641L62.3227 41.7359ZM96.6429 44.2656C100.071 41.3863 102.274 35.4326 102.522 29.3296C102.772 23.1922 101.06 16.5484 96.2212 12.3102C91.3393 8.0343 83.5463 6.43746 72.1584 9.84669C60.7832 13.2521 45.6648 21.6871 25.8705 37.723L27.1295 39.277C46.8351 23.3129 61.7167 15.0604 72.732 11.7627C83.7347 8.46876 90.7229 10.1531 94.9035 13.8147C99.127 17.514 100.759 23.464 100.524 29.2484C100.288 35.0673 98.1788 40.3635 95.3565 42.7342L96.6429 44.2656ZM25.8705 37.723C16.321 45.4593 8.50612 54.7008 3.7652 61.1575L5.3773 62.3412C10.0516 55.9752 17.752 46.874 27.1295 39.277L25.8705 37.723Z" fill="white"/>
            </svg>
      </span>
   </h6>
   <div class="nav-btn-hiro">
      <ul class="list-unstyled">
         @foreach($cuisine as $key=>$name)
         <li><a href="{{ route('search-by-cuisine',$name->id) }}">@if( Session()->get('locale') == 'ara' &&  $name->name_ar!="")
                              {{$name->name_ar}}
                              @elseif(Session::get('locale') == 'fr' && $name->name_fr!="")
                              {{$name->name_fr}}
                              @else
                               {{$name->name}}
                              @endif
          </a></li>
         @endforeach
      </ul>
   </div>
   </div>
</div>

      <!-- restaurant list -->
      <section class="popular-restaurants">
         <div class="container">
            <h2 class="text-center">
               <span><span> {{ __('message.Popular restaurants in') }} @if($countryId==1)
                                                      Kuwait
                                                   @elseif($countryId==2)
                                                      Morocco
                                                   @endif </span>
                <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.202C172.852 17.5591 170.476 23.3131 168.842 25.0988C166.912 18.452 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.0631C74.8429 19.7416 4.00944 32.1424 0 11.2099V7.04323V6.94403C0.148498 13.3924 9.65236 17.4599 21.6807 18.0551C38.3124 18.8488 59.8446 14.4837 70.982 12.1028C90.4352 7.93609 118.204 1.58688 141.964 0.197995C150.28 -0.298037 158.15 -0.0996239 164.833 0.991646C170.921 2.08292 173 6.5472 173 11.4083Z" fill="#FCCC00"/>
               

                  <defs>
                     <clipPath id="clip0">
                        <rect width="173" height="25" fill="white"/>
                     </clipPath>
                  </defs>
               </svg>
            </h2>
            <div class="row">
               @if(count($restaurants)>0)
               @foreach($restaurants as $key=>$detail)
               <div class="col-lg-6 col-xl-4 col-md-6">
                  <div class="card restaurant">
                     <a href="{{ route('restdetails',['id'=>$detail->id]) }}">
                     <div class="card-img">
                       <!--  <div class="hart">
                           <img src="{{ asset('front/imgs/heart.png') }}" alt="">
                        </div> -->
                        @if(!empty($detail->images[0]))
                        <img src="{{  asset('storage').'/'.$detail->images[0]->image }}" alt="" class="w-100 store-cover">
                        @else
                       <img src="{{ asset('front/imgs/placeholder.png') }}" alt="" class="w-100 store-cover">
                       @endif
                    <!--   <img src="{{ asset('front/imgs/item.png') }}" alt="" class="w-100">  -->
                        <div class="card-img-overly">
                           <div class="left"> 
                               <span class="American"><img src="{{ asset('front/imgs/American.png') }}" alt="">    
                                 
                                 @if(isset($detail->getRestaurantCuisine['name']))
                                  @if( Session()->get('locale') == 'ara' &&  $detail->getRestaurantCuisine['name_ar']!="")
                                    {{$detail->getRestaurantCuisine['name_ar']}}
                                    @elseif(Session::get('locale') == 'fr' && $detail->getRestaurantCuisine['name_fr']!="")
                                    {{$detail->getRestaurantCuisine['name_fr']}}
                                    @else
                                     {{$detail->getRestaurantCuisine['name']}}
                                    @endif
                                  
                                 @endif
                                                                 
               
                               </span>
                              </div>

                               <div class="right f-right">
                                 @if($detail->verified == 1)
                                   @if( Session()->get('locale') == 'ara' )
                                    <img src="{{ asset('front/imgs/verified_ara.png') }}" alt="">
                                    @elseif(Session::get('locale') == 'fr' )
                                   <img src="{{ asset('front/imgs/verified_fr.png') }}" alt="">
                                    @else
                                     <img src="{{ asset('front/imgs/Verified.png') }}" alt="">
                                    @endif
                               
                              
                               @endif
                               <span class="Star"><img src="{{ asset('front/imgs/Star.png') }}" alt="">{{$detail->rating}}</span>
                               </div>
                        </div>
                     </div>
                     </a>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-7">
                              @if( Session()->get('locale') == 'ara' &&  $detail->ar_name!="")
                              <h3 class="fifty-chars">{{$detail->ar_name}}</h3>
                              @elseif(Session::get('locale') == 'fr' && $detail->fr_name!="")
                              <h3 class="fifty-chars">{{$detail->fr_name}}</h3>
                              @else
                               <h3 class="fifty-chars">{{$detail->name}}</h3>
                              @endif
                              <p  class="fifty-chars">{{$detail->address}}</p>
                          <!--  @php echo htmlspecialchars_decode($detail->notes) @endphp -->
                           </div>
                           <div class="col-5 text-end">
                           
                  <?php    $today_date = date('Y-m-d'); ?>
                            
                     @if(!empty($detail->getHour) || !empty($detail->holidaydate))
                        @if( isset($detail->getHour->mon_to)  && (!in_array($today_date, $detail->holidaydate)))
                          @if((($detail->getHour->mon_to >= date("H:i:s")) 
                                    && ($detail->getHour->mon_from <= date("H:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->getHour->tue_to >= date("H:i:s")) 
                                    && ($detail->getHour->tue_from <= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->getHour->wed_to >= date("H:i:s")) 
                                    && ($detail->getHour->wed_from <= date("H:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->getHour->thu_to >= date("H:i:s"))
                                    && ($detail->getHour->thu_from <= date("H:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->getHour->fri_to >= date("H:i:s"))
                                    && ($detail->getHour->fri_from <= date("H:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->getHour->sat_to >= date("H:i:s"))
                                    && ($detail->getHour->sat_from <= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->getHour->sun_to >= date("H:i:s"))
                                    && ($detail->getHour->sun_from <= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                ) 
                              <span class="open">   {{ __('message.open') }}</span>    

                           @else
                            <span class="close">         {{ __('message.close') }}</span>
                         @endif
                        @else
                           <span class="close">   {{ __('message.close') }}</span>
                        @endif  
                        @else
                               <span class="close">   {{ __('message.close') }}</span>
                        @endif



                              </span>
                              <span class="doller">{{$detail->expensiveness}}</span>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-7">
                              <h6>{{ __('message.What we provide?') }}</h6>
                                 <ul class="list-unstyled">
                                 @if($detail->takeout == 1)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt=""> {{ __('message.Takeout') }} </li>
                                 @elseif($detail->takeout == 0)
                                 <li class="s-disable"><img src="{{ asset('front/imgs/Takeout.png') }}" alt="">{{ __('message.Takeout') }} </li>
                                 @endif
                                 @if($detail->home_delivery == 1)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> {{ __('message.Delivery') }} </li>
                                 @elseif($detail->home_delivery == 0)
                                 <li class="s-disable"><img src="{{ asset('front/imgs/Delivery.png') }}" alt="">{{ __('message.Delivery') }} </li>
                                 @endif
                              </ul>
                           </div>
                           <div class="col-5 text-end">
                              <a href="{{ route('restdetails',['id'=>$detail->id]) }}" class="btn btn-primary"> {{ __('message.Visit') }}</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            @endforeach
            @else
            <h1 class="text-center">{{ __('message.No Reastuarant Found') }}</h1>
            @endif
            </div>
            <div class="btn-center text-center pt-3">
               <!-- <a href="restaurant-list/{{$countryId}}" class="btn btn-black"> -->
               <a href="restaurant-list" class="btn btn-black">
                  {{ __('message.See All Restaurants') }}
                  <svg class="ms-2" width="15" height="11" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M12.6363 4.81412C11.3716 4.81412 10.1893 4.81412 9.00765 4.81412C6.32339 4.81347 3.63914 4.81154 0.954248 4.81412C0.796313 4.81412 0.632623 4.82185 0.481082 4.8618C0.165852 4.94494 -0.00742817 5.20271 0.000244141 5.53266C0.0079174 5.84327 0.186954 6.08429 0.493871 6.16162C0.63582 6.19706 0.788 6.20415 0.935704 6.20415C4.6865 6.20609 8.43601 6.20609 12.1855 6.20609C12.3109 6.20609 12.4362 6.20609 12.6312 6.20609C12.5148 6.33433 12.4432 6.41875 12.3652 6.49673C11.2961 7.5755 10.2251 8.6517 9.15919 9.7337C9.05688 9.83745 8.95778 9.96183 8.9079 10.0959C8.79664 10.3936 8.92069 10.7223 9.1739 10.8866C9.44437 11.0619 9.78006 11.0355 10.023 10.797C10.4431 10.3859 10.8543 9.96441 11.2686 9.54682C12.4061 8.40037 13.543 7.25393 14.6792 6.10684C15.1038 5.67765 15.107 5.34319 14.6882 4.92109C13.1523 3.37252 11.6133 1.82653 10.0812 0.273456C9.86446 0.0537048 9.6055 -0.0784035 9.3395 0.0511272C9.14448 0.145858 8.96097 0.359165 8.87465 0.56345C8.75892 0.836044 8.93795 1.07126 9.13617 1.27039C10.2072 2.34659 11.2763 3.42537 12.3454 4.50414C12.4247 4.58534 12.5014 4.67041 12.6363 4.81412Z" fill="white"/>
                  </svg>
               </a>
            </div>
         </div>
      </section>
      <!-- /restaurant list -->

      <!-- city -->
      <section class="explore-location">
         <div class="container">
            <h2 class="text-center">
               <span>
                  {{ __('message.Explore by top Locations') }}
                  <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.202C172.852 17.5591 170.476 23.3131 168.842 25.0988C166.912 18.452 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.0631C74.8429 19.7416 4.00944 32.1424 0 11.2099V7.04323V6.94403C0.148498 13.3924 9.65236 17.4599 21.6807 18.0551C38.3124 18.8488 59.8446 14.4837 70.982 12.1028C90.4352 7.93609 118.204 1.58688 141.964 0.197995C150.28 -0.298037 158.15 -0.0996239 164.833 0.991646C170.921 2.08292 173 6.5472 173 11.4083Z" fill="#FCCC00"/>
                  </svg>
               </span>
            </h2>
            <div class="row">
               @foreach($city as $key=>$cities)
               <div class="col-md-4 col-lg-3 col-xl-2">
                  <div class="card border-0">
                     <div class="icon">
                        <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">
                           <img class="card-img-top" src="{{ asset('storage').'/'.$cities->city_image }}" alt="Card image cap">
                        <div class="hover">
                           <div class="hover-c">
                              <div>
                                 <span>@if( Session()->get('locale') == 'ara' &&  $cities->name_ar!="")
                              {{$cities->name_ar}}
                              @elseif(Session::get('locale') == 'fr' && $cities->name_fr!="")
                              {{$cities->name_fr}}
                              @else
                              {{$cities->city_name}}
                              @endif</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">
                     <h4>@if( Session()->get('locale') == 'ara' &&  $cities->name_ar!="")
                              {{$cities->name_ar}}
                              @elseif(Session::get('locale') == 'fr' && $cities->name_fr!="")
                              {{$cities->name_fr}}
                              @else
                              {{$cities->city_name}}
                              @endif

                        </h4></a>
                  </div>
               </div>
               @endforeach
            </div>
         </div>
      </section>
      <!-- /city -->


      <!-- How it Work -->
         @include('restaurant-layout.how-it-work')
      <!-- end of How it Work -->

@endsection