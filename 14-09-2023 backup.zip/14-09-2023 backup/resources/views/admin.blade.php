@extends('layouts.admin')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
            You're logged in!
        </div>
    </div>
@endsection

