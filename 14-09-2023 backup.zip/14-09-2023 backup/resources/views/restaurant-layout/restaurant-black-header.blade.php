   <!-- header -->
   <div class="header  header-inner">
      <div class="container-fluid">
         <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
               <a class="navbar-brand me-5" href="{{ route('home') }}"><img src="{{ asset('front/imgs/r-logo.jpg') }}" alt=""></a>

               <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                  aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
               </button>
               <div class="collapse navbar-collapse" id="navbarNav">
                  <ul class="navbar-nav me-auto">
                     <li class="nav-item">
                        <a class="nav-link {{ (request()->is('restaurant-features')) ? 'active' : '' }}" href="{{ url('restaurant-features') }}">{{ __('message.Features') }}</a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link {{ (request()->is('restaurant-page')) ? 'active' : '' }}" href="{{ url('restaurant-page')}}">{{ __('message.Restaurants') }}</a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link {{ (request()->is('restaurant-price')) ? 'active' : '' }}" href="{{ route('restaurant-price') }}">{{ __('message.Pricing') }}</a>
                     </li>
                  </ul>

               </div>
               <a class="btn btn-outline ms-3 px-3" href="{{ url('restaurant-app-request') }}" tabindex="-1" aria-disabled="true">{{ __('message.Request Demo') }}</a>
               <a class="btn btn-primary ms-3 px-3" href="{{ url('restaurant-owner/login') }}" tabindex="-1" aria-disabled="true">{{ __('message.Get Started') }}</a>
            </div>
         </nav>
      </div>
   </div>
   <!-- end off header -->