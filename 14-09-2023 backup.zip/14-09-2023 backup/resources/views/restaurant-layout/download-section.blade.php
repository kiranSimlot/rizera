   <!-- download section -->
   <section class="download-section">
      <div class="container">
         <h6>{{ __('message.Download the app from here...') }}</h6>
         <ul class="list-unstyled">
            <li><a href=""><img src="{{ asset('front/imgs/google-s.png') }}" alt=""> </a></li>
            <li><a href=""><img src="{{ asset('front/imgs/app-s.png') }}" alt=""> </a></li>
         </ul>
      </div>
   </section>
   <!-- end of download  -->