   <!-- Footer -->
   <div class="footer">
      <div class="container">
         <div class="row">
            <div class="col-md-6 pe-md-5">
               <div class="logo-footer">
                  <a href=""><img src="{{ asset('front/imgs/r-logo.jpg') }}" alt=""></a>
               </div>
               <p class="mb-4 pe-md-5">{{ __('message.Amet minim mollit non deserunt ullamco est aliqua sit dolor do amet sint. Velit
                  officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.') }}</p>
               <h5>{{ __('message.Connect and Share') }}</h5>
               <ul class="list-unstyled socal">
                  <li>
                     <a href="https://www.facebook.com/" target="_blank">
                        <svg width="8" height="17" viewBox="0 0 8 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path
                              d="M7.57281 8.35415H5.34053V16.3037H2.03395V8.35415H0.464355V5.55111H2.03395V3.72082C2.02572 3.63987 2.0216 3.5452 2.0216 3.44916C2.0216 1.73688 3.41009 0.348389 5.12238 0.348389C5.20882 0.348389 5.29388 0.352504 5.37895 0.359364L5.36797 0.357993H7.81566V3.16104H6.04026C6.02929 3.16104 6.01831 3.15967 6.00596 3.15967C5.63414 3.15967 5.33367 3.46014 5.33367 3.83196C5.33367 3.86489 5.33642 3.89782 5.34053 3.92937V3.92526V5.57854H7.86231L7.57281 8.35415Z"
                              fill="#141414" />
                        </svg>
                     </a>
                  </li>
                  <li>
                     <a href="https://www.instagram.com/" target="_blank">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path
                              d="M11.1666 0.265776H4.75783C4.75509 0.265776 4.75234 0.265776 4.74823 0.265776C2.32523 0.265776 0.359121 2.22503 0.348145 4.64528V11.054C0.348145 13.4893 2.32249 15.4637 4.75783 15.4637H11.1666C13.5896 15.4582 15.5515 13.4962 15.557 11.0732V4.64528C15.5461 2.2264 13.5854 0.269892 11.1666 0.264404V0.265776ZM7.96288 11.3065C6.064 11.3065 4.52459 9.76705 4.52459 7.86816C4.52459 5.96928 6.064 4.42987 7.96288 4.42987C9.86176 4.42987 11.4012 5.96928 11.4012 7.86816C11.4012 9.76705 9.86176 11.3065 7.96288 11.3065ZM11.6989 5.02944C11.183 5.02807 10.7659 4.61098 10.7659 4.0951C10.7659 3.57922 11.1844 3.16075 11.7003 3.16075C12.2162 3.16075 12.6346 3.57922 12.6346 4.0951C12.6346 4.11156 12.6346 4.12803 12.6333 4.14449V4.14174C12.6086 4.63705 12.1997 5.02944 11.7003 5.02944C11.6907 5.02944 11.6797 5.02944 11.6701 5.02944H11.6715H11.6989Z"
                              fill="#141414" />
                        </svg>
                     </a>
                  </li>
                  <li>
                     <a href="https://in.pinterest.com/" target="_blank">
                        <svg width="11" height="15" viewBox="0 0 11 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path
                              d="M6.2723 10.5617C5.5657 10.4368 4.94692 10.1281 4.44613 9.68907L4.45025 9.69318C4.08529 11.5619 3.65584 13.3647 2.35791 14.2991C1.96551 11.496 2.94651 9.3488 3.40476 7.08771C2.61997 5.78017 3.49806 3.13628 5.14175 3.78113C7.16823 4.58513 3.38556 8.66691 5.92654 9.17181C8.46753 9.67672 9.66257 4.58514 8.00928 2.91264C5.63705 0.511595 1.10525 2.86599 1.66641 6.30428C1.79675 7.14533 2.67485 7.40602 2.01216 8.56538C0.498816 8.22923 0.0405602 7.03283 0.0968132 5.43579C0.305361 2.9634 2.2454 1.00415 4.69035 0.766791L4.71093 0.765418C7.51398 0.447109 10.2498 1.81227 10.6148 4.50144C11.0346 7.53773 9.32505 10.8169 6.27092 10.5823L6.2723 10.5617Z"
                              fill="#141414" />
                        </svg>
                     </a>
                  </li>
                <!--   <li>
                     <a href="youtube.com" target="_blank">
                        <svg width="19" height="13" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path
                              d="M18.1279 3.28017C18.1279 1.86698 16.9823 0.719971 15.5677 0.719971H3.53643C2.12325 0.719971 0.976234 1.86561 0.976234 3.28017V10.165C0.976234 11.5782 2.12188 12.7252 3.53643 12.7252H15.5677C16.9809 12.7252 18.1279 11.5795 18.1279 10.165V3.28017ZM7.85282 9.62304V3.18687L12.7564 6.40976L7.85282 9.62304Z"
                              fill="#141414" />
                        </svg>
                     </a>
                  </li> -->
               </ul>
            </div>
            <div class="col-md-3">
               <h3>{{ __('message.Company') }}</h3>
               <ul class="list-unstyled">
                     <li><a href="{{ url('restaurant-page')}}">{{ __('message.About us')}}</a></li>
                  <li><a href="{{ route('contact-us') }}">{{ __('message.Contact us') }} </a></li>
                  <li><a href="{{ route('privacy-policy') }}">{{ __('message.Privacy policy') }} </a></li>
                  <li><a href="{{ route('terms-conditions') }}">{{ __('message.Terms of service') }} </a></li>
                  <li><a href="{{ route('restaurant-price') }}">{{ __('message.Pricing') }} </a></li>
               </ul>
            </div>
            <div class="col-md-3"> 
               @php
                  $common_setting = DB::table('common_settings')->first();
               @endphp
               <h3>{{ __('message.Support') }}</h3>
               <h5>{{ __('message.Address') }}</h5>
               <address><?php echo $common_setting->address; ?></address>
               <h5>{{ __('message.Helpline') }}</h5>
               <a href="" class="call"> <?php echo $common_setting->helpline; ?> </a>
               <h5>{{ __('message.Timing') }}</h5>
               <div class="timeing">
			      <?php echo $common_setting->timing; ?> 
               </div>
            </div>
         </div>
      </div>
      <div class="copy-right text-center">
         <p>{{ __('message.All Right Reserved') }} 2021-Rizera</p>
      </div>
   </div>
   
   <!-- end of footer  -->
   
      <script src="{{ asset('front/js/jquery.min.js') }}" ></script>
      <script src="{{ asset('front/assets/bootstrap/js/bootstrap.bundle.min.js') }}" ></script>
      <script type="text/javascript" src="{{ asset('front/assets/slick/slick.min.js') }}"></script>
      <script type="text/javascript" src="{{ asset('front/js/custom.js') }}"></script> 
      <script type="text/javascript" src="{{ asset('admin/js/owl.carousel.min.js') }}"></script> 

      