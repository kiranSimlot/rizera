@extends('main')


@section('content')


      <section class="popular-restaurants">
         <div class="container">
            <h2 class="text-center">
               <span><span> {{ __('message.Popular restaurants in Morocco') }} </span>
               <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0)">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.2019C172.852 17.559 170.476 23.313 168.842 25.0987C166.912 18.4519 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.063C74.8429 19.7416 4.00944 32.1424 0 11.2098V7.04317V6.94397C0.148498 13.3924 9.65236 17.4598 21.6807 18.0551C38.3124 18.8487 59.8446 14.4836 70.982 12.1027C90.4352 7.93603 118.204 1.58682 141.964 0.197934C150.28 -0.298098 158.15 -0.0996849 164.833 0.991585C170.921 2.08285 173 6.54714 173 11.4083Z" fill="#FCCC00"/>
                  </g>
                  <defs>
                     <clipPath id="clip0">
                        <rect width="173" height="25" fill="white"/>
                     </clipPath>
                  </defs>
               </svg>
            </h2>
            <div class="row">
               @foreach($restaurants as $key=>$detail)
               <div class="col-lg-6 col-xl-4 col-md-6">
                  <div class="card">
                     <div class="card-img">
                        <div class="hart">
                           <img src="{{ asset('front/imgs/hart.svg') }}" alt="">
                        </div>
                        <img src="{{ asset('front/imgs/item.png') }}" alt="" class="w-100">
                        <div class="card-img-overly">
                           <div class="row">
                              <div class="col-6">
                                 <span class="American"><img src="{{ asset('front/imgs/American.png') }}" alt="">    
                                 @foreach($detail->getCuisine as $cuisine)
                                {{$cuisine->Cuisine['name']}}
                                @endforeach</span>
                              </div>
                                 <div class="col-6 text-end">
                                 @if($detail->verified == 1)
                                 <span class="Verified"><img src="{{ asset('front/imgs/Verified.png') }}" alt="">Verified</span>
                                 @elseif($detail->verified == 0)
                                 <span class="Verified"><img src="{{ asset('front/imgs/Verified.png') }}" alt="">Not Verified</span>
                                 @endif
                                 <span class="Star"><img src="{{ asset('front/imgs/Star.png') }}" alt="">{{$detail->rating}}</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-7">
                              <h3>{{$detail->name}}</h3>
                              <p>Metropolitian Hotel, Umm al Sheif</p>
                           </div>
                           <div class="col-5 text-end">
                             

                              {{-- open/close --}}

                           @if( isset($detail->getHour->mon_to) )
                              @if((($detail->getHour->mon_to <= date("H:i:s")) 
                                    && ($detail->getHour->mon_from >= date("H:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->getHour->tue_to <= date("H:i:s")) 
                                    && ($detail->getHour->tue_from >= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->getHour->wed_to <= date("H:i:s")) 
                                    && ($detail->getHour->wed_from >= date("H:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->getHour->thu_to <= date("H:i:s"))
                                    && ($detail->getHour->thu_from >= date("H:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->getHour->fri_to <= date("H:i:s"))
                                    && ($detail->getHour->fri_from >= date("H:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->getHour->sat_to <= date("H:i:s"))
                                    && ($detail->getHour->sat_from >= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->getHour->sun_to <= date("H:i:s"))
                                    && ($detail->getHour->sun_from >= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                )
                                 <span class="open"> 
                               {{ __('message.open') }} 
                                </span>
                                @else
                                <span class="close">
                               {{ __('message.close') }}
                                </span>
                              @endif
                           @endif
 
                              <span class="doller">$$</span>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-7">
                              <h6>What we provide?</h6>
                                 <ul class="list-unstyled">
                                 @if($detail->takeout == 1)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt=""> Takeout </li>
                                 @elseif($detail->takeout == 0)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt="">No Takeout </li>
                                 @endif
                                 @if($detail->home_delivery == 1)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> Delivery </li>
                                 @elseif($detail->home_delivery == 0)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> No Delivery </li>
                                 @endif
                              </ul>
                           </div>
                           <div class="col-5 text-end">
                              <a href="" class="btn btn-primary"> Reserve Now</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            @endforeach
            </div>
            <div class="btn-center text-center pt-3">
               <a href="restaurant-list/{{$countryId}}" class="btn btn-black">
                  {{ __('message.See all restaurants') }}
                  <svg class="ms-2" width="15" height="11" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M12.6363 4.81412C11.3716 4.81412 10.1893 4.81412 9.00765 4.81412C6.32339 4.81347 3.63914 4.81154 0.954248 4.81412C0.796313 4.81412 0.632623 4.82185 0.481082 4.8618C0.165852 4.94494 -0.00742817 5.20271 0.000244141 5.53266C0.0079174 5.84327 0.186954 6.08429 0.493871 6.16162C0.63582 6.19706 0.788 6.20415 0.935704 6.20415C4.6865 6.20609 8.43601 6.20609 12.1855 6.20609C12.3109 6.20609 12.4362 6.20609 12.6312 6.20609C12.5148 6.33433 12.4432 6.41875 12.3652 6.49673C11.2961 7.5755 10.2251 8.6517 9.15919 9.7337C9.05688 9.83745 8.95778 9.96183 8.9079 10.0959C8.79664 10.3936 8.92069 10.7223 9.1739 10.8866C9.44437 11.0619 9.78006 11.0355 10.023 10.797C10.4431 10.3859 10.8543 9.96441 11.2686 9.54682C12.4061 8.40037 13.543 7.25393 14.6792 6.10684C15.1038 5.67765 15.107 5.34319 14.6882 4.92109C13.1523 3.37252 11.6133 1.82653 10.0812 0.273456C9.86446 0.0537048 9.6055 -0.0784035 9.3395 0.0511272C9.14448 0.145858 8.96097 0.359165 8.87465 0.56345C8.75892 0.836044 8.93795 1.07126 9.13617 1.27039C10.2072 2.34659 11.2763 3.42537 12.3454 4.50414C12.4247 4.58534 12.5014 4.67041 12.6363 4.81412Z" fill="white"/>
                  </svg>
               </a>
            </div>
         </div>
      </section>





      @endsection