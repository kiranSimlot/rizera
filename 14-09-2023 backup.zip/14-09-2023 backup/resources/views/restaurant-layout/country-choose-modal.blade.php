      <div class="modal fade" id="selesct-modal" tabindex="-1" role="dialog" aria-labelledby="selesct-modalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
         <div class="modal-dialog">
           <div class="modal-content select_location">
             
             <div class="modal-body p-0">
              <div class="alert alert-danger" role="alert" style="display: none;" id="errordiv">
                Please select any country for further process!
              </div>
             <h3>Select your location</h3>

             <ul class="list-unstyled">
                <li>
                   <div class="form-group check">
                      <input type="radio" name="country" value=1 id="countryId" class="countryId" />
                      <label><span><span class="icon"><img src="{{ asset('front/imgs/location1.svg') }}"></span> Kuwait</span><span class="check-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="12" fill="#FCCC00"/>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.6443 7.46429C18.1346 8.06354 18.1157 9.01303 17.602 9.58504L11.3163 16.585C10.8195 17.1383 10.0376 17.1383 9.54078 16.585L6.39796 13.085C5.88432 12.513 5.8654 11.5635 6.35569 10.9643C6.84599 10.365 7.65984 10.343 8.17348 10.915L10.4285 13.4263L15.8265 7.41497C16.3402 6.84296 17.154 6.86504 17.6443 7.46429Z" fill="#141414"/>
                        </svg>
                        </span> </label>
                   </div>
                </li>
                <li>
                  <div class="form-group check">
                     <input type="radio" name="country" value=2 id="countryId" class="countryId" />
                     <label><span><span class="icon"><img src="{{ asset('front/imgs/location1.svg') }}"></span> Morocco</span><span class="check-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <circle cx="12" cy="12" r="12" fill="#FCCC00"/>
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M17.6443 7.46429C18.1346 8.06354 18.1157 9.01303 17.602 9.58504L11.3163 16.585C10.8195 17.1383 10.0376 17.1383 9.54078 16.585L6.39796 13.085C5.88432 12.513 5.8654 11.5635 6.35569 10.9643C6.84599 10.365 7.65984 10.343 8.17348 10.915L10.4285 13.4263L15.8265 7.41497C16.3402 6.84296 17.154 6.86504 17.6443 7.46429Z" fill="#141414"/>
                       </svg>
                       </span> </label>
                  </div>
               </li>
             </ul>
               
             <button class="btn btn-black w-100 py-3" id="countrySelectButton" class="countrySelectButton">Continue</button>
             </div>
             
           </div>
         </div>
       </div>