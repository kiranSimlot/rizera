<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="{{ asset('front/assets/bootstrap/css/bootstrap.min.css') }}">
   <!-- Custom CSS -->
   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" href="{{ asset('front/imgs/favicon.jpg') }}" type="image/x-icon">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
   <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/slick/slick.css') }}" />
   <link rel="stylesheet" href="{{ asset('front/css/style.css') }}">
   @if(app()->getLocale() == 'ara')
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css">
        <link rel="stylesheet" href="{{ asset('front/css/style-rtl.css') }}" >
        @endif
   <link rel="stylesheet" href="{{ asset('front/css/responsive.css') }}">
   <title>Rizera</title>
</head>

<body>
   <script src="{{ asset('front/js/jquery.min.js') }}"></script>
   <script src="{{ asset('front/assets/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
   <script type="text/javascript" src="{{ asset('front/assets/slick/slick.min.js') }}"></script>
   <script type="text/javascript" src="{{ asset('front/js/custom.js') }}"></script>
   <!-- page content -->
      @yield('content')
   <!-- /page content -->

   

</div>
  

</body>

</html>