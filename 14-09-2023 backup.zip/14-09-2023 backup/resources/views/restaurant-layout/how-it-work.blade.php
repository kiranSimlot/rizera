      <section class="how-it-work">
         <div class="container">
            <h2 class="text-center">
               <span>
                  {{ __('message.How it Work') }}
                  <svg width="111" height="25" viewBox="0 0 111 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M111 11.4083V12.202C110.905 17.5591 109.38 23.3131 108.332 25.0988C107.094 18.452 99.5665 16.6662 90.9914 16.4678C87.1803 16.4678 83.2738 16.6662 79.5579 17.0631C48.0206 19.7416 2.57253 32.1424 0 11.2099V7.04323V6.94403C0.095279 13.3924 6.19313 17.4599 13.9107 18.0551C24.582 18.8488 38.3974 14.4837 45.5433 12.1028C58.0249 7.93609 75.8421 1.58688 91.0867 0.197995C96.4223 -0.298037 101.472 -0.0996239 105.76 0.991646C109.666 2.08292 111 6.5472 111 11.4083Z" fill="#FCCC00"/>
                  </svg>
               </span>
            </h2>
            <div class="row">
               <div class="col-md-4">
                  <div class="card">
                     <div class="icon">
                        <img src="{{ asset('front/imgs/Search-Location.svg') }}" alt="">
                     </div>
                     <h3>{{ __('message.Find Restaurant') }}</h3>
                     <p>{{ __('message.Amet minim mollit non deserunt est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit.') }}</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="card" style="background: #2BD2FF;">
                     <div class="icon">
                        <img src="{{ asset('front/imgs/Shop.svg') }}" alt="">
                     </div>
                     <h3>{{ __('message.Review Listings') }}</h3>
                     <p>{{ __('message.Amet minim mollit non deserunt est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit.') }}</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="card"  style="background: #FCCC00;">
                     <div class="icon">
                        <img src="{{ asset('front/imgs/Calender.svg') }}" alt="">
                     </div>
                     <h3>{{ __('message.Make a Reservation') }}</h3>
                     <p>{{ __('message.Amet minim mollit non deserunt est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit.') }}</p>
                  </div>
               </div>
            </div>
         </div>
      </section>