    
       <!-- header -->
      <html lang="{{ app()->getLocale() }}">
      <div class="header">
         <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
               <div class="container-fluid">
                  <a class="navbar-brand" href="{{ route('home') }}"><img src="{{ asset('front/imgs/r-logo.jpg') }}" alt=""></a>


                  <?php if(Request::segment(1)!='restaurantdetails') {?>
                   
                  <div class="dropdown lang hh" id="countryselect" >
                     <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
          
                        @if($countryId==1)
                          <img src="{{ asset('front/imgs/kuwait.png') }}" />
                        @elseif($countryId==2)
                          <img src="{{ asset('front/imgs/morocco.png') }}" />
                        @endif            
                        @if($countryId==1)
                           <span>Kuwait</span>
                        @elseif($countryId==2)
                           <span>Morocco</span>
                        @elseif(empty($countryId))
                           Choose your country
                        @endif
                        <svg class="arrow" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5.5914 4.06061C5.7252 4.15395 5.8746 4.21728 6.0306 4.24595C6.18241 4.24328 6.32821 4.17728 6.43801 4.06061L9.87725 0.382564C10.1116 0.137964 10.4207 0.00124584 10.7422 8.47257e-06C11.0637 -0.00122889 11.3736 0.133106 11.6095 0.375897L11.6275 0.394564C11.7446 0.516318 11.8381 0.663431 11.9022 0.826844C11.9663 0.990258 11.9995 1.16651 12 1.34476C12.0004 1.523 11.9681 1.69946 11.9048 1.86327C11.8416 2.02708 11.7488 2.17478 11.6323 2.29726L6.46441 7.80866C6.34622 7.9301 6.19158 7.99831 6.0306 8C5.86582 7.97067 5.70783 7.90566 5.5656 7.80866L0.366533 2.29726C0.250139 2.17459 0.157575 2.02676 0.0945406 1.86285C0.0315063 1.69894 -0.000664114 1.52243 1.03909e-05 1.34418C0.000684896 1.16594 0.03419 0.989732 0.0984627 0.826418C0.162735 0.663103 0.256415 0.516135 0.373733 0.394564L0.395333 0.375897C0.632717 0.1331 0.943877 -0.00111428 1.26652 0.00012191C1.58917 0.0013581 1.89948 0.137954 2.13536 0.382564L5.5914 4.06061Z" fill="#484848"/>
                         </svg>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li>
                           <a class="dropdown-item choose-country " href="javascript:void(0);"   country-id="1">
         
                              <img src="{{ asset('front/imgs/kuwait.png') }}" />
                              <span>Kuwait</span>
                           </a>
                        </li>
                        <li>
                           <a class="dropdown-item  choose-country " href="javascript:void(0);"  country-id="2">
                         
                              <img src="{{ asset('front/imgs/morocco.png') }}" />
                              <span>Morocco</span>
                           </a>
                        </li>
                     </ul>
                  </div>
                  <?php  } ?>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNav">
                     <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                           <a class="nav-link language" href="{{ url('locale/fr') }}">{{ __('message.French') }}</a>
                           <!-- <a href="{{ url('/restaurant-owner/restaurant/booking/'.session('id_restaurant')) }}"> -->
                        </li>
                        <li class="nav-item">
                           <a class="nav-link language" href="{{ url('locale/ara') }}">{{ __('message.Arabic') }}</a>
                        </li>
                         <li class="nav-item">
                           <a class="nav-link language" href="{{ url('locale/en') }}">{{ __('message.English') }}</a>
                        </li>
                     </ul>
                  </div>
                  <a class="btn btn-primary ms-3 px-3" href="{{ route('restaurant.home') }}" tabindex="-1" aria-disabled="true">{{ __('message.For Restaurant') }}</a>
               </div>
            </nav>
         </div>
      </div>
      <!-- end off header -->