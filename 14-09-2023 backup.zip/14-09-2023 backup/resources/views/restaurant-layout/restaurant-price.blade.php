
@extends('restaurant-layout.restaurant-layout')


   <!-- header content -->
   <!-- /header content -->
   @section('content')
      @include('restaurant-layout.restaurant-black-header')
        <style type="text/css">
               .text-block2.active,.text-block.active {
    display: block;
}

.text-block.deactive ,.text-block2.deactive {
    display: none;
}
            </style>
   <!-- pricing -->
   <section class="pricing-table">
      <div class="container">
         <div class="text-center">
              @if(session()->has('message'))
                      <div class="alert alert-success">
                          {{ session()->get('message') }}
                      </div>
                  @endif
                     @if(session()->has('error'))
                      <div class="alert alert-danger">
                          {{ session()->get('error') }}
                      </div>
                  @endif
            <h2>{{ __('message.Start you free trial') }}</h2>
            <h6>{{ __('message.Setup your') }} <b>{{ __('message.restaurant') }}</b> {{ __('message.today.') }}<b> {{ __('message.No card') }}</b> {{ __('message.required.') }}</h6>     
            <div class="form_redaio switch_price_price">
            <label class="form-check-label month" for="switch_price">{{ __('message.Pay Monthly') }}</label>
            <div class="form-check form-switch">
               <input class="form-check-input" type="checkbox" id="switch_price" checked>
               <label class="form-check-label year" for="switch_price">{{ __('message.Pay Yearly') }}</label>
             </div>
             <svg width="70" height="33" viewBox="0 0 70 33" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M0.96967 26.4697C0.676777 26.7626 0.676777 27.2374 0.96967 27.5303L5.74264 32.3033C6.03553 32.5962 6.51041 32.5962 6.8033 32.3033C7.09619 32.0104 7.09619 31.5355 6.8033 31.2426L2.56066 27L6.8033 22.7574C7.09619 22.4645 7.09619 21.9896 6.8033 21.6967C6.51041 21.4038 6.03553 21.4038 5.74264 21.6967L0.96967 26.4697ZM23.2482 16.0516C23.2767 15.6384 22.9648 15.2803 22.5516 15.2518C22.1384 15.2233 21.7803 15.5352 21.7518 15.9484L23.2482 16.0516ZM1.5 27.75C4.35836 27.75 7.0882 27.7878 9.5586 27.6615C12.0298 27.5352 14.304 27.2429 16.2604 26.5579C18.2314 25.8677 19.8959 24.7728 21.1119 23.044C22.3217 21.324 23.042 19.0413 23.2482 16.0516L21.7518 15.9484C21.558 18.7587 20.8908 20.751 19.885 22.181C18.8854 23.6022 17.5061 24.5323 15.7646 25.1421C14.0085 25.7571 11.9014 26.0398 9.48202 26.1635C7.06179 26.2872 4.39164 26.25 1.5 26.25V27.75Z" fill="#179A6B"/>
               <path d="M12.2 11.168C14.706 11.168 15.812 9.824 15.812 8.27C15.812 4.798 10.38 5.876 10.38 4.126C10.38 3.44 10.996 2.964 11.948 2.964C12.928 2.964 13.922 3.3 14.664 4.042L15.588 2.824C14.734 1.984 13.544 1.508 12.102 1.508C10.044 1.508 8.7 2.698 8.7 4.252C8.7 7.682 14.132 6.464 14.132 8.424C14.132 9.054 13.614 9.712 12.27 9.712C10.968 9.712 9.946 9.096 9.316 8.41L8.392 9.684C9.232 10.552 10.478 11.168 12.2 11.168ZM22.8785 11V6.506C22.8785 4.7 21.5625 4.07 20.0505 4.07C18.9725 4.07 17.9925 4.406 17.2085 5.162L17.8245 6.184C18.3985 5.596 19.0705 5.316 19.8265 5.316C20.7505 5.316 21.4085 5.792 21.4085 6.576V7.584C20.9045 7.01 20.1345 6.716 19.2105 6.716C18.1045 6.716 16.8725 7.36 16.8725 8.928C16.8725 10.412 18.1185 11.168 19.2105 11.168C20.1065 11.168 20.9045 10.846 21.4085 10.258V11H22.8785ZM19.7985 10.16C18.9725 10.16 18.3425 9.684 18.3425 8.942C18.3425 8.214 18.9725 7.724 19.7985 7.724C20.4285 7.724 21.0585 7.962 21.4085 8.424V9.46C21.0585 9.922 20.4285 10.16 19.7985 10.16ZM28.144 11L30.902 4.238H29.334L27.36 9.306L25.386 4.238H23.804L26.562 11H28.144ZM34.961 11.168C36.025 11.168 37.019 10.818 37.705 10.174L37.033 9.208C36.543 9.698 35.773 9.964 35.101 9.964C33.827 9.964 33.071 9.11 32.959 8.102H38.167V7.738C38.167 5.61 36.879 4.07 34.849 4.07C32.847 4.07 31.419 5.652 31.419 7.612C31.419 9.754 32.917 11.168 34.961 11.168ZM36.753 7.052H32.945C33.001 6.24 33.589 5.274 34.835 5.274C36.165 5.274 36.711 6.254 36.753 7.052ZM46.1394 11.168C48.3094 11.168 49.6674 10.034 49.6674 8.438C49.6674 6.996 48.3934 6.268 47.4974 6.17C48.4494 6.016 49.5134 5.288 49.5134 4.028C49.5134 2.474 48.1694 1.522 46.1534 1.522C44.5994 1.522 43.4654 2.138 42.7374 2.992L43.5774 4.014C44.2494 3.328 45.0334 2.978 45.9994 2.978C47.0354 2.978 47.8894 3.426 47.8894 4.28C47.8894 5.134 47.0634 5.512 45.9574 5.512C45.5934 5.512 45.0474 5.512 44.8934 5.498V6.982C45.0334 6.968 45.5654 6.954 45.9574 6.954C47.3014 6.954 48.0294 7.36 48.0294 8.284C48.0294 9.138 47.3154 9.712 46.0834 9.712C45.0894 9.712 44.1094 9.278 43.5074 8.578L42.6114 9.656C43.2554 10.496 44.4874 11.168 46.1394 11.168ZM54.6405 11.168C57.2585 11.168 58.3645 8.676 58.3645 6.338C58.3645 3.986 57.2585 1.522 54.6405 1.522C52.0085 1.522 50.9025 3.986 50.9025 6.338C50.9025 8.676 52.0085 11.168 54.6405 11.168ZM54.6405 9.712C53.1145 9.712 52.5685 8.116 52.5685 6.338C52.5685 4.546 53.1145 2.978 54.6405 2.978C56.1665 2.978 56.6985 4.546 56.6985 6.338C56.6985 8.116 56.1525 9.712 54.6405 9.712ZM61.6711 6.156C63.0711 6.156 63.9951 5.148 63.9951 3.846C63.9951 2.53 63.0711 1.522 61.6711 1.522C60.2851 1.522 59.3471 2.53 59.3471 3.846C59.3471 5.148 60.2851 6.156 61.6711 6.156ZM61.6991 11L67.6771 1.662H66.7251L60.7611 11H61.6991ZM66.6971 11.168C68.0831 11.168 69.0211 10.16 69.0211 8.858C69.0211 7.542 68.0831 6.534 66.6971 6.534C65.3111 6.534 64.3731 7.542 64.3731 8.858C64.3731 10.16 65.3111 11.168 66.6971 11.168ZM61.6711 5.218C60.9571 5.218 60.4391 4.658 60.4391 3.846C60.4391 3.02 60.9571 2.446 61.6711 2.446C62.3991 2.446 62.9171 3.02 62.9171 3.846C62.9171 4.658 62.3991 5.218 61.6711 5.218ZM66.6971 10.23C65.9691 10.23 65.4511 9.67 65.4511 8.858C65.4511 8.032 65.9691 7.458 66.6971 7.458C67.4251 7.458 67.9431 8.032 67.9431 8.858C67.9431 9.67 67.4251 10.23 66.6971 10.23Z" fill="#179A6B"/>
               </svg>
               
            </div>
         </div>

         <div class="row align-items-center justify-content-center">



            @foreach($plan as $key=>$detail)
            <div class="col-md-4 col-lg-4">
               @if($detail->id%2!=0)
               <div class="card pricing active">
            
               @else
                  <div class="card pricing ">
               @endif

                 
                     @if($detail->id%2!=0)
                         <div class="card-header">
                     <span>most popular</span>
                     <h3>{{$detail->name}}</h3>
                     <h4 class="text-block active">${{$detail->yearly_amount}}<sub class="text-white">/year</sub></h4>
                     <h4 class="text-block2 deactive">${{$detail->monthly_amount}}<sub class="text-white">/month</sub></h4>
                       
                          
                     @else
                     <div class="card-header">
                 
                     <h3>{{$detail->name}}</h3>
                     <h4 class="text-block active">${{$detail->yearly_amount}}<sub>/year</sub></h4>
                     <h4 class="text-block2 deactive">${{$detail->monthly_amount}}<sub>/month</sub></h4>
                          
                     @endif
                     
                  
                    @if($detail->monthly_amount == null ||$detail->yearly_amount==null)
                       <a href="{{ route('owner.register') }}"  class="btn btn-outline w-100">Speak to us</a>
                     @else

                    @if(Auth::check())
                       <form name="subscription_form" id="subscription_form" method="GET" action="{{ url('buy-subscription') }}">
                           {{ csrf_field() }}
                           <input type="hidden" name="type" id="type" value="year">
                           <input type="hidden" name="auth_id" id="auth_id" value="{{Auth::user()->id}}">
                           <input type="hidden" name="plan_id" id="plan_id" value="{{$detail->id}}">
                         
                        </form>
                       <a href="{{ url('restaurant-owner/login') }}" class="btn btn-outline w-100 subscription">Get Started</a> 
                  
                    @else
                     @php request()->session()->put('url.intended', url('/restaurant-price'));@endphp
                      <a href="{{ route('owner.login')  }}" class="btn btn-outline w-100">Get Started</a> 
                    @endif
                  

                    
                     @endif
                    
                  </div>
                  <div class="card-body">
                     <!-- <h5>Online Reservations</h5> -->
                     @php echo htmlspecialchars_decode($detail->description) @endphp

                  </div>
                  <div class="card-footer">
                     
                 
                   @if($detail->monthly_amount == null)
                       <a href="{{ route('owner.register') }}"  class="btn btn-outline w-100">Speak to us</a>
                     @else

                     @if(Auth::check()) 

                       <form name="subscription_form" id="subscription_form" method="GET" action="{{ url('buy-subscription') }}">
                           {{ csrf_field() }}
                          <input type="hidden" name="type" id="type" value="year">
                           <input type="hidden" name="auth_id" id="auth_id" value="{{Auth::user()->id}}">
                           <input type="hidden" name="plan_id" id="plan_id" value="{{$detail->id}}">
                         
                        </form>
                       <a href="" class="btn btn-outline w-100 subscription">Get Started</a> 
                     @else
                      @php request()->session()->put('url.intended', url('/restaurant-price'));@endphp
                       <a href="{{ route('owner.login') }}" class="btn btn-outline w-100">Get Started</a> 
                       <!-- <button onclick="function(){ redirectlogin, 'restaurant-price'}" href="{{ route('owner.login') }}" class="btn btn-outline w-100">Get Started</a>  -->
                     @endif
                    

                    
                     @endif
                    </div> 
               </div>
            </div>
            @endforeach
          
          
         </div>
      </div>
   </section>
   <section class="includents">
      <div class="container">
         <h3>{{ __('message.All plans includents') }}</h3>
         <div class="line">
            <svg width="259" height="7" viewBox="0 0 259 7" fill="none" xmlns="http://www.w3.org/2000/svg">
               <rect x="132" y="3" width="127" height="1" fill="url(#paint0_linear)"/>
               <rect y="3" width="127" height="1" fill="url(#paint1_linear)"/>
               <circle cx="129.5" cy="3.5" r="3" stroke="#C4C4C4"/>
               <defs>
               <linearGradient id="paint0_linear" x1="130.5" y1="3.99995" x2="259" y2="3.99989" gradientUnits="userSpaceOnUse">
               <stop stop-color="#C4C4C4"/>
               <stop offset="1" stop-color="#C4C4C4" stop-opacity="0"/>
               </linearGradient>
               <linearGradient id="paint1_linear" x1="-1.5" y1="3.99995" x2="127" y2="3.99989" gradientUnits="userSpaceOnUse">
               <stop stop-color="#C4C4C4" stop-opacity="0"/>
               <stop offset="1" stop-color="#C4C4C4"/>
               </linearGradient>
               </defs>
               </svg>
               
         </div>
         <div class="row">
            <div class="col-md-4">
               <div class="item">
                  <p><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <circle cx="25" cy="25" r="24" stroke="#179A6B" stroke-width="2"/>
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M34.6522 19.336C35.1159 19.784 35.1159 20.5103 34.6522 20.9582L23.5688 31.664C23.1051 32.112 22.3533 32.112 21.8895 31.6641L16.3478 26.3114C15.8841 25.8634 15.884 25.1371 16.3478 24.6892C16.8115 24.2412 17.5634 24.2411 18.0272 24.6891L22.7291 29.2307L32.9728 19.336C33.4366 18.888 34.1885 18.888 34.6522 19.336Z" fill="#179A6B"/>
                     </svg>
                      {{ __('message.24/7 Phone & chat support') }}</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="item">
                  <p><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <circle cx="25" cy="25" r="24" stroke="#179A6B" stroke-width="2"/>
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M34.6522 19.336C35.1159 19.784 35.1159 20.5103 34.6522 20.9582L23.5688 31.664C23.1051 32.112 22.3533 32.112 21.8895 31.6641L16.3478 26.3114C15.8841 25.8634 15.884 25.1371 16.3478 24.6892C16.8115 24.2412 17.5634 24.2411 18.0272 24.6891L22.7291 29.2307L32.9728 19.336C33.4366 18.888 34.1885 18.888 34.6522 19.336Z" fill="#179A6B"/>
                     </svg>
                     {{ __('message.Onboarding & training') }}</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="item">
                  <p><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <circle cx="25" cy="25" r="24" stroke="#179A6B" stroke-width="2"/>
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M34.6522 19.336C35.1159 19.784 35.1159 20.5103 34.6522 20.9582L23.5688 31.664C23.1051 32.112 22.3533 32.112 21.8895 31.6641L16.3478 26.3114C15.8841 25.8634 15.884 25.1371 16.3478 24.6892C16.8115 24.2412 17.5634 24.2411 18.0272 24.6891L22.7291 29.2307L32.9728 19.336C33.4366 18.888 34.1885 18.888 34.6522 19.336Z" fill="#179A6B"/>
                     </svg>
                     {{ __('message.Knowledge center') }}</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="item">
                  <p><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <circle cx="25" cy="25" r="24" stroke="#179A6B" stroke-width="2"/>
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M34.6522 19.336C35.1159 19.784 35.1159 20.5103 34.6522 20.9582L23.5688 31.664C23.1051 32.112 22.3533 32.112 21.8895 31.6641L16.3478 26.3114C15.8841 25.8634 15.884 25.1371 16.3478 24.6892C16.8115 24.2412 17.5634 24.2411 18.0272 24.6891L22.7291 29.2307L32.9728 19.336C33.4366 18.888 34.1885 18.888 34.6522 19.336Z" fill="#179A6B"/>
                     </svg>
                     {{ __('message.Website & socials media bookings') }}</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="item">
                  <p><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <circle cx="25" cy="25" r="24" stroke="#179A6B" stroke-width="2"/>
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M34.6522 19.336C35.1159 19.784 35.1159 20.5103 34.6522 20.9582L23.5688 31.664C23.1051 32.112 22.3533 32.112 21.8895 31.6641L16.3478 26.3114C15.8841 25.8634 15.884 25.1371 16.3478 24.6892C16.8115 24.2412 17.5634 24.2411 18.0272 24.6891L22.7291 29.2307L32.9728 19.336C33.4366 18.888 34.1885 18.888 34.6522 19.336Z" fill="#179A6B"/>
                     </svg>
                     {{ __('message.Official Google & TripAdviser reservations') }}</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="item">
                  <p><svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <circle cx="25" cy="25" r="24" stroke="#179A6B" stroke-width="2"/>
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M34.6522 19.336C35.1159 19.784 35.1159 20.5103 34.6522 20.9582L23.5688 31.664C23.1051 32.112 22.3533 32.112 21.8895 31.6641L16.3478 26.3114C15.8841 25.8634 15.884 25.1371 16.3478 24.6892C16.8115 24.2412 17.5634 24.2411 18.0272 24.6891L22.7291 29.2307L32.9728 19.336C33.4366 18.888 34.1885 18.888 34.6522 19.336Z" fill="#179A6B"/>
                     </svg>
                     {{ __('message.Table management') }}</p>
               </div>
            </div>
         </div>

      </div>
   </section>

   <div class="body_bg" style="background-image: url(imgs/body_bg.png);">
   
      <!-- guest experience -->
      <section class="available-of-experience" >
         <div class="container">
             <h4>{{ __('message.Join') }} <b>{{ __('message.3,000+ restaurants') }} </b> {{ __('message.in 50 countries using') }} <b>{{ __('message.Rizera') }}</b> {{ __('message.to') }} <br>
               {{ __('message.improve the guest experience.') }}</h4>
               <div class="line">
                  <svg width="259" height="7" viewBox="0 0 259 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <rect x="132" y="3" width="127" height="1" fill="url(#paint0_linear)"/>
                     <rect y="3" width="127" height="1" fill="url(#paint1_linear)"/>
                     <circle cx="129.5" cy="3.5" r="3" stroke="#C4C4C4"/>
                     <defs>
                     <linearGradient id="paint0_linear" x1="130.5" y1="3.99995" x2="259" y2="3.99989" gradientUnits="userSpaceOnUse">
                     <stop stop-color="#C4C4C4"/>
                     <stop offset="1" stop-color="#C4C4C4" stop-opacity="0"/>
                     </linearGradient>
                     <linearGradient id="paint1_linear" x1="-1.5" y1="3.99995" x2="127" y2="3.99989" gradientUnits="userSpaceOnUse">
                     <stop stop-color="#C4C4C4" stop-opacity="0"/>
                     <stop offset="1" stop-color="#C4C4C4"/>
                     </linearGradient>
                     </defs>
                     </svg>
                        
               </div>
      
               <div class="available-of-experience_slider">
                  <div class="item">
                     <img src="{{ asset('front/imgs/logo_1.svg') }}" alt="" class="img-fluid">
                  </div>
                  <div class="item">
                     <img src="{{ asset('front/imgs/logo_2.svg') }}" alt="" class="img-fluid">
                  </div>
                  <div class="item">
                     <img src="{{ asset('front/imgs/logo_3.svg') }}" alt="" class="img-fluid">
                  </div>
                  <div class="item">
                     <img src="{{ asset('front/imgs/logo_4.svg') }}" alt="" class="img-fluid">
                  </div>
                  <div class="item">
                     <img src="{{ asset('front/imgs/logo_5.svg') }}" alt="" class="img-fluid">
                  </div>
                  <div class="item">
                     <img src="{{ asset('front/imgs/logo_6.svg') }}" alt="" class="img-fluid">
                  </div>
               </div>
               </div>
               </section>
       <!-- end of guest experience -->

       <div class="container">
         <div class="Let_us_take">
        <h3> {{ __('message.Let us take care of all your restaurant needs') }}</h3>
        <a  href="{{ url('restaurant-owner/login') }}" class="btn btn-black">{{ __('message.Get Started') }}</a>
      </div>


       </div>
 <!-- faq section -->
       <section class="Frequently-section">
         <div class="container">
            <h2 class="text-center">{{ __('message.Frequently asked questions') }}</h2>
            <div class="accordion" id="accordionExample">
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingOne">
                   <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                     {{ __('message.Can I pay monthly?') }}
                   </button>
                 </h2>
                 <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                     {{ __('message.Zero Support is free 24/7 through the app via instant messaging. Support is also available over the phone.') }}
                   </div>
                 </div>
               </div>
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingTwo">
                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                     {{ __('message.How much is support?') }}
                   </button>
                 </h2>
                 <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                    {{ __('message.Zero Support is free 24/7 through the app via instant messaging. Support is also available over the phone.') }}
                   </div>
                 </div>
               </div>
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingThree">
                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                     {{ __('message.What’s included with contactless dining?') }}
                   </button>
                 </h2>
                 <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                     {{ __('message.Zero Support is free 24/7 through the app via instant messaging. Support is also available over the phone.') }}
                   </div>
                 </div>
               </div>
             </div>
            </div>

         </section>
       </div>
   <!-- pricing -->
   <!-- end What our clients say? -->
   <script src="{{ asset('front/js/jquery.min.js') }}"></script>


     
    <script type="text/javascript">


   $(document).on('change','.switch_price_price', function() {
      if($("#switch_price").prop("checked")){
      //alert('year');
              $('#type').val('year');
       $('.text-block').removeClass('deactive');
         $('.text-block2').removeClass('active');
           $('.text-block').addClass('active');
         $('.text-block2').addClass('deactive');
    } else {
      //  alert('month');
                $('#type').val('month');
       $('.text-block').addClass('deactive');
         $('.text-block2').addClass('active');
           $('.text-block').removeClass('active');
         $('.text-block2').removeClass('deactive');
        
    }
});
        
            </script>
          
<script type="text/javascript">


   $(document).on('click','.subscription', function(e) {
      e.preventDefault();
              $("#subscription_form").submit();
    });   



</script>
@endsection

