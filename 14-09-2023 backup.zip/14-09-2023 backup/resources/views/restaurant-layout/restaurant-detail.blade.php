@extends('layouts.front')

@section('content') 

<style>



.img-wrapper {
  position: relative;
  height: 110px;
  overflow: hidden;
}
.img-wrapper img {
     width: 100%;
    height: 100%;
    object-fit: cover;
}

.img-overlay {
  background: rgba(0, 0, 0, 0.7);
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0;
  cursor: pointer;
}
.img-overlay i {
  color: #fff;
  font-size: 3em;
}

#overlay {
  background: rgba(0, 0, 0, 0.7);
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 99999;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
#overlay img {
  margin: 0;
  width: 80%;
  height: auto;
  -o-object-fit: contain;
     object-fit: contain;
  padding: 5%;
}
@media screen and (min-width: 768px) {
  #overlay img {
    width: 60%;
  }
}
@media screen and (min-width: 1200px) {
  #overlay img {
    width: 50%;
  }
}

#nextButton {
  color: #fff;
  font-size: 2em;
  transition: opacity 0.8s;
}
#nextButton:hover {
  opacity: 0.7;
}
@media screen and (min-width: 768px) {
  #nextButton {
    font-size: 2em;
  }
}

#prevButton {
  color: #fff;
  font-size: 2em;
  transition: opacity 0.8s;
}
#prevButton:hover {
  opacity: 0.7;
}
@media screen and (min-width: 768px) {
  #prevButton {
    font-size: 2em;
  }
}

#exitButton {
  color: #fff;
  font-size: 2em;
  transition: opacity 0.8s;
  position: absolute;
  top: 15px;
  right: 15px;
}
#exitButton:hover {
  opacity: 0.7;
}
@media screen and (min-width: 768px) {
  #exitButton {
    font-size: 2em;
  }
}
</style>

      <!-- hiro -->
      @foreach($restaurant as $key =>$detail)
      @if(!empty($detail->bannerImage[0]))
       <section class="detail_page_banner" style="background: url({{asset('storage').'/'.$detail->bannerImage[0]->image }}) no-repeat center center; background-size: cover;">
      @else
       <section class="detail_page_banner" style="background: url({{ asset('front/imgs/detail.png') }}) no-repeat center center; background-size: cover;">
        @endif 
     

                       <!-- @if(!empty($detail->bannerImage[0]))
                        <img src="{{  asset('storage').'/'.$detail->bannerImage[0]->image }}" alt="" class="w-100">
                        @else
                       <img src="{{ asset('front/imgs/detail.png') }}" alt="" class="w-100">
                       @endif -->
                       
        <!--  <img src="{{ asset('front/imgs/detail.png') }}" alt="" class="w-100">    -->
       
        <div class="detail_abs">
         <div class="container">
           <div class="row">
              <div class="col-md-6">
                  <h2>
                      @if( Session()->get('locale') == 'ara' &&  $detail->ar_name!="")
                       {{$detail->ar_name}} 
                      @elseif(Session::get('locale') == 'fr' && $detail->fr_name!="")
                       {{$detail->fr_name}} 
                      @else
                         {{$detail->name}} 
                      @endif
                   
                   
                   @if($detail->verified == 1)
                    <span class="Verified">
                   @if( Session()->get('locale') == 'ara' )
                                    <img src="{{ asset('front/imgs/verified_ara.png') }}" alt="">
                                    @elseif(Session::get('locale') == 'fr' )
                                   <img src="{{ asset('front/imgs/verified_fr.png') }}" alt="">
                                    @else
                                     <img src="{{ asset('front/imgs/Verified.png') }}" alt="">
                                    @endif
                  
                   @endif
              </span></h2>
                 <h6>{{$detail->address}} 
                  <a href="http://maps.google.co.uk/maps?q=51.917168,-0.2292397" target=_blank>
                  <span class="map"><svg width="11" height="10" viewBox="0 0 11 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4.04419 8.44897L6.86053 9.85714V1.40811L4.04419 -6.10352e-05V8.44897Z" fill="#FCCC00"/>
                  <path d="M0.523926 9.8572L3.34027 8.44903V0L0.523926 1.40817V9.8572Z" fill="#FCCC00"/>
                  <path d="M7.56445 1.40811V9.85714L10.3808 8.44897V-6.10352e-05L7.56445 1.40811Z" fill="#FCCC00"/>
                  </svg>
                  {{ __('message.Map') }}</span>
                </a>
                </h6>
              </div>
              <div class="col-md-6 text-md-end">
                 <a href="#" class="btn btn-primary" >
                  {{ __('message.Reserve Now') }}
                 </a>
              </div>
           </div>
           </div>
        </div>
      </section>
      <div class="section_detail_page_tab">
         <div class="top_nav">
            <div class="container">
               <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="Profile-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="button" role="tab" aria-controls="Profile" aria-selected="true">{{ __('message.Profile') }}</button>
                  </li>
               @foreach($detail->getWebImages as $images)
                  @if($images->doc_for==2)   
                  <li class="nav-item" role="presentation">
                     <a href="{{ Route('restaurant-menu-pdf',['id'=>$detail->id]) }}" target="_blank" class="nav-link">{{ __('message.Menu List') }}</a>
                  </li>
                  @endif                    
               @endforeach
               @if(!empty($detail->resturant_key) )
                  <li class="nav-item" role="presentation">
                    <a href="{{Route('restaurant_item_list',['key'=>$detail->resturant_key]) }}" id="Restuarant-Item-tab" class="nav-link" target="_blank" > {{ __('message.Restaurant Item') }}</a>
                  </li>
                  @endif 
                  <li class="nav-item" role="presentation">
                    <a href="{{Route('restaurant_item_list_html',[$detail->id])}}" id="Restuarant-Menu-tab" class="nav-link">New Menu List</a>
                  </li>
                  <li class="nav-item" role="presentation">
                    <a href="#contact-tab" id="Restaurant-tab" class="nav-link"  data-bs-toggle="tab" data-bs-target="#Profile" type="a" role="tab" aria-controls="Profile" aria-selected="false" > {{ __('message.Restaurant Info') }}</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="Notes-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="a" role="tab" aria-controls="Profile" aria-selected="false" > {{ __('message.Notes') }}</a>
                   </li>
   
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="Chef-tab" data-bs-toggle="tab" data-bs-target="#Profile" type="a" role="tab" aria-controls="Profile" aria-selected="false" > {{ __('message.Chef') }}</a>
                   </li>
                  
                                             
                </ul>
                </div>
         </div>
         <div class="container">
            
             <div class="tab-content" id="myTabContent">
               <div class="tab-pane fade show active" id="Profile" role="tabpanel" aria-labelledby="Profile-tab">
                  <div class="row">
                 <div class="col-md-12">
                    <div class="due">
                       <p><img src="{{ asset('front/imgs/due.svg') }}" alt="" />{{ __('message.Due to COVID-19, Currently we have only delivery services.') }}</p>
                    </div>
                 </div>
                 <div class="col-md-6">
                    <div class="add_review card">
                        <div class="row">
                           <div class="col-md-6">
                              <div class="review_start">
                                 <img src="{{ asset('front/imgs/reviiew_icon.svg') }}" alt="" />
                                 <span class="start">
                                   <span></span>
                                   <span></span>
                                   <span></span>
                                   <span class="half"></span>
                                   <span class="blank"></span>
                                 </span>
                                 <p>{{$detail->rating}} / 5 Excellent</p>
                              </div>
                             <h6>Rated By TripAdvisor</h6>
                             <a href="" class="link_review">{{ __('message.View All Reviews') }}</a>
                           </div>
                           <div class="col-md-6 text-md-end">
                               <a href="" class="btn btn-black">{{ __('message.Add a Review') }}</a>
                           </div>
                        </div>
                    </div>

                      <div class="Restaurant_Info" id="Profile">
                     <h3>{{ __('message.Description') }}</h3>

             
                        @php echo htmlspecialchars_decode($detail->description) @endphp
             
                  </div>
                    <div class="Restaurant_Info" id="contact-tab">
                       <h3>{{ __('message.Restaurant Info') }}</h3>

                       <ul class="list-unstyled">
                           @foreach($detail->getFacilities as $facility)
                           <li><img src="{{ asset($facility->facilities['image']) }}" alt="">
                           {{$facility->facilities['name']}}
                           </li>
                           @endforeach
                       </ul>
                    </div>
                    
                    <div class="Restaurant_Info" id="notes">
                     <h3>{{ __('message.Notes') }}</h3>

                
                        @php echo htmlspecialchars_decode($detail->notes) @endphp
       
                  </div>
                 </div>
                 <div class="col-md-6">
                    <div class="add_Review_share_list">
                       <div class="item">
                          <div class="icon">
                        <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M11 1.84214L13.3538 7.12273L13.5299 7.51784L13.9601 7.56324L19.7096 8.17007L15.4149 12.0405L15.0935 12.3301L15.1833 12.7532L16.3829 18.4089L11.3747 15.5203L11 15.3042L10.6253 15.5203L5.61715 18.4089L6.81672 12.7532L6.90647 12.3301L6.58513 12.0405L2.29036 8.17007L8.03987 7.56324L8.47006 7.51784L8.64618 7.12273L11 1.84214Z" stroke="#484848" stroke-width="1.5"/>
                           </svg>
                        </div>
                          <h6>{{ __('message.Add Review') }}</h6>
                       </div>
                       <div class="item">
                        <div class="icon">
                               <span class="doller">{{$detail->expensiveness}}</span>
                              
                      </div>
                        <h6>{{ __('message.Price Range') }}</h6>
                     </div>
                   <!--   <div class="item">
                        <div class="icon">
                      <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                         <path d="M11 1.84214L13.3538 7.12273L13.5299 7.51784L13.9601 7.56324L19.7096 8.17007L15.4149 12.0405L15.0935 12.3301L15.1833 12.7532L16.3829 18.4089L11.3747 15.5203L11 15.3042L10.6253 15.5203L5.61715 18.4089L6.81672 12.7532L6.90647 12.3301L6.58513 12.0405L2.29036 8.17007L8.03987 7.56324L8.47006 7.51784L8.64618 7.12273L11 1.84214Z" stroke="#484848" stroke-width="1.5"/>
                         </svg>
                      </div>
                        <h6>{{ __('message.Add Review') }}</h6>
                     </div> -->
                    <!--  <div class="item">
                        <div class="icon">
                           <svg width="21" height="19" viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M9.61639 3.54811L10.2743 4.75049L10.9323 3.54813C11.2426 2.98101 11.7577 2.22596 12.5108 1.64351C13.2836 1.04585 14.1453 0.75 15.0904 0.75C17.7317 0.75 19.7987 2.90085 19.7987 5.92035C19.7987 7.5128 19.1697 8.88426 17.9535 10.3518C16.7184 11.8422 14.9363 13.3641 12.7033 15.267L12.7033 15.267L12.7027 15.2675C11.9702 15.8918 11.1394 16.5998 10.2744 17.3553C9.40989 16.6003 8.57955 15.8927 7.84781 15.2691L7.84583 15.2674L7.84581 15.2674C5.61259 13.3643 3.83043 11.8423 2.5952 10.3518C1.37898 8.88426 0.75 7.5128 0.75 5.92035C0.75 2.90085 2.81699 0.75 5.45824 0.75C6.40338 0.75 7.26507 1.04585 8.03785 1.64351C8.79099 2.22597 9.30607 2.98098 9.61639 3.54811Z" stroke="#484848" stroke-width="1.5"/>
                              </svg>
                              
                      </div>
                        <h6>{{ __('message.Bookmark') }}</h6>
                     </div> -->
                     <div class="item">
                        <div class="icon">
                           <svg width="22" height="19" viewBox="0 0 22 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M12.6845 6.95417H13.4345V6.20417V1.81067L20.9393 9.3155L13.4345 16.8203V12.399V11.7362L12.7767 11.6547C8.44635 11.1183 4.04311 12.7298 1.09004 16.0485C2.36437 10.8284 7.07204 6.95417 12.6845 6.95417Z" stroke="#484848" stroke-width="1.5"/>
                              </svg>
                              
                      </div>
                        <h6>{{ __('message.Share') }}</h6>
                     </div>
                    </div>
                                <?php    $today_date = date('Y-m-d'); ?>
                              @if(!empty($detail->getHour) || !empty($detail->holidaydate))
                                 @if( isset($detail->getHour->mon_to)  && (!in_array($today_date, $detail->holidaydate)))
                                    @if((($detail->getHour->mon_to >= date("H:i:s")) 
                                          && ($detail->getHour->mon_from <= date("H:i:s")) 
                                          && ('Monday' == date("l"))
                                      )
                                      || (($detail->getHour->tue_to >= date("H:i:s")) 
                                          && ($detail->getHour->tue_from <= date("H:i:s")) 
                                          && ('Tuesday' == date("l"))
                                        ) 
                                      || (($detail->getHour->wed_to >= date("H:i:s")) 
                                          && ($detail->getHour->wed_from <= date("H:i:s"))
                                          && ('Wednesday' == date("l"))
                                        )
                                      || (($detail->getHour->thu_to >= date("H:i:s"))
                                          && ($detail->getHour->thu_from <= date("H:i:s"))
                                          && ('Thursday' == date("l"))
                                        )
                                      || (($detail->getHour->fri_to >= date("H:i:s"))
                                          && ($detail->getHour->fri_from <= date("H:i:s"))
                                          && ('Friday' == date("l"))
                                        )
                                      || (($detail->getHour->sat_to >= date("H:i:s"))
                                          && ($detail->getHour->sat_from <= date("H:i:s"))
                                          && ('Saturday' == date("l"))
                                        )
                                      || (($detail->getHour->sun_to >= date("H:i:s"))
                                          && ($detail->getHour->sun_from <= date("H:i:s"))
                                          && ('Saturday' == date("l"))
                                        )

                                      )
                                   <div class="open_date">
                                 @else
                                <div class="open_date close">
                                 
                                    @endif
                                    @else
                                   <div class="open_date close">
                                 
                                 @endif
                        @else
                            <div class="open_date close">
                                 
                        @endif
                    
                    
                    
                        <?php    $today_date = date('Y-m-d'); ?>
                              @if(!empty($detail->getHour) || !empty($detail->holidaydate))
                                 @if( isset($detail->getHour->mon_to)  && (!in_array($today_date, $detail->holidaydate)))
                                    @if((($detail->getHour->mon_to >= date("H:i:s")) 
                                          && ($detail->getHour->mon_from <= date("H:i:s")) 
                                          && ('Monday' == date("l"))
                                      )
                                      || (($detail->getHour->tue_to >= date("H:i:s")) 
                                          && ($detail->getHour->tue_from <= date("H:i:s")) 
                                          && ('Tuesday' == date("l"))
                                        ) 
                                      || (($detail->getHour->wed_to >= date("H:i:s")) 
                                          && ($detail->getHour->wed_from <= date("H:i:s"))
                                          && ('Wednesday' == date("l"))
                                        )
                                      || (($detail->getHour->thu_to >= date("H:i:s"))
                                          && ($detail->getHour->thu_from <= date("H:i:s"))
                                          && ('Thursday' == date("l"))
                                        )
                                      || (($detail->getHour->fri_to >= date("H:i:s"))
                                          && ($detail->getHour->fri_from <= date("H:i:s"))
                                          && ('Friday' == date("l"))
                                        )
                                      || (($detail->getHour->sat_to >= date("H:i:s"))
                                          && ($detail->getHour->sat_from <= date("H:i:s"))
                                          && ('Saturday' == date("l"))
                                        )
                                      || (($detail->getHour->sun_to >= date("H:i:s"))
                                          && ($detail->getHour->sun_from <= date("H:i:s"))
                                          && ('Saturday' == date("l"))
                                        )

                                      )
                                      <span class="open">    {{ __('message.open') }} </span>
                                 @else
                                
                                 <span class="open">{{ __('message.close') }}</span>
                                 
                                 
                                    @endif
                                    @else
                                  
                                 <span class="open">{{ __('message.close') }}</span>
                               
                                 
                                 @endif
                        @else
                             
                                 <span class="open">{{ __('message.close') }}</span>
                            
                                 
                        @endif

                   
                       <select class="opening-hrs">
                         <?php 
                            $key = array_search($today_date,$detail->holidaydate);
                                         
                           ?>

                        @if(!empty($detail->getHour)|| !empty($detail->holidaydate))
                        @if(isset($detail->getHour->mon_to)  && (!in_array($today_date,$detail->holidaydate)))
                          @if( Session()->get('locale') == 'ara')

                          <option>{{ $detail->getHour->mon_from==null?'-':date('h:i a', strtotime($detail->getHour->mon_from))}} - {{ $detail->getHour->mon_to==null?'-':date('h:i a', strtotime($detail->getHour->mon_to))}}&nbsp;&nbsp;&nbsp;الإثنين</option>
                          <option>{{ $detail->getHour->tue_from==null?'-':date('h:i a', strtotime($detail->getHour->tue_from))}} - {{ $detail->getHour->tue_to==null?'-':date('h:i a', strtotime($detail->getHour->tue_to))}}&nbsp;&nbsp;&nbsp;يوم الثلاثاء</option>
                          <option>{{ $detail->getHour->wed_from==null?'-':date('h:i a', strtotime($detail->getHour->wed_from))}} - {{ $detail->getHour->wed_to==null?'-':date('h:i a', strtotime($detail->getHour->wed_to))}}&nbsp;&nbsp;&nbsp;الأربعاء</option>
                          <option>{{ $detail->getHour->thu_from==null?'-':date('h:i a', strtotime($detail->getHour->thu_from))}} - {{ $detail->getHour->thu_to==null?'-':date('h:i a', strtotime($detail->getHour->thu_to))}}&nbsp;&nbsp;&nbsp;يوم الخميس</option>
                          <option>{{ $detail->getHour->fri_from==null?'-':date('h:i a', strtotime($detail->getHour->fri_from))}} - {{ $detail->getHour->fri_to==null?'-':date('h:i a', strtotime($detail->getHour->fri_to))}}&nbsp;&nbsp;&nbsp;جمعة</option>
                          <option>{{ $detail->getHour->sat_from==null?'-':date('h:i a', strtotime($detail->getHour->sat_from))}} - {{ $detail->getHour->sat_to==null?'-':date('h:i a', strtotime($detail->getHour->sat_to))}}&nbsp;&nbsp;&nbsp;السبت</option>

                         

                          @elseif(Session::get('locale') == 'fr' )

                          <option>Lundi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->mon_from==null?'-':date('h:i a', strtotime($detail->getHour->mon_from))}} - {{ $detail->getHour->mon_to==null?'-':date('h:i a', strtotime($detail->getHour->mon_to))}}</option>
                          <option>Mardi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->tue_from==null?'-':date('h:i a', strtotime($detail->getHour->tue_from))}} - {{ $detail->getHour->tue_to==null?'-':date('h:i a', strtotime($detail->getHour->tue_to))}}</option>
                          <option>Mercredi&nbsp;&nbsp;{{ $detail->getHour->wed_from==null?'-':date('h:i a', strtotime($detail->getHour->wed_from))}} - {{ $detail->getHour->wed_to==null?'-':date('h:i a', strtotime($detail->getHour->wed_to))}}</option>
                          <option>jeudi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->thu_from==null?'-':date('h:i a', strtotime($detail->getHour->thu_from))}} - {{ $detail->getHour->thu_to==null?'-':date('h:i a', strtotime($detail->getHour->thu_to))}}</option>
                          <option>vendredi&nbsp;&nbsp;{{ $detail->getHour->fri_from==null?'-':date('h:i a', strtotime($detail->getHour->fri_from))}} - {{ $detail->getHour->fri_to==null?'-':date('h:i a', strtotime($detail->getHour->fri_to))}}</option>
                          <option>samedi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->sat_from==null?'-':date('h:i a', strtotime($detail->getHour->sat_from))}} - {{ $detail->getHour->sat_to==null?'-':date('h:i a', strtotime($detail->getHour->sat_to))}}</option>

                          @else

                          <option>Monday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{$detail->getHour->mon_from==null?'-':date('h:i a', strtotime($detail->getHour->mon_from))}} - {{ $detail->getHour->mon_to==null?'-':date('h:i a', strtotime($detail->getHour->mon_to))}}</option>
                          <option>Tuesday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->tue_from==null?'-':date('h:i a', strtotime($detail->getHour->tue_from))}} - {{ $detail->getHour->tue_to==null?'-':date('h:i a', strtotime($detail->getHour->tue_to))}}</option>
                          <option>Wednesday&nbsp;&nbsp;{{ $detail->getHour->wed_from==null?'-':date('h:i a', strtotime($detail->getHour->wed_from))}} - {{ $detail->getHour->wed_to==null?'-':date('h:i a', strtotime($detail->getHour->wed_to))}}</option>
                          <option>Thursday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->thu_from==null?'-':date('h:i a', strtotime($detail->getHour->thu_from))}} - {{ $detail->getHour->thu_to==null?'-':date('h:i a', strtotime($detail->getHour->thu_to))}}</option>
                          <option>Friday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->fri_from==null?'-':date('h:i a', strtotime($detail->getHour->fri_from))}} - {{ $detail->getHour->fri_to==null?'-':date('h:i a', strtotime($detail->getHour->fri_to))}}</option>
                          <option>Saturday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->sat_from==null?'-':date('h:i a', strtotime($detail->getHour->sat_from))}} - {{ $detail->getHour->sat_to==null?'-':date('h:i a', strtotime($detail->getHour->sat_to))}}</option> 

                          @endif
                         
                          @if(!$detail->getHour->sun_from==null)

                             @if( Session()->get('locale') == 'ara')
                              <option>{{ $detail->getHour->sun_from==null?'-':date('h:i a', strtotime($detail->getHour->sun_from))}} - {{ $detail->getHour->sun_to==null?'-':date('h:i a', strtotime($detail->getHour->sun_to))}}&nbsp;&nbsp;&nbsp;يوم الأحد</option>
                             @elseif(Session::get('locale') == 'fr' )
                              <option>dimanche&nbsp;{{ $detail->getHour->sun_from==null?'-':date('h:i a', strtotime($detail->getHour->sun_from))}} - {{ $detail->getHour->sun_to==null?'-':date('h:i a', strtotime($detail->getHour->sun_to))}}</option>
                             @else
                              <option>Sunday&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $detail->getHour->sun_from==null?'-':date('h:i a', strtotime($detail->getHour->sun_from))}} - {{ $detail->getHour->sun_to==null?'-':date('h:i a', strtotime($detail->getHour->sun_to))}}</option>
                             @endif

                       

                            @else
                            @if( Session()->get('locale') == 'ara')
                              <option>Close || يوم الأحد</option>
                             @elseif(Session::get('locale') == 'fr' )
                               <option>dimanche || Close</option>
                             @else
                               <option>Sunday || Close</option>
                             @endif
                          

                              @endif
                          @else
                         <!--  <option>{{$key}} || Close</option> -->
                           @endif
                        @else
                           {{ __('message.close') }}
                        @endif
                       </select>
                    </div>
                    <div class="Restaurant_Info pb-2">
                     <h3>{{ __('message.Gallery') }}</h3>
                <div id="gallery">
                   <div id="image-gallery">
                   <div class="row">
                      @foreach($detail->getImages as $images)
                      
                        @if(isset($images->image))
                        @if($images->doc_for==1)
                        <div class="col-6 col-md-4 mb-10">
                        <div class="img-wrapper">
                          <a href="{{ asset('storage').'/'.$images->image }}"><img src="{{ asset('storage').'/'.$images->image }}" class="img-responsive"></a>
                          <div class="img-overlay">
                            <svg width="40" height="40" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <rect x="10" width="2" height="22" rx="1" fill="#ffffff"/>
                              <rect y="10" width="22" height="2" rx="1" fill="#ffffff"/>
                            </svg>
                          </div>
                        </div>
                     
                       
               
                           </div>
                        @endif                
                        @endif
                   
                       @endforeach
                   </div>  </div>  </div>
                  </div>
                  <div class="Restaurant_Info" id="Chef">
                     <h3>{{ __('message.Restaurant Chef') }}</h3>

                    <div class="chef_info">
                      @if(isset($detail->restaurantChef))
                        <div class="chef_img">
                          @if(!empty($detail->restaurantChef->chef_image) && file_exists('public/storage/'.$detail->restaurantChef->chef_image))
                          <img src=" {{ asset('storage').'/'.$detail->restaurantChef->chef_image }} " class="w-100 h-100">
                          @else  
                          <img src="{{ asset('front/imgs/placeholder.png') }}" class="w-100 h-100">
                          @endif
                        </div>
                      <div class="chef_body">
                        <h6>{{$detail->restaurantChef->chef_name}}</h6>
                        <p>{{$detail->restaurantChef->chef_mobile}}</p>
                        <div class="link-chif">
                          <a href="{{$detail->restaurantChef->chef_fb_link}}" target="_blank"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19.0259 0H4.97409C2.22698 0 0 2.22698 0 4.97409V19.0259C0 21.773 2.22698 24 4.97409 24H19.0259C21.773 24 24 21.773 24 19.0259V4.97409C24 2.22698 21.773 0 19.0259 0Z" fill="#1778F2"/>
                            <path d="M12.957 18.7732V12.3497H15.1131L15.4364 9.8464H12.957V8.2481C12.957 7.52337 13.1583 7.02944 14.1976 7.02944H15.5232V4.7911C14.8816 4.72322 14.2368 4.69034 13.5916 4.69261C11.6803 4.69261 10.3718 5.85916 10.3718 8.00163V9.8464H8.21021V12.3497H10.3718V18.7732H12.957Z" fill="#FDFDFD"/>
                            </svg>
                          </a>
                          <a href="{{$detail->restaurantChef->chef_insta_link}}" target="_blank"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0)">
                              <path d="M6.08588 23.9151C5.15758 23.9047 4.23801 23.7344 3.36753 23.4118C2.73187 23.1768 2.15676 22.8027 1.68424 22.3169C1.19712 21.8454 0.822514 21.2701 0.588235 20.6339C0.265824 19.7634 0.0958076 18.8439 0.0856471 17.9158C0.0143529 16.3727 0 15.9099 0 12C0 8.09012 0.0157647 7.62894 0.0849412 6.08471C0.0963347 5.15689 0.26656 4.23788 0.588235 3.36753C0.823654 2.73176 1.19773 2.15642 1.68329 1.68329C2.15523 1.19662 2.73061 0.822358 3.36682 0.588235C4.2373 0.265557 5.15687 0.0953008 6.08518 0.0849412C7.62871 0.0143529 8.09224 0 12 0C15.9078 0 16.3711 0.0157647 17.9153 0.0849412C18.8433 0.0962542 19.7626 0.266481 20.6332 0.588235C21.2691 0.822667 21.8443 1.1968 22.3165 1.68306C22.8029 2.15535 23.1772 2.73073 23.4118 3.36682C23.7345 4.23729 23.9049 5.15686 23.9153 6.08518C23.9859 7.62941 24.0002 8.09176 24.0002 12.0005C24.0002 15.9092 23.9859 16.3715 23.9153 17.9158C23.9041 18.8439 23.7338 19.7633 23.4118 20.6339C23.1682 21.2652 22.7951 21.8386 22.3166 22.317C21.838 22.7954 21.2646 23.1683 20.6332 23.4118C19.7627 23.7345 18.8431 23.9049 17.9148 23.9153C16.372 23.9859 15.9082 24.0002 11.9995 24.0002C8.09082 24.0002 7.62847 23.9866 6.08565 23.9153" fill="url(#paint0_radial)"/>
                              <path d="M6.08588 23.9151C5.15758 23.9047 4.23801 23.7344 3.36753 23.4118C2.73187 23.1768 2.15676 22.8027 1.68424 22.3169C1.19712 21.8454 0.822514 21.2701 0.588235 20.6339C0.265824 19.7634 0.0958076 18.8439 0.0856471 17.9158C0.0143529 16.3727 0 15.9099 0 12C0 8.09012 0.0157647 7.62894 0.0849412 6.08471C0.0963347 5.15689 0.26656 4.23788 0.588235 3.36753C0.823654 2.73176 1.19773 2.15642 1.68329 1.68329C2.15523 1.19662 2.73061 0.822358 3.36682 0.588235C4.2373 0.265557 5.15687 0.0953008 6.08518 0.0849412C7.62871 0.0143529 8.09224 0 12 0C15.9078 0 16.3711 0.0157647 17.9153 0.0849412C18.8433 0.0962542 19.7626 0.266481 20.6332 0.588235C21.2691 0.822667 21.8443 1.1968 22.3165 1.68306C22.8029 2.15535 23.1772 2.73073 23.4118 3.36682C23.7345 4.23729 23.9049 5.15686 23.9153 6.08518C23.9859 7.62941 24.0002 8.09176 24.0002 12.0005C24.0002 15.9092 23.9859 16.3715 23.9153 17.9158C23.9041 18.8439 23.7338 19.7633 23.4118 20.6339C23.1682 21.2652 22.7951 21.8386 22.3166 22.317C21.838 22.7954 21.2646 23.1683 20.6332 23.4118C19.7627 23.7345 18.8431 23.9049 17.9148 23.9153C16.372 23.9859 15.9082 24.0002 11.9995 24.0002C8.09082 24.0002 7.62847 23.9866 6.08565 23.9153" fill="url(#paint1_radial)"/>
                              <path d="M9.05336 12.051C9.05341 11.4632 9.22776 10.8886 9.55438 10.3999C9.88099 9.91117 10.3452 9.53027 10.8883 9.30538C11.4314 9.08048 12.029 9.02169 12.6055 9.13643C13.182 9.25117 13.7115 9.53429 14.1271 9.94999C14.5427 10.3657 14.8257 10.8953 14.9403 11.4718C15.0549 12.0484 14.996 12.6459 14.771 13.189C14.5459 13.732 14.1649 14.1961 13.6761 14.5226C13.1873 14.8491 12.6127 15.0234 12.0249 15.0233C11.2367 15.0231 10.4808 14.7099 9.92358 14.1525C9.36632 13.5951 9.0533 12.8392 9.05336 12.051ZM7.44653 12.051C7.44653 12.9565 7.71505 13.8417 8.21812 14.5946C8.7212 15.3475 9.43624 15.9344 10.2728 16.2809C11.1094 16.6274 12.03 16.7181 12.9181 16.5414C13.8062 16.3648 14.622 15.9287 15.2623 15.2884C15.9026 14.6481 16.3386 13.8323 16.5153 12.9442C16.6919 12.0561 16.6013 11.1355 16.2547 10.299C15.9082 9.46238 15.3214 8.74734 14.5685 8.24426C13.8156 7.74119 12.9304 7.47267 12.0249 7.47267C11.4236 7.47264 10.8283 7.59104 10.2728 7.82112C9.71731 8.05119 9.21258 8.38842 8.78743 8.81357C8.36229 9.23871 8.02505 9.74344 7.79498 10.2989C7.56491 10.8544 7.4465 11.4498 7.44653 12.051ZM15.7145 7.29126C15.7144 7.50286 15.7771 7.70974 15.8946 7.88573C16.0121 8.06173 16.1791 8.19893 16.3746 8.27999C16.57 8.36106 16.7851 8.38234 16.9927 8.34115C17.2002 8.29996 17.3909 8.19814 17.5406 8.04858C17.6903 7.89902 17.7923 7.70844 17.8336 7.50092C17.875 7.2934 17.8539 7.07827 17.773 6.88274C17.6921 6.68721 17.5551 6.52006 17.3792 6.40242C17.2033 6.28478 16.9965 6.22194 16.7849 6.22185C16.5013 6.22198 16.2293 6.33467 16.0287 6.53518C15.8281 6.7357 15.7153 7.00763 15.715 7.29126H15.7145ZM8.42324 19.3087C7.85786 19.3025 7.29776 19.199 6.76747 19.0028C6.3829 18.8546 6.03363 18.6274 5.74214 18.3361C5.45064 18.0447 5.22339 17.6955 5.075 17.311C4.87871 16.7808 4.77524 16.2206 4.76912 15.6553C4.72583 14.7155 4.71736 14.4331 4.71736 12.0522C4.71736 9.67126 4.72677 9.38962 4.76912 8.44891C4.77598 7.88359 4.87943 7.3236 5.075 6.79314C5.22322 6.40845 5.45041 6.05909 5.74191 5.76759C6.03342 5.47608 6.38278 5.24889 6.76747 5.10067C7.29773 4.90439 7.85785 4.80092 8.42324 4.79479C9.363 4.7515 9.64535 4.74303 12.0254 4.74303C14.4054 4.74303 14.6879 4.75221 15.6286 4.79503C16.194 4.80189 16.754 4.90534 17.2844 5.10091C17.6691 5.24914 18.0185 5.47633 18.31 5.76784C18.6015 6.05934 18.8287 6.4087 18.9769 6.79338C19.1732 7.32364 19.2766 7.88376 19.2828 8.44915C19.3261 9.39032 19.3345 9.67126 19.3345 12.0524C19.3345 14.4336 19.3258 14.715 19.2828 15.6557C19.2762 16.2211 19.1727 16.7811 18.9769 17.3115C18.8285 17.696 18.6012 18.0452 18.3097 18.3366C18.0183 18.6279 17.669 18.855 17.2844 19.0033C16.7542 19.1995 16.194 19.303 15.6286 19.3091C14.6889 19.3524 14.4065 19.3609 12.0254 19.3609C9.64418 19.3609 9.36277 19.3522 8.42324 19.3091V19.3087ZM8.34936 3.18938C7.60955 3.20393 6.87758 3.34395 6.18465 3.60349C5.5923 3.83252 5.05434 4.18281 4.60527 4.63188C4.15619 5.08095 3.80591 5.61891 3.57688 6.21126C3.31737 6.90421 3.17735 7.63617 3.16277 8.37597C3.11877 9.32656 3.10889 9.63055 3.10889 12.052C3.10889 14.4734 3.11901 14.7771 3.16277 15.728C3.17735 16.4678 3.31737 17.1997 3.57688 17.8927C3.80592 18.485 4.15621 19.023 4.60528 19.472C5.05435 19.9211 5.5923 20.2714 6.18465 20.5004C6.87762 20.7599 7.60957 20.8999 8.34936 20.9146C9.30042 20.9578 9.60394 20.9684 12.0254 20.9684C14.4468 20.9684 14.7505 20.9583 15.7014 20.9146C16.4412 20.8999 17.1731 20.7599 17.8661 20.5004C18.4584 20.2714 18.9964 19.9211 19.4454 19.472C19.8945 19.023 20.2448 18.485 20.4738 17.8927C20.7337 17.1998 20.8737 16.4678 20.8879 15.728C20.9312 14.7767 20.9411 14.4734 20.9411 12.052C20.9411 9.63055 20.931 9.32679 20.8879 8.37597C20.8734 7.63616 20.7334 6.9042 20.4738 6.21126C20.2448 5.61902 19.8946 5.08115 19.4457 4.63209C18.9967 4.18303 18.4589 3.83268 17.8668 3.60349C17.1739 3.34378 16.4419 3.20375 15.7021 3.18938C14.7512 3.14585 14.4475 3.1355 12.0265 3.1355C9.60559 3.1355 9.30112 3.14562 8.34982 3.18938" fill="white"/>
                            </g>
                            <defs>
                              <radialGradient id="paint0_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(1.55318 23.4744) scale(30.4711)">
                              <stop offset="0.09" stop-color="#FA8F21"/>
                              <stop offset="0.78" stop-color="#D82D7E"/>
                              </radialGradient>
                              <radialGradient id="paint1_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(16.624 22.7035) scale(26.8148)">
                              <stop offset="0.64" stop-color="#8C3AAA" stop-opacity="0"/>
                              <stop offset="1" stop-color="#8C3AAA"/>
                              </radialGradient>
                              <clipPath id="clip0">
                              <rect width="24" height="24" fill="white"/>
                              </clipPath>
                            </defs></svg>
                          </a>
                        </div>
                      </div>
                    @endif
                  </div>
                </div>
              </div>
            </div>
          </div>
               <div class="tab-pane fade" id="Menu_List" role="tabpanel" aria-labelledby="Menu_List-tab">
                <div class="row">
                    @foreach($detail->getImages as $images)
                   <div class="col-md-6 mb-4">
                        @if($images->doc_for==2)
                        
                        <img src="{{ asset('storage').'/'.$images->image }}" alt="" class="w-100">

                        @endif
                   </div>
                    @endforeach
                 <!-- <div class="col-md-6 mb-4">
                     <img src="{{ asset('front/imgs/menu2.jpg') }}" alt="" class="w-100">
                  </div> -->
                  </div>
               </div>
               
             </div>
         </div>
      </div>
@endforeach
      <!-- banner -->
      <!-- Popular restaurants in Morocco -->
      <section class="popular-restaurants">
         <div class="container">
            <h2 class="text-center">
               <span><span> {{ __('message.You May Also Be Interested In') }} </span>
              <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.202C172.852 17.5591 170.476 23.3131 168.842 25.0988C166.912 18.452 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.0631C74.8429 19.7416 4.00944 32.1424 0 11.2099V7.04323V6.94403C0.148498 13.3924 9.65236 17.4599 21.6807 18.0551C38.3124 18.8488 59.8446 14.4837 70.982 12.1028C90.4352 7.93609 118.204 1.58688 141.964 0.197995C150.28 -0.298037 158.15 -0.0996239 164.833 0.991646C170.921 2.08292 173 6.5472 173 11.4083Z" fill="#FCCC00"></path>
               

                  <defs>
                     <clipPath id="clip0">
                        <rect width="173" height="25" fill="white"></rect>
                     </clipPath>
                  </defs>
               </svg>
            </h2>

            <div class="row">
               @foreach($similar as $key =>$detail)
               <div class="col-lg-6 col-xl-4 col-md-6">
                  <div class="card restaurant">
                     <a href="{{ route('restdetails',['id'=>$detail->restaurant_id]) }}">
                     <div class="card-img">
                       <!--  <div class="hart">
                           <img src="{{ asset('front/imgs/hart.svg') }}" alt="">
                        </div> -->
                        <!-- <img src="{{ asset('front/imgs/item.png') }}" alt="" class="w-100"> -->
                         @if(!empty($detail->images[0]))
                        <img src="{{  asset('storage').'/'.$detail->images[0]->image }}" alt="" class="w-100 store-cover">
                        @else
                       <img src="{{ asset('front/imgs/placeholder.png') }}" alt="" class="w-100 store-cover">
                       @endif
                      <div class="card-img-overly">
                           <div class="left"> 
                               <span class="American"><img src="{{ asset('front/imgs/American.png') }}" alt="">    
                                       
                                 @if(isset($detail->getRestaurantCuisine['name']))
                                  @if( Session()->get('locale') == 'ara' &&  $detail->getRestaurantCuisine['name_ar']!="")
                                    {{$detail->getRestaurantCuisine['name_ar']}}
                                    @elseif(Session::get('locale') == 'fr' && $detail->getRestaurantCuisine['name_fr']!="")
                                    {{$detail->getRestaurantCuisine['name_fr']}}
                                    @else
                                     {{$detail->getRestaurantCuisine['name']}}
                                    @endif
                                  
                                 @endif
                               </span>
                              </div>

                               <div class="right f-right">
                                 @if($detail->verified == 1)
                                   @if( Session()->get('locale') == 'ara' )
                                    <img src="{{ asset('front/imgs/verified_ara.png') }}" alt="">
                                    @elseif(Session::get('locale') == 'fr' )
                                   <img src="{{ asset('front/imgs/verified_fr.png') }}" alt="">
                                    @else
                                     <img src="{{ asset('front/imgs/Verified.png') }}" alt="">
                                    @endif
                              
                               @endif
                               <span class="Star"><img src="{{ asset('front/imgs/Star.png') }}" alt="">{{$detail->rating}}</span>
                               </div>
                        </div>
                     </div>
                   </a>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-7">
                            <h3 class="fifty-chars">{{$detail->name}}</h3>
                              <p class="fifty-chars">{{$detail->address}}</p>
                              <!-- <p> @php echo htmlspecialchars_decode($detail->notes) @endphp</p> -->
                           </div>
                           <div class="col-5 text-end">
                          
                              @if(!empty($detail->getHour) || !empty($detail->holidaydate))
                                 @if( isset($detail->getHour->mon_to)  && (!in_array($today_date, $detail->holidaydate)))
                              @if((($detail->getHour->mon_to >= date("H:i:s")) 
                                    && ($detail->getHour->mon_from <= date("H:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->getHour->tue_to >= date("H:i:s")) 
                                    && ($detail->getHour->tue_from <= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->getHour->wed_to >= date("H:i:s")) 
                                    && ($detail->getHour->wed_from <= date("H:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->getHour->thu_to >= date("H:i:s"))
                                    && ($detail->getHour->thu_from <= date("H:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->getHour->fri_to >= date("H:i:s"))
                                    && ($detail->getHour->fri_from <= date("H:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->getHour->sat_to >= date("H:i:s"))
                                    && ($detail->getHour->sat_from <= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->getHour->sun_to >= date("H:i:s"))
                                    && ($detail->getHour->sun_from <= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                ) 
                                <span class="open">    {{ __('message.open') }} </span>
                                @else
                                 <span class="close">         {{ __('message.close') }}</span>
                                    @endif
                                    @else
                                  <span class="close">        {{ __('message.close') }}</span>
                                 @endif
                                @else
                                <span class="close">   {{ __('message.close') }}</span>
                                @endif

                              <span class="doller">{{$detail->expensiveness}}</span>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-7">
                              <h6>{{ __('message.What we provide?') }}</h6>
                               <ul class="list-unstyled">
                                 @if($detail->takeout == 1)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt="">  {{ __('message.Takeout') }} </li>
                                 @elseif($detail->takeout == 0)
                                 <li class="s-disable"><img src="{{ asset('front/imgs/Takeout.png') }}" alt=""> {{ __('message.Takeout') }} </li>
                                 @endif
                                 @if($detail->home_delivery == 1)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> {{ __('message.Delivery') }} </li>
                                 @elseif($detail->home_delivery == 0)
                                 <li class="s-disable"><img src="{{ asset('front/imgs/Delivery.png') }}" alt="">{{ __('message.Delivery') }} </li>
                                 @endif
                              </ul>
                           </div>
                           <div class="col-5 text-end">
                              <a href="{{ route('restdetails',['id'=>$detail->restaurant_id]) }}" class="btn btn-primary">{{ __('message.Visit') }}</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               @endforeach   
            </div>
         </div>
      </section>
     

  
      <script src="{{ asset('front/js/jquery.min.js') }}" ></script>
<script type="text/javascript">
$(document).ready(function () {

$('#Profile-tab').click(function(){
   $('html, body').animate({
        scrollTop: $('#Profile').offset().top -100
   }, 'slow');
});

$('#Menu_List-tab').click(function(){
   $('html, body').animate({
        scrollTop: $('#Menu_List').offset().top -100
   }, 'slow');
});

$('#Restaurant-tab').click(function(){
   $('html, body').animate({
        scrollTop: $('#contact-tab').offset().top -100
   }, 'slow');
});

$('#Notes-tab').click(function(){
    $('html, body').animate({
        scrollTop: $('#notes').offset().top -100 
    }, 'slow');
});

$('#Chef-tab').click(function(){
    $('html, body').animate({
        scrollTop: $('#Chef').offset().top -100 
    }, 'slow');
});

// $(function() {
//       $('.pop').on('click', function() {
//          $('.imagepreview').attr('src', $(this).find('img').attr('src'));
//          $('#selesct-modal').modal('show');   
//       });      
// });

// $('#closemodal').click(function() {
//     $('#selesct-modal').modal('hide');
// });

});
</script>

<script type="text/javascript">
       // Gallery image hover
$( ".img-wrapper" ).hover(
  function() {
    $(this).find(".img-overlay").animate({opacity: 1}, 600);
  }, function() {
    $(this).find(".img-overlay").animate({opacity: 0}, 600);
  }
);

// Lightbox
var $overlay = $('<div id="overlay"></div>');
var $image = $("<img>");
var $prevButton = $('<div id="prevButton"><i class="fa fa-chevron-left"></i></div>');
var $nextButton = $('<div id="nextButton"><i class="fa fa-chevron-right"></i></div>');
var $exitButton = $('<div id="exitButton"><i class="fa fa-times"></i></div>');

// Add overlay
$overlay.append($image).prepend($prevButton).append($nextButton).append($exitButton);
$("#gallery").append($overlay);

// Hide overlay on default
$overlay.hide();

// When an image is clicked
$(".img-overlay").click(function(event) {
  // Prevents default behavior
  event.preventDefault();
  // Adds href attribute to variable
  var imageLocation = $(this).prev().attr("href");
  // Add the image src to $image
  $image.attr("src", imageLocation);
  // Fade in the overlay
  $overlay.fadeIn("slow");
});

// When the overlay is clicked
$overlay.click(function() {
  // Fade out the overlay
  $(this).fadeOut("slow");
});

// When next button is clicked
$nextButton.click(function(event) {
  // Hide the current image
  $("#overlay img").hide();
  // Overlay image location
  var $currentImgSrc = $("#overlay img").attr("src");
  // Image with matching location of the overlay image
  var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
  // Finds the next image
  var $nextImg = $($currentImg.closest(".image").next().find("img"));
  // All of the images in the gallery
  var $images = $("#image-gallery img");
  // If there is a next image
  if ($nextImg.length > 0) { 
    // Fade in the next image
    $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
  } else {
    // Otherwise fade in the first image
    $("#overlay img").attr("src", $($images[0]).attr("src")).fadeIn(800);
  }
  // Prevents overlay from being hidden
  event.stopPropagation();
});

// When previous button is clicked
$prevButton.click(function(event) {
  // Hide the current image
  $("#overlay img").hide();
  // Overlay image location
  var $currentImgSrc = $("#overlay img").attr("src");
  // Image with matching location of the overlay image
  var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
  // Finds the next image
  var $nextImg = $($currentImg.closest(".image").prev().find("img"));
  // Fade in the next image
  $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
  // Prevents overlay from being hidden
  event.stopPropagation();
});

// When the exit button is clicked
$exitButton.click(function() {
  // Fade out the overlay
  $("#overlay").fadeOut("slow");
});
</script>
 @endsection