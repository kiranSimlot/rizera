@extends('restaurant-layout.restaurant-layout')
   
   <!-- header -->
   @include('restaurant-layout.restaurant-black-header')
   <!-- end off header -->

@section('content')

<div class="body_bg" style="background-image: url(front/imgs/body_bg.png);">
   <section class="RequestApp-form" style="background-image: url(front/imgs/form-bg-2.svg);">
      <div class="container">
         <div class="row">
             <div class="col-md-6">
                <h2>{{ __('message.Request a demo of Rizera App') }}</h2>
                <p>{{ __('message.Want to see how Rizera App can help you and your 
                  business? Fill out the form and get a demo from one our 
                  restaurant tech experts.') }}'
                  </p>
                  <div class="YouTube-Player">
                     <img src="{{ asset('front/imgs/YouTube-Player.png') }}" alt="" class="img-fluid">
                  </div>
                   </div>

                   <div class="col-md-6">
                  @if(session()->has('message'))
                      <div class="alert alert-success">
                          {{ session()->get('message') }}
                      </div>
                  @endif
                      <div class="form-bg" style="background-image: url(front/imgs/form_bg.svg);">
                      <div class="form-demo">
                          <h3>{{ __('message.Let’s talk') }}</h3>
                          <p>{{ __('message.Amet minim mollit non deserunt ullamco est sit.') }}</p>
                     <form action="{{ route('demoStore') }}" method="post">
                     @csrf
                     <div class="form-group">
                        <label>{{ __('message.First name') }}<span style="color: red">*</span></label>
                        <input type="text" name="first_name" class="form-control" onKeyPress="return ValidateAlpha(event);" value="{{old('first_name')}}">
                        @error('first_name')
                        <div class="error-box" style="color: red">{{__('message.First name is required') }}</div>
                        @enderror
                     </div>
                     <div class="form-group">
                        <label>{{ __('message.Last name') }}<span style="color: red">*</span></label>
                        <input type="text" name="last_name" class="form-control" onKeyPress="return ValidateAlpha(event);"  value="{{old('last_name')}}">
                        @error('last_name')
                        <div class="error-box" style="color: red">{{__('message.Last name is required') }}</div>
                        @enderror
                     </div>
                     <div class="form-group code">
                        <label>{{ __('message.Mobile') }}<span style="color: red">*</span></label>
                        <div class="code-in">
                           <div class="code">
                            <select name="country_code">
                               <option value="+965">+965</option>
                               <option value="+212">+212</option>
                            </select>
                           </div>
                       <div class="in">
                       
                        <input type="text" name="mobile_no" class="form-control" onkeypress="return isNumberKey(event)"  value="{{old('mobile_no')}}">
                       </div>
                     </div>
                        @error('mobile_no')
                        <div class="error-box" style="color: red">{{__('message.Mobile Number is required') }}</div>
                        @enderror
                        @error('country_code')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                     </div>
                     <div class="form-group">
                        <label>{{ __('message.Email') }}<span style="color: red">*</span></label>
                        <input type="text" name="email" class="form-control"  value="{{old('email')}}">
                        @error('email')
                        <div class="error-box" style="color: red">{{__('message.Email is required') }}</div>
                        @enderror
                     </div>
                     <div class="form-group">
                        <label>{{ __('message.Restaurant name') }}<span style="color: red">*</span></label>
                        <input type="text" name="restaurant_name" class="form-control"  value="{{old('restaurant_name')}}">
                        @error('restaurant_name')
                        <div class="error-box" style="color: red">{{__('message.Restaurant name is required') }}</div>
                        @enderror
                     </div>
                     <div class="form-group">
                        <button type="submit" value="submit" class="btn btn-black">{{ __('message.Submit') }}</button>
                     </div>
                   </div>
                  </div>
                  </div>
            </div>
            </div>
   </section>
   
      
<!-- guest experience -->
<section class="available-of-experience" >
   <div class="container">
       <h4>{{ __('message.Join') }} <b>{{ __('message.3,000+ restaurants') }} </b> {{ __('message.in 50 countries using') }} <b>{{ __('message.Rizera') }}</b> {{ __('message.to') }} <br>
         {{ __('message.improve the guest experience.') }}</h4>
         <div class="line">
            <svg width="259" height="7" viewBox="0 0 259 7" fill="none" xmlns="http://www.w3.org/2000/svg">
               <rect x="132" y="3" width="127" height="1" fill="url(#paint0_linear)"/>
               <rect y="3" width="127" height="1" fill="url(#paint1_linear)"/>
               <circle cx="129.5" cy="3.5" r="3" stroke="#C4C4C4"/>
               <defs>
               <linearGradient id="paint0_linear" x1="130.5" y1="3.99995" x2="259" y2="3.99989" gradientUnits="userSpaceOnUse">
               <stop stop-color="#C4C4C4"/>
               <stop offset="1" stop-color="#C4C4C4" stop-opacity="0"/>
               </linearGradient>
               <linearGradient id="paint1_linear" x1="-1.5" y1="3.99995" x2="127" y2="3.99989" gradientUnits="userSpaceOnUse">
               <stop stop-color="#C4C4C4" stop-opacity="0"/>
               <stop offset="1" stop-color="#C4C4C4"/>
               </linearGradient>
               </defs>
               </svg>
                  
         </div>

         <div class="available-of-experience_slider">
            <div class="item">
               <img src="{{ asset('front/imgs/logo_1.svg') }}" alt="" class="img-fluid">
            </div>
            <div class="item">
               <img src="{{ asset('front/imgs/logo_2.svg') }}" alt="" class="img-fluid">
            </div>
            <div class="item">
               <img src="{{ asset('front/imgs/logo_3.svg') }}" alt="" class="img-fluid">
            </div>
            <div class="item">
               <img src="{{ asset('front/imgs/logo_4.svg') }}" alt="" class="img-fluid">
            </div>
            <div class="item">
               <img src="{{ asset('front/imgs/logo_5.svg') }}" alt="" class="img-fluid">
            </div>
            <div class="item">
               <img src="{{ asset('front/imgs/logo_6.svg') }}" alt="" class="img-fluid">
            </div>
         </div>
         </div>
         </section>
 <!-- end of guest experience -->


   <!-- end Learn more through our case studies -->
   <!-- What our clients say? -->
     <div class="clients-say" style="background-image: url(imgs/say_bg.svg);">
        <div class="container">
           <div class="row">
              <h2 class="text-center">{{ __('message.What our clients say?') }}</h2>

              <div class="clients_say">
                 <div class="item">
                    <div class="card">
                       <div class="user">
                          <img src="{{ asset('front/imgs/user_1.png') }}" alt="" />
                       </div>
                       <div class="card-body">
                          <p>{{ __('message.Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt.') }}</p>
                        <h5>Courtney Henry</h5>
                        <h6>General Manager, Taj Hotal</h6>
                        </div>
                      
                    </div>
                 </div>
                 <div class="item">
                  <div class="card">
                     <div class="user">
                        <img src="{{ asset('front/imgs/user_1.png') }}" alt="" />
                     </div>
                     <div class="card-body">
                        <p>{{ __('message.Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt.') }}</p>
                      <h5>Courtney Henry</h5>
                      <h6>General Manager, Taj Hotal</h6>
                      </div>
                    
                  </div>
               </div>
              </div>
              <div class="text-center">
                 <p class="see-all">{{ __('message.See all') }} <b><a href="">{{ __('message.150+ Reviews') }} </a></b> {{ __('message.by top brands') }}...</p>
              </div>
           </div>
        </div>
     </div>

   <!-- end What our clients say? -->
@endsection

<script type="text/javascript">
   
   function isNumberKey(evt){  
    //var e = evt || window.event;
   var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
   && (charCode < 48 || charCode > 57))
        return false;
        return true;
   }
         
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }

</script>