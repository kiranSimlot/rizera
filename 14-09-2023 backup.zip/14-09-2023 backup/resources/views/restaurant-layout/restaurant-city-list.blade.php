      <section class="explore-location">
         <div class="container">
            <h2 class="text-center">
               <span>
                  {{ __('message.Explore by top Locations') }}
                  <svg width="173" height="25" viewBox="0 0 173 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M173 11.4083V12.202C172.852 17.5591 170.476 23.3131 168.842 25.0988C166.912 18.452 155.18 16.6662 141.815 16.4678C135.876 16.4678 129.787 16.6662 123.996 17.0631C74.8429 19.7416 4.00944 32.1424 0 11.2099V7.04323V6.94403C0.148498 13.3924 9.65236 17.4599 21.6807 18.0551C38.3124 18.8488 59.8446 14.4837 70.982 12.1028C90.4352 7.93609 118.204 1.58688 141.964 0.197995C150.28 -0.298037 158.15 -0.0996239 164.833 0.991646C170.921 2.08292 173 6.5472 173 11.4083Z" fill="#FCCC00"/>
                  </svg>
               </span>
            </h2>
            <div class="row">
               @foreach($city as $key=>$cities)
               <div class="col-md-4 col-lg-3 col-xl-2">
                  <div class="card border-0">
                     <div class="icon">
                        <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">
                           <img class="card-img-top" src="asset('storage').'/'.$cities->city_image" alt="Card image cap">
                        </a>
                        <div class="hover">
                           <div class="hover-c">
                              <div>
                                 <span>{{$cities->city_name}}</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <a href="{{ route('listofcityrest',['id'=>$cities->id]) }}">
                     <h4>{{$cities->city_name}}</h4></a>
                  </div>
               </div>
               @endforeach
            </div>
         </div>
      </section>