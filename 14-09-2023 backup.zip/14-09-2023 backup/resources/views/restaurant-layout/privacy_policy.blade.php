@extends('restaurant-layout.restaurant-layout-informative')


   <!-- header content -->
      @include('restaurant-layout.restaurant-black-header')
   <!-- /header content -->
   @section('content')
   <section class="restaurant_online_top">
         <div class="container">
           <h2 class="text-center">
            @if( Session()->get('locale') == 'ara')
                              سياسة خاصة
                              @elseif(Session::get('locale') == 'fr')
                              Politique de confidentialité
                              @else
                              Privacy Policy
                              @endif
           
        </h2>
    @php echo htmlspecialchars_decode($cms->content) @endphp
         </div>
   </section>
@endsection

