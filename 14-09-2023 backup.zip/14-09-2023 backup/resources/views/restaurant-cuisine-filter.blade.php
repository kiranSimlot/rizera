@extends('layouts.front')

@section('content')  
  <div class="bg-grey-light">
   <div class="container mt-4 popular-restaurants">
      <div class="row">
         @if(count($restaurants)>0)
            @foreach($restaurants as $key =>$detail)
               <div class="col-lg-6 col-xl-4 col-md-6">
                  <div class="card restaurant">

                     <a href="{{ route('restdetails',['id'=>$detail->id]) }}">
                     <div class="card-img">
                      <!--   <div class="hart">
                           <img src="{{ asset('front/imgs/heart.png') }}" alt="">
                        </div> -->
                       <!--  <img src="{{ asset('front/imgs/item.png') }}" alt="" class="w-100"> -->

                         @if(!empty($detail->images[0]))
                        <img src="{{  asset('storage').'/'.$detail->images[0]->image }}" alt="" class="w-100 store-cover">
                        @else
                       <img src="{{ asset('front/imgs/placeholder.png') }}" alt="" class="w-100 store-cover">
                       @endif
                         <div class="card-img-overly">
                           <div class="left"> 
                               <span class="American"><img src="{{ asset('front/imgs/American.png') }}" alt="">    
                                  @foreach($detail->getCuisine as $cuisine)
                                    @if( Session()->get('locale') == 'ara' && $cuisine->Cuisine['name_ar']!="")
                                    {{$cuisine->Cuisine['name_ar']}}
                                    @elseif(Session::get('locale') == 'fr' && $cuisine->Cuisine['name_fr']!="")
                                    {{$cuisine->Cuisine['name_fr']}}
                                    @else
                                    {{$cuisine->Cuisine['name']}}
                                    @endif
                                  @endforeach
                               </span>
                              </div>

                               <div class="right f-right">
                                 @if($detail->verified == 1)
                              @if( Session()->get('locale') == 'ara' )
                                    <img src="{{ asset('front/imgs/verified_ara.png') }}" alt="">
                                    @elseif(Session::get('locale') == 'fr' )
                                   <img src="{{ asset('front/imgs/verified_fr.png') }}" alt="">
                                    @else
                                     <img src="{{ asset('front/imgs/Verified.png') }}" alt="">
                                    @endif
                              
                               @endif
                               <span class="Star"><img src="{{ asset('front/imgs/Star.png') }}" alt="">{{$detail->rating}}</span>
                               </div>
                        </div>
                     </div>
                   </a>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-7">
                              @if( Session()->get('locale') == 'ara' &&  $detail->ar_name!="")
                              <h3 class="fifty-chars">{{$detail->ar_name}}</h3>
                              @elseif(Session::get('locale') == 'fr' && $detail->fr_name!="")
                              <h3 class="fifty-chars">{{$detail->fr_name}}</h3>
                              @else
                               <h3 class="fifty-chars">{{$detail->name}}</h3>
                              @endif
                              <p class="fifty-chars">{{$detail->address}}</p>
                           </div>
                           <div class="col-5 text-end">
                         

                              {{-- open/close --}}
                                    
                             <?php    $today_date = date('Y-m-d'); ?>
                              {{-- open/close --}}
                    
                                 @if( isset($detail->mon_to)  && (!in_array($today_date, $detail->holidaydate)))
                              @if((($detail->mon_to >= date("H:i:s")) 
                                    && ($detail->mon_from <= date("H:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->tue_to >= date("H:i:s")) 
                                    && ($detail->tue_from <= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->wed_to >= date("H:i:s")) 
                                    && ($detail->wed_from <= date("H:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->thu_to >= date("H:i:s"))
                                    && ($detail->thu_from <= date("H:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->fri_to >= date("H:i:s"))
                                    && ($detail->fri_from <= date("H:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->sat_to >= date("H:i:s"))
                                    && ($detail->sat_from <= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->sun_to >= date("H:i:s"))
                                    && ($detail->sun_from <= date("H:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                ) 
                                 <span class="open">    {{ __('message.open') }} </span>
                                @else
                                 <span class="close">         {{ __('message.close') }}</span>
                                    @endif
                                    @else
                                  <span class="close">        {{ __('message.close') }}</span>
                                 @endif
                       

                              <span class="doller">{{$detail->expensiveness}}</span>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-7">
                              <h6>{{ __('message.What we provide?') }}</h6>
                                 <ul class="list-unstyled">
                                 @if($detail->takeout == 1)
                                 <li><img src="{{ asset('front/imgs/Takeout.png') }}" alt=""> {{ __('message.Takeout') }} </li>
                                 @elseif($detail->takeout == 0)
                                 <li class="s-disable"><img src="{{ asset('front/imgs/Takeout.png') }}" alt="">{{ __('message.Takeout') }} </li>
                                 @endif
                                 @if($detail->home_delivery == 1)
                                 <li><img src="{{ asset('front/imgs/Delivery.png') }}" alt=""> {{ __('message.Delivery') }}  </li>
                                 @elseif($detail->home_delivery == 0)
                                 <li class="s-disable"><img src="{{ asset('front/imgs/Delivery.png') }}" alt="">{{ __('message.Delivery') }}  </li>
                                 @endif
                              </ul>
                           </div>
                           <div class="col-5 text-end">
                              <a href="{{ route('restdetails',['id'=>$detail->id]) }}" class="btn btn-primary"> {{ __('message.Visit') }} </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            @endforeach
            @else
            <h1 class="text-center no-restaurant">No Reastuarant Found</h1>
            @endif
        </div>
   </div>
      </div>
 @endsection 