@extends('layouts.admin')

    
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
{{--  <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b>Edit Category </b>
        </div>
    </div>
      <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem; border-radius:5px;">

            <form method="post" action="{{ route('admin.category.update',$category->id) }}">
                @csrf
				<label for="name" class="form-label">Name</label>
 				<input type="text" name="name" value="{{$category->name}}" class="form-control" id="exampleFormControlInput1" placeholder="Category Name" required />
                <br>
 				 <button type="submit" class="btn btn-primary" value="submit">Update</button>
            </form>
    	</div>
    </div> --}}
    {{--  --}}
      <div class="row">
        <div class="col-md-12 col-sm-12 ">
            <a href="{{Route('admin.category.category')}}" class="btn btn-primary">Back</a>
            <div class="x_panel">
                <div class="x_title">
                    <h2>Edit Category</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.category.updatecategory',$category->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">New Category <span class="required spanColor">*</span></label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="text" name="name" value="{{old('name', $category->name)}}" id="name" class="form-control ">
                        @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                    </div>
                </div>
                <div class="ln_solid"></div>
                <div class="item form-group">
                    <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" class="btn btn-success" value="submit">Update</button>
                    </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>
@endsection