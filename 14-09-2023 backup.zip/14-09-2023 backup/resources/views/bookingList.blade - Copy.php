@extends('layouts.default')   
@section('content')

<div class="container-fluid">
    <div class="fix-width">
        @include('layouts.floor_management_left_menu')
        <main role="main" class="main-box">
          <div class="container">
            <div style="padding-top:1rem; padding-bottom:1rem;">
              <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b> {{ __('owner.Booking') }}</b>
             </div>
            </div>
          </div>

        <div class="col" role="main">
          <div class="">
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="row">
                  <div class="input-group mb-3">
         

<select name="date_type" id="date_type" class="form-control" onchange="show_hide();">
<option value="">Select</option>
<option value="today">Today</option>
<option value="week">Weekly</option>
<option value="month">Monthly</option>
<option value="date">Date Range</option>
</select>
	 
<!--<button class="btn btn-outline-secondary" type="button" id="search_daily">Today</button>-->

<div id="week_input">
<input type="week" id="week" placeholder="Week" name="week" min="2017-W01" class="form-control">
</div>

<div id="month_input">
<input type="month" id="month" placeholder="Month" name="month" max="{{date('Y-m')}}" min="1970-01" class="form-control" >
</div>

<div id="date_input">
<input class="form-control" type="date" name="from_date" id="from_date" required="">
<input class="form-control" type="date" name="to_date" id="to_date" required="">
</div>

<select name="status" id="status" class="form-control">
<option value="">Status</option>
<option value="0">Pending</option>
<option value="1">Confirm</option>
<option value="2">Cancelled</option>
<option value="3">Denied</option>
</select>

<select name="tag_id" id="tag_id" class="form-control">
<option value="">Tag</option>
@foreach  ($tags as $key => $value)
<option value="{{$key}}">{{$value}}</option>
@endforeach
</select>

<select name="category_id" id="category_id" class="form-control">
<option value="">Category</option>
@foreach  ($categories as $key => $value)
<option value="{{$key}}">{{$value}}</option>
@endforeach
</select>

         
		            <div class="input-group-append">
                      <button class="btn btn-outline-secondary" type="button" id="search">search</button>
                    </div>
                  </div>
                </div>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Booking List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive subscription-list">
							<div id="newSearchPlace"></div>
                            <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                              <thead>
                                <tr>
                                    <th>Id</th>
		                            <th>Restaurant</th>
                                    <th>User</th>
                                    <th>Category</th>
                                    <th>Tag</th>
                                    <th>Status</th>
                                    <th>Booking Date</th>
									<!--<th>Created Date</th>-->
                                </tr>
                              </thead>
                              <tbody>
                              </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
</main>
</div>
</div>

<style type="text/css">
.subscription-list .dt-buttons.btn-group {
    float: left;
}
.subscription-list div#datatable_length {
    float: right;
}
.subscription-list div#datatable_filter {
    float: right;
    margin-right: 20px;
}
.subscription-list a.btn.btn-default {
    font-size: 12px;
    font-weight: 500;
    border: 1px solid #dee2e6;
    background: rgba(0,0,0,.05);
}
</style>

<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>

<script type="text/javascript">

$('#week_input').hide();
$('#month_input').hide();
$('#date_input').hide();

function show_hide()
{
     var date_type = $('#date_type :selected').val();

	 if(date_type == 'today')
	  {
	    $('#week_input').hide();
		$('#month_input').hide();
		$('#date_input').hide();
	  } 
	  
     if(date_type == 'week')
	  {
	    $('#week_input').show();
		$('#month_input').hide();
		$('#date_input').hide();
	  } 
	  
	  if(date_type == 'month')
	  {
	    $('#week_input').hide();
		$('#month_input').show();
		$('#date_input').hide();
	  } 
	  
	  if(date_type == 'date')
	  {
	    $('#week_input').hide();
		$('#month_input').hide();
		$('#date_input').show();
	  }
}

$(document).ready(function() {

    data();

    $("#search").click(function() {
      data();
    });
	
    /*$("#search_daily").click(function() {
      
      $('#datatable').DataTable().clear().destroy();
      
	  var daily = 'today';
      var month = '';
      var week = '';
      var status = '';
      var tag_id = '';
      var category_id = '';
	  var from_date = '';
	  var to_date = '';
	  
      $('#datatable').DataTable({
	       "dom": 'Blfrtip',
           // "pageLength": 5,
           "buttons": ['csv','excel','print','pdf'],
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('owner.restaurant.ownerBookingListfn') !!}',
             data : {"_token": "{{ csrf_token() }}",daily:daily,month:month,week:week,status:status,tag_id:tag_id,category_id:category_id,from_date:from_date,to_date:to_date}
           },
           "columns": [
              {data:'id', name:'id'},
              {data:'restaurant', name:'restaurant'},
              {data:'user', name:'user'},
              {data:'category', name:'category'},
              {data:'tag', name:'tag'},
              {data:'status', name:'status'},
              {data:'booking_date', name:'booking_date'},
			  <!--{data:'created_date', name:'created_date'},-->
           ]
       });
    
    });*/

    function data (){
      $('#datatable').DataTable().clear().destroy();
      
	   var daily = '';
	   var week = '';
	   var month = '';
	   var from_date = '';
	   var to_date = '';
	   
	  var date_type = $('#date_type :selected').val();
	  
	  if(date_type == 'today')
	  {
	   var daily = 'today';
	  } 
	  
	  if(date_type == 'week')
	  {
	   var week = $('#week').val();
	  } 
	  
	  if(date_type == 'month')
	  {
	   var month = $('#month').val();
	  } 
	  
	  if(date_type == 'date')
	  {
	   var from_date = $('#from_date').val();
	   var to_date = $('#to_date').val();
	  } 
	  
      
	  var status = $('#status').val();
      var tag_id = $('#tag_id').val();
      var category_id = $('#category_id').val();
	  
	  
      $('#datatable').DataTable({
	       "dom": 'Blfrtip',
           // "pageLength": 5,
           "buttons": ['csv','excel','print','pdf'],
           "processing": true,
           "serverSide": true,
           "ajax":{
             url:'{!! route('owner.restaurant.ownerBookingListfn') !!}',
             data : {"_token": "{{ csrf_token() }}",daily:daily,month:month,week:week,status:status,tag_id:tag_id,category_id:category_id,from_date:from_date,to_date:to_date}
           },
           "columns": [
              {data:'id', name:'id'},
              {data:'restaurant', name:'restaurant'},
              {data:'user', name:'user'},
              {data:'category', name:'category'},
              {data:'tag', name:'tag'},
              {data:'status', name:'status'},
              {data:'booking_date', name:'booking_date'},
			  <!--{data:'created_date', name:'created_date'},-->
           ]
       });
    }
		
});

</script>

@endsection