@extends('layouts.default')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">
                <b> Restaurants </b>
                <div style="float:right;">
                    @if(Auth::user()->type != 1)
                    <a href="{{url('restaurant/add')}}" class="btn btn-primary btn-sm">Add Restaurant</a>
                    @endif
                </div>
        </div>
    </div>
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem; border-radius:5px;">

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th> 
                        @if(Auth::user()->type == 1)
                            <th scope="col">Name</th>
                        @endif 
                    </tr>
                </thead>
                <tbody>
                    @foreach($cuisine_types as $key =>$restaurant)
                    <tr>
                        <th scope="row">{{++$key}}</th>
                        <td>{{$restaurant->name}}</td> 
                        @if( Auth::user()->type == 1 )
                        <td>
                       <!--      <a href="{{url('cuisine_types/edit',$restaurant['id'])}}" class=" btn btn-sm btn-primary" >Edit</a>
                            <button class="btn btn-sm btn-danger" onclick="event.preventDefault(); if(confirm('Are you delete it.')){ document.getElementById('delete-form-{{$restaurant->id}}').submit();  } " >
                                Delete
                            </button>
                            <form id="delete-form-{{$restaurant->id}}" action="{{url('cuisine_types/delete',$restaurant->id)}}" method="post" style="display:none;">
                                @csrf
                                @method("DELETE")
                            </form> -->
                        </td>
                        @endif
                    </tr>
                    @endforeach 
                </tbody>
            </table>
            <div class="d-felx justify-content-center">
                {{$cuisine_types->links()}}
            </div>
    </div>
@endsection

