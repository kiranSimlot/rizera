@extends('layouts.default')

    
@section('content')
    
    <style type="text/css">
        .openinghours {
    font-family:Lucida Console;
    border-radius:4px;
    margin:10px;
    box-shadow: 0 0 10px black;
    padding:0 10px 0 10px;
    overflow: hidden;
    display: inline-block;
}
.openinghourscontent {
    float:left;
}
.openinghourscontent h2 {
    display:block;
    text-align:center;
    margin-top:.33em;
}
.openinghourscontent button {
    color:white;
    font-family:Courier New;
    font-size:large;
    font-weight:bolder;
    background-color:#4679BD;
    border-radius:4px;
    width:100%;
    margin-bottom:10px;
}
.today {
    color: #8AC007;
}
.opening-hours-table tr td:first-child {
    font-weight:bold;
}
#open-status {
    display:block;
    margin-top:-1em;
    text-align:center;
    border:dotted lightgrey 3px;
}
.openorclosed:after {
    content:" open during these hours:";
}
.open {
    color:green;
}
.open:after {
    content:" Open";
    color: #6C0;
}
.closed:after {
    content:" Closed";
    color: red;
}
.opening-hours-table tr td {
    padding:5px;
}
    </style>

   

    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">            
                @if(isset($restaurant->id) && $restaurant->id>0)
                    <b>Update Restaurant</b>
                @else
                    <b>Add Restaurant</b>
                @endif            
            <div style="float:right;">
                <a href="{{url('restaurants')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem;">
            <form action="{{ ( (isset($restaurant->id)&&$restaurant->id>0)? url('editrestaurant') :url('addrestaurant') ) }}" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    @csrf
                    <label for="exampleFormControlInput1" class="form-label">Name</label>
                    @if(isset($restaurant->id))
                    <input type="hidden" name="id" value="{{$restaurant->id}}">
                    <input type="hidden" name="delete_list" value="{{$restaurant->id}}">
                    <input type="hidden" name="restaurant_cuisine_types_saved" value="{{implode(',',$restaurantCuisineTypes)}}">
                    <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Restaurant Name" value="{{old('name')??$restaurant->name}}">
                    @else
                    <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Restaurant Name" value="{{old('name')}}">
                    @endif
                    @error('name')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Country</label>
                        <select name="country_id" id="country_id" class="form-select" aria-label="Default select example">
                            <option value="">Country</option>
                            @foreach($countries as $key=>$country)
                                @if(isset($restaurant->country_id) && $restaurant->country_id == $key)
                                    <option selected value="{{$key}}">{{$country}}</option>
                                @elseif(old('country_id')== $key)
                                    <option selected value="{{$key}}">{{$country}}</option>
                                @else 
                                    <option value="{{$key}}">{{$country}}</option>
                                @endif
                            @endforeach
                        </select>
                    @error('country_id')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>

                 <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">City</label>
                        <select name="city_id" id="city_id" class="form-select" aria-label="Default select example" >
                            <option value="">City</option>
                        </select>
                    @error('city_id')
                        <div class="error-box" >{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Cuisine Type</label>

                        <select name="cuisine_type_id[]" id="cuisine_type_id" class="form-select form-control chosen-select" aria-label="Default select example" multiple> 
                            @foreach($cuisineTypes as $key=>$cuisineType)
                                @if(in_array($key,$restaurantCuisineTypes))
                                    <option selected value="{{$key}}">{{$cuisineType}}</option>
                                @elseif(old('cuisine_type_id')== $key)
                                    <option selected value="{{$key}}">{{$cuisineType}}</option>
                                @else 
                                    <option value="{{$key}}">{{$cuisineType}}</option>
                                @endif
                            @endforeach
                        </select>
                    @error('cuisine_type_id')
                        <div class="error-box" >{{$message}}</div>
                    @enderror
                </div>
<!-- 
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Home Delivery</label>
                        <select name="home_delivery" id="home_delivery" class="form-select" aria-label="Default select example"> 
                                <option 
                                @if(isset($restaurant->home_delivery) && $restaurant->home_delivery == 1)
                                    selected 
                                @endif
                                value="1">Yes</option>
                                <option 
                                @if(isset($restaurant->home_delivery) && $restaurant->home_delivery == 0)
                                    selected 
                                @endif
                                value="0">No</option>
                                
                                @if(old('home_delivery'))
                                    @if(old('home_delivery') == 1)
                                    <option selected value="1">Yes </option>
                                    @elseif(old('home_delivery') == 0)
                                    <option selected value="0">No </option>
                                    @endif
                                @endif 
                        </select>
                    @error('home_delivery')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
 -->


                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Home Delivery available</label>
                           <select name="home_delivery" id="home_delivery" class="form-select form-control" aria-label="Default select example"> 
                            @foreach($homeDeliveryArray as $key=>$homeDelivery)
                                @if(isset($restaurant->home_delivery) && $key == $restaurant->home_delivery)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @elseif(old('home_delivery')== $key)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @else 
                                    <option value="{{$key}}">{{$homeDelivery}}</option>
                                @endif
                            @endforeach
                        </select>
                    @error('home_delivery')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>


                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Take-out facility available </label>
                           <select name="takeout" id="takeout" class="form-select form-control" aria-label="Default select example"> 
                            @foreach($homeDeliveryArray as $key=>$homeDelivery)
                                @if(isset($restaurant->takeout) && $key == $restaurant->takeout)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @elseif(old('takeout')== $key)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @else 
                                    <option value="{{$key}}">{{$homeDelivery}}</option>
                                @endif
                            @endforeach
                        </select>
                    @error('takeout')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>


                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Open status</label>
                           <select name="open_status" id="open_status" class="form-select form-control" aria-label="Default select example"> 
                            @foreach($openStatusArray as $key=>$homeDelivery)
                                @if(isset($restaurant->open_status) && $key == $restaurant->open_status)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @elseif(old('open_status')== $key)
                                    <option selected value="{{$key}}">{{$homeDelivery}}</option>
                                @else 
                                    <option value="{{$key}}">{{$homeDelivery}}</option>
                                @endif
                            @endforeach
                        </select>
                    @error('open_status')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>


               
                 <div class="mb-3">
                     <h4>Upload Photos</h4>
                     <div id="msg">
                     </div>
                     <div class="row">
                        <div class="col-md-3"> 
                           <input type="file" class="file" id="files" accept="image/*" name="images[]" multiple>
                            @error('images')
                            <div class="error-box">{{$message}}</div>
                            @enderror<br/> 
                            <br/>
                           </button>
                        </div>

                         @if(isset($restaurant->id))
                        <div class="col-md-9" id="new_images">
                           <div class="row">
                            @if(count($restaurant->getImages->where('doc_type',1)->where('image_type',1))>0)
                              <label><strong>Saved Images</strong></label>
                              @endif

                              @foreach($restaurant->getImages->where('doc_type',1)->where('image_type',1) as $key=>$val)
                              <div class="col-md-3">
                                  <div class="img-wrap">
                                    <span id="{{$val->id}}" style="height:85px; border: 2px solid; width: 100px;" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>  
                                    <img class="loaded image" style="height:85px; border: 2px solid; width: 100px;" id="image_{{$val->id}}" src="{{ asset('storage').'/'.$val->image}}" style="height: 85px;" >
                                 </div>
                              </div>
                              @endforeach 
                              <div id="selectedFiles" class="row">
                              </div>
                           </div>
                        </div>
                        @endif

                        <h4>Upload 360<span>&#176;</span> Photos</h4>
                        <div class="col-md-3"> 
                           <input type="file" class="file" id="files" name="images_360[]" accept="image/*" multiple>
                            @error('images_360')
                            <div class="error-box">{{$message}}</div>
                            @enderror<br/>  
                           </button>
                        </div>


                         @if(isset($restaurant->id))
                        <div class="col-md-9" id="new_images">
                           <div class="row">
                            @if(count($restaurant->getImages->where('doc_type',1)->where('image_type',2))>0)
                              <label><strong>Saved Images</strong></label>
                              @endif

                              @foreach($restaurant->getImages->where('doc_type',1)->where('image_type',2) as $key=>$val)
                              <div class="col-md-3">
                                  <div class="img-wrap">
                                    <span id="{{$val->id}}" style="height:85px; border: 2px solid; width: 100px;" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>  
                                    <img class="loaded image" style="height:85px; border: 2px solid; width: 100px;" id="image_{{$val->id}}" src="{{ URL::asset('storage').'/'.$val->image}}" style="height: 85px;" >
                                 </div>
                              </div>
                              @endforeach 
                              <div id="selectedFiles" class="row">
                              </div>
                           </div>
                        </div>
                        @endif
                        <br>
                        <br>
                        <br>


                        <h4>Upload Menu <span style="font-size: 16px;">*(only image and pdf are allowed)</span> </h4>
                        <div class="col-md-3"> 
                           <input type="file" class="file" id="files" name="menu_files[]" accept="image/*,application/pdf" multiple>
                           @error('menu_files')
                            <div class="error-box">{{$message}}</div>
                            @enderror<br/> 
                           </button>
                        </div>

                        @if(isset($restaurant->id))
                        <div class="col-md-9" id="new_images">
                           <div class="row">

                              @if(count($restaurant->getImages->where('doc_for',2))>0)
                              <label><strong>Saved Menu</strong></label>
                              @endif
                              @foreach($restaurant->getImages->where('doc_for',2) as $key=>$val)
                              <div class="col-md-3">
                                  <div class="img-wrap">
                                    <span id="{{$val->id}}" style="height:85px; border: 2px solid; width: 100px;" onclick="removeSavedImage(id);" class="close close-icon">&times;</span>   
                                    @if($val->doc_type == 2)
                                    <object  id="image_{{$val->id}}" data="{{URL::asset('storage').'/'.$val->image}}" type="application/pdf" width="100%" height="100%">
                                    {{URL::asset('storage').'/'.$val->image}}
                                    </object> 
                                    @elseif($val->doc_type == 1) 
                                    <img class="loaded image" style="height:85px; border: 2px solid; width: 100px;" id="image_{{$val->id}}" src="{{ URL::asset('storage').'/'.$val->image}}" style="height: 85px;" >
                                    @endif
                                 </div>
                              </div>
                              @endforeach 
                              <div id="selectedFiles" class="row">
                              </div>
                           </div>
                        </div>
                        @endif

                        <br>    
                        <br>
                        <section class="openinghours">
    <div class="openinghourscontent section">
        <div class="header">
             <h2>Opening hours</h2> 

        </div>
        <table class="opening-hours-table">
            <tr id="Monday" itemprop="openingHours" title="Open Monday at 9am to 6pm">
                <td>Monday</td>
                <td class="opens"><input type="time" name="monday_open_time" value="{{ isset($openingHours['mon_from']) ? $openingHours['mon_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="monday_close_time" value="{{ isset($openingHours['mon_to']) ? $openingHours['mon_to'] : '' }}"></td>
            </tr>
            <tr id="Tuesday" itemprop="openingHours" title="Open Tuesday at 9am to 6pm">
                <td>Tuesday</td>
                <td class="opens"><input type="time" name="tuesday_open_time" value="{{ isset($openingHours['tue_from']) ? $openingHours['tue_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="tuesday_close_time" value="{{ isset($openingHours['tue_to']) ? $openingHours['tue_to'] : '' }}"></td>
            </tr>
            <tr id="Wednesday" itemprop="openingHours" title="Open Wednesday at 9am to 6pm">
                <td>Wednesday</td>
                <td class="opens"><input type="time" name="wednesday_open_time" value="{{ isset($openingHours['wed_from']) ? $openingHours['wed_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="wednesday_close_time" value="{{ isset($openingHours['wed_to']) ? $openingHours['wed_to'] : '' }}"></td>
            </tr>
            <tr id="Thursday" itemprop="openingHours" title="Open Thursday at 9am to 8pm">
                <td>Thursday</td>
                <td class="opens"><input type="time" name="thursday_open_time" value="{{ isset($openingHours['thu_from']) ? $openingHours['thu_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="thursday_close_time" value="{{ isset($openingHours['thu_to']) ? $openingHours['thu_to'] : '' }}"></td>
            </tr>
            <tr id="Friday" itemprop="openingHours" title="Open Friday at 9am to 6pm">
                <td>Friday</td>
                <td class="opens"><input type="time" name="friday_open_time" value="{{ isset($openingHours['fri_from']) ? $openingHours['fri_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="friday_close_time" value="{{ isset($openingHours['fri_to']) ? $openingHours['fri_to'] : '' }}"></td>
            </tr>
            <tr id="Saturday" itemprop="openingHours" title="Open Saturday at 10am to 6pm">
                <td>Saturday</td>
                <td class="opens"><input type="time" name="saturday_open_time" value="{{ isset($openingHours['sat_from']) ? $openingHours['sat_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="saturday_close_time" value="{{ isset($openingHours['sat_to']) ? $openingHours['sat_to'] : '' }}"></td>
            </tr>
            <tr id="Sunday" itemprop="openingHours" title="Open Sunday at 11am to 4pm">
                <td>Sunday</td>
                <td class="opens"><input type="time" name="sunday_open_time" value="{{ isset($openingHours['sun_from']) ? $openingHours['sun_from'] : '' }}"></td>
                <td>-</td>
                <td class="closes"><input type="time" name="sunday_close_time" value="{{ isset($openingHours['sun_to']) ? $openingHours['sun_to'] : '' }}"></td>
            </tr>
        </table> 
        <script>
            (function(e, t, n, r) {
                if (e) return;
                t._appt = true;
                var i = n.createElement(r),
                    s = n.getElementsByTagName(r)[0];
                i.async = true;
                i.src = '//dje0x8zlxc38k.cloudfront.net/loaders/s-min.js';
                s.parentNode.insertBefore(i, s)
            })(window._appt, window, document, "script")
        </script>
    </div>
</section>




                     </div>
                  </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">
                        @if(isset($restaurant->id) && $restaurant->id>0)
                            Update Restaurant
                        @else
                            Add Restaurant
                        @endif
                    </button>
                </div>
            </form>
        </div>
    </div>


    <script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>

<script type="text/javascript">

     $(".chosen-select").chosen({
  no_results_text: "Oops, nothing found!"
});



      function removeSavedImage(id) {
      var image_id = id; 
      var delete_list = [];
      
      if (!delete_list.includes(image_id)) {    
      delete_list.push(image_id);

      var delete_list_string = $('input[name=delete_list]').val();
      
      $('input[name=delete_list]').val(delete_list_string + ',' + image_id);
      }
     $('#image_'+image_id).parent().remove(); 
             
    } 


    $(document).ready(function ()
    {
        $('select[name="country_id"]').on('change',function(){
            var countryId = jQuery(this).val();
            if(countryId)
            {
                getCity(countryId);
            }
            else
            {
               $('select[name="city_id"]').empty();
            }
        });
    });
    @if( isset($restaurant->id) && $restaurant->id>0) 
        getCity({{$restaurant->country_id}},{{$restaurant->city_id}});
    @endif
    function getCity(countryId,cityId=0){
        jQuery.ajax({
            url : "{{ url('dropdown/getCity/') }}/"+countryId,
            type : "GET",
            dataType : "json",
            success:function(data)
            {
                console.log(data);
                jQuery('select[name="city_id"]').empty();
                $('select[name="city_id"]').append('<option value="">City</option>');
                jQuery.each(data, function(key,value){
                    if(cityId==key)
                    $('select[name="city_id"]').append('<option selected value="'+ key +'">'+ value +'</option>');
                    else
                    $('select[name="city_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                });
            }
        });
    }






    
</script>


@endsection

