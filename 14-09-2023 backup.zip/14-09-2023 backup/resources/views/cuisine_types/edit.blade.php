@extends('layouts.default')

    
@section('content')
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1rem; border-radius:5px;">            
                @if(isset($staff->id) && $staff->id>0)
                    <b>Updae Restaurant</b>
                @else
                    <b>Add Restaurant</b>
                @endif            
            <div style="float:right;">
                <a href="{{url('restaurants')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <div style="padding-top:1rem; padding-bottom:1rem;">
        <div class="bg-white" style="padding:1.5rem;">
            <form action="{{ ( (isset($staff->id)&&$staff->id>0)? url('editrestaurant') :url('addrestaurant') ) }}" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    @csrf
                    <label for="exampleFormControlInput1" class="form-label">Name</label>
                    @if(isset($staff->id) && $staff->id>0)
                        <input type="hidden" name="id" value="{{$staff->id}}">
                    @endif

                    @if(old('name'))
                        <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Restaurant Name" value="{{old('name')}}">
                    @elseif(isset($staff->name) )
                        <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Restaurant Name" value="{{$staff->name}}">
                    @else
                        <input type="text" name="name"  class="form-control" id="exampleFormControlInput1" placeholder="Restaurant Name" value="">
                    @endif
                    @error('name')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Country</label>
                        <select name="country_id" id="country_id" class="form-select" aria-label="Default select example">
                            <option value="">Country</option>
                            <option value="1">Kuwait</option>
                            <option value="2">Morocco</option>
                        </select>
                    @error('country_id')
                        <div class="error-box">{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">City</label>
                        <select name="city_id" id="city_id" class="form-select" aria-label="Default select example" >
                            <option value="">City</option>
                        </select>
                    @error('city_id')
                        <div class="error-box" >{{$message}}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">
                        @if(isset($staff->id) && $staff->id>0)
                            Update Restaurant
                        @else
                            Add Restaurant
                        @endif
                    </button>
                </div>
            </form>
        </div>
    </div>
<script type="text/javascript">
    $(document).ready(function ()
    {
        $('select[name="country_id"]').on('change',function(){
            var countryId = jQuery(this).val();
            if(countryId)
            {
                jQuery.ajax({
                    url : "http://localhost/rizera/public/dropdown/getCity/"+countryId,
                    type : "GET",
                    dataType : "json",
                    success:function(data)
                    {
                        console.log(data);
                        jQuery('select[name="city_id"]').empty();
                        $('select[name="city_id"]').append('<option value="">City</option>');
                        jQuery.each(data, function(key,value){
                            $('select[name="city_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }
            else
            {
               $('select[name="city_id"]').empty();
            }
        });
    });
</script>

@endsection

