                        @if( isset($detail->getHour->mon_to) )
                            @if((($detail->getHour->mon_to <= date("h:i:s")) 
                                    && ($detail->getHour->mon_from >= date("h:i:s")) 
                                    && ('Monday' == date("l"))
                                )
                                || (($detail->getHour->tue_to <= date("H:i:s")) 
                                    && ($detail->getHour->tue_from >= date("H:i:s")) 
                                    && ('Tuesday' == date("l"))
                                  ) 
                                || (($detail->getHour->wed_to <= date("h:i:s")) 
                                    && ($detail->getHour->wed_from >= date("h:i:s"))
                                    && ('Wednesday' == date("l"))
                                  )
                                || (($detail->getHour->thu_to <= date("h:i:s"))
                                    && ($detail->getHour->thu_from >= date("h:i:s"))
                                    && ('Thursday' == date("l"))
                                  )
                                || (($detail->getHour->fri_to <= date("h:i:s"))
                                    && ($detail->getHour->fri_from >= date("h:i:s"))
                                    && ('Friday' == date("l"))
                                  )
                                || (($detail->getHour->sat_to <= date("h:i:s"))
                                    && ($detail->getHour->sat_from >= date("h:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                || (($detail->getHour->sun_to <= date("h:i:s"))
                                    && ($detail->getHour->sun_from >= date("h:i:s"))
                                    && ('Saturday' == date("l"))
                                  )
                                ){
                                <span class="badge badge-pill badge-danger"> Open </span>
                                }@else{
                                <span class="badge badge-pill badge-danger"> Close </span>
                            }
                            @endif
                        @endif
////////
owners.blade.php file data
            <tbody>
                @foreach($owners as $key =>$owner)
                <tr class="even pointer">
                <th scope="row">{{++$key}}</th>
                <td>{{ Str::ucfirst($owner['name'])}}</td>
                <td>{{$owner['email']}}</td>
                <td>{{$owner['created_at']}}</td>
                <td>
                @if($owner->status==2)
                <button type="button" class="btn btn-warning btn-sm " onclick="event.preventDefault(); document.getElementById('status-form-{{$owner->id}}').submit();">Disable</button>
                @else
                <button type="button" class="btn btn-primary btn-sm " onclick="event.preventDefault(); document.getElementById('status-form-{{$owner->id}}').submit();">Enable</button>
                @endif
                <form id="status-form-{{$owner['id']}}" action="{{url('statusChange',$owner['id'])}}" method="post" style="display:none;">
                    @csrf
                    @method("PUT")
                </form>
                <button type="button" class="btn btn-sm btn-danger" onclick="event.preventDefault(); if(confirm('Are you sure to delete id.')){ document.getElementById('delete-form-{{$owner->id}}').submit(); }">Delete</button>
                <form id="delete-form-{{$owner['id']}}" action="{{url('destroy',$owner['id'])}}" method="post" style="display:none;">
                    @csrf
                    @method("DELETE")
                </form>
                </td>
                </tr>
                @endforeach
            </tbody>

                   <div class="d-felx justify-content-center">
            {{ $owners->links() }}
            <p>Displaying {{$owners->count()}} of {{ $owners->total() }} Owner(s).</p>
        </div>
                   @foreach($country as $value)
        @if($countryId==1)
            <section class="hiro" style="background-image: url({{ asset('storage').'/'.$value->image }})">
        @elseif($countryId==2)
            <section class="hiro" style="background-image: url({{ asset('storage').'/'.$value->image }})">
        @endif
    @endforeach