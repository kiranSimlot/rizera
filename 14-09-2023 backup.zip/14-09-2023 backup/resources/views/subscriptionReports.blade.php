@extends('layouts.admin')
@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
<div class="col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>All Subscription List</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">

                                @if(session()->has('success'))
<div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                           <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">×</span>
                           </button>
                           <strong>Success!</strong> {{ \Session::get('success') }}.
                        </div>
@endif

                                <div class="card-box table-responsive subscription-list">
                              <div id="newSearchPlace"></div>                                    
                                    <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                        <thead>
                                            <tr>
											    <th data-searchable=false>S. No.</th>
                                                <!--<th>Id</th>-->
                                                <th>Owner Name</th>
                                                <th>Plan name</th>
                                                <th>Type</th>
                                                <th>Active From</th>
                                                <th>Expires At</th>
                                                <th>Status</th>
                                                <!-- <th data-searchable=false>Action</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.subscription-list .dt-buttons.btn-group {
    float: left;
}
.subscription-list div#datatable_length {
    float: right;
}
.subscription-list div#datatable_filter {
    float: right;
    margin-right: 20px;
}
.subscription-list a.btn.btn-default {
    font-size: 12px;
    font-weight: 500;
    border: 1px solid #dee2e6;
    background: rgba(0,0,0,.05);
}
</style>

<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>

<script type="text/javascript">


$(document).ready(function() {



data();

    function data (){
      $('#datatable').DataTable().clear().destroy();

      $('#datatable').DataTable({
            "dom": 'Blfrtip',
            // "pageLength": 5,
            "buttons": ['csv','print','excel','pdf'],
            "processing": true,
            "serverSide": true,
           "ajax":{
             url:'{!! route('admin.report.subscription-list') !!}',
             data : {"_token": "{{ csrf_token() }}"},
             // "data": {search: $(#search).val()} 
           },
		   'columnDefs': [
                 { "targets": 6, "className": "text-center" }
              ],
           "columns": [
		      { "data": 'DT_RowIndex', orderable: false, searchable: false },
              /*{data:'id', name:'id'},*/
              {data:'ownername', name:'ownername'},
              {data:'plan_name', name:'plan_name'},
              {data:'type', name:'type'},
              {data:'active_from', name:'active_from'},
              {data:'expires_at', name:'expires_at'},
              {data:'status', name:'status'},
              // {data:'action', name:'action'},
           ]
       });


    }
});


/*$(document).ready(function() {
    $('#datatable').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {
                text: 'My button',
                action: function ( e, dt, node, config ) {
                    alert( 'Button activated' );
                }
            }
        ]
    } );
} );
*/

</script>


@endsection