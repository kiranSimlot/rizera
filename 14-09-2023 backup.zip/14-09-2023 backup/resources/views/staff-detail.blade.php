@extends('layouts.admin') 
@section('content')
<h1>Staff Details</h1>
<link href="{{ asset('admin_theme/admin-view/style.css') }}" rel="stylesheet">
 <a href="{{Route('admin.owners')}}" class="btn btn-primary">Back</a>
<div class="container emp-profile">
	@if(count($staff)>0)
		@foreach($staff as $value)
            <form method="post">
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img" style="width:275px; height:183px;">
                            <img src="{{ asset('storage').'/'.$value->image }}" alt=""/>
                            <div class="file btn btn-lg btn-primary">
                                Change Photo
                                <input type="file" name="file"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5>
                                        {{$value->name}}
                                    </h5>
                                    <h6>
                                        {{$value->email}}
                                    </h6>
                                    <p class="proile-rating">Restaurants Name: <span>{{$value->Rname}}</span></p>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-work">
                            <p>Languages</p>
                            <a href="">@if($value->lang_id == 1)
											English
										@elseif($value->lang_id == 2)
											Arabic
										@endif
							</a><br/>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>User Id</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>{{$value->id}}</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>First Name</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>{{$value->first_name}}</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Last Name</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>{{$value->last_name}}</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>{{$value->email}}</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Phone</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>{{$value->mobile}}</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Country</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>
                                                	@if($value->country_id == 1)
													Kuwait
													@elseif($value->country_id == 2)
													Morocco
													@endif
												</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>User Type</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>
                                                	@if($value->type == 1)
														Admin
													@elseif($value->type == 2)
														Owner
													@elseif($value->type == 3)
														Staff
													@elseif($value->type == 4)
														App User
													@endif
												</p>
                                            </div>
                                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>           
        </div>
        @endforeach
	@else
		<h1>No Restaurant Found</h1>
	@endif
@endsection