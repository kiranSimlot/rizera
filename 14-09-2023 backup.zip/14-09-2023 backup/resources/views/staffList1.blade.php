@extends('layouts.default')
@section('content')
<div class="container-fluid">
    <div class="fix-width">
    @include('layouts.floor_management_left_menu')
        <!-- main -->
         <main role="main" class="main-box w-100 border-main-box report-chart">
               <!-- main header -->
               <div class="dis-header">
                  <div class="row align-items-center">
                    <div class=" col-md-6 text-left">
                        @if(Auth::user()->type != 1)
                         <b style="font-size: 20px;">{{ __('owner.All Staff List') }}</b>
                        @endif
                     </div>
                     <div class="col-md-6 text-right">
                        @if(Auth::user()->type != 1)
                        <a href="{{route('owner.staff.add')}}" class="btn advanced-report">{{ __('owner.Add Staff') }}</a>
                        @endif
                     </div>
                  </div>
               </div>
               <!-- end  main header -->
               <!-- container-main -->
               <div class="container-main">

                <div class="table-responsive report_table restaurants-table">
  <table class="table">
    <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col" class="restaurant-th">{{ __('owner.Staff Name') }}</th>
      @if(Auth::user()->type == 1)
      <th scope="col">{{ __('owner.Name') }}</th>
      @endif
      <th scope="col">{{ __('owner.Type') }}</th>
      <th scope="col">{{ __('owner.Email') }}</th>
      <th scope="col">{{ __('owner.Restaurant Name') }}</th>

      <th scope="col" class="action-th">{{ __('owner.Action') }}</th>

    </tr>
  </thead>

  <tbody>
     @if($stafflist->count() > 0)
     @foreach($stafflist as $key =>$list)
    <tr>
      <td>{{++$key}}</td>
      <td>{{$list->name}}</td>
      <td>@if($list->type == 3) <?php echo"Staff";?>@elseif($list->type == 5)<?php echo"Chef";?>@elseif($list->type == 6)<?php echo"Waiter";?>@endif</td>
    <td>{{$list->email}}</td>
    <td>{{$list->Rname}}</td>



      <td>
         <a href="{{ Route('owner.staff.edit',$list->id)}}" class="btn report-edit mr-2"><img src="{{ asset('admin/imgs/edit_icon.svg') }}" style="height: 15px;"  data-toggle="tooltip" data-placement="top" title="Edit"></a>
         <a href="#" class="btn report-trash mr-2"onclick="event.preventDefault(); if(confirm('Are you delete it.')){ document.getElementById('delete-form-{{$list->id}}').submit();  } "><img src="{{ asset('admin/imgs/trash.svg') }}" style="height: 15px;" data-toggle="tooltip" data-placement="top" title="Delete" >
         <form id="delete-form-{{$list->id}}" action="{{Route('owner.staff.staffdelete',$list->id)}}" method="post" style="display:none;">
                                                @csrf
                                                @method("DELETE")
                                            </form> </a>
  <!--         @if($list->status == 1)
                                              <a href="{{ Route('owner.staff.statusUpdate',$list->id)}}" class="btn btn-primary btn-sm status">{{__('owner.Enable')}}</button>
                                             @elseif($list->status == 2)
                                             <a href="{{ Route('owner.staff.statusUpdate',$list->id)}}" class="btn btn-warning btn-sm status">{{__("owner.Disabled")}}</button>
                                             @endif -->
    </tr>
 @endforeach

 @else

<tr>
    <td></td>
    <td><h5>No Restaurant Found!</h5></td>
</tr>
@endif


  </tbody>
  </table>
</div>

<div class="table_footer">
   <div class="row align-items-center">

   <div class="col-md-12 text-right">

<div class="table-pagination pt-2">
  <ul class="pagination justify-content-end mb-0">
    {!! $stafflist->links() !!}
  </ul>
</div>
   </div>
</div>
</div>



               </div>
               <!-- end container-main -->
            </main>
            <!-- end main -->

         </div>
      </div>
      <!-- end of footer -->
   <script type="text/javascript">
       $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
   </script>


@endsection

