@extends('layouts.default')

@section('content')

    <style>
        table,
        th,
        td {
            border: 1px solid;
        }
    </style>
    {{--<div class="container">
    <div class="row mt-2">
        <div class="col-6"></div>
        <div class="col-2"><a href="{{url('restaurant-owner/kitchen_order_list/complete_orders')}}" class="btn btn-secondary">Completed order</a></div>
        <div class="col-2"><a href="{{url('restaurant-owner/kitchen_order_list/panding_orders')}}" class="btn btn-secondary">Pending order</a></div>
        <div class="col-2"><a href="{{url('restaurant-owner/kitchen_order_list/cancel_orders')}}" class="btn btn-secondary">Cancelled order</a></div>
    </div>
</div>--}}



    {{-- html --}}
    <section class="kitchen">
        <div class="container-fluid">
            <nav>
                <div class="nav nav-tabs justify-content-center" id="nav-tab" role="tablist">
                    <a href="{{url('restaurant-owner/kitchen_order_list/panding_orders')}}"><button class="nav-link @if ($order == 'panding_orders'||$order == null ) active @endif" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home"
                        type="button" role="tab" aria-controls="nav-home" aria-selected="true">Pending</button></a>
                    <a href="{{url('restaurant-owner/kitchen_order_list/complete_orders')}}"><button class="nav-link @if ($order == 'complete_orders') active @endif" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Completed</button></a>
                    <a href="{{url('restaurant-owner/kitchen_order_list/cancel_orders')}}"><button class="nav-link @if ($order == 'cancel_orders') active @endif" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact"
                        type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Cancelled</button></a>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                    tabindex="0">
                    <div class="d-flex list_wapper">

                        
                        @if ($order == 'panding_orders' || $order == null)
                        @foreach ($panding_orders as $val)
                        <div class="list_card">
                            <div class="top_content">
                                <div class="_details">
                                    <h6 class="size28">T-{{ $val->table_no }}</h6>
                                    <p>{{ $val->getOrder->name }}</p>
                                </div>
                                <div class="status_button">
                                    @if($val->status == 0 || $val->status != 2)
                                    <a href="#" class="accepted status_accept" id="{{$val->id}}"><i class="fa fa-check"></i>Accept</a>
                                    @elseif($val->status == 2)
                                    <a href="#" class="completed status_complete" id="{{$val->id}}"><i class="fa fa-check"></i>Completed</a>
                                    @endif
                                    <!-- <a href="javascript:void(0)" class="status_complete" id="{{$val->id}}">Complete</a> -->
                                </div>
                            </div>
                            <hr class="seperation">
                            <div class="bottom_content">
                                <div class="_details">
                                    <h6 class="size28">{{ $val->getOrderItems->name }} </h6>
                                    <p>{{ $val->quantity_in_variation }}</p>
                                </div>
                                <div class="orderdetails ">
                                    <h6 class="size28 text-right">{{ $val->quantity }}X</h6>
                                    <p class="ordertime">Ordered at : {{ $val->created_at->format('h:i A') }}</p>
                                </div>
                            </div>
                            @if($val->notes != '')
                            <div class="note">
                                <span>Note:</span> <span>{{ $val->notes }}</span>
                            </div>
                            @endif
                        </div>
                        @endforeach 
                        @endif

                    </div>
                </div>
                <div class="tab-pane fade @if ($order == 'complete_orders') show active  @endif" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"
                    tabindex="0">

                    <div class="d-flex list_wapper">
                        
                         @if ($order == 'complete_orders')

                         @foreach ($complete_order as $val)

                        <div class="list_card">
                            <div class="top_content">
                                <div class="_details">
                                    <h6 class="size28">T-{{ $val->table_no }}</h6>
                                    <p>{{ $val->getOrder->name }}</p>
                                </div>
                                <div class="status_button">
                                    <a href="#" class="complete"><i class="fa fa-check"></i></a>
                                </div>
                            </div>
                            <hr class="seperation">
                            <div class="bottom_content">
                                <div class="_details">
                                    <h6 class="size28">{{ $val->getOrderItems->name }}</h6>
                                    <p>{{ $val->quantity_in_variation }}</p>
                                </div>
                                <div class="orderdetails ">
                                    <h6 class="size28 text-right">{{ $val->quantity }}X</h6>
                                    <p class="ordertime">Ordered at : {{ $val->created_at->format('h:i A') }}</p>
                                </div>
                            </div>
                            @if($val->notes != '')
                            <div class="note">
                                <span>Note:</span> <span>{{ $val->notes }}</span>
                            </div>
                            @endif
                        </div>
                        @endforeach
                        @endif

                    </div>
                </div>
                <div class="tab-pane fade @if ($order == 'cancel_orders') show active  @endif" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"
                    tabindex="0">
                    <div class="d-flex list_wapper">

                       @if ($order == 'cancel_orders')
                        @foreach ($cancel_order as $val)
                        <div class="list_card">
                            <div class="top_content">
                                <div class="_details">
                                    <h6 class="size28">T-{{ $val->table_no }}</h6>
                                    <p>{{ $val->getOrder->name }}</p>
                                </div>
                                <div class="status_button">
                                    <a href="#" class="cancelled"><i class="fa fa-ban"></i></a>
                                </div>
                            </div>
                            <hr class="seperation">
                            <div class="bottom_content">
                                <div class="_details">
                                    <h6 class="size28">{{ $val->getOrderItems->name }} </h6>
                                    <p>{{ $val->quantity_in_variation }}</p>
                                </div>
                                <div class="orderdetails ">
                                    <h6 class="size28 text-right">{{ $val->quantity }}X</h6>
                                    <p class="ordertime">Ordered at : {{ $val->created_at->format('h:i A') }}</p>
                                </div>
                            </div>
                            @if($val->notes != '')
                            <div class="note">
                                <span>Note:</span> <span>{{ $val->notes }}</span>
                            </div>
                            @endif
                        </div>
                        @endforeach 
                        @endif

                    </div>
                </div>

            </div>
    </section>
    {{-- html --}}





    <!-- <div class="container">
        @if ($order == 'panding_orders')
            <div class="pending_data">

            </div>
            {{-- @foreach ($panding_orders as $val)
        <div class="border m-4 col-4">
        Item: {{ $val->getOrderItems->name }},
        Quantity: {{ $val->quantity }},
            <br>
        Status: {{ isset($val->status) ? $val->status = "Panding" :''}},
        Action:  <a href="javascript:void(0)" class="status_complete" id="{{$val->id}}">Complete</a>
            <br>
        </div>
    @endforeach --}}
        @endif
    </div> -->
    <!-- <div class="container">
        @if ($order == '')
            <div class="pending_data">

            </div>
            {{-- @foreach ($panding_orders as $val)
        <div class="border m-4 col-4">
        Item: {{ $val->getOrderItems->name??'' }},
        Quantity: {{ $val->quantity }},
            <br>
        Status: {{ isset($val->status) ? $val->status = "Panding" :''}},
        Action:  <a href="javascript:void(0)" class="status_complete" id="{{$val->id}}">Complete</a>
            <br>
        </div>
    @endforeach --}}
        @endif
    </div> -->
    <!-- <div class="container">
        @if ($order == 'cancel_orders')
            <div class="panding_data">

            </div>
            @foreach ($cancel_order as $val)
                <div class="border m-4 col-4">
                    Item: {{ $val->getOrderItems->name }},
                    Quantity: {{ $val->quantity }},
                    <br>
                    Status: {{ isset($val->status) ? ($val->status = 'Cancelled') : '' }}
                </div>
            @endforeach
        @endif
    </div> -->
    <!-- <div class="container">
        @if ($order == 'complete_orders')
            @foreach ($complete_order as $val)
                <div class="border m-4 col-4">
                    Item: {{ $val->getOrderItems->name }},
                    Quantity: {{ $val->quantity }},
                    <br>
                    Status: {{ isset($val->status) ? ($val->status = 'Completed') : '' }}
                </div>
            @endforeach
        @endif
    </div> -->

    <script>
        function displayPendingData() {
            $.ajax({
                url: "{{ route('owner.pending_data') }}",
                type: 'get',
                dataType: 'json',
                success: function(panding_orders) {
                    let content = '';
                    panding_orders.forEach(row => {
                        content += `<div class="border m-4 col-4">`;
                        content +=
                            `<p>Item: ${row.get_order_items.name} Quantity:  ${row.quantity} Status:` +
                            (row.status == 0 ? 'Pending' : '') + `</p>`,
                            content +=
                            `Status: <a href="javascrip:void(0);" class="status_complete" id=${row.id}>Complete</a>`;
                        content += `</div>`;
                    });
                    $('.pending_data').html(content);
                }

            })
        }

        $(document).ready(function() {
            displayPendingData();
            setInterval(displayPendingData, 1000);
        })
    </script>


    <script type="text/javascript">
        $(document).ready(function() {
            $(document).on('click', '.status_complete', function() {
                var id = $(this).attr('id');
                var status = $(this).text().trim();
                if (status == 'Completed') {
                    status = 1;
                }
                $.ajax({
                    type: 'get',
                    dataType: 'json',
                    url: "{{ route('owner.complete_status') }}",
                    data: {
                        'id': id,
                        'status': status
                    },
                    success: function(data) {
                        window.location.reload();
                    }
                })
            })
        })
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $(document).on('click', '.status_accept', function() {
                var id = $(this).attr('id');
                var status = $(this).text().trim();
                if (status == 'Accept') {
                    status = 2;
                }
                $.ajax({
                    type: 'get',
                    dataType: 'json',
                    url: "{{ route('owner.accept_status') }}",
                    data: {
                        'id': id,
                        'status': status
                    },
                    success: function(data) {
                        window.location.reload();
                    }
                })
            })
        })
    </script>

@endsection
