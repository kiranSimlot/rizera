@extends('layouts.admin') 

@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">&nbsp;</div>
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Edit menu category</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br />
                <form method="post" action="{{ route('admin.menu_category.updatecategory', $category->id) }}" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                    @csrf
                    <div class="item form-group">
                        <label class="label-align col-form-label col-md-3 col-sm-3 label-align" for="name">Name<span class="required spanColor">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6">
                            <!-- <textarea rows="3" class="resizable_textarea form-control" name="name" id="name">{{ old('name', $category->name) }}</textarea> -->
                            <input type="text" name="name" class="form-control" id="name" value="{{ old('name', $category->name) }}">
                        </div>
                        @error('name')
                        <div class="error-box" style="color: red">{{$message}}</div>
                        @enderror
                    </div>
                    <div class="ln_solid"></div>

                    <div class="item form-group">
                        <div class="col-md-6 col-sm-6 offset-md-3">
                            <button type="submit" class="btn btn-success" value="submit">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
