@extends('layouts.admin')

@section('content')
<div style="padding-top:1rem; padding-bottom:1rem;" class="headdesign">

    <div class="bg-white" style="padding:1rem; border-radius:5px;">
        <b style="font-size: 20px;"> MENU CATEGORY </b>
        <div style="float:right;">
            <a href="{{route('admin.menu_category.addcategory')}}" class="btn btn-primary btn-sm">Add menu category</a>
        </div>
    </div>
</div>
<div class="col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>All menu category List</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>

                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-12">
                                @if(session()->has('success'))
                                <div class="alert round bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2 headdesign txt_clr" role="alert" style="color: white;">
                                    <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <strong>Success!</strong> {{ \Session::get('success') }}.
                                </div>
                                @endif
                                <div class="card-box faqlisttable table-responsive">
                                    <table id="datatable" class="table table-striped table-bordered datatable" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th data-searchable="false">S.No.</th>
                                                <th>Name</th>
                                                <th data-searchable="false">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        data();

        function data() {
            $('#datatable').DataTable().clear().destroy();

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    url: '{!! route('admin.menu_category.categoryData') !!}',
                    data: {"_token": "{{ csrf_token() }}"}
                },
                "bAutoWidth": false,
                "columns": [
                    {"data": 'DT_RowIndex', orderable: false, searchable: false, sWidth: '30px'},
                    {data: 'name', name: 'name'},
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                ],
                "order": []
            });
        }
    });

    //for delete
$(document).on('click','.category_delete',function(event){
        var id  = $(this).data('id');
        // alert(id);
        // return id;
        if(confirm('Are you sure to delete this record ?')) {
            $.ajax({
                type: "get",
                url: "{{ route('admin.menu_category.delete','') }}"+'/'+id,
                data: {
                    id: id,
                    _token: '{{ csrf_token() }}',
                },
                error: function() {
                    alert('Something is wrong, couldn\'t delete record');
                },
                success: function(data) {
                    //alert(id);
                     $('#datatable').DataTable().ajax.reload();
                }
            });
        }
    });
</script>

@endsection
