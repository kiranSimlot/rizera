<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Owner\UserController as OwnerUserController;
use App\Http\Controllers\RestaurantController;
use App\Http\Controllers\Owner\RestaurantController as OwnerRestaurantController;
use App\Http\Controllers\ManageController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\TagController;
use App\Http\Controllers\Dashboard;
use App\Http\Controllers\TemplateController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CityController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\CuisineTypeController;
use App\Http\Controllers\RequestDemoController;
use App\Http\Controllers\Front\FrontController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PlansController;
use App\Http\Controllers\CmsController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\SplashSliderController;
use App\Http\Controllers\VipTagController;
use App\Http\Controllers\CuisineController;
use App\Http\Controllers\AllergyController;
use App\Http\Controllers\FoodintoleranceController;
use App\Http\Controllers\CommonSettingController;
use App\Http\Controllers\SupportController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\MenuCategoryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('locale/{locale}', function ($locale){
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('changerestaurant/{restaurant_id}', function ($restaurant_id){
    Session::put('id_restaurant', $restaurant_id);
    return redirect()->back();
});

Route::get('changerestaurantfloor/{floor_id}', function ($floor_id){
    Session::put('id_floor', $floor_id);
    return redirect()->back();
});


// Route::view('restaurant-detail','restaurant-layout/restaurant-detail');
Route::view('restaurant-features','restaurant-layout/restaurant-features');
Route::view('restaurant-page','restaurant-layout/restaurant-page');
Route::view('about-us-app','restaurant-layout/about-us-app');

//kiran
Route::get('restaurant_item_list/{key?}',[HomeController::class,'restaurantItemList'])->name('restaurant_item_list');
Route::get('all_resturant/{key?}',[HomeController::class,'allResturant'])->name('all_resturant');
Route::get('restaurant_item_list_html/{key?}',[HomeController::class,'restaurantMenuListHtml'])->name('restaurant_item_list_html');


Route::get('restaurant-price',[PlansController::class,'index'])->name('restaurant-price');
Route::get('buy-subscription',[PlansController::class,'buy_subscription'])->name('buy-subscription');
Route::get('terms-conditions',[PlansController::class,'terms_conditions'])->name('terms-conditions');
Route::get('privacy-policy',[PlansController::class,'privacy_policy'])->name('privacy-policy');
Route::get('contact-us',[PlansController::class,'contact_us'])->name('contact-us');
//Route::view('','main');
Route::view('restaurant-app-request','restaurant-layout/restaurant-app-request')->name('restaurant-app-request');
Route::post('demoStore',[FrontController::class,'demoStore'])->name('demoStore');
//front page routes
Route::get('cuisine/{id}',[HomeController::class,'cuisine'])->name('cuisine');
Route::get('',[HomeController::class,'index'])->name('home');
Route::post('defaultCountrySet',[HomeController::class,'defaultCountrySet']);
// Route::get('lang/{name}',[HomeController::class,'lang_change']);
// Route::post('lang',[HomeController::class,'lang_change']);
Route::get('restaurant-search',[HomeController::class,'restaurantList'])->name('restaurant-search');
Route::get('search-by-cuisine/{id}',[HomeController::class,'cuisine'])->name('search-by-cuisine');
Route::get('restaurant-menu-pdf/{id}',[HomeController::class,'pdf'])->name('restaurant-menu-pdf');
Route::get('restaurantdetails/{id}',[HomeController::class,'details'])->name('restdetails');
// Route::get('restaurant-list/{id?}',[HomeController::class,'restaurantList'])->name('restaurant-list');
Route::get('restaurant-list',[HomeController::class,'restaurantList'])->name('restaurant-list');
Route::get('listofrest/{id?}',[HomeController::class,'allrest'])->name('listofcityrest');

// Route::get('restaurant-layout', function() {
	  // return view('restaurant-layout/restaurant-layout');
// })->name('restaurant.home');
Route::get('restaurant-features', function(){
	return view('restaurant-layout/restaurant-features');
})->name('restaurant.home');

Route::get('admin/login', function () {
	if (Auth::check() && Auth::user()->type == 1) {
		return redirect('admin/owners');
	}
    return view('auth.admin_login');
})->name('admin.login');

Route::get('restaurant-owner/login', function () {
	// if (Auth::check()) {
		if (Auth::check() && Auth::user()->type == 2) {
			return redirect()->route('owner.restaurant.list');
		}if (Auth::check() && Auth::user()->type == 3) {
			return redirect()->route('owner.staff.list');
		} if (Auth::check() && Auth::user()->type == 5) {
			return redirect()->route('owner.kitchen_order_list');
		}

	// if (Auth::check() && Auth::user()->type == 3) {
	// 	return redirect()->route('staff');
	// }
    return view('auth.owner.login');
})->name('owner.login');
Route::get('restaurant-owner/otp', function () {
    return view('auth.owner.otp');
})->name('owner.otp');
Route::get('restaurant-owner/register', function () {
    return view('auth.owner.register');
})->name('owner.register');
Route::get('restaurant-owner/forgot-password', function () {
    return view('auth.owner.forgot-password');
})->name('owner.forgot.password');

Route::get('dashboard', function () {
	if (Auth::check() && Auth::user()->type == 1) {
		return redirect('admin/owners');
	}if (Auth::check() && Auth::user()->type == 2) {
		return redirect()->route('owner.restaurant.list');
	}if (Auth::check() && Auth::user()->type == 3) {
		return redirect()->route('owner.staff.list');
	}

    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

//'ownerPage',////////////[Owner routes Start]//////////////////////////////////////////////////////////
Route::group(['middleware'=>['ownerPage','auth'],'prefix'=>'restaurant-owner', 'as'=> 'owner.'],function(){

	// Route::view('owner','owner');
	Route::get('logout',[OwnerUserController::class,'logout'])->name('logout');
	Route::get('kitchen_order_list/{order?}', [OwnerUserController::class,'orederData'])->name('kitchen_order_list');
	Route::get('complete_status', [OwnerUserController::class,'completeOrderStatus'])->name('complete_status');
	Route::get('pending_data', [OwnerUserController::class, 'pendingsData'])->name('pending_data');
	Route::get('accept_status', [OwnerUserController::class,'acceptOrderStatus'])->name('accept_status');

	///////////////////////////////////[owner.staff.]//////////////////////////////////////////
	Route::group(['as'=> 'staff.'],function(){
		Route::get('staff/add',[OwnerUserController::class,'addStaffView'])->name('add');
		// Route::get('staff/list',[OwnerUserController::class,'staff'])->name('list');
		Route::get('staff/list',[OwnerUserController::class,'ownerStaffList'])->name('list');
		Route::get('ownerStaffData',[OwnerUserController::class,'ownerStaffData'])->name('ownerStaffData');
		Route::post('addStaff',[OwnerUserController::class,'addStaff'])->name('create');
		Route::get('staff/edit/{id}',[OwnerUserController::class,'editStaff'])->name('edit');
		Route::post('updateStaff',[OwnerUserController::class,'updateStaff'])->name('update');
		Route::delete('destroyStaff/{id}',[OwnerUserController::class,'destroy'])->name('destroy');
		Route::get('ownerStaffdetail/{id}',[OwnerUserController::class,'ownerStaffdetail'])->name('ownerStaffdetail');
		Route::get('staff/ownerPanelReport',[OwnerUserController::class,'ownerPanelReport'])->name('ownerPanelReport');
		Route::get('staff/ownerPanelReport1',[OwnerUserController::class,'ownerPanelReport1'])->name('ownerPanelReport1');

        Route::delete('staff/delete/{id}',[OwnerUserController::class,'staffdelete'])->name('staffdelete');
        Route::get('statusUpdate/{id}',[OwnerUserController::class,'statusUpdate'])->name('statusUpdate');
	});

	///////////////////////////////////[owner.account.]//////////////////////////////////////////
	Route::group(['as'=> 'account.'],function(){
		Route::post('update-account',[OwnerRestaurantController::class,'updateAccount'])->name('update');
		Route::get('account',[OwnerRestaurantController::class,'account'])->name('detail');
	});

	Route::group(['as' => 'items.'], function(){
		Route::get('item_list', [ItemController::class, 'list'])->name('list');
		Route::get('itemData', [ItemController::class, 'itemData'])->name('itemData');
		Route::get('additem', [ItemController::class,'add'])->name('additem');
		Route::post('storeitem', [ItemController::class,'store'])->name('storeitem');

		//tanmay Crop image url
		Route::post('crop_image', [ItemController::class,'cropImageUpload'])->name('crop_image');
		Route::get('/get-session', [ItemController::class,'getSession'])->name('get-session');

		Route::get('edititem/{id}', [ItemController::class,'edit'])->name('edititem');
		Route::get('delete_item/', [ItemController::class,'softDeleteItem'])->name('delete_item');
		Route::post('updateitem/{id}', [ItemController::class,'update'])->name('updateitem');
		Route::post('remove_price',  [ItemController::class,'removePrice'])->name('remove_price');
	});

	///////////////////////////////////Tanmay //////////////////////////////////////////////////////
	Route::group(['as' => 'menucategory.'], function(){
	Route::post('storecategory', [MenuCategoryController::class,'storecategory'])->name('storecategory');
	Route::get('addcategory', [MenuCategoryController::class,'addcategory'])->name('addcategory');
	Route::get('menu-list',[MenuCategoryController::class,'menuCategoryList'])->name('menu-list');
	Route::get('menu-category-list',[MenuCategoryController::class,'menucategoryData'])->name('menu-category-list');

	Route::get('editcategory/{id}', [MenuCategoryController::class,'editcategory'])->name('editcategory');
	Route::post('updatecategory/{id}', [MenuCategoryController::class,'updatecategory'])->name('updatecategory');
	Route::get('delete_category/', [MenuCategoryController::class,'softDeleteCategory'])->name('delete_category');
	});
	///////////////////////////////////Tanmay //////////////////////////////////////////////////////

	///////////////////////////////// Kiran [owner.order] start ////////////////////////////////////
	Route::group(['as' => 'order.'], function(){
		Route::get('order_list', [OwnerUserController::class, 'list'])->name('list');
		Route::get('orderData', [OwnerUserController::class, 'orderData'])->name('orderData');
        Route::get('order_view/{order_id}', [OwnerUserController::class, 'orderView'])->name('order_view');
		Route::get('order_view_data/{order_id}', [OwnerUserController::class, 'orderViewData'])->name('order_view_data');
	});
	//////////////////////////////// Kiran [owner.order] end /////////////////////////////////

	///////////////////////////////////[owner.restaurant.]//////////////////////////////////////////
	Route::group(['as'=> 'restaurant.'],function(){
	// Route::view('restaurant/add','restaurant.add')->name('restaurant.add');
		Route::get('restaurants',[OwnerRestaurantController::class,'index'])->name('list');
		Route::post('restaurants',[OwnerRestaurantController::class,'index']);

		Route::get('restaurants/restaurantlist',[OwnerRestaurantController::class,'restaurantlist'])->name('restaurantlist');
		Route::get('restaurants/bookingrestaurantlist',[OwnerRestaurantController::class,'bookingrestaurantlist'])->name('bookingrestaurantlist');
		Route::get('restaurants/restauranttimeline',[OwnerRestaurantController::class,'restauranttimeline'])->name('restauranttimeline');
		Route::get('restaurant/add',[OwnerRestaurantController::class,'add'])->name('add');
		Route::post('addrestaurant',[OwnerRestaurantController::class,'insert'])->name('create');
		Route::get('restaurant/edit/{id}',[OwnerRestaurantController::class,'edit'])->name('edit');
		Route::post('editrestaurant',[OwnerRestaurantController::class,'update'])->name('update');
		Route::delete('restaurant/delete/{id}',[OwnerRestaurantController::class,'delete'])->name('delete');
		Route::get('restaurant/setdefaultfloor/{id}',[OwnerRestaurantController::class,'setdefaultfloor'])->name('setdefaultfloor');
		Route::get('/getdata', [OwnerRestaurantController::class,'getdata'])->name('getdata');
		Route::post('/primaryUpdate', [OwnerRestaurantController::class,'primaryUpdate'])->name('primaryUpdate');
		Route::get('/restaurant/defaultfloor',[OwnerRestaurantController::class,'defaultfloor'])->name('defaultfloor');

        Route::put('booking_status_change',[OwnerRestaurantController::class,'booking_status_change'])->name('booking_status_change');

		////////////////////[Canvas Ajax function Routes]///////////////////////////////////
		Route::get('restaurant/floorManagement',[OwnerRestaurantController::class,'floorManagement'])->name('floorManagement');
		Route::get('restaurant/editFloor',[OwnerRestaurantController::class,'editFloor']);
		Route::get('restaurant/floor_management',[OwnerRestaurantController::class,'getRestaurantFloor']);
		Route::get('restaurant/getRestaurantFloorDetail/{id}/{type}',[OwnerRestaurantController::class,'getRestaurantFloorDetail']);
		Route::get('restaurant/saveRestaurantFloor',[OwnerRestaurantController::class,'saveRestaurantFloor']);
		Route::get('restaurant/allBooking',[OwnerRestaurantController::class,'allBooking']);
		Route::post('/restaurant/createRestaurantFloor',[OwnerRestaurantController::class,'createFloor']);
		Route::delete('/restaurant/deleteRestaurantFloor',[OwnerRestaurantController::class,'deleteRestaurantFloor']);
		Route::delete('/restaurant/deleteRestaurantFloorTable',[OwnerRestaurantController::class,'deleteRestaurantFloorTable']);
		Route::get('restaurant/confirmBookingList',[OwnerRestaurantController::class,'confirmBooking']);

		////////////////////[Restaurent table booking]///////////////////////////////////
		Route::post('/restaurant/bookingSave',[OwnerRestaurantController::class,'bookingSave']);
		Route::post('/restaurant/updateCategoryBooking',[OwnerRestaurantController::class,'updateCategoryOfBooking']);
		Route::post('/restaurant/bookingUpdate',[OwnerRestaurantController::class,'bookingUpdate']);
		Route::get('restaurant/bookingDetail',[OwnerRestaurantController::class,'bookingDetail']);
		Route::get('/restaurant/booking',[OwnerRestaurantController::class,'bookingNew'])->name('bookingNew');
		Route::get('/restaurant/bookingnew',[OwnerRestaurantController::class,'addgustuser'])->name('bookingNewGuest');

		Route::get('/restaurant/bookinglist',[OwnerRestaurantController::class,'ownerBookingList'])->name('ownerBookingList');
		Route::get('ownerBookingListfn',[OwnerRestaurantController::class,'ownerBookingListfn'])->name('ownerBookingListfn');


		Route::post('/restaurant/bookingby',[OwnerRestaurantController::class,'bookingby']);


		Route::post('/restaurant/newbooking',[OwnerRestaurantController::class,'newbooking'])->name('bookadduser');

		/////Route::get('/restaurant/newreservation',[OwnerRestaurantController::class,'newreservation']);
		Route::post('/restaurant/newreservation',[OwnerRestaurantController::class,'newreservation'])->name('newreservation');


		Route::post('/restaurant/tablelistbyfloorid',[OwnerRestaurantController::class,'tablelistbyfloorid']);
		/////////////////////////[addgustuser not vip]/////////////////////////////////
		Route::post('/restaurant/addgustuser',[OwnerRestaurantController::class,'addgustuser'])->name('addgustuser');

		/////////////////////////[guestUser ]/////////////////////////////////
		Route::get('/restaurant/guest',[OwnerRestaurantController::class,'guest']);
		Route::post('/restaurant/newvip',[OwnerRestaurantController::class,'addvipgust'])->name('addvip');

		Route::get('/restaurant/guestuser/{id}',[OwnerRestaurantController::class,'guestuser'])->name('guestuser');
		Route::post('/restaurant/vipgust',[OwnerRestaurantController::class,'vipgust'])->name('vipgust');

		Route::get('/restaurant/restaurantsTimeSlot/{floor_id?}/{id?}',[OwnerRestaurantController::class,'restaurantsTimeSlot']);

		// Route::post('/restaurant/restaurantsTimeSlot',[OwnerRestaurantController::class,'restaurantsTimeSlot'])->name('restaurantsTimeSlot');

		Route::any('{query}', function() { return redirect('/'); })->where('query', '.*');

	});
});

///////////////////////////////[Owner routes End]//////////////////////////////////////////////////////////

///////////////////////////////[Staff Routes Start]//////////////////////////////////////////////////////////
//Route::group(['middleware'=>['staffPage','auth'], 'prefix'=> 'staff','as'=>'staff.']

// Route::group(['middleware'=>['ownerPage','auth'],'prefix'=>'restaurant-owner', 'as'=> 'owner.'],function(){
// 	// Route::view('staff','staff');
// 	Route::group(['as'=> 'account.'],function(){
// 		Route::post('update-account',[OwnerRestaurantController::class,'updateAccount'])->name('update');
// 		Route::get('account',[OwnerRestaurantController::class,'account'])->name('detail');
// 	});

// 	Route::group(['as'=> 'restaurant.'],function(){
// 		// Route::view('restaurant/add','restaurant.add')->name('restaurant.add');
// 		Route::get('restaurant/add',[OwnerRestaurantController::class,'add'])->name('add');
// 		Route::post('addrestaurant',[OwnerRestaurantController::class,'insert'])->name('create');
// 		Route::get('restaurants',[OwnerRestaurantController::class,'index'])->name('list');
// 		Route::post('restaurants',[OwnerRestaurantController::class,'index']);
// 		Route::get('restaurant/edit/{id}',[OwnerRestaurantController::class,'edit'])->name('edit');
// 		Route::post('editrestaurant',[OwnerRestaurantController::class,'update'])->name('update');
// 		Route::delete('restaurant/delete/{id}',[OwnerRestaurantController::class,'delete'])->name('delete');

// 		Route::get('restaurant/floorManagement',[OwnerRestaurantController::class,'floorManagement'])->name('floorManagement');
// 		Route::get('restaurant/editFloor/{id}',[OwnerRestaurantController::class,'editFloor']);

// 		Route::get('restaurant/floor_management',[OwnerRestaurantController::class,'getRestaurantFloor']);


// 		Route::get('restaurant/getRestaurantFloorDetail/{id}/{type}',[OwnerRestaurantController::class,'getRestaurantFloorDetail']);
// 		Route::get('restaurant/saveRestaurantFloor',[OwnerRestaurantController::class,'saveRestaurantFloor']);
// 		Route::post('/restaurant/createRestaurantFloor',[OwnerRestaurantController::class,'createFloor']);
// 		Route::delete('/restaurant/deleteRestaurantFloor',[OwnerRestaurantController::class,'deleteRestaurantFloor']);

// 		Route::delete('/restaurant/deleteRestaurantFloorTable',[OwnerRestaurantController::class,'deleteRestaurantFloorTable']);


// 		Route::post('/restaurant/bookingSave',[OwnerRestaurantController::class,'bookingSave']);
// 		Route::post('/restaurant/updateCategoryBooking',[OwnerRestaurantController::class,'updateCategoryOfBooking']);
// 		Route::post('/restaurant/bookingUpdate',[OwnerRestaurantController::class,'bookingUpdate']);
// 		Route::get('restaurant/bookingDetail',[OwnerRestaurantController::class,'bookingDetail']);

// 		Route::get('/restaurant/booking/{id}',[OwnerRestaurantController::class,'bookingNew']);
// 		Route::post('/restaurant/bookingby',[OwnerRestaurantController::class,'bookingby'])->name('bookuser');
// 		Route::post('/restaurant/newbooking',[OwnerRestaurantController::class,'newbooking'])->name('bookadduser');
// 		Route::post('/restaurant/tablelistbyfloorid',[OwnerRestaurantController::class,'tablelistbyfloorid']);

// 		Route::post('/restaurant/addgustuser',[OwnerRestaurantController::class,'addgustuser'])->name('addgustuser');


// Route::group(['middleware'=>['staffPage','auth'], 'prefix'=> 'staff','as'=>'staff.'],function(){
// 	// Route::view('staff','staff');
// 	Route::group(['as'=> 'account.'],function(){

// 	Route::post('update-account',[OwnerRestaurantController::class,'updateAccount'])->name('update');
// 	Route::get('account',[OwnerRestaurantController::class,'account'])->name('detail');

// 	});

// 	Route::group(['as'=> 'restaurant.'],function(){
// 	// Route::view('restaurant/add','restaurant.add')->name('restaurant.add');
// 	Route::get('restaurant/add',[OwnerRestaurantController::class,'add'])->name('add');
// 	Route::post('addrestaurant',[OwnerRestaurantController::class,'insert'])->name('create');
// 	Route::get('restaurants',[OwnerRestaurantController::class,'index'])->name('list');
// 	Route::post('restaurants',[OwnerRestaurantController::class,'index']);
// 	Route::get('restaurant/edit/{id}',[OwnerRestaurantController::class,'edit'])->name('edit');
// 	Route::post('editrestaurant',[OwnerRestaurantController::class,'update'])->name('update');
// 	Route::delete('restaurant/delete/{id}',[OwnerRestaurantController::class,'delete'])->name('delete');

// 	Route::get('restaurant/floorManagement/{id}',[OwnerRestaurantController::class,'floorManagement'])->name('floorManagement');
// 	Route::get('restaurant/editFloor/{id}',[OwnerRestaurantController::class,'editFloor']);
// 	Route::get('restaurant/floor_management',[OwnerRestaurantController::class,'getRestaurantFloor']);
// 	Route::get('restaurant/getRestaurantFloorDetail/{id}/{type}',[OwnerRestaurantController::class,'getRestaurantFloorDetail']);
// 	Route::get('restaurant/saveRestaurantFloor',[OwnerRestaurantController::class,'saveRestaurantFloor']);
// 	Route::post('/restaurant/createRestaurantFloor',[OwnerRestaurantController::class,'createFloor']);
// 	Route::delete('/restaurant/deleteRestaurantFloor',[OwnerRestaurantController::class,'deleteRestaurantFloor']);

// 	Route::delete('/restaurant/deleteRestaurantFloorTable',[OwnerRestaurantController::class,'deleteRestaurantFloorTable']);


// 	Route::post('/restaurant/bookingSave',[OwnerRestaurantController::class,'bookingSave']);
// 	Route::post('/restaurant/updateCategoryBooking',[OwnerRestaurantController::class,'updateCategoryOfBooking']);
// 	Route::post('/restaurant/bookingUpdate',[OwnerRestaurantController::class,'bookingUpdate']);
// 	Route::get('restaurant/bookingDetail',[OwnerRestaurantController::class,'bookingDetail']);

// 	Route::get('/restaurant/booking/{id}',[OwnerRestaurantController::class,'bookingNew']);
// 	Route::post('/restaurant/bookingby',[OwnerRestaurantController::class,'bookingby'])->name('bookuser');
// 	Route::post('/restaurant/newbooking',[OwnerRestaurantController::class,'newbooking'])->name('bookadduser');
// 	Route::post('/restaurant/tablelistbyfloorid',[OwnerRestaurantController::class,'tablelistbyfloorid']);

// 	Route::post('/restaurant/addgustuser',[OwnerRestaurantController::class,'addgustuser'])->name('addgustuser');

// 	Route::get('restaurant/setdefaultfloor/{id}',[OwnerRestaurantController::class,'setdefaultfloor'])->name('setdefaultfloor');
// 	Route::post('/restaurant/defaultfloor',[OwnerRestaurantController::class,'defaultfloor'])->name('defaultfloor');

// 	Route::get('/restaurant/guest/{id}',[OwnerRestaurantController::class,'guest']);

// 	});
// });


///////////////////////////////[Admin Routes Start]//////////////////////////////////////////////////////////
Route::group(['middleware'=>['adminPage','auth'], 'prefix'=> 'admin','as'=>'admin.'],function(){

	// Route::view('admin','admin');

	Route::get('admin-dashboard',[DashboardController::class,'index'])->name('admin-dashboard');
	Route::get('admin-index',[DashboardController::class,'dashboardRest'])->name('admin-index');
	Route::get('restaurant-approve',[DashboardController::class,'dashboardRestList'])->name('restaurantApprove');
	Route::get('detes',[DashboardController::class,'dates'])->name('dates');

	Route::get('restaurant/restaurantedit/{id}',[RestaurantController::class,'editres'])->name('editres');
	Route::post('editrestaurant',[RestaurantController::class,'updateres'])->name('updateres');


	Route::get('owners',[UserController::class,'ownerList']);
	Route::get('ownersData',[UserController::class,'ownerData'])->name('ownersData');
	Route::get('users',[UserController::class,'usersList']);
	Route::get('usersData',[UserController::class,'usersData'])->name('usersData');
	Route::get('staffs',[UserController::class,'staffList']);
	Route::get('staffsData',[UserController::class,'staffData'])->name('staffData');
	Route::post('owners',[UserController::class,'ownerList'])->name('owners');
	Route::get('ownersDetail/{id}',[UserController::class,'detail'])->name('ownersDetail');
	Route::get('usersDetail/{id}',[UserController::class,'usersdetail'])->name('usersDetail');
	Route::get('staffDetail/{id}',[UserController::class,'staffdetail'])->name('staffDetail');
	// Route::delete('destroy/{id}',[UserController::class,'destroy'])->name('destroy');
	// Route::put('statusChange/{id}',[UserController::class,'statusChange']);
	Route::put('supdate',[UserController::class,'statusModified'])->name('supdate');
	Route::post('sdelete',[UserController::class,'sdelete'])->name('sdelete');
	// Route::post('edit/{id}',[UserController::class,'destroy']);
	Route::get('restaurant/list',[RestaurantController::class,'index'])->name('restaurant.list');
	Route::get('restaurant/lists',[RestaurantController::class,'restaurantdata'])->name('restaurantdata');


	Route::get('cuisine_types/list',[CuisineTypeController::class,'index'])->name('cuisine_types.list');
	Route::get('cuisine_types/add',[CuisineTypeController::class,'add']);
	Route::post('add_cuisine_types',[CuisineTypeController::class,'insert']);
	Route::get('cuisine_types/edit/{id}',[CuisineTypeController::class,'edit']);
	Route::post('edit_cuisine_types',[CuisineTypeController::class,'update']);
	Route::delete('cuisine_types/delete/{id}',[CuisineTypeController::class,'delete'])->name('cuisine_types/delete');

	Route::get('restaurant/restaurantdetails/{id}',[RestaurantController::class,'details'])->name('details');
	Route::put('verifiedChange/{id}',[RestaurantController::class,'statusChange']);
	Route::put('restaurant-status-update',[RestaurantController::class,'statusModified'])->name('restaurant-status-update');

	Route::put('restaurant-reject-update',[RestaurantController::class,'rejectModified'])->name('restaurant-reject-update');

	Route::put('restaurant-verity-update',[RestaurantController::class,'verifyModified'])->name('restaurant-verity-update');
	Route::post('restaurant/addreason',[RestaurantController::class,'store'])->name('storereason');

	// Category Routes
	Route::group(['as'=> 'category.'],function(){

	// Route::get('category',[CategoryController::class,'index'])->name('list');
	Route::get('category',[CategoryController::class,'index'])->name('category');
	Route::get('category-list',[CategoryController::class,'categoryData'])->name('category-list');

	Route::get('add',[CategoryController::class,'add'])->name('add');
	Route::post('add',[CategoryController::class,'store'])->name('store');

	Route::get('editcategory/{id}',[CategoryController::class,'edit'])->name('editcategory');
	Route::post('updatecategory/{id}',[CategoryController::class,'update'])->name('updatecategory');

	Route::put('statusUpdatecategory',[CategoryController::class,'statusUpdatecategory'])->name('statusUpdatecategory');

	Route::get('category-delete/{id}',[CategoryController::class,'delete'])->name('delete');

	});

	// Cuisine Routes
	Route::group(['as'=>'cuisine.'], function(){
		Route::get('cuisine',[CuisineController::class,'index'])->name('cuisine');
		Route::get('cuisine-list',[CuisineController::class,'cuisineData'])->name('cuisine-list');
		Route::get('addcuisine',[CuisineController::class,'add'])->name('addcuisine');
		Route::post('addcuisine',[CuisineController::class,'store'])->name('storecuisine');
		Route::get('editcuisine/{id}',[CuisineController::class,'edit'])->name('editcuisine');
		Route::post('updatecuisine/{id}',[CuisineController::class,'update'])->name('updatecuisine');
		Route::put('statusupdatecuisine',[CuisineController::class,'statusupdatecuisine'])->name('statusupdatecuisine');
		Route::get('cuisine-delete/{id}',[CuisineController::class,'delete'])->name('delete');
	});



	// Allergy Routes
	Route::group(['as'=>'allergy.'], function(){
		Route::get('allergy',[AllergyController::class,'index'])->name('allergy');
		Route::get('allergy-list',[AllergyController::class,'allergyData'])->name('allergy-list');
		Route::get('addallergy',[AllergyController::class,'add'])->name('addallergy');
		Route::post('addallergy',[AllergyController::class,'store'])->name('storeallergy');
		Route::get('editallergy/{id}',[AllergyController::class,'edit'])->name('editallergy');
		Route::post('updateallergy/{id}',[AllergyController::class,'update'])->name('updateallergy');
		Route::put('statusupdateallergy',[AllergyController::class,'statusupdateallergy'])->name('statusupdateallergy');
		Route::get('allergy-delete/{id}',[AllergyController::class,'delete'])->name('delete');
	});

	// Foodintolerance Routes
	Route::group(['as'=>'foodintolerance.'], function(){
		Route::get('foodintolerance',[FoodintoleranceController::class,'index'])->name('foodintolerance');
		Route::get('foodintolerance-list',[FoodintoleranceController::class,'foodintoleranceData'])->name('foodintolerance-list');
		Route::get('addfoodintolerance',[FoodintoleranceController::class,'add'])->name('addfoodintolerance');
		Route::post('addfoodintolerance',[FoodintoleranceController::class,'store'])->name('storefoodintolerance');
		Route::get('editfoodintolerance/{id}',[FoodintoleranceController::class,'edit'])->name('editfoodintolerance');
		Route::post('updatefoodintolerance/{id}',[FoodintoleranceController::class,'update'])->name('updatefoodintolerance');
		Route::put('statusupdatefoodintolerance',[FoodintoleranceController::class,'statusupdatefoodintolerance'])->name('statusupdatefoodintolerance');
		Route::get('foodintolerance-delete/{id}',[FoodintoleranceController::class,'delete'])->name('delete');
	});



	Route::group(['as'=> 'common_setting.'],function(){
		Route::get('common_setting',[CommonSettingController::class,'index'])->name('common_setting');
		Route::post('updatecommon_setting/{id}',[CommonSettingController::class,'update'])->name('updatecommon_setting');
	});

	//Tag Route
	Route::group(['as'=> 'tag.'],function(){
		Route::get('tag',[TagController::class,'index'])->name('tag');
		Route::get('tag-list',[TagController::class,'tagData'])->name('tag-list');
		Route::get('addtag',[TagController::class,'add'])->name('addtag');
		Route::post('addtag',[TagController::class,'store'])->name('storetag');
		Route::get('edittag/{id}',[TagController::class,'edit'])->name('edittag');
		Route::post('updatetag/{id}',[TagController::class,'update'])->name('updatetag');
		Route::put('statusupdatetag',[TagController::class,'statusupdatetag'])->name('statusupdatetag');
		Route::get('tag-delete/{id}',[TagController::class,'delete'])->name('delete');
	});

	//VipTag Route
	Route::group(['as'=>'viptag.'],function(){
		Route::get('viptag',[VipTagController::class,'index'])->name('viptag');
		Route::get('viptag-list',[VipTagController::class,'vipTagData'])->name('viptag-list');
		Route::get('addviptag',[VipTagController::class,'add'])->name('addviptag');
		Route::post('addviptag',[VipTagController::class,'store'])->name('storeViptag');
		Route::get('editviptag/{id}',[VipTagController::class,'edit'])->name('editViptag');
		Route::post('updateviptag/{id}',[VipTagController::class,'update'])->name('updateViptag');
		Route::put('statusupdateviptag',[VipTagController::class,'statusupdateviptag'])->name('statusupdateviptag');
		Route::get('viptag-delete/{id}',[VipTagController::class,'delete'])->name('deleteViptag');
	});

	//City Route
	Route::group(['as'=> 'city.'],function(){
		Route::get('cities',[CityController::class,'index'])->name('cities');
		Route::get('city-list',[CityController::class,'cityData'])->name('cityData');
		Route::get('addcity',[CityController::class,'add'])->name('addcity');
		Route::post('addcity',[CityController::class,'store'])->name('storecity');
		Route::get('editcity/{id}',[CityController::class,'edit'])->name('editcity');
		Route::post('updatecity/{id}',[CityController::class,'update'])->name('updatecity');
		Route::put('statusupdatecity',[CityController::class,'statusupdatecity'])->name('statusupdatecity');
		Route::get('city-delete/{id}',[CityController::class,'delete'])->name('delete');
	});

	//App Splash Slider Route
	Route::group(['as'=> 'splashSlider.'],function(){
		Route::get('splash-slider',[SplashSliderController::class,'index'])->name('list');
		Route::get('splash-slider-list',[SplashSliderController::class,'splashSliderData'])->name('splashSliderData');
		Route::get('add-splash-slider',[SplashSliderController::class,'add'])->name('addSplashSlider');
		Route::post('add-splash-slider',[SplashSliderController::class,'store'])->name('storeSplashSlider');
		Route::get('edit-splash-slider/{id}',[SplashSliderController::class,'edit'])->name('editSplashSlider');
		Route::post('update-splash-slider/{id}',[SplashSliderController::class,'update'])->name('updateSplashSlider');
		Route::put('status-update-splash-slider',[SplashSliderController::class,'statusUpdateSplashSlider'])->name('statusUpdateSplashSlider');
		Route::get('splash-slider-delete/{id}',[SplashSliderController::class,'delete'])->name('deleteSplashSlider');
	});

	//Menu Category

	Route::group(['as' => 'menu_category.'], function(){
		Route::get('list', [MenuCategoryController::class, 'list'])->name('list');
		Route::get('categoryData', [MenuCategoryController::class, 'categoryData'])->name('categoryData');
		Route::get('addcategory', [MenuCategoryController::class,'add'])->name('addcategory');
		Route::post('addcategory', [MenuCategoryController::class,'store'])->name('storecategory');
		Route::get('editcategory/{id}', [MenuCategoryController::class,'edit'])->name('editcategory');
		Route::post('updatecategory/{id}', [MenuCategoryController::class,'update'])->name('updatecategory');
		Route::get('category-delete/{id}', [MenuCategoryController::class, 'delete'])->name('delete');
	});
	//Template Route
	Route::group(['as'=> 'template.'],function(){
		// Route::get('template',[TemplateController::class,'index'])->name('list');
		Route::get('template',[TemplateController::class,'index'])->name('template');
		Route::get('template-list',[TemplateController::class,'templateData'])->name('template-list');
		Route::get('addtemplate',[TemplateController::class,'add'])->name('addtemplate');
		Route::post('addtemplate',[TemplateController::class,'store'])->name('storetemplate');
		Route::get('edittemplate/{id}',[TemplateController::class,'edit'])->name('edittemplate');
		Route::post('updatetemplate/{id}',[TemplateController::class,'update'])->name('updatetemplate');
		Route::put('statusupdatetemplate',[TemplateController::class,'statusupdatetemplate'])->name('statusupdatetemplate');
		Route::get('deletetemplate/{id}',[TemplateController::class,'delete'])->name('deletetemplate');
	});

	/*//Report Route
	Route::group(['as'=> 'report.'],function(){
	Route::get('subscriptionReports',[ReportController::class,'subscriptionReports'])->name('subscriptionReports');
	Route::get('subscription-list',[ReportController::class,'subscriptionList'])->name('subscription-list');
	Route::get('edit-subscription-list/{id}',[ReportController::class,'edit_subcription'])->name('edit-subscription-list');
		Route::post('update-subscription-list/{id}',[ReportController::class,'update_subscription'])->name('update-subscription-list');
	Route::get('monthlyBookingsReport',[ReportController::class,'monthlyBookingsReport']);
	Route::get('monthlyReportData',[ReportController::class,'monthlyReportData'])->name('datareport');

	});*/

	Route::group(['as'=> 'report.'],function(){
		Route::get('subscriptionReports',[ReportController::class,'subscriptionReports'])->name('subscriptionReports');
		Route::get('subscription-list',[ReportController::class,'subscriptionList'])->name('subscription-list');
		Route::get('edit-subscription-list/{id}',[ReportController::class,'edit_subcription'])->name('edit-subscription-list');
		Route::post('update-subscription-list/{id}',[ReportController::class,'update_subscription'])->name('update-subscription-list');
		Route::get('monthlyBookingsReport',[ReportController::class,'monthlyBookingsReport']);
		Route::get('monthlyReportData',[ReportController::class,'monthlyReportData'])->name('datareport');
	});

	//demo request route
	Route::group(['as'=> 'demo.'],function(){
		Route::get('request-demo',[RequestDemoController::class,'index']);
		Route::get('request-demo-list',[RequestDemoController::class,'requestData'])->name('requestData');
		Route::put('requestAprove',[RequestDemoController::class,'update'])->name('requestAprove');
		Route::put('requestReject',[RequestDemoController::class,'reject'])->name('requestReject');
	});

	Route::group(['as'=> 'support.'],function(){
		Route::get('support',[SupportController::class,'index']);
		Route::get('support-list',[SupportController::class,'requestData'])->name('requestData');
		Route::put('supportstatusupdate',[SupportController::class,'supportstatusupdate'])->name('supportstatusupdate');
	});

	//Plan Route
	Route::group(['as'=>'plan.'],function(){
		Route::get('plan',[PlansController::class,'list'])->name('plan');
		Route::get('planData',[PlansController::class,'planData'])->name('planData');
		Route::get('addplan',[PlansController::class,'add'])->name('addplan');
		Route::post('addplan',[PlansController::class,'store'])->name('storeplan');
		Route::put('statusupdate',[PlansController::class,'statusUpdate'])->name('statusupdate');
		Route::get('editplan/{id}',[PlansController::class,'edit'])->name('editplan');
		Route::post('updateplan/{id}',[PlansController::class,'update'])->name('updateplan');
		Route::get('plan-delete/{id}',[PlansController::class,'delete'])->name('delete');
	});

		//Plan Route
	Route::group(['as'=>'cms.'],function(){
		Route::get('cms',[CmsController::class,'list'])->name('cms');
		Route::get('cmsData',[CmsController::class,'cmsData'])->name('cmsData');
		Route::get('addcms',[CmsController::class,'add'])->name('addcms');
		Route::post('addcms',[CmsController::class,'store'])->name('storecms');
		Route::put('cmsstatusupdate',[CmsController::class,'statusUpdate'])->name('cmsstatusupdate');
		Route::get('editcms/{id}',[CmsController::class,'edit'])->name('editcms');
		Route::post('updatecms/{id}',[CmsController::class,'update'])->name('updatecms');
		Route::get('cms-delete/{id}',[CmsController::class,'delete'])->name('delete');
	});

	//Banner Route
	Route::group(['as'=>'banner.'],function(){

		Route::get('banner',[BannerController::class,'index'])->name('banner');
		Route::get('banner-image',[BannerController::class,'bannerIamge'])->name('banner-image');

		Route::get('addbanner',[BannerController::class,'add'])->name('addbanner');
		Route::post('addbanner',[BannerController::class,'store'])->name('storebanner');

		Route::get('edit/{id}',[BannerController::class,'edit'])->name('banner-edit');
		Route::post('update/{id}',[BannerController::class,'update'])->name('banner-update');

	   	Route::put('statusupdatebanner',[BannerController::class,'statusupdatebanner'])->name('statusupdatebanner');

		Route::get('banner-delete/{id}',[BannerController::class,'delete'])->name('delete');

	});

});
///////////////////////////////[Admin Routes End]//////////////////////////////////////////////////////////


Route::get('dropdown/getCity/{id}',[OwnerRestaurantController::class,'getCity']);
Route::get('dropdown/getCuisine/{id}',[OwnerRestaurantController::class,'getCuisine']);


Route::view('/noaccess','noaccess');
Route::get('verifymail/{_token}',[UserController::class,'verifymail']);

Route::post('restaurants',[RestaurantController::class,'index'])->name('restaurant.search');

Route::get('chart',[Dashboard::class,'index']);
Route::get('latest',[Dashboard::class,'latest']);
Route::get('layout',[Dashboard::class,'layout']);
Route::get('logout', [UserController::class,'logout']);


require __DIR__.'/auth.php';
