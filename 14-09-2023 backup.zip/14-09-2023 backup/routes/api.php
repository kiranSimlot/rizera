<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Dashboard;
use App\Http\Controllers\Api\MoreController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\RestaurantController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\AuthenticationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

//API Route
Route::get('demoApi',[Dashboard::class,'show']);
Route::get('demoApi/{id}',[Dashboard::class,'single']);
Route::post('demoApi',[Dashboard::class,'create']);
Route::put('update/{id}',[Dashboard::class,'update']);
Route::delete('demoApi/{id}',[Dashboard::class,'delete']);
Route::get('search/{name}',[Dashboard::class,'search']);



Route::post('login', [AuthenticationController::class, 'login']);
//kiran
Route::post('waiter_login', [AuthenticationController::class, 'waiterLogin']);

Route::post('register', [AuthenticationController::class, 'register']);
Route::post('social-login', [AuthenticationController::class, 'socialLogin']);
Route::post('forgot-password', [AuthenticationController::class, 'forgotPassword']);
// Route::post('floor-data', [AuthenticationController::class, 'floorData']);
Route::post('languages-list', [AuthenticationController::class, 'languagesList']);
Route::post('countries-list', [AuthenticationController::class, 'countriesList']);
Route::post('splash-banners', [AuthenticationController::class, 'splashBanners']);


Route::group([
    'middleware' => 'api',
    'namespace' => 'App\Http\Controllers'

], function ($router) {

    // Route::post('login', 'AuthController@login');
    // Route::post('logout', 'AuthController@logout');
    // Route::post('refresh', 'AuthController@refresh');
    // Route::post('me', 'AuthController@me');
    Route::post('search', [RestaurantController::class, 'search']);
    Route::post('personalisation', [RestaurantController::class, 'personalisation']);
    Route::post('update-personalisation', [RestaurantController::class, 'updatePersonalisation']);
    Route::post('create-support-request', [MoreController::class, 'createSupportRequest']);
    Route::post('mark-notifications-read', [NotificationController::class, 'markNotificationsRead']);
    Route::post('notifications', [NotificationController::class, 'notifications']);
    Route::post('change-password', [RestaurantController::class, 'changePassword']);
    Route::post('create-booking', [BookingController::class, 'createBooking']);
    Route::post('booking-list', [BookingController::class, 'bookingList']);
    Route::post('user-detail', [RestaurantController::class, 'userDetail']);
    Route::post('update-user-detail', [RestaurantController::class, 'updateUserDetail']);
    Route::post('send-otp', [RestaurantController::class, 'sendOtp']);
    Route::post('resend-otp', [RestaurantController::class, 'resendOtp']);
    Route::post('verify-otp', [RestaurantController::class, 'verifyOtp']);
    Route::post('upload-image', [RestaurantController::class, 'uploadImage']);
    Route::post('filter-list', [RestaurantController::class, 'filterList']);
    Route::post('restaurant-list', [RestaurantController::class, 'restaurantList']);
    Route::post('add-or-remove-wishlist', [RestaurantController::class, 'addOrRemoveWishlist']);
    Route::get('get-wishlist', [RestaurantController::class, 'getWishlist']);
    Route::post('restaurant-detail', [RestaurantController::class, 'restaurantDetail']);
    Route::post('restaurant-floors-data', [RestaurantController::class, 'restaurantFloorsData']);
    Route::post('waiter-floors-data', [RestaurantController::class, 'waiterFloorsData']);
    //kiran
    Route::post('order', [RestaurantController::class,'addOrder'])->name('order');
    Route::post('order_cancel', [AuthenticationController::class,'orderCancel'])->name('order_cancel');
    Route::post('order_reservation', [RestaurantController::class,'orderReservation'])->name('order_reservation');
    Route::post('generate_bill', [AuthenticationController::class,'totalTableBill'])->name('generate_bill');
    Route::post('order_list', [RestaurantController::class,'orderList'])->name('order_list');
    Route::get('notify_waiter', [RestaurantController::class,'notifyWaiter'])->name('notify_waiter');
    Route::post('add_to_cart', [RestaurantController::class,'addToCart'])->name('add_to_cart');
    Route::post('view_cart', [RestaurantController::class,'viewCart'])->name('view_cart');
    Route::post('confirm_order', [AuthenticationController::class,'confirmOrder'])->name('confirm_order');
    Route::post('restaurant-item-list', [AuthenticationController::class, 'categoryProducts']);
    // Route::post('update_cart', [AuthenticationController::class, 'updateCart'])->name('update_cart');
    Route::post('cancel_cart', [AuthenticationController::class, 'cancelCart'])->name('cancel_cart');
});
    // Route::post('restaurant-itm-list', [AuthenticationController::class, 'categoryProducts']);
    Route::post('price', [AuthenticationController::class, 'productPrice']);
    //Tanmay
    Route::post('logout', [AuthenticationController::class, 'logout']);


